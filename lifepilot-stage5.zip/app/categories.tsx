import { ActivityIndicator, View } from 'react-native';
import { useRouter } from 'expo-router';
import { toPersianDigits } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import { useCategoriesWithCounts } from '@/features/categories/hooks/useCategories';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Screen } from '@/shared/components/Screen';

export default function CategoriesScreen() {
  const router = useRouter();
  const { spacing } = useTheme();
  const { items, loading } = useCategoriesWithCounts();

  return (
    <Screen title="دسته‌بندی‌ها" subtitle="برای ویرایش یا حذف، روی دسته بزنید" onBack={() => router.back()}>
      <Button title="دسته‌ی جدید" icon="add" onPress={() => router.push('/category/new')} />
      {loading ? <ActivityIndicator /> : null}
      {items.map((c) => (
        <Card key={c.id} onPress={() => router.push(`/category/${c.id}`)} accessibilityLabel={c.name}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
            <View style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: c.color }} />
            <View style={{ flex: 1 }}>
              <AppText variant="bodyStrong">{c.name}</AppText>
            </View>
            <AppText variant="caption" muted>{toPersianDigits(c.taskCount)} کار</AppText>
          </View>
        </Card>
      ))}
    </Screen>
  );
}
