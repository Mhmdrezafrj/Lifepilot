import Constants from 'expo-constants';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { View } from 'react-native';
import { toPersianDigits } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import { useDbInfo } from '@/providers/DatabaseProvider';
import { AppText } from '@/shared/components/AppText';
import { Card } from '@/shared/components/Card';
import { IconName } from '@/shared/types/icon';
import { Screen } from '@/shared/components/Screen';

function LinkRow({ icon, title, subtitle, onPress }: { icon: IconName; title: string; subtitle: string; onPress: () => void }) {
  const { colors, iconSizes, spacing } = useTheme();
  return (
    <Card onPress={onPress} accessibilityLabel={title}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
        <Ionicons name={icon} size={iconSizes.lg} color={colors.accent} />
        <View style={{ flex: 1 }}>
          <AppText variant="bodyStrong">{title}</AppText>
          <AppText variant="caption" muted>{subtitle}</AppText>
        </View>
      </View>
    </Card>
  );
}

export default function SettingsScreen() {
  const router = useRouter();
  const db = useDbInfo();
  return (
    <Screen title="تنظیمات">
      <LinkRow
        icon="pricetags-outline"
        title="دسته‌بندی‌ها"
        subtitle="ساخت، تغییر نام و رنگ، و حذف دسته‌ها"
        onPress={() => router.push('/categories')}
      />
      <LinkRow
        icon="color-palette-outline"
        title="نمایشگاه طراحی (ابزار توسعه)"
        subtitle="پیش‌نمایش تم، رنگ و کامپوننت‌ها"
        onPress={() => router.push('/design-showcase')}
      />
      <Card variant="outlined">
        <AppText variant="bodyStrong">درباره</AppText>
        <AppText muted>نسخه برنامه: {Constants.expoConfig?.version ?? '—'}</AppText>
        <AppText muted>شناسه بسته: com.lifepilot.personalassistant</AppText>
        <AppText muted>نسخه‌ی ساختار پایگاه داده: {toPersianDigits(db.schemaVersion)}</AppText>
        <AppText muted>دفعات اجرای برنامه: {toPersianDigits(db.launchCount)}</AppText>
      </Card>
      <Card variant="outlined">
        <AppText muted>گزینه‌های ظاهر، اعلان و حریم خصوصی در مرحله ۷ اضافه می‌شوند.</AppText>
      </Card>
    </Screen>
  );
}
