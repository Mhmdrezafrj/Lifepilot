import { useCallback, useMemo, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { useRouter } from 'expo-router';
import { toPersianDigits } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import { useCategories } from '@/features/categories/hooks/useCategories';
import { TaskCard } from '@/features/tasks/components/TaskCard';
import { useToggleTask } from '@/features/tasks/hooks/useToggleTask';
import { useTasks } from '@/features/tasks/hooks/useTasks';
import type { Task } from '@/features/tasks/models/task';
import { groupActiveTasks } from '@/features/tasks/services/taskStatus';
import { AppText } from '@/shared/components/AppText';
import { EmptyState } from '@/shared/components/EmptyState';
import { Fab } from '@/shared/components/Fab';
import { Screen } from '@/shared/components/Screen';
import { SegmentedControl } from '@/shared/components/SegmentedControl';

type Filter = 'active' | 'done';

export default function TasksScreen() {
  const router = useRouter();
  const { spacing } = useTheme();
  const [filter, setFilter] = useState<Filter>('active');
  const { tasks, loading, error } = useTasks({ status: filter === 'active' ? 'pending' : 'completed' });
  const { byId } = useCategories();
  const toggle = useToggleTask();
  const now = Date.now();

  const open = useCallback((t: Task) => router.push(`/task/${t.id}`), [router]);
  const sections = useMemo(() => {
    if (filter === 'done') {
      const sorted = [...tasks].sort((a, b) => (b.completedAt ?? 0) - (a.completedAt ?? 0));
      return [{ key: 'done', title: 'انجام‌شده', items: sorted }];
    }
    const g = groupActiveTasks(tasks, now);
    return [
      { key: 'overdue', title: 'عقب‌افتاده', items: g.overdue },
      { key: 'today', title: 'امروز', items: g.today },
      { key: 'upcoming', title: 'پیش‌رو', items: g.upcoming },
      { key: 'unscheduled', title: 'بدون تاریخ', items: g.unscheduled },
    ].filter((s) => s.items.length > 0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tasks, filter]);

  return (
    <View style={{ flex: 1 }}>
      <Screen title="کارها">
        <SegmentedControl
          options={[
            { value: 'active' as Filter, label: 'فعال' },
            { value: 'done' as Filter, label: 'انجام‌شده' },
          ]}
          value={filter}
          onChange={setFilter}
        />

        {loading ? <ActivityIndicator /> : null}
        {error ? <AppText color="danger">{error}</AppText> : null}

        {!loading && !error && tasks.length === 0 ? (
          filter === 'active' ? (
            <EmptyState
              icon="checkmark-done-outline"
              title="هیچ کار فعالی ندارید"
              description="با دکمه‌ی + اولین کار خود را بسازید."
              actionLabel="افزودن کار"
              onAction={() => router.push('/task/new')}
            />
          ) : (
            <EmptyState icon="archive-outline" title="هنوز کاری را انجام نداده‌اید" />
          )
        ) : null}

        {sections.map((s) => (
          <View key={s.key} style={{ gap: spacing.sm }}>
            <AppText variant="label" color={s.key === 'overdue' ? 'danger' : 'textMuted'}>
              {s.title} ({toPersianDigits(s.items.length)})
            </AppText>
            {s.items.map((t) => (
              <TaskCard
                key={t.id}
                task={t}
                category={t.categoryId ? byId.get(t.categoryId) : undefined}
                now={now}
                onPress={open}
                onToggle={toggle}
              />
            ))}
          </View>
        ))}
        <View style={{ height: 80 }} />
      </Screen>
      <Fab onPress={() => router.push('/task/new')} accessibilityLabel="افزودن کار جدید" />
    </View>
  );
}
