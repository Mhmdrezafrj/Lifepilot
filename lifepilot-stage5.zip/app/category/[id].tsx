import { useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { describeError } from '@/core/errors';
import { categoryPalette } from '@/core/theme/colors';
import { useTheme } from '@/core/theme/useTheme';
import { CategoryDeleteModal } from '@/features/categories/components/CategoryDeleteModal';
import { useCategoryActions } from '@/features/categories/hooks/useCategoryActions';
import { useCategoriesWithCounts } from '@/features/categories/hooks/useCategories';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Chip } from '@/shared/components/Chip';
import { Screen } from '@/shared/components/Screen';
import { TextField } from '@/shared/components/TextField';

function CategoryForm({
  initialName,
  initialColor,
  isNew,
  onSubmit,
  onDelete,
}: {
  initialName: string;
  initialColor: string;
  isNew: boolean;
  onSubmit: (name: string, color: string) => Promise<string | null>;
  onDelete?: () => void;
}) {
  const { colors, spacing, iconSizes } = useTheme();
  const [name, setName] = useState(initialName);
  const [color, setColor] = useState(initialColor);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    setSaving(true);
    setError(null);
    const message = await onSubmit(name, color);
    if (message) {
      setError(message);
      setSaving(false);
    }
  };

  return (
    <View style={{ gap: spacing.lg }}>
      <TextField label="نام دسته" value={name} onChangeText={setName} maxLength={40} autoFocus={isNew} returnKeyType="done" />

      <View style={{ gap: spacing.sm }}>
        <AppText variant="label" muted>رنگ</AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.md }}>
          {categoryPalette.map((c) => (
            <Pressable
              key={c}
              accessibilityRole="button"
              accessibilityLabel={`رنگ ${c}`}
              accessibilityState={{ selected: color === c }}
              onPress={() => setColor(c)}
              style={{
                width: 44,
                height: 44,
                borderRadius: 22,
                backgroundColor: c,
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: color === c ? 3 : 0,
                borderColor: colors.text,
              }}
            >
              {color === c ? <Ionicons name="checkmark" size={iconSizes.lg} color="#FFFFFF" /> : null}
            </Pressable>
          ))}
        </View>
      </View>

      <View style={{ gap: spacing.sm }}>
        <AppText variant="label" muted>پیش‌نمایش</AppText>
        <View style={{ flexDirection: 'row' }}>
          <Chip label={name.trim() || 'نام دسته'} color={color} selected />
        </View>
      </View>

      {error ? <AppText color="danger">{error}</AppText> : null}

      <Button title={isNew ? 'ساخت دسته' : 'ذخیره تغییرات'} size="lg" fullWidth loading={saving} onPress={submit} />
      {onDelete ? <Button title="حذف دسته" variant="ghost" icon="trash-outline" fullWidth onPress={onDelete} /> : null}
    </View>
  );
}

export default function CategoryEditorScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const isNew = id === 'new';
  const router = useRouter();
  const actions = useCategoryActions();
  const { items, loading } = useCategoriesWithCounts();
  const [deleteOpen, setDeleteOpen] = useState(false);

  const current = isNew ? null : items.find((c) => c.id === id) ?? null;

  if (!isNew && loading) {
    return <Screen title="ویرایش دسته" onBack={() => router.back()}><AppText muted>در حال بارگذاری…</AppText></Screen>;
  }
  if (!isNew && !current) {
    return (
      <Screen title="ویرایش دسته" onBack={() => router.back()}>
        <AppText muted>این دسته پیدا نشد (ممکن است حذف شده باشد).</AppText>
      </Screen>
    );
  }

  const save = async (name: string, color: string): Promise<string | null> => {
    try {
      if (current) await actions.update(current.id, { name, color });
      else await actions.create({ name, color });
      router.back();
      return null;
    } catch (e) {
      return describeError(e);
    }
  };

  const remove = async (reassignTo: string | null) => {
    if (!current) return;
    setDeleteOpen(false);
    try {
      await actions.remove(current.id, { reassignTo });
      router.back();
    } catch (e) {
      Alert.alert('خطا', describeError(e));
    }
  };

  const askDelete = () => {
    if (!current) return;
    if (current.taskCount > 0) {
      setDeleteOpen(true);
      return;
    }
    Alert.alert('حذف دسته', `دسته‌ی «${current.name}» حذف شود؟`, [
      { text: 'انصراف', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: () => remove(null) },
    ]);
  };

  return (
    <Screen title={isNew ? 'دسته‌ی جدید' : 'ویرایش دسته'} onBack={() => router.back()}>
      <CategoryForm
        key={current ? current.id : 'new'}
        isNew={isNew}
        initialName={current?.name ?? ''}
        initialColor={current?.color ?? categoryPalette[0]}
        onSubmit={save}
        onDelete={current ? askDelete : undefined}
      />
      {current ? (
        <CategoryDeleteModal
          visible={deleteOpen}
          category={current}
          taskCount={current.taskCount}
          others={items.filter((c) => c.id !== current.id)}
          onConfirm={remove}
          onClose={() => setDeleteOpen(false)}
        />
      ) : null}
    </Screen>
  );
}
