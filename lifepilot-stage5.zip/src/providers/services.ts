import { createCategoryService } from '../features/categories/services/categoryService';
import { createTaskService } from '../features/tasks/services/taskService';
import type { Repositories } from './repositories';

export function createServices(repos: Repositories, options: { now?: () => number } = {}) {
  return {
    tasks: createTaskService(repos.tasks, options),
    categories: createCategoryService(repos.categories),
  };
}

export type Services = ReturnType<typeof createServices>;
