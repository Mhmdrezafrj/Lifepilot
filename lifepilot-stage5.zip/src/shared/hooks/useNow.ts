import { useEffect, useState } from 'react';

/** Current time in ms, refreshed on an interval. Only for refreshing what is displayed (never for alarms). */
export function useNow(intervalMs = 60_000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}
