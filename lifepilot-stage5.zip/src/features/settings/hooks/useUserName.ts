import { useCallback, useEffect, useState } from 'react';
import { useRepositories } from '@/providers/DatabaseProvider';

const KEY = 'user_name';

/** The user's first name for greetings, stored locally in app_settings. */
export function useUserName(): { name: string | null; loaded: boolean; save: (name: string) => Promise<void> } {
  const { settings } = useRepositories();
  const [name, setName] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    settings
      .get(KEY)
      .then((v) => {
        if (!cancelled) {
          setName(v && v.trim() ? v : null);
          setLoaded(true);
        }
      })
      .catch(() => {
        if (!cancelled) setLoaded(true);
      });
    return () => {
      cancelled = true;
    };
  }, [settings]);

  const save = useCallback(
    async (value: string) => {
      const clean = value.trim().slice(0, 40);
      if (clean) await settings.set(KEY, clean);
      else await settings.remove(KEY);
      setName(clean || null);
    },
    [settings],
  );

  return { name, loaded, save };
}
