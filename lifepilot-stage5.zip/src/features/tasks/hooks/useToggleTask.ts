import { useCallback } from 'react';
import { Alert } from 'react-native';
import { describeError } from '@/core/errors';
import type { Task } from '../models/task';
import { useTaskActions } from './useTaskActions';

/** Completes a pending task or reopens a completed one, showing an alert on failure. */
export function useToggleTask(): (task: Task) => Promise<void> {
  const actions = useTaskActions();
  return useCallback(
    async (task: Task) => {
      try {
        if (task.status === 'pending') await actions.complete(task.id);
        else await actions.reopen(task.id);
      } catch (e) {
        Alert.alert('خطا', describeError(e));
      }
    },
    [actions],
  );
}
