import { Modal, Pressable, View } from 'react-native';
import { toPersianDigits } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import type { Category } from '../models/category';

interface Props {
  visible: boolean;
  category: Category;
  taskCount: number;
  /** Other categories the tasks can be moved to. */
  others: Category[];
  onConfirm: (reassignTo: string | null) => void;
  onClose: () => void;
}

/** Asks what should happen to the tasks of a category that is being deleted. Tasks are never deleted. */
export function CategoryDeleteModal({ visible, category, taskCount, others, onConfirm, onClose }: Props) {
  const { colors, radii, spacing } = useTheme();
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable
        style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: 'center', padding: spacing.xl }}
        onPress={onClose}
      >
        <Pressable
          onPress={() => {}}
          style={{ backgroundColor: colors.surface, borderRadius: radii.xl, padding: spacing.lg, gap: spacing.md }}
        >
          <AppText variant="heading">حذف دسته‌ی «{category.name}»</AppText>
          <AppText muted>
            {toPersianDigits(taskCount)} کار در این دسته است. کارها حذف نمی‌شوند؛ انتخاب کنید چه بر سرشان بیاید:
          </AppText>
          <Button
            title="نگه داشتن بدون دسته‌بندی"
            variant="secondary"
            fullWidth
            onPress={() => onConfirm(null)}
          />
          {others.map((o) => (
            <View key={o.id} style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
              <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: o.color }} />
              <View style={{ flex: 1 }}>
                <Button title={`انتقال به «${o.name}»`} variant="ghost" fullWidth onPress={() => onConfirm(o.id)} />
              </View>
            </View>
          ))}
          <Button title="انصراف" variant="ghost" size="sm" onPress={onClose} />
        </Pressable>
      </Pressable>
    </Modal>
  );
}
