import type { DbClient, SqlParam } from '../../../core/database/connection/types';
import { newId } from '../../../core/utils/id';
import type { Category } from '../models/category';
import {
  CreateCategoryInput,
  UpdateCategoryInput,
  createCategoryInputSchema,
  updateCategoryInputSchema,
} from '../validation/categorySchemas';

interface CategoryRow {
  id: string; name: string; color: string; icon: string | null; sort_order: number; created_at: number;
}

const toCategory = (r: CategoryRow): Category => ({
  id: r.id, name: r.name, color: r.color, icon: r.icon, sortOrder: r.sort_order, createdAt: r.created_at,
});

export interface CategoryWithCount extends Category {
  /** Number of tasks (any status) in this category. */
  taskCount: number;
}

export interface CategoryRepository {
  list(): Promise<Category[]>;
  listWithTaskCounts(): Promise<CategoryWithCount[]>;
  getById(id: string): Promise<Category | null>;
  create(input: CreateCategoryInput): Promise<Category>;
  update(id: string, patch: UpdateCategoryInput): Promise<Category | null>;
  /**
   * Deletes a category. Its tasks are moved to `reassignTo` when given,
   * otherwise they become uncategorized. Tasks themselves are never deleted.
   */
  remove(id: string, options?: { reassignTo?: string | null }): Promise<boolean>;
  count(): Promise<number>;
}

export function createCategoryRepository(db: DbClient, options: { now?: () => number } = {}): CategoryRepository {
  const now = options.now ?? (() => Date.now());

  async function getById(id: string): Promise<Category | null> {
    const row = await db.getFirstAsync<CategoryRow>('SELECT * FROM categories WHERE id = ?', [id]);
    return row ? toCategory(row) : null;
  }

  async function list(): Promise<Category[]> {
    const rows = await db.getAllAsync<CategoryRow>('SELECT * FROM categories ORDER BY sort_order, created_at, name');
    return rows.map(toCategory);
  }

  async function listWithTaskCounts(): Promise<CategoryWithCount[]> {
    const rows = await db.getAllAsync<CategoryRow & { task_count: number }>(
      `SELECT c.*, (SELECT COUNT(*) FROM tasks t WHERE t.category_id = c.id) AS task_count
       FROM categories c ORDER BY c.sort_order, c.created_at, c.name`);
    return rows.map((r) => ({ ...toCategory(r), taskCount: r.task_count }));
  }

  async function create(raw: CreateCategoryInput): Promise<Category> {
    const input = createCategoryInputSchema.parse(raw);
    const id = newId();
    const max = await db.getFirstAsync<{ m: number | null }>('SELECT MAX(sort_order) AS m FROM categories');
    await db.runAsync(
      'INSERT INTO categories (id, name, color, icon, sort_order, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      [id, input.name, input.color, input.icon ?? null, (max?.m ?? -1) + 1, now()],
    );
    const created = await getById(id);
    if (!created) throw new Error('Category was not saved');
    return created;
  }

  async function update(id: string, raw: UpdateCategoryInput): Promise<Category | null> {
    const p = updateCategoryInputSchema.parse(raw);
    const sets: string[] = [];
    const params: SqlParam[] = [];
    if (p.name !== undefined) { sets.push('name = ?'); params.push(p.name); }
    if (p.color !== undefined) { sets.push('color = ?'); params.push(p.color); }
    if (p.icon !== undefined) { sets.push('icon = ?'); params.push(p.icon); }
    if (sets.length) {
      params.push(id);
      await db.runAsync(`UPDATE categories SET ${sets.join(', ')} WHERE id = ?`, params);
    }
    return getById(id);
  }

  async function remove(id: string, opts: { reassignTo?: string | null } = {}): Promise<boolean> {
    if (opts.reassignTo === id) throw new Error('Cannot reassign tasks to the category being deleted');
    const existing = await getById(id);
    if (!existing) return false;
    await db.withTransactionAsync(async () => {
      await db.runAsync('UPDATE tasks SET category_id = ? WHERE category_id = ?', [opts.reassignTo ?? null, id]);
      await db.runAsync('DELETE FROM categories WHERE id = ?', [id]);
    });
    return true;
  }

  async function count(): Promise<number> {
    const row = await db.getFirstAsync<{ n: number }>('SELECT COUNT(*) AS n FROM categories');
    return row?.n ?? 0;
  }

  return { list, listWithTaskCounts, getById, create, update, remove, count };
}
