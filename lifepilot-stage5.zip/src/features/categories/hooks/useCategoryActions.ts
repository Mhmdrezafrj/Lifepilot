import { useMemo } from 'react';
import { useServices } from '@/providers/DatabaseProvider';
import { useDataStore } from '@/shared/state/dataStore';
import type { CategoryService } from '../services/categoryService';

/** CategoryService whose changes refresh every screen showing categories or tasks. */
export function useCategoryActions(): CategoryService {
  const { categories } = useServices();
  const bump = useDataStore((s) => s.bump);
  return useMemo<CategoryService>(() => {
    const wrap =
      <A extends unknown[], R>(fn: (...a: A) => Promise<R>) =>
      async (...a: A): Promise<R> => {
        try {
          return await fn(...a);
        } finally {
          bump(); // tasks may have moved between categories, so tasks screens reload too
        }
      };
    return {
      create: wrap(categories.create),
      update: wrap(categories.update),
      remove: wrap(categories.remove),
    };
  }, [categories, bump]);
}
