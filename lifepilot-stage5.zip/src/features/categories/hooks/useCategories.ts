import { useEffect, useMemo, useState } from 'react';
import { useRepositories } from '@/providers/DatabaseProvider';
import { useDataStore } from '@/shared/state/dataStore';
import type { Category } from '../models/category';
import type { CategoryWithCount } from '../repositories/categoryRepository';

export function useCategories(): { categories: Category[]; byId: Map<string, Category>; loading: boolean } {
  const { categories: repo } = useRepositories();
  const version = useDataStore((s) => s.version);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    repo
      .list()
      .then((list) => {
        if (!cancelled) {
          setCategories(list);
          setLoading(false);
        }
      })
      .catch(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [repo, version]);

  const byId = useMemo(() => new Map(categories.map((c) => [c.id, c])), [categories]);
  return { categories, byId, loading };
}

/** Categories with the number of tasks in each (used by the category manager). */
export function useCategoriesWithCounts(): { items: CategoryWithCount[]; loading: boolean } {
  const { categories: repo } = useRepositories();
  const version = useDataStore((s) => s.version);
  const [items, setItems] = useState<CategoryWithCount[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    repo
      .listWithTaskCounts()
      .then((list) => {
        if (!cancelled) {
          setItems(list);
          setLoading(false);
        }
      })
      .catch(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [repo, version]);

  return { items, loading };
}
