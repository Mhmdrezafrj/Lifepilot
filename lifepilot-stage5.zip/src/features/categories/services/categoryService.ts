import { InvalidOperationError, NotFoundError } from '../../../core/errors';
import type { Category } from '../models/category';
import type { CategoryRepository } from '../repositories/categoryRepository';
import type { CreateCategoryInput, UpdateCategoryInput } from '../validation/categorySchemas';

export interface CategoryService {
  create(input: CreateCategoryInput): Promise<Category>;
  update(id: string, patch: UpdateCategoryInput): Promise<Category>;
  /**
   * Deletes a category without deleting its tasks: they move to `reassignTo`,
   * or become uncategorized when it is omitted/null.
   */
  remove(id: string, options?: { reassignTo?: string | null }): Promise<void>;
}

const DUPLICATE = 'دسته‌ای با این نام وجود دارد';
const norm = (s: string) => s.trim().toLocaleLowerCase();

export function createCategoryService(repo: CategoryRepository): CategoryService {
  async function assertNameFree(name: string, exceptId?: string): Promise<void> {
    const all = await repo.list();
    if (all.some((c) => c.id !== exceptId && norm(c.name) === norm(name))) {
      throw new InvalidOperationError(DUPLICATE);
    }
  }

  return {
    async create(input) {
      if (typeof input.name === 'string' && input.name.trim() !== '') await assertNameFree(input.name);
      return repo.create(input);
    },

    async update(id, patch) {
      const existing = await repo.getById(id);
      if (!existing) throw new NotFoundError('دسته');
      if (typeof patch.name === 'string' && patch.name.trim() !== '') await assertNameFree(patch.name, id);
      const updated = await repo.update(id, patch);
      if (!updated) throw new NotFoundError('دسته');
      return updated;
    },

    async remove(id, options = {}) {
      if (!(await repo.getById(id))) throw new NotFoundError('دسته');
      const target = options.reassignTo ?? null;
      if (target !== null) {
        if (target === id) throw new InvalidOperationError('کارها را نمی‌توان به همان دسته منتقل کرد');
        if (!(await repo.getById(target))) throw new NotFoundError('دسته‌ی مقصد');
      }
      await repo.remove(id, { reassignTo: target });
    },
  };
}
