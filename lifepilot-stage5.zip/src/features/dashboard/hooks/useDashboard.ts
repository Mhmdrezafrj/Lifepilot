import { useMemo } from 'react';
import { addDays, startOfDay } from '@/core/calendar/dates';
import { useTasks } from '@/features/tasks/hooks/useTasks';
import { useNow } from '@/shared/hooks/useNow';
import { computeDashboardStats, pickNextTask, sortTimeline } from '../services/dashboardStats';

/** Everything the home screen shows, derived from the real database. */
export function useDashboard() {
  const now = useNow();
  const todayStart = startOfDay(new Date(now));
  const today = useTasks({ dueFrom: todayStart.getTime(), dueTo: addDays(todayStart, 1).getTime() });
  const pending = useTasks({ status: 'pending' });

  const stats = useMemo(
    () => computeDashboardStats(today.tasks, pending.tasks, now),
    [today.tasks, pending.tasks, now],
  );
  const next = useMemo(() => pickNextTask(pending.tasks, now), [pending.tasks, now]);
  const timeline = useMemo(() => sortTimeline(today.tasks), [today.tasks]);

  return {
    now,
    stats,
    next,
    timeline,
    loading: today.loading || pending.loading,
    error: today.error ?? pending.error,
    hasPendingTasks: pending.tasks.length > 0,
  };
}
