import { View } from 'react-native';
import { formatTime } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import type { Category } from '@/features/categories/models/category';
import { TaskCard } from '@/features/tasks/components/TaskCard';
import type { Task } from '@/features/tasks/models/task';
import { AppText } from '@/shared/components/AppText';

interface Props {
  tasks: Task[];
  categories: Map<string, Category>;
  now: number;
  onPress: (task: Task) => void;
  onToggle: (task: Task) => void;
}

/** Vertical timeline of today's tasks: time label, a dot on a line, then the task card. */
export function TodayTimeline({ tasks, categories, now, onPress, onToggle }: Props) {
  const { colors, spacing } = useTheme();
  return (
    <View>
      {tasks.map((t, i) => {
        const last = i === tasks.length - 1;
        const dot = t.status === 'completed' ? colors.accent : colors.priority[t.priority];
        return (
          <View key={t.id} style={{ flexDirection: 'row', gap: spacing.md }}>
            <View style={{ width: 52, paddingTop: spacing.lg }}>
              <AppText variant="caption" muted>
                {t.hasTime && t.dueAt !== null ? formatTime(new Date(t.dueAt)) : 'همه‌روز'}
              </AppText>
            </View>
            <View style={{ alignItems: 'center', width: 12 }}>
              <View style={{ width: 12, height: 12, borderRadius: 6, marginTop: spacing.lg + 6, backgroundColor: dot }} />
              {!last ? <View style={{ flex: 1, width: 2, backgroundColor: colors.border }} /> : null}
            </View>
            <View style={{ flex: 1, paddingBottom: spacing.md }}>
              <TaskCard
                task={t}
                category={t.categoryId ? categories.get(t.categoryId) : undefined}
                now={now}
                onPress={onPress}
                onToggle={onToggle}
              />
            </View>
          </View>
        );
      })}
    </View>
  );
}
