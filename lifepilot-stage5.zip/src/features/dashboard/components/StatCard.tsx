import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { toPersianDigits } from '@/core/calendar/format';
import { withAlpha } from '@/core/theme/colors';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from '@/shared/components/AppText';
import { Card } from '@/shared/components/Card';
import { IconName } from '@/shared/types/icon';

interface Props {
  label: string;
  value: number;
  icon: IconName;
  /** Accent color for the icon; defaults to the theme accent. */
  color?: string;
  onPress?: () => void;
}

export function StatCard({ label, value, icon, color, onPress }: Props) {
  const { colors, spacing, radii, iconSizes } = useTheme();
  const c = color ?? colors.accent;
  return (
    <Card onPress={onPress} accessibilityLabel={`${label}: ${toPersianDigits(value)}`} style={{ flex: 1, gap: spacing.xs }}>
      <View
        style={{
          width: 36,
          height: 36,
          borderRadius: radii.md,
          backgroundColor: withAlpha(c, 0.16),
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Ionicons name={icon} size={iconSizes.md} color={c} />
      </View>
      <AppText variant="title">{toPersianDigits(value)}</AppText>
      <AppText variant="caption" muted>{label}</AppText>
    </Card>
  );
}
