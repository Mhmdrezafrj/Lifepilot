import { addDays, startOfDay } from '../../../core/calendar/dates';
import { Task, comparePriorityDesc } from '../../tasks/models/task';
import { isOverdue } from '../../tasks/services/taskStatus';

export interface DashboardStats {
  /** Tasks whose due date is today (any status). */
  todayTotal: number;
  completedToday: number;
  /** Today's tasks that are still pending. */
  remainingToday: number;
  /** All pending tasks that are overdue, from any day. */
  overdue: number;
}

function dayRange(now: number): { start: number; end: number } {
  const start = startOfDay(new Date(now));
  return { start: start.getTime(), end: addDays(start, 1).getTime() };
}

export function computeDashboardStats(todayTasks: Task[], pendingTasks: Task[], now: number): DashboardStats {
  const { start, end } = dayRange(now);
  const today = todayTasks.filter((t) => t.dueAt !== null && t.dueAt >= start && t.dueAt < end);
  const completedToday = today.filter((t) => t.status === 'completed').length;
  return {
    todayTotal: today.length,
    completedToday,
    remainingToday: today.length - completedToday,
    overdue: pendingTasks.filter((t) => isOverdue(t, now)).length,
  };
}

/**
 * The next pending task that is not overdue. A date-only task counts from "now"
 * on its day (it can be done any time that day).
 */
export function pickNextTask(pendingTasks: Task[], now: number): Task | null {
  let best: Task | null = null;
  let bestKey = Infinity;
  for (const t of pendingTasks) {
    if (t.status !== 'pending' || t.dueAt === null || isOverdue(t, now)) continue;
    const key = Math.max(t.dueAt, now);
    if (key < bestKey || (key === bestKey && best !== null && comparePriorityDesc(t.priority, best.priority) < 0)) {
      best = t;
      bestKey = key;
    }
  }
  return best;
}

/** Today's tasks in display order: all-day tasks first, then by time, then by priority. */
export function sortTimeline(todayTasks: Task[]): Task[] {
  return [...todayTasks].sort((a, b) => {
    if (a.hasTime !== b.hasTime) return a.hasTime ? 1 : -1;
    if (a.hasTime && b.hasTime && a.dueAt !== b.dueAt) return (a.dueAt ?? 0) - (b.dueAt ?? 0);
    const p = comparePriorityDesc(a.priority, b.priority);
    return p !== 0 ? p : a.createdAt - b.createdAt;
  });
}

export function greetingForHour(hour: number): string {
  if (hour >= 5 && hour < 12) return 'صبح بخیر';
  if (hour >= 12 && hour < 16) return 'روز بخیر';
  if (hour >= 16 && hour < 20) return 'عصر بخیر';
  return 'شب بخیر';
}
