import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createNodeClient } from '../helpers/nodeClient';
import { migrate, migrations } from '../../src/core/database/migrations';
import { createRepositories } from '../../src/providers/repositories';
import { createServices } from '../../src/providers/services';
import { InvalidOperationError, NotFoundError } from '../../src/core/errors';

async function setup() {
  const db = createNodeClient();
  await migrate(db, migrations);
  const repos = createRepositories(db);
  return { repos, ...createServices(repos) };
}

describe('category service', () => {
  it('creates a category and rejects duplicate names (ignoring spaces and case)', async () => {
    const { categories } = await setup();
    const c = await categories.create({ name: ' ورزش ', color: '#112233' });
    assert.equal(c.name, 'ورزش');
    await assert.rejects(() => categories.create({ name: 'ورزش', color: '#445566' }), InvalidOperationError);
    await assert.rejects(() => categories.create({ name: 'کار', color: '#445566' }), InvalidOperationError); // default category
  });

  it('renames and recolors, allowing the unchanged name', async () => {
    const { categories } = await setup();
    const c = await categories.create({ name: 'a', color: '#112233' });
    const u = await categories.update(c.id, { name: 'a', color: '#445566' });
    assert.equal(u.color, '#445566');
    const r = await categories.update(c.id, { name: 'b' });
    assert.equal(r.name, 'b');
    await assert.rejects(() => categories.update(c.id, { name: 'سلامت' }), InvalidOperationError);
    await assert.rejects(() => categories.update('nope', { name: 'x' }), NotFoundError);
  });

  it('deletes a category and leaves its tasks uncategorized', async () => {
    const { categories, tasks, repos } = await setup();
    const c = await categories.create({ name: 'x', color: '#112233' });
    const t = await tasks.create({ title: 't', categoryId: c.id });
    await categories.remove(c.id);
    assert.equal(await repos.categories.getById(c.id), null);
    assert.equal((await repos.tasks.getById(t.id))?.categoryId, null);
  });

  it('moves tasks to another category when deleting', async () => {
    const { categories, tasks, repos } = await setup();
    const c = await categories.create({ name: 'x', color: '#112233' });
    const t = await tasks.create({ title: 't', categoryId: c.id });
    await categories.remove(c.id, { reassignTo: 'cat_other' });
    assert.equal((await repos.tasks.getById(t.id))?.categoryId, 'cat_other');
  });

  it('refuses bad delete targets and missing categories', async () => {
    const { categories } = await setup();
    await assert.rejects(() => categories.remove('cat_work', { reassignTo: 'cat_work' }), InvalidOperationError);
    await assert.rejects(() => categories.remove('cat_work', { reassignTo: 'missing' }), NotFoundError);
    await assert.rejects(() => categories.remove('missing'), NotFoundError);
  });

  it('never deletes tasks when a category is removed', async () => {
    const { categories, tasks, repos } = await setup();
    await tasks.create({ title: '1', categoryId: 'cat_work' });
    await tasks.create({ title: '2', categoryId: 'cat_work' });
    await categories.remove('cat_work');
    assert.equal(await repos.tasks.count(), 2);
  });
});

describe('category task counts', () => {
  it('counts tasks of any status per category', async () => {
    const { tasks, repos } = await setup();
    const a = await tasks.create({ title: 'a', categoryId: 'cat_work' });
    await tasks.create({ title: 'b', categoryId: 'cat_work' });
    await tasks.create({ title: 'c', categoryId: 'cat_health' });
    await tasks.complete(a.id);
    const list = await repos.categories.listWithTaskCounts();
    const by = new Map(list.map((c) => [c.id, c.taskCount]));
    assert.equal(by.get('cat_work'), 2);
    assert.equal(by.get('cat_health'), 1);
    assert.equal(by.get('cat_study'), 0);
    assert.equal(list.length, 7);
  });
});
