import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { Task } from '../../src/features/tasks/models/task';
import {
  computeDashboardStats, greetingForHour, pickNextTask, sortTimeline,
} from '../../src/features/dashboard/services/dashboardStats';

const now = new Date(2026, 10, 5, 12, 0).getTime();
const at = (d: number, h = 0, m = 0) => new Date(2026, 10, d, h, m).getTime();
const t = (over: Partial<Task>): Task => ({
  id: 'x', title: 'x', description: null, dueAt: null, hasTime: false, priority: 'medium', categoryId: null,
  status: 'pending', snoozedUntil: null, createdAt: 0, updatedAt: 0, completedAt: null, recurrenceId: null,
  tags: [], checklist: [], reminders: [], recurrence: null, ...over,
});

describe('dashboard statistics', () => {
  it('is all zeros when there are no tasks', () => {
    assert.deepEqual(computeDashboardStats([], [], now), { todayTotal: 0, completedToday: 0, remainingToday: 0, overdue: 0 });
  });

  it("counts today's, completed, remaining and overdue tasks", () => {
    const todayTasks = [
      t({ id: '1', dueAt: at(5, 9), hasTime: true, status: 'completed' }),
      t({ id: '2', dueAt: at(5, 18), hasTime: true }),
      t({ id: '3', dueAt: at(5) }),
      t({ id: '4', dueAt: at(5, 8), hasTime: true }), // earlier today, still pending -> overdue too
    ];
    const pending = [
      todayTasks[1], todayTasks[2], todayTasks[3],
      t({ id: '5', dueAt: at(1, 9), hasTime: true }), // overdue from earlier days
      t({ id: '6', dueAt: at(9) }),
      t({ id: '7' }),
    ];
    assert.deepEqual(computeDashboardStats(todayTasks, pending, now), {
      todayTotal: 4, completedToday: 1, remainingToday: 3, overdue: 2,
    });
  });

  it('ignores tasks outside today even if they were passed in', () => {
    const s = computeDashboardStats([t({ dueAt: at(6, 9), hasTime: true })], [], now);
    assert.equal(s.todayTotal, 0);
  });

  it('date-only tasks from today are not overdue yet', () => {
    assert.equal(computeDashboardStats([], [t({ dueAt: at(5) })], now).overdue, 0);
    assert.equal(computeDashboardStats([], [t({ dueAt: at(4) })], now).overdue, 1);
  });
});

describe('next task', () => {
  it('returns null when nothing is scheduled ahead', () => {
    assert.equal(pickNextTask([], now), null);
    assert.equal(pickNextTask([t({}), t({ dueAt: at(1, 9), hasTime: true })], now), null);
  });

  it('picks the earliest upcoming timed task and skips overdue/completed ones', () => {
    const tasks = [
      t({ id: 'late', dueAt: at(5, 20), hasTime: true }),
      t({ id: 'soon', dueAt: at(5, 14), hasTime: true }),
      t({ id: 'past', dueAt: at(5, 9), hasTime: true }),
      t({ id: 'done', dueAt: at(5, 13), hasTime: true, status: 'completed' }),
    ];
    assert.equal(pickNextTask(tasks, now)?.id, 'soon');
  });

  it("a date-only task due today counts as 'now' and comes before later timed tasks", () => {
    const tasks = [t({ id: 'timed', dueAt: at(5, 14), hasTime: true }), t({ id: 'allday', dueAt: at(5) })];
    assert.equal(pickNextTask(tasks, now)?.id, 'allday');
  });

  it('breaks ties by priority', () => {
    const tasks = [
      t({ id: 'low', dueAt: at(5, 14), hasTime: true, priority: 'low' }),
      t({ id: 'crit', dueAt: at(5, 14), hasTime: true, priority: 'critical' }),
    ];
    assert.equal(pickNextTask(tasks, now)?.id, 'crit');
  });
});

describe('timeline order and greeting', () => {
  it('lists all-day tasks first, then timed tasks by time', () => {
    const list = sortTimeline([
      t({ id: 'b', dueAt: at(5, 18), hasTime: true }),
      t({ id: 'a', dueAt: at(5, 9), hasTime: true }),
      t({ id: 'z', dueAt: at(5), priority: 'low' }),
      t({ id: 'y', dueAt: at(5), priority: 'high' }),
    ]);
    assert.deepEqual(list.map((x) => x.id), ['y', 'z', 'a', 'b']);
  });

  it('greets by time of day', () => {
    assert.equal(greetingForHour(7), 'صبح بخیر');
    assert.equal(greetingForHour(13), 'روز بخیر');
    assert.equal(greetingForHour(17), 'عصر بخیر');
    assert.equal(greetingForHour(22), 'شب بخیر');
    assert.equal(greetingForHour(2), 'شب بخیر');
  });
});
