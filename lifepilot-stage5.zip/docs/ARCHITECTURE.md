# LifePilot architecture notes

## Data layer (stage 3)
- SQLite is the single source of truth; the app works fully offline.
- `DbClient` (src/core/database/connection/types.ts) is a tiny async interface.
  expo-sqlite implements it in the app, node:sqlite implements it in tests, so the
  same SQL and repositories are tested without a phone.
- Schema changes are migrations (src/core/database/migrations), versioned with
  `PRAGMA user_version`. Each migration runs in a transaction. Never edit an old
  migration after release; add a new one.
- UI code never writes SQL. Screens use repositories/services through hooks.
- All timestamps are UTC epoch milliseconds. "Overdue" is derived from `due_at`,
  not stored, and overdue tasks are never deleted automatically.
- IDs are random UUIDs (strings). Booleans are stored as 0/1.
- Input is validated with Zod inside the repositories, so invalid data cannot reach the DB.
- Tables `reminder_events` and `behavior_events` exist for later phases and are not written yet.

## Task management (stage 4)
- `taskService` (src/features/tasks/services) owns the rules: complete / reopen /
  snooze / reschedule / duplicate / delete. Status is stored as `pending` or `completed` only.
- Recurring tasks: completing one creates the next occurrence as a new task
  (details copied, checklist reset). Occurrences already in the past are skipped.
  `maxOccurrences` counts down on each generated task; `endsAt` stops the series.
  Monthly and yearly rules use the Jalali calendar (day is clamped to the month length).
- A task with a recurrence must have a date.
- Jalali calendar code lives in src/core/calendar (33-year leap rule, cross-checked
  against ICU for years 1300-1500 in tests). No external calendar dependency.
- After every successful change `useTaskActions()` bumps a tiny zustand store
  (`useDataStore.version`); `useTasks()` / `useCategories()` reload when it changes.
- Reminders are stored with tasks but nothing is delivered yet (notification phase).

## Dashboard and categories (stage 5)
- Dashboard numbers come from pure functions in `features/dashboard/services/dashboardStats.ts`
  (unit-tested): today = tasks due today (any status); remaining = pending among them;
  overdue = all pending overdue tasks from any day.
- "Next task" = earliest pending, non-overdue task; a date-only task due today counts from "now".
- The greeting name is stored locally in `app_settings` (`user_name`).
- Deleting a category never deletes tasks: they move to another category or become uncategorized.
  Category names must be unique (case/space-insensitive).

## Folder note
Routes live in the root `app/` folder (Expo Router). Do not create `src/app/`, it would conflict.
