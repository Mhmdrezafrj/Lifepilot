# Quick capture, inbox, minimal home (stage 17)
- The home screen: three full-width soft cards (today / overdue / remaining), a calm task list without borders, one floating button (quick capture).
- Quick capture: type, or hold the microphone and speak. Text is parsed locally (no internet, no AI) by `nlParser.ts`:
  "فردا ساعت ۵ دکتر" -> tomorrow 17:00; "۲ ساعت دیگه زنگ بزنم"; "شنبه خرید" (date only); "امشب" = 20:00.
  Rules: "ساعت 1..6" without a period word = afternoon; "7..11" = morning; a time already past today moves to tomorrow.
- Text without a date goes to the inbox (a pending task with no date and the tag "صندوق ورودی"). Inbox screen: today / tomorrow / plan / delete.
- Limits: simple phrases only; speech recognition for Persian may need internet (see voice notes).
