import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { parseQuickText } from '../../src/features/capture/services/nlParser';
import { INBOX_TAG, isInboxTask } from '../../src/features/capture/services/inbox';

const NOW = new Date(2026, 10, 5, 12, 0).getTime(); // Thursday
const at = (d: number, h = 0, m = 0) => new Date(2026, 10, d, h, m).getTime();
const p = (t: string) => parseQuickText(t, NOW);

describe('quick text parser', () => {
  it('tomorrow at 5 means 17:00 and the filler words are removed', () => {
    assert.deepEqual(p('فردا ساعت ۵ باید برم دکتر'), { title: 'برم دکتر', dueAt: at(6, 17), hasTime: true });
  });

  it('understands the day after tomorrow with a morning hour', () => {
    assert.deepEqual(p('پس‌فردا ساعت ۹ صبح جلسه'), { title: 'جلسه', dueAt: at(7, 9), hasTime: true });
  });

  it('understands "N hours later" and "N minutes later"', () => {
    const a = p('۲ ساعت دیگه به مامانم زنگ بزنم');
    assert.equal(a.dueAt, NOW + 2 * 3_600_000);
    assert.equal(a.hasTime, true);
    assert.equal(a.title, 'به مامانم زنگ بزنم');
    assert.equal(p('30 دقیقه بعد چای').dueAt, NOW + 30 * 60_000);
  });

  it('a weekday gives a date-only task on its next occurrence', () => {
    assert.deepEqual(p('شنبه خرید'), { title: 'خرید', dueAt: at(7), hasTime: false });
    assert.equal(p('پنجشنبه آینده کتاب').dueAt, at(12)); // today is Thursday -> next week
    assert.equal(p('دوشنبه تمیز کردن').dueAt, at(9));
    assert.equal(p('جمعه دوستان').dueAt, at(6));
  });

  it('a time without a day is today, or tomorrow if it already passed', () => {
    assert.equal(p('ساعت ۸ شب قرص').dueAt, at(5, 20));
    assert.equal(p('ساعت ۹ صبح ورزش').dueAt, at(6, 9));
    assert.equal(p('ساعت 15:30 تماس').dueAt, at(5, 15, 30));
  });

  it('understands half, quarter and extra minutes', () => {
    assert.equal(p('فردا ساعت ۵ و نیم عصر مطب').dueAt, at(6, 17, 30));
    assert.equal(p('فردا ساعت ۴ و ربع کلاس').dueAt, at(6, 16, 15));
    assert.equal(p('فردا ساعت ۱۰ و ۲۰ دقیقه جلسه').dueAt, at(6, 10, 20));
  });

  it('knows tonight, today and next week', () => {
    assert.equal(p('امشب فیلم').dueAt, at(5, 20));
    assert.deepEqual(p('امروز ایمیل'), { title: 'ایمیل', dueAt: at(5), hasTime: false });
    assert.equal(p('هفته بعد دندانپزشک').dueAt, at(12));
  });

  it('handles Persian and Arabic digits and noon', () => {
    assert.equal(p('فردا ساعت ٦ عصر').dueAt, at(6, 18));
    assert.equal(p('فردا ساعت ۱۲ ظهر ناهار').dueAt, at(6, 12));
    assert.equal(p('فردا ساعت ۱۱ شب').dueAt, at(6, 23));
  });

  it('text without a date stays undated, and an empty title falls back to the original', () => {
    assert.deepEqual(p('ایده‌ی یک اپ جدید'), { title: 'ایده‌ی یک اپ جدید'.replace('\u200c', ' ').replace(/\s+/g, ' '), dueAt: null, hasTime: false });
    assert.equal(p('فردا').title, 'فردا');
    assert.equal(p('فردا').dueAt, at(6));
  });

  it('ignores impossible clock times', () => {
    assert.equal(p('ساعت ۲۵ کار').dueAt, null);
  });
});

describe('inbox', () => {
  it('is a pending, undated task with the inbox tag', () => {
    assert.equal(isInboxTask({ status: 'pending', dueAt: null, tags: [INBOX_TAG] }), true);
    assert.equal(isInboxTask({ status: 'pending', dueAt: 5, tags: [INBOX_TAG] }), false);
    assert.equal(isInboxTask({ status: 'completed', dueAt: null, tags: [INBOX_TAG] }), false);
    assert.equal(isInboxTask({ status: 'pending', dueAt: null, tags: [] }), false);
  });
});
