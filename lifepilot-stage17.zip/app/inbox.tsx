import { Alert, View } from 'react-native';
import { useRouter } from 'expo-router';
import { addDays, startOfDay } from '@/core/calendar/dates';
import { toPersianDigits } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { useTheme } from '@/core/theme/useTheme';
import { INBOX_TAG, isInboxTask } from '@/features/capture/services/inbox';
import { useTaskActions } from '@/features/tasks/hooks/useTaskActions';
import { useTasks } from '@/features/tasks/hooks/useTasks';
import type { Task } from '@/features/tasks/models/task';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { EmptyState } from '@/shared/components/EmptyState';
import { Screen } from '@/shared/components/Screen';

export default function InboxScreen() {
  const router = useRouter();
  const { spacing } = useTheme();
  const { tasks, loading } = useTasks({ status: 'pending' });
  const actions = useTaskActions();
  const inbox = tasks.filter(isInboxTask);
  const fail = (e: unknown) => Alert.alert('خطا', describeError(e));

  const schedule = (t: Task, days: number) =>
    actions
      .update(t.id, {
        dueAt: addDays(startOfDay(new Date()), days).getTime(),
        hasTime: false,
        tags: t.tags.filter((x) => x !== INBOX_TAG),
      })
      .catch(fail);

  return (
    <Screen title="صندوق ورودی" subtitle={`${toPersianDigits(inbox.length)} مورد برای برنامه‌ریزی`} onBack={() => router.back()}>
      {!loading && inbox.length === 0 ? (
        <EmptyState icon="file-tray-outline" title="صندوق ورودی خالی است" description="هرچه با «ثبت سریع» بدون تاریخ بنویسی اینجا جمع می‌شود." />
      ) : null}
      {inbox.map((t) => (
        <Card key={t.id} variant="outlined" style={{ gap: spacing.md }}>
          <AppText variant="bodyStrong">{t.title}</AppText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            <Button title="امروز" size="sm" variant="secondary" onPress={() => void schedule(t, 0)} />
            <Button title="فردا" size="sm" variant="secondary" onPress={() => void schedule(t, 1)} />
            <Button title="برنامه‌ریزی" size="sm" icon="calendar-outline" onPress={() => router.push(`/task/${t.id}`)} />
            <Button
              title="حذف"
              size="sm"
              variant="ghost"
              onPress={() =>
                Alert.alert('حذف', `«${t.title}» حذف شود؟`, [
                  { text: 'انصراف', style: 'cancel' },
                  { text: 'حذف', style: 'destructive', onPress: () => actions.delete(t.id).catch(fail) },
                ])
              }
            />
          </View>
        </Card>
      ))}
    </Screen>
  );
}
