import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { formatJalaliDate, toPersianDigits } from '@/core/calendar/format';
import { withAlpha } from '@/core/theme/colors';
import { useTheme } from '@/core/theme/useTheme';
import { INBOX_TAG } from '@/features/capture/services/inbox';
import { QuickCapture } from '@/features/capture/components/QuickCapture';
import { useDashboard } from '@/features/dashboard/hooks/useDashboard';
import { greetingForHour } from '@/features/dashboard/services/dashboardStats';
import { useUserName } from '@/features/settings/hooks/useUserName';
import { SimpleTaskRow } from '@/features/tasks/components/SimpleTaskRow';
import { useTasks } from '@/features/tasks/hooks/useTasks';
import { useToggleTask } from '@/features/tasks/hooks/useToggleTask';
import type { Task } from '@/features/tasks/models/task';
import { AppText } from '@/shared/components/AppText';
import { Screen } from '@/shared/components/Screen';

function BigCard({ label, value, tint, onPress }: { label: string; value: number; tint: string; onPress: () => void }) {
  const { colors, spacing, radii } = useTheme();
  return (
    <View
      accessibilityRole="button"
      accessibilityLabel={`${label}: ${toPersianDigits(value)}`}
      onTouchEnd={onPress}
      style={{
        width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        paddingVertical: spacing.xl, paddingHorizontal: spacing.xl, borderRadius: radii.xl, backgroundColor: withAlpha(tint, 0.14),
      }}
    >
      <AppText variant="heading" style={{ color: colors.text }}>{label}</AppText>
      <AppText variant="display" style={{ color: tint }}>{toPersianDigits(value)}</AppText>
    </View>
  );
}

export default function HomeScreen() {
  const router = useRouter();
  const { colors, spacing } = useTheme();
  const { now, stats, timeline, loading } = useDashboard();
  const toggle = useToggleTask();
  const { name } = useUserName();
  const { tasks: pending } = useTasks({ status: 'pending' });
  const inbox = pending.filter((t) => t.dueAt === null && t.tags.includes(INBOX_TAG)).length;

  const open = (t: Task) => router.push(`/task/${t.id}`);
  const nowDate = new Date(now);
  const greeting = `${greetingForHour(nowDate.getHours())}${name ? `، ${name}` : ''}`;

  return (
    <View style={{ flex: 1 }}>
      <Screen title={greeting} subtitle={formatJalaliDate(nowDate, { weekday: true })}>
        <View style={{ gap: spacing.md }}>
          <BigCard label="کارهای امروز" value={stats.todayTotal} tint={colors.accent} onPress={() => router.push('/(tabs)/tasks')} />
          <BigCard label="عقب‌افتاده" value={stats.overdue} tint={colors.warning} onPress={() => router.push('/(tabs)/tasks')} />
          <BigCard label="باقی‌مانده" value={stats.remainingToday} tint={colors.success} onPress={() => router.push('/(tabs)/tasks')} />
        </View>

        <View style={{ marginTop: spacing.lg }}>
          {timeline.length === 0 ? (
            <AppText muted style={{ textAlign: 'center', paddingVertical: spacing.xxl }}>
              {loading ? '' : 'برای امروز کاری نیست ✨'}
            </AppText>
          ) : (
            timeline.map((t) => <SimpleTaskRow key={t.id} task={t} onPress={open} onToggle={toggle} />)
          )}
        </View>

        {inbox > 0 ? (
          <AppText color="accent" variant="bodyStrong" style={{ textAlign: 'center', paddingVertical: spacing.lg }} onPress={() => router.push('/inbox')}>
            📥 صندوق ورودی ({toPersianDigits(inbox)})
          </AppText>
        ) : null}
        <View style={{ height: 96 }} />
      </Screen>
      <QuickCapture />
    </View>
  );
}
