import { useEffect, useState } from 'react';
import { Modal, Pressable, ToastAndroid, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { formatDue } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { useTheme } from '@/core/theme/useTheme';
import { useDefaultReminder } from '@/features/settings/hooks/useDefaultReminder';
import { useTaskActions } from '@/features/tasks/hooks/useTaskActions';
import { useVoiceInput } from '@/features/voice/hooks/useVoiceInput';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Fab } from '@/shared/components/Fab';
import { TextField } from '@/shared/components/TextField';
import { INBOX_TAG } from '../services/inbox';
import { parseQuickText } from '../services/nlParser';

/**
 * The one floating button of the home screen. Opens a small sheet: type or hold the microphone and speak.
 * If the text contains a date or time ("فردا ساعت ۵ دکتر") the task is scheduled; otherwise it goes to the inbox.
 */
export function QuickCapture() {
  const { colors, radii, spacing, iconSizes } = useTheme();
  const actions = useTaskActions();
  const defaults = useDefaultReminder();
  const voice = useVoiceInput();
  const [open, setOpen] = useState(false);
  const [text, setText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const listening = voice.state.status === 'listening';
  const parsed = parseQuickText(text, Date.now());

  // Spoken words flow into the text field (still editable).
  useEffect(() => {
    if (voice.state.transcript) setText(voice.state.transcript);
  }, [voice.state.transcript]);

  const close = () => {
    voice.reset();
    setOpen(false);
    setText('');
    setError(null);
  };

  const save = async () => {
    if (!text.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const dated = parsed.dueAt !== null;
      await actions.create({
        title: parsed.title,
        dueAt: parsed.dueAt,
        hasTime: parsed.hasTime,
        tags: dated ? [] : [INBOX_TAG],
        reminders: parsed.hasTime
          ? [{ offsetMinutes: defaults.offset ?? 0, channel: defaults.style, enabled: true }]
          : [],
      });
      ToastAndroid.show(dated ? 'ثبت شد ✅' : 'به صندوق ورودی رفت 📥', ToastAndroid.SHORT);
      close();
    } catch (e) {
      setError(describeError(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <Fab onPress={() => setOpen(true)} accessibilityLabel="ثبت سریع" />
      <Modal visible={open} transparent animationType="slide" onRequestClose={close}>
        <Pressable style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: 'flex-end' }} onPress={close}>
          <Pressable
            onPress={() => {}}
            style={{
              backgroundColor: colors.surface, borderTopLeftRadius: radii.xl, borderTopRightRadius: radii.xl,
              padding: spacing.xl, gap: spacing.md,
            }}
          >
            <AppText variant="heading">ثبت سریع</AppText>
            <TextField
              placeholder="هر چه به ذهنت رسید… مثلاً: فردا ساعت ۵ دکتر"
              value={text}
              onChangeText={(t) => { setText(t); voice.edit(t); }}
              autoFocus
              multiline
              maxLength={200}
            />

            {text.trim() ? (
              <AppText variant="caption" color={parsed.dueAt ? 'accent' : 'textMuted'}>
                {parsed.dueAt
                  ? `برنامه‌ریزی می‌شود: ${formatDue(parsed.dueAt, parsed.hasTime, Date.now())} · «${parsed.title}»`
                  : 'بدون تاریخ: به «صندوق ورودی» می‌رود و بعداً برنامه‌ریزی می‌کنی.'}
              </AppText>
            ) : null}

            <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="نگه دارید و صحبت کنید"
                onPressIn={() => void voice.start()}
                onPressOut={() => voice.stop()}
                style={{
                  width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center',
                  backgroundColor: listening ? colors.danger : colors.accentSoft,
                }}
              >
                <Ionicons name={listening ? 'mic' : 'mic-outline'} size={iconSizes.xl} color={listening ? '#FFFFFF' : colors.accent} />
              </Pressable>
              <View style={{ flex: 1 }}>
                <AppText variant="label" muted>{listening ? 'در حال گوش دادن… رها کن تا تمام شود' : 'نگه دار و صحبت کن'}</AppText>
                {voice.state.error ? <AppText variant="caption" color="danger">{voice.state.error.message}</AppText> : null}
              </View>
            </View>

            {error ? <AppText color="danger">{error}</AppText> : null}
            <View style={{ flexDirection: 'row', gap: spacing.sm }}>
              <Button title="ثبت" disabled={!text.trim() || listening} loading={saving} onPress={() => void save()} />
              <Button title="بستن" variant="ghost" onPress={close} />
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </>
  );
}
