import { addDays, startOfDay } from '../../../core/calendar/dates';

export interface ParsedCapture {
  /** The text without the date/time words. Falls back to the original text. */
  title: string;
  dueAt: number | null;
  hasTime: boolean;
}

const HOUR = 3_600_000;
const MINUTE = 60_000;

function normalize(text: string): string {
  return text
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/\u200c/g, ' ')
    .replace(/[،,؛;]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Date.getDay() numbers
const WEEKDAYS: [RegExp, number][] = [
  [/ یک ?شنبه /, 0],
  [/ دو ?شنبه /, 1],
  [/ سه ?شنبه /, 2],
  [/ چهار ?شنبه /, 3],
  [/ پنج ?شنبه /, 4],
  [/ جمعه /, 5],
  [/ شنبه /, 6],
];

/** Takes the first match of `re` out of `text`; returns the match and the rest. */
function take(text: string, re: RegExp): { match: RegExpMatchArray | null; rest: string } {
  const m = text.match(re);
  if (!m || m.index === undefined) return { match: null, rest: text };
  return { match: m, rest: `${text.slice(0, m.index)} ${text.slice(m.index + m[0].length)}` };
}

const FILLER = /^(?:(?:یادم بنداز|یادآوری کن|یاداوری کن|باید|می ?خوام|میخوام|لازمه|بایستی)\s+)+(?:که\s+)?/;

/**
 * Understands simple Persian phrases like "فردا ساعت ۵ عصر دکتر", "۲ ساعت دیگه زنگ بزنم", "شنبه خرید".
 * Rules: with "ساعت 1..6" and no period word the afternoon is assumed (ساعت ۵ = ۱۷:۰۰);
 * "ساعت 7..11" without a period means the morning; a time that already passed today moves to tomorrow.
 */
export function parseQuickText(input: string, now: number): ParsedCapture {
  const original = normalize(input);
  let text = ` ${original} `; // words are matched between spaces (JS \\b does not understand Persian letters)
  const today = startOfDay(new Date(now));
  let dayOffset: number | null = null;
  let hour: number | null = null;
  let minute = 0;
  let relative: number | null = null; // ms from now
  let evening = false;

  // "2 ساعت دیگه", "30 دقیقه بعد", "3 روز دیگه"
  let r = take(text, / (\d{1,3}) ?(دقیقه|ساعت|روز) ?(?:دیگه|دیگر|بعد|بعدش) /);
  if (r.match) {
    const n = Number(r.match[1]);
    if (r.match[2] === 'روز') dayOffset = n;
    else relative = n * (r.match[2] === 'ساعت' ? HOUR : MINUTE);
    text = r.rest;
  }

  // day words
  r = take(text, / پس ?فردا /);
  if (r.match) { dayOffset = 2; text = r.rest; }
  if (dayOffset === null) {
    r = take(text, / فردا /);
    if (r.match) { dayOffset = 1; text = r.rest; }
  }
  if (dayOffset === null) {
    r = take(text, / امشب /);
    if (r.match) { dayOffset = 0; evening = true; text = r.rest; }
  }
  if (dayOffset === null) {
    r = take(text, / امروز /);
    if (r.match) { dayOffset = 0; text = r.rest; }
  }
  if (dayOffset === null) {
    r = take(text, / هفته ?(?:ی)? ?(?:بعد|آینده) /);
    if (r.match) { dayOffset = 7; text = r.rest; }
  }
  if (dayOffset === null) {
    for (const [re, day] of WEEKDAYS) {
      r = take(text, re);
      if (r.match) {
        const diff = (day - today.getDay() + 7) % 7;
        dayOffset = diff === 0 ? 7 : diff;
        text = r.rest.replace(/ (?:این|آینده) /, ' ');
        break;
      }
    }
  }

  // clock time: "ساعت 5", "ساعت 5:30", "ساعت 5 و نیم", "ساعت 9 صبح"
  r = take(text, / ساعت ?(\d{1,2})(?::(\d{2}))?(?: و (نیم|ربع|(\d{1,2}) دقیقه))? /);
  if (r.match) {
    hour = Number(r.match[1]);
    if (r.match[2]) minute = Number(r.match[2]);
    else if (r.match[3] === 'نیم') minute = 30;
    else if (r.match[3] === 'ربع') minute = 15;
    else if (r.match[4]) minute = Number(r.match[4]);
    text = r.rest;
    const period = take(text, / (صبح|ظهر|بعد ?از ?ظهر|عصر|شب) /);
    if (period.match) {
      const p = period.match[1];
      if (p === 'صبح') { if (hour === 12) hour = 0; }
      else if (p === 'ظهر') { if (hour < 11) hour += 12; }
      else if (hour < 12) hour += 12; // عصر / بعدازظهر / شب
      text = period.rest;
    } else if (hour >= 1 && hour <= 6) {
      hour += 12;
    }
    if (hour > 23 || minute > 59) { hour = null; minute = 0; }
  } else if (evening) {
    hour = 20;
  }

  let dueAt: number | null = null;
  let hasTime = false;
  if (relative !== null) {
    dueAt = now + relative;
    hasTime = true;
  } else if (hour !== null) {
    const day = addDays(today, dayOffset ?? 0);
    let t = new Date(day.getFullYear(), day.getMonth(), day.getDate(), hour, minute).getTime();
    if (dayOffset === null && t <= now) t = addDays(new Date(t), 1).getTime();
    dueAt = t;
    hasTime = true;
  } else if (dayOffset !== null) {
    dueAt = addDays(today, dayOffset).getTime();
  }

  let title = text.replace(/\s+/g, ' ').trim().replace(FILLER, '').replace(/^[\s\-–:،.]+|[\s\-–:،.]+$/g, '').trim();
  if (!title) title = original;
  return { title, dueAt, hasTime };
}
