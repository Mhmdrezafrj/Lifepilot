import type { Task } from '../../tasks/models/task';

/** Quickly captured thoughts without a date carry this tag; together with "no date" it defines the inbox. */
export const INBOX_TAG = 'صندوق ورودی';

export function isInboxTask(t: Pick<Task, 'status' | 'dueAt' | 'tags'>): boolean {
  return t.status === 'pending' && t.dueAt === null && t.tags.includes(INBOX_TAG);
}
