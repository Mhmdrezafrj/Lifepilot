import { memo } from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { formatTime } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from '@/shared/components/AppText';
import type { Task } from '../models/task';

interface Props {
  task: Task;
  onPress: (task: Task) => void;
  onToggle: (task: Task) => void;
}

/** A calm task row: no card, no border, lots of space. */
export const SimpleTaskRow = memo(function SimpleTaskRow({ task, onPress, onToggle }: Props) {
  const { colors, spacing, iconSizes } = useTheme();
  const done = task.status === 'completed';
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={task.title}
      onPress={() => onPress(task)}
      style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.lg, paddingVertical: spacing.lg }}
    >
      <Pressable
        accessibilityRole="checkbox"
        accessibilityState={{ checked: done }}
        accessibilityLabel={done ? 'بازگشایی کار' : 'انجام شد'}
        hitSlop={12}
        onPress={() => onToggle(task)}
        style={{
          width: 28, height: 28, borderRadius: 14, borderWidth: 2, alignItems: 'center', justifyContent: 'center',
          borderColor: done ? colors.accent : colors.textMuted, backgroundColor: done ? colors.accent : 'transparent',
        }}
      >
        {done ? <Ionicons name="checkmark" size={iconSizes.md} color={colors.textOnAccent} /> : null}
      </Pressable>
      <View style={{ flex: 1 }}>
        <AppText variant="bodyStrong" muted={done} style={done ? { textDecorationLine: 'line-through' } : undefined} numberOfLines={2}>
          {task.title}
        </AppText>
      </View>
      <AppText variant="label" muted>
        {task.hasTime && task.dueAt !== null ? formatTime(new Date(task.dueAt)) : ''}
      </AppText>
    </Pressable>
  );
});
