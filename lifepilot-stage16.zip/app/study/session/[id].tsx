import { Alert, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { formatDayLabel, formatTime, toPersianDigits } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { useTheme } from '@/core/theme/useTheme';
import { useBlockActions, useStudyBlocks } from '@/features/study/hooks/useStudyBlocks';
import { currentRun, formatCountdown, totalMinutes } from '@/features/study/services/blockPlanner';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Screen } from '@/shared/components/Screen';
import { useNow } from '@/shared/hooks/useNow';

export default function SessionScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { colors, spacing, radii } = useTheme();
  const { blocks, loading } = useStudyBlocks();
  const actions = useBlockActions();
  const block = blocks.find((b) => b.id === id);
  const now = useNow(1000); // refreshes the countdown only; the alarms come from scheduled notifications
  const fail = (e: unknown) => Alert.alert('خطا', describeError(e));

  if (!block) {
    return (
      <Screen title="جلسه‌ی مطالعه" onBack={() => router.back()}>
        <AppText muted>{loading ? 'در حال بارگذاری…' : 'این جلسه پیدا نشد.'}</AppText>
      </Screen>
    );
  }

  const run = currentRun(block, now);
  const label = block.subjectName ?? block.title;

  return (
    <Screen
      title={label}
      subtitle={`${formatDayLabel(new Date(block.startAt), new Date(now))} ${formatTime(new Date(block.startAt))} · ${toPersianDigits(totalMinutes(block.steps))} دقیقه`}
      onBack={() => router.back()}
    >
      {run ? (
        <Card>
          <AppText variant="label" muted>مرحله‌ی {toPersianDigits(run.index + 1)} از {toPersianDigits(block.steps.length)}</AppText>
          <AppText variant="heading">{run.title}</AppText>
          <AppText variant="display" color={run.remainingMs < 0 ? 'danger' : 'accent'} style={{ textAlign: 'center' }}>
            {formatCountdown(run.remainingMs)}
          </AppText>
          {run.remainingMs < 0 ? <AppText color="danger" style={{ textAlign: 'center' }}>زمان این مرحله تمام شد؛ برو مرحله‌ی بعد.</AppText> : null}
          <View style={{ height: 8, borderRadius: radii.pill, backgroundColor: colors.surfaceAlt, overflow: 'hidden' }}>
            <View style={{ width: `${Math.round(run.progress * 100)}%`, height: 8, backgroundColor: colors.accent }} />
          </View>
          <AppText variant="caption" muted>{run.nextTitle ? `بعدی: ${run.nextTitle}` : 'این آخرین مرحله است.'}</AppText>
          <Button
            title={run.isLast ? 'پایان جلسه' : 'مرحله‌ی بعد'}
            size="lg"
            fullWidth
            icon={run.isLast ? 'checkmark-done' : 'play-skip-forward'}
            onPress={() => actions.nextStep(block.id).catch(fail)}
          />
        </Card>
      ) : null}

      {block.status === 'planned' ? (
        <Card>
          <AppText muted>این جلسه هنوز شروع نشده است. سر ساعت شروع آلارم می‌زند.</AppText>
          <Button title="شروع جلسه" size="lg" fullWidth icon="play" onPress={() => actions.start(block.id).catch(fail)} />
        </Card>
      ) : null}
      {block.status === 'done' ? <Card variant="flat"><AppText>🎉 این جلسه تمام شد. آفرین! مباحث تازه را برای مرور ثبت کنید.</AppText></Card> : null}
      {block.status === 'cancelled' ? <Card variant="flat"><AppText muted>این جلسه لغو شد.</AppText></Card> : null}

      <View style={{ gap: spacing.sm }}>
        <AppText variant="heading">مراحل</AppText>
        {block.steps.map((s, i) => {
          const active = run?.index === i;
          return (
            <Card key={s.id} variant={active ? 'outlined' : 'flat'} style={active ? { borderColor: colors.accent } : undefined}>
              <AppText variant="bodyStrong" muted={s.done}>{s.done ? '✓ ' : ''}{s.title}</AppText>
              <AppText variant="caption" muted>{toPersianDigits(s.minutes)} دقیقه</AppText>
            </Card>
          );
        })}
      </View>

      <View style={{ flexDirection: 'row', gap: spacing.sm, flexWrap: 'wrap' }}>
        {block.status === 'running' ? <Button title="پایان زودهنگام" variant="ghost" size="sm" onPress={() => actions.finish(block.id).catch(fail)} /> : null}
        {block.status === 'planned' || block.status === 'running' ? (
          <Button title="لغو جلسه" variant="ghost" size="sm" onPress={() => actions.cancel(block.id).catch(fail)} />
        ) : null}
        <Button
          title="حذف"
          variant="ghost"
          size="sm"
          icon="trash-outline"
          onPress={() =>
            Alert.alert('حذف جلسه', 'این جلسه حذف شود؟', [
              { text: 'انصراف', style: 'cancel' },
              { text: 'حذف', style: 'destructive', onPress: () => actions.delete(block.id).then(() => router.back()).catch(fail) },
            ])
          }
        />
      </View>
    </Screen>
  );
}
