import { useState } from 'react';
import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { formatDayLabel, formatTimeParts, toPersianDigits } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { useTheme } from '@/core/theme/useTheme';
import { useBlockActions } from '@/features/study/hooks/useStudyBlocks';
import { useStudyData } from '@/features/study/hooks/useStudyData';
import { TOTAL_OPTIONS, defaultSteps, totalMinutes } from '@/features/study/services/blockPlanner';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Chip } from '@/shared/components/Chip';
import { IconButton } from '@/shared/components/IconButton';
import { JalaliDatePicker } from '@/shared/components/JalaliDatePicker';
import { Screen } from '@/shared/components/Screen';
import { TextField } from '@/shared/components/TextField';
import { TimePicker } from '@/shared/components/TimePicker';

export default function NewSessionScreen() {
  const router = useRouter();
  const { colors, spacing } = useTheme();
  const { subjects } = useStudyData();
  const actions = useBlockActions();
  const [subjectId, setSubjectId] = useState<string | null>(null);
  const [customTitle, setCustomTitle] = useState('');
  const [when, setWhen] = useState(() => {
    const d = new Date();
    d.setHours(d.getHours() + 1, 0, 0, 0);
    return d;
  });
  const [total, setTotal] = useState(60);
  const [steps, setSteps] = useState(() => defaultSteps(60));
  const [dateOpen, setDateOpen] = useState(false);
  const [timeOpen, setTimeOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const subject = subjects.find((s) => s.id === subjectId) ?? null;
  const title = customTitle.trim() || (subject ? `مطالعه‌ی ${subject.name}` : '');

  const setStep = (i: number, patch: Partial<{ title: string; minutes: number }>) =>
    setSteps((s) => s.map((x, j) => (j === i ? { ...x, ...patch } : x)));

  const save = async () => {
    setSaving(true);
    setError(null);
    try {
      const b = await actions.create({ subjectId, title, startAt: when.getTime(), steps });
      router.replace(`/study/session/${b.id}`);
    } catch (e) {
      setError(describeError(e));
      setSaving(false);
    }
  };

  return (
    <Screen title="جلسه‌ی مطالعه‌ی جدید" subtitle="مراحل با زمان مشخص؛ سر هر مرحله یک آلارم کوتاه می‌شنوی" onBack={() => router.back()}>
      <View style={{ gap: spacing.sm }}>
        <AppText variant="label" muted>درس</AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          {subjects.map((s) => (
            <Chip key={s.id} label={s.name} color={s.color} selected={subjectId === s.id} onPress={() => setSubjectId(subjectId === s.id ? null : s.id)} />
          ))}
        </View>
        <TextField placeholder={subjects.length ? 'یا عنوان دلخواه' : 'عنوان جلسه، مثلاً: ریاضی - مشتق'} value={customTitle} onChangeText={setCustomTitle} maxLength={120} />
      </View>

      <View style={{ gap: spacing.sm }}>
        <AppText variant="label" muted>زمان شروع</AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          <Chip icon="calendar-outline" label={formatDayLabel(when, new Date())} onPress={() => setDateOpen(true)} selected />
          <Chip icon="time-outline" label={formatTimeParts(when.getHours(), when.getMinutes())} onPress={() => setTimeOpen(true)} selected />
          <Chip label="الان" onPress={() => setWhen(new Date())} />
          <Chip label="۱ ساعت دیگر" onPress={() => setWhen(new Date(Date.now() + 3_600_000))} />
        </View>
        <AppText variant="caption" muted>سر ساعت شروع، آلارم می‌زند و با زدن آن جلسه باز می‌شود.</AppText>
      </View>

      <View style={{ gap: spacing.sm }}>
        <AppText variant="label" muted>مدت کل</AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          {TOTAL_OPTIONS.map((m) => (
            <Chip key={m} label={`${toPersianDigits(m)} دقیقه`} selected={total === m} onPress={() => { setTotal(m); setSteps(defaultSteps(m)); }} />
          ))}
        </View>
      </View>

      <View style={{ gap: spacing.sm }}>
        <AppText variant="heading">مراحل ({toPersianDigits(totalMinutes(steps))} دقیقه)</AppText>
        {steps.map((s, i) => (
          <Card key={i} variant="outlined" style={{ gap: spacing.sm }}>
            <TextField value={s.title} onChangeText={(t) => setStep(i, { title: t })} placeholder="عنوان مرحله" maxLength={80} />
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
              <IconButton icon="remove-circle-outline" accessibilityLabel="کم کردن زمان" onPress={() => setStep(i, { minutes: Math.max(5, s.minutes - 5) })} />
              <AppText variant="bodyStrong">{toPersianDigits(s.minutes)} دقیقه</AppText>
              <IconButton icon="add-circle-outline" accessibilityLabel="زیاد کردن زمان" onPress={() => setStep(i, { minutes: Math.min(120, s.minutes + 5) })} />
              <View style={{ flex: 1 }} />
              <IconButton icon="trash-outline" color={colors.danger} accessibilityLabel="حذف مرحله" onPress={() => setSteps((x) => x.filter((_, j) => j !== i))} />
            </View>
          </Card>
        ))}
        <Button title="افزودن مرحله" variant="ghost" icon="add" onPress={() => setSteps((x) => [...x, { title: '', minutes: 10 }])} />
        <Button title="بازگشت به مراحل پیش‌فرض" variant="ghost" size="sm" onPress={() => setSteps(defaultSteps(total))} />
      </View>

      {error ? <AppText color="danger">{error}</AppText> : null}
      <Button title="ساخت جلسه" size="lg" fullWidth loading={saving} onPress={() => void save()} />

      <JalaliDatePicker
        visible={dateOpen}
        value={when}
        onSelect={(d) => { const n = new Date(when); n.setFullYear(d.getFullYear(), d.getMonth(), d.getDate()); setWhen(n); setDateOpen(false); }}
        onClose={() => setDateOpen(false)}
      />
      <TimePicker
        visible={timeOpen}
        value={{ hour: when.getHours(), minute: when.getMinutes() }}
        onConfirm={(h, m) => { const n = new Date(when); n.setHours(h, m, 0, 0); setWhen(n); setTimeOpen(false); }}
        onClose={() => setTimeOpen(false)}
      />
    </Screen>
  );
}
