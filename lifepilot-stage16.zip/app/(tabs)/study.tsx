import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { addDays, startOfDay, weekdayIndexSat } from '@/core/calendar/dates';
import { WEEKDAY_SHORT_SAT_FIRST, formatDayLabel, formatTime, toPersianDigits } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import { useStudyBlocks } from '@/features/study/hooks/useStudyBlocks';
import { useStudyData } from '@/features/study/hooks/useStudyData';
import { daysUntil } from '@/features/study/services/srs';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { EmptyState } from '@/shared/components/EmptyState';
import { Screen } from '@/shared/components/Screen';

export default function StudyScreen() {
  const router = useRouter();
  const { colors, spacing, radii } = useTheme();
  const { queue, upcoming, materials, topics, exam, now, loading } = useStudyData();
  const { blocks } = useStudyBlocks();
  const sessions = blocks.filter((b) => b.status === 'running' || (b.status === 'planned' && b.startAt >= startOfDay(new Date(now)).getTime())).slice(0, 3);
  const max = Math.max(1, ...upcoming);
  const examDays = exam === null ? null : daysUntil(exam, now);

  return (
    <Screen title="مطالعه" subtitle="مرور فاصله‌دار و خودآزمایی">
      {!loading && materials.length === 0 ? (
        <EmptyState
          icon="school-outline"
          title="هنوز چیزی ثبت نکرده‌اید"
          description="کتاب یا فیلم آموزشی‌ای که خوانده/دیده‌اید و مباحثش را ثبت کنید تا برنامه‌ی مرور بسازیم."
          actionLabel="ثبت اولین مطلب"
          onAction={() => router.push('/study/learn')}
        />
      ) : (
        <>
          <Card>
            <AppText variant="label" muted>مرور امروز</AppText>
            <AppText variant="display">{toPersianDigits(queue.length)}</AppText>
            <AppText muted>
              {queue.length === 0 ? 'امروز مرور باقی نمانده 🎉' : 'مبحث برای مرور (درس‌ها قاطی می‌شوند تا بهتر یاد بماند)'}
            </AppText>
            <Button title="شروع مرور" icon="play" disabled={queue.length === 0} onPress={() => router.push('/study/review')} />
          </Card>

          <Card variant="outlined">
            <AppText variant="bodyStrong">مرورهای ۷ روز آینده</AppText>
            <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: spacing.sm, height: 96 }}>
              {upcoming.map((n, i) => {
                const date = addDays(startOfDay(new Date(now)), i);
                return (
                  <View key={i} style={{ flex: 1, alignItems: 'center', justifyContent: 'flex-end', gap: 4 }}>
                    <AppText variant="caption" muted>{toPersianDigits(n)}</AppText>
                    <View
                      style={{
                        width: '70%',
                        height: Math.max(4, Math.round((n / max) * 56)),
                        borderRadius: radii.sm,
                        backgroundColor: i === 0 ? colors.accent : colors.accentSoft,
                      }}
                    />
                    <AppText variant="caption" color={i === 0 ? 'accent' : 'textMuted'}>
                      {i === 0 ? 'امروز' : WEEKDAY_SHORT_SAT_FIRST[weekdayIndexSat(date)]}
                    </AppText>
                  </View>
                );
              })}
            </View>
            <AppText variant="caption" muted>{toPersianDigits(topics.length)} مبحث در برنامه</AppText>
          </Card>

          {examDays !== null ? (
            <Card variant="flat">
              <AppText>
                {examDays > 0 ? `${toPersianDigits(examDays)} روز تا کنکور؛ فاصله‌ی مرورها کوتاه‌تر می‌شود.` : 'کنکور امروز یا گذشته است.'}
              </AppText>
            </Card>
          ) : null}
        </>
      )}

      <Card variant="outlined">
        <AppText variant="bodyStrong">جلسه‌های مطالعه</AppText>
        {sessions.length === 0 ? (
          <AppText variant="caption" muted>جلسه‌ای برنامه‌ریزی نشده. برای هر درس یک جلسه با مراحل زمان‌بندی‌شده بساز تا سر هر مرحله آلارم کوتاه بشنوی.</AppText>
        ) : (
          sessions.map((b) => (
            <Card key={b.id} variant="flat" onPress={() => router.push(`/study/session/${b.id}`)} accessibilityLabel={b.title}>
              <AppText variant="bodyStrong">{b.status === 'running' ? '▶ ' : ''}{b.subjectName ?? b.title}</AppText>
              <AppText variant="caption" muted>
                {b.status === 'running' ? 'در حال اجرا' : `${formatDayLabel(new Date(b.startAt), new Date(now))} ${formatTime(new Date(b.startAt))}`}
              </AppText>
            </Card>
          ))
        )}
        <Button title="ساخت جلسه‌ی مطالعه" icon="timer-outline" size="sm" onPress={() => router.push('/study/session-new')} />
      </Card>

      <Button title="ثبت چیزی که یاد گرفتم" icon="add" variant={materials.length === 0 ? 'primary' : 'secondary'} onPress={() => router.push('/study/learn')} />
      <Button title="برنامه‌ی هفتگی و پیشرفت" icon="calendar-outline" variant="secondary" onPress={() => router.push('/study/plan')} />
      <Button title="منابع و مباحث من" icon="library-outline" variant="ghost" onPress={() => router.push('/study/materials')} />
      <Button title="تنظیمات مطالعه (کنکور، ساعت، یادآوری)" icon="options-outline" variant="ghost" onPress={() => router.push('/study/profile')} />
    </Screen>
  );
}
