import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createNodeClient } from '../helpers/nodeClient';
import { LATEST_SCHEMA_VERSION, migrate, migrations } from '../../src/core/database/migrations';
import { createRepositories } from '../../src/providers/repositories';

function fakeClock() {
  let t = 1_700_000_000_000;
  return () => (t += 1000);
}

async function freshDb() {
  const db = createNodeClient();
  await migrate(db, migrations);
  return db;
}

describe('migrations', () => {
  it('creates every expected table', async () => {
    const db = await freshDb();
    const rows = await db.getAllAsync<{ name: string }>(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name");
    assert.deepEqual(rows.map((r) => r.name), [
      'app_settings', 'behavior_events', 'categories', 'recurrences', 'reminder_events',
      'reminders', 'study_block_steps', 'study_blocks', 'study_materials', 'study_reviews', 'study_subjects', 'study_topics',
      'task_checklist_items', 'task_tags', 'tasks',
    ]);
  });

  it('records the latest version in user_version', async () => {
    const db = await freshDb();
    const row = await db.getFirstAsync<{ user_version: number }>('PRAGMA user_version');
    assert.equal(row?.user_version, LATEST_SCHEMA_VERSION);
  });

  it('seeds the 7 default categories exactly once, even if run again', async () => {
    const db = await freshDb();
    await migrate(db, migrations);
    await migrate(db, migrations);
    const repos = createRepositories(db);
    assert.equal(await repos.categories.count(), 7);
  });

  it('keeps existing data when upgrading from version 1', async () => {
    const db = createNodeClient();
    await migrate(db, [migrations[0]]);
    await db.runAsync(
      "INSERT INTO tasks (id, title, priority, status, created_at, updated_at) VALUES ('t1','old task','medium','pending',1,1)");
    await migrate(db, migrations);
    const repos = createRepositories(db);
    assert.equal((await repos.tasks.getById('t1'))?.title, 'old task');
    assert.equal(await repos.categories.count(), 7);
  });

  it('refuses to open a database newer than the app', async () => {
    const db = createNodeClient();
    await db.execAsync('PRAGMA user_version = 99');
    await assert.rejects(() => migrate(db, migrations), /newer/);
  });

  it('enforces foreign keys', async () => {
    const db = await freshDb();
    await assert.rejects(() =>
      db.runAsync(
        "INSERT INTO tasks (id, title, category_id, created_at, updated_at) VALUES ('a','b','missing',1,1)"));
  });

  it('creates the planned indexes', async () => {
    const db = await freshDb();
    const rows = await db.getAllAsync<{ name: string }>("SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_%'");
    const names = rows.map((r) => r.name);
    for (const n of ['idx_tasks_due_at', 'idx_tasks_status_due', 'idx_tasks_category', 'idx_reminders_task', 'idx_checklist_task']) {
      assert.ok(names.includes(n), `missing index ${n}`);
    }
  });
});

describe('task repository', () => {
  it('creates a task with tags, checklist, reminders and recurrence', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db, { now: fakeClock() });
    const t = await tasks.create({
      title: 'جلسه',
      description: 'توضیح',
      dueAt: 1_800_000_000_000,
      hasTime: true,
      priority: 'high',
      categoryId: 'cat_work',
      tags: ['مهم', 'تیم'],
      checklist: [{ title: 'آماده کردن' }, { title: 'ارسال', isCompleted: true }],
      reminders: [{ offsetMinutes: 30 }, { offsetMinutes: 5, channel: 'alarm', repeatIntervalMinutes: 5, maxRepeats: 3 }],
      recurrence: { frequency: 'weekly', weekdays: [1, 3] },
    });

    assert.equal(t.status, 'pending');
    assert.equal(t.priority, 'high');
    assert.equal(t.categoryId, 'cat_work');
    assert.deepEqual(t.tags, ['تیم', 'مهم'].sort());
    assert.deepEqual(t.checklist.map((c) => [c.title, c.isCompleted, c.sortOrder]), [['آماده کردن', false, 0], ['ارسال', true, 1]]);
    assert.equal(t.reminders.length, 2);
    assert.equal(t.reminders.find((r) => r.channel === 'alarm')?.maxRepeats, 3);
    assert.deepEqual(t.recurrence?.weekdays, [1, 3]);
    assert.equal(t.completedAt, null);
  });

  it('does not create duplicates and gives each task a unique id', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db);
    const a = await tasks.create({ title: 'same' });
    const b = await tasks.create({ title: 'same' });
    assert.notEqual(a.id, b.id);
    assert.equal(await tasks.count(), 2);
  });

  it('rolls back everything if any part of a create fails', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db);
    await assert.rejects(() => tasks.create({ title: 'bad', categoryId: 'no-such-category', tags: ['t'] }));
    assert.equal(await tasks.count(), 0);
    const tags = await db.getFirstAsync<{ n: number }>('SELECT COUNT(*) AS n FROM task_tags');
    assert.equal(tags?.n, 0);
  });

  it('rejects invalid input before touching the database', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db);
    await assert.rejects(() => tasks.create({ title: '' }));
    assert.equal(await tasks.count(), 0);
  });

  it('edits a task and bumps updated_at', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db, { now: fakeClock() });
    const t = await tasks.create({ title: 'old', tags: ['a'], priority: 'low' });
    const u = await tasks.update(t.id, { title: 'new', priority: 'critical', tags: ['b', 'c'], description: 'd' });
    assert.equal(u?.title, 'new');
    assert.equal(u?.priority, 'critical');
    assert.deepEqual(u?.tags, ['b', 'c']);
    assert.equal(u?.description, 'd');
    assert.ok((u?.updatedAt ?? 0) > t.updatedAt);
    assert.equal(u?.createdAt, t.createdAt);
  });

  it('leaves untouched fields alone on partial update', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db);
    const t = await tasks.create({ title: 'keep', tags: ['x'], priority: 'high' });
    const u = await tasks.update(t.id, { description: 'only this' });
    assert.equal(u?.title, 'keep');
    assert.equal(u?.priority, 'high');
    assert.deepEqual(u?.tags, ['x']);
  });

  it('completes and reopens a task, tracking completed_at', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db, { now: fakeClock() });
    const t = await tasks.create({ title: 'x' });
    const done = await tasks.update(t.id, { status: 'completed' });
    assert.equal(done?.status, 'completed');
    assert.ok(done?.completedAt);
    const reopened = await tasks.update(t.id, { status: 'pending' });
    assert.equal(reopened?.status, 'pending');
    assert.equal(reopened?.completedAt, null);
  });

  it('adds and removes recurrence on update', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db);
    const t = await tasks.create({ title: 'x' });
    const withRec = await tasks.update(t.id, { recurrence: { frequency: 'daily', intervalCount: 2 } });
    assert.equal(withRec?.recurrence?.intervalCount, 2);
    const without = await tasks.update(t.id, { recurrence: null });
    assert.equal(without?.recurrence, null);
    const n = await db.getFirstAsync<{ n: number }>('SELECT COUNT(*) AS n FROM recurrences');
    assert.equal(n?.n, 0);
  });

  it('returns null when updating or reading a missing task', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db);
    assert.equal(await tasks.update('nope', { title: 'x' }), null);
    assert.equal(await tasks.getById('nope'), null);
  });

  it('deletes a task together with its tags, checklist, reminders and recurrence', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db);
    const t = await tasks.create({
      title: 'x', tags: ['a'], checklist: [{ title: 'c' }], reminders: [{ offsetMinutes: 1 }],
      recurrence: { frequency: 'daily' },
    });
    assert.equal(await tasks.delete(t.id), true);
    assert.equal(await tasks.delete(t.id), false);
    for (const table of ['tasks', 'task_tags', 'task_checklist_items', 'reminders', 'recurrences']) {
      const r = await db.getFirstAsync<{ n: number }>(`SELECT COUNT(*) AS n FROM ${table}`);
      assert.equal(r?.n, 0, `${table} should be empty`);
    }
  });

  it('lists with status, date range and category filters, ordered by due date', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db);
    const a = await tasks.create({ title: 'a', dueAt: 3000, categoryId: 'cat_work' });
    const b = await tasks.create({ title: 'b', dueAt: 1000 });
    const c = await tasks.create({ title: 'c' }); // no due date
    await tasks.update(b.id, { status: 'completed' });

    assert.deepEqual((await tasks.list()).map((t) => t.title), ['b', 'a', 'c']);
    assert.deepEqual((await tasks.list({ status: 'pending' })).map((t) => t.title), ['a', 'c']);
    assert.deepEqual((await tasks.list({ dueFrom: 1000, dueTo: 3000 })).map((t) => t.title), ['b']);
    assert.deepEqual((await tasks.list({ categoryId: 'cat_work' })).map((t) => t.id), [a.id]);
    assert.deepEqual((await tasks.list({ categoryId: null })).map((t) => t.id), [b.id, c.id]);
    assert.equal((await tasks.list({ limit: 1 })).length, 1);
  });

  it('never removes an overdue task on its own', async () => {
    const db = await freshDb();
    const { tasks } = createRepositories(db);
    const t = await tasks.create({ title: 'old', dueAt: 1 });
    await migrate(db, migrations);
    assert.equal((await tasks.getById(t.id))?.status, 'pending');
  });
});

describe('categories', () => {
  it('creates, renames and recolors a category', async () => {
    const db = await freshDb();
    const { categories } = createRepositories(db);
    const c = await categories.create({ name: 'ورزش', color: '#112233' });
    assert.equal(c.sortOrder, 7);
    const u = await categories.update(c.id, { name: 'باشگاه', color: '#445566' });
    assert.equal(u?.name, 'باشگاه');
    assert.equal(u?.color, '#445566');
  });

  it('associates tasks with a category', async () => {
    const db = await freshDb();
    const { tasks, categories } = createRepositories(db);
    const c = await categories.create({ name: 'x', color: '#112233' });
    const t = await tasks.create({ title: 't', categoryId: c.id });
    assert.equal(t.categoryId, c.id);
  });

  it('keeps tasks (uncategorized) when their category is deleted', async () => {
    const db = await freshDb();
    const { tasks, categories } = createRepositories(db);
    const c = await categories.create({ name: 'x', color: '#112233' });
    const t = await tasks.create({ title: 't', categoryId: c.id });
    assert.equal(await categories.remove(c.id), true);
    assert.equal((await tasks.getById(t.id))?.categoryId, null);
  });

  it('moves tasks to another category when asked', async () => {
    const db = await freshDb();
    const { tasks, categories } = createRepositories(db);
    const c = await categories.create({ name: 'x', color: '#112233' });
    const t = await tasks.create({ title: 't', categoryId: c.id });
    await categories.remove(c.id, { reassignTo: 'cat_other' });
    assert.equal((await tasks.getById(t.id))?.categoryId, 'cat_other');
    assert.equal(await categories.getById(c.id), null);
  });

  it('refuses to reassign tasks to the category being deleted', async () => {
    const db = await freshDb();
    const { categories } = createRepositories(db);
    await assert.rejects(() => categories.remove('cat_work', { reassignTo: 'cat_work' }));
  });
});

describe('settings', () => {
  it('stores, overwrites and removes values', async () => {
    const db = await freshDb();
    const { settings } = createRepositories(db, { now: fakeClock() });
    assert.equal(await settings.get('k'), null);
    await settings.set('k', 'v1');
    await settings.set('k', 'v2');
    assert.equal(await settings.get('k'), 'v2');
    await settings.remove('k');
    assert.equal(await settings.get('k'), null);
  });
});

describe('persistence', () => {
  it('keeps data after the database is closed and reopened (app restart)', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'lifepilot-'));
    const file = join(dir, 'test.db');
    try {
      const first = createNodeClient(file);
      await migrate(first, migrations);
      const r1 = createRepositories(first);
      const t = await r1.tasks.create({ title: 'survives restart', tags: ['x'], categoryId: 'cat_health' });
      await r1.settings.set('launch_count', '1');
      first.close();

      const second = createNodeClient(file);
      await migrate(second, migrations);
      const r2 = createRepositories(second);
      const again = await r2.tasks.getById(t.id);
      assert.equal(again?.title, 'survives restart');
      assert.deepEqual(again?.tags, ['x']);
      assert.equal(await r2.settings.get('launch_count'), '1');
      assert.equal(await r2.categories.count(), 7);
      assert.equal(await r2.tasks.count(), 1);
      second.close();
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});
