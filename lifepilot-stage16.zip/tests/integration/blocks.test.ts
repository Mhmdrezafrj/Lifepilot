import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createNodeClient } from '../helpers/nodeClient';
import { migrate, migrations } from '../../src/core/database/migrations';
import { createRepositories } from '../../src/providers/repositories';
import { createServices } from '../../src/providers/services';
import { InvalidOperationError, NotFoundError } from '../../src/core/errors';

let clock = new Date(2026, 10, 5, 16, 0).getTime();
const at = (h: number, m = 0) => new Date(2026, 10, 5, h, m).getTime();
const steps = [{ title: 'هدف', minutes: 5 }, { title: 'یادگیری', minutes: 25 }, { title: 'تمرین', minutes: 20 }];

async function setup() {
  clock = at(16);
  const db = createNodeClient();
  await migrate(db, migrations);
  const repos = createRepositories(db, { now: () => clock });
  const sv = createServices(repos, { now: () => clock });
  const subject = await sv.study.addSubject({ name: 'فیزیک', color: '#0EA5E9' });
  return { db, repos, ...sv, subject };
}

describe('study sessions', () => {
  it('saves a session with ordered steps and its subject', async () => {
    const { blocks, subject } = await setup();
    const b = await blocks.create({ subjectId: subject.id, title: 'فیزیک ۱', startAt: at(17), steps });
    assert.equal(b.status, 'planned');
    assert.equal(b.subjectName, 'فیزیک');
    assert.deepEqual(b.steps.map((s) => [s.title, s.minutes, s.sortOrder, s.done]), [['هدف', 5, 0, false], ['یادگیری', 25, 1, false], ['تمرین', 20, 2, false]]);
  });

  it('validates input', async () => {
    const { blocks } = await setup();
    await assert.rejects(() => blocks.create({ subjectId: null, title: ' ', startAt: at(17), steps }));
    await assert.rejects(() => blocks.create({ subjectId: null, title: 'x', startAt: at(17), steps: [] }));
    await assert.rejects(() => blocks.create({ subjectId: null, title: 'x', startAt: at(17), steps: [{ title: 'a', minutes: 0 }] }));
  });

  it('runs through the steps and finishes after the last one', async () => {
    const { blocks } = await setup();
    const b = await blocks.create({ subjectId: null, title: 'x', startAt: at(17), steps });
    clock = at(17);
    let r = await blocks.start(b.id);
    assert.deepEqual([r.status, r.currentStep, r.stepStartedAt], ['running', 0, at(17)]);
    clock = at(17, 5);
    r = await blocks.nextStep(b.id);
    assert.deepEqual([r.currentStep, r.stepStartedAt], [1, at(17, 5)]);
    assert.equal(r.steps[0].done, true);
    clock = at(17, 33);
    r = await blocks.nextStep(b.id);
    assert.equal(r.currentStep, 2);
    clock = at(17, 55);
    r = await blocks.nextStep(b.id);
    assert.equal(r.status, 'done');
    assert.equal(r.finishedAt, at(17, 55));
    assert.ok(r.steps.every((s) => s.done));
  });

  it('refuses invalid transitions', async () => {
    const { blocks } = await setup();
    const b = await blocks.create({ subjectId: null, title: 'x', startAt: at(17), steps });
    await assert.rejects(() => blocks.nextStep(b.id), InvalidOperationError);
    await assert.rejects(() => blocks.finish(b.id), InvalidOperationError);
    await blocks.start(b.id);
    await assert.rejects(() => blocks.start(b.id), InvalidOperationError);
    await blocks.finish(b.id);
    await assert.rejects(() => blocks.cancel(b.id), InvalidOperationError);
    await assert.rejects(() => blocks.start('nope'), NotFoundError);
  });

  it('lists by status and deletes with its steps', async () => {
    const { blocks, repos, db } = await setup();
    const a = await blocks.create({ subjectId: null, title: 'a', startAt: at(17), steps });
    const b = await blocks.create({ subjectId: null, title: 'b', startAt: at(18), steps });
    await blocks.start(b.id);
    assert.deepEqual((await repos.blocks.list({ statuses: ['planned'] })).map((x) => x.id), [a.id]);
    assert.deepEqual((await repos.blocks.list({ statuses: ['planned', 'running'] })).map((x) => x.id), [a.id, b.id]);
    await blocks.delete(a.id);
    const n = await db.getFirstAsync<{ n: number }>('SELECT COUNT(*) AS n FROM study_block_steps');
    assert.equal(n?.n, 3);
    await assert.rejects(() => blocks.delete(a.id), NotFoundError);
  });

  it('keeps the session when its subject is deleted', async () => {
    const { blocks, repos, subject } = await setup();
    const b = await blocks.create({ subjectId: subject.id, title: 'x', startAt: at(17), steps });
    await repos.study.deleteSubject(subject.id);
    const again = await repos.blocks.get(b.id);
    assert.equal(again?.subjectId, null);
    assert.equal(again?.subjectName, null);
  });
});
