import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { StudyBlock } from '../../src/features/study/models/studyBlock';
import {
  currentRun, defaultSteps, formatCountdown, planBlockNotifications, totalMinutes,
} from '../../src/features/study/services/blockPlanner';

const at = (h: number, m = 0, s = 0) => new Date(2026, 10, 5, h, m, s).getTime();
const mk = (over: Partial<StudyBlock> = {}): StudyBlock => ({
  id: 'b1', subjectId: 's', subjectName: 'ریاضی', subjectColor: '#4F46E5', title: 'جلسه', startAt: at(17), status: 'planned',
  currentStep: 0, stepStartedAt: null, startedAt: null, finishedAt: null, createdAt: 0,
  steps: [
    { id: 'a', title: 'هدف', minutes: 5, sortOrder: 0, done: false },
    { id: 'b', title: 'یادگیری', minutes: 25, sortOrder: 1, done: false },
    { id: 'c', title: 'تمرین', minutes: 20, sortOrder: 2, done: false },
  ], ...over,
});

describe('default steps', () => {
  it('makes 5 / 25 / 20 / 10 for one hour, and always sums to the total', () => {
    assert.deepEqual(defaultSteps(60).map((s) => s.minutes), [5, 25, 20, 10]);
    for (const t of [30, 45, 60, 90, 120]) {
      const steps = defaultSteps(t);
      assert.equal(totalMinutes(steps), t, String(t));
      assert.equal(steps.length, 4);
      assert.ok(steps.every((s) => s.minutes >= 5 && s.minutes % 5 === 0));
    }
  });
});

describe('running state', () => {
  it('is null unless running', () => {
    assert.equal(currentRun(mk(), at(17)), null);
    assert.equal(currentRun(mk({ status: 'done' }), at(17)), null);
  });

  it('counts down inside the current step', () => {
    const b = mk({ status: 'running', currentStep: 1, stepStartedAt: at(17, 5) });
    const r = currentRun(b, at(17, 15));
    assert.equal(r?.title, 'یادگیری');
    assert.equal(r?.remainingMs, 15 * 60_000);
    assert.equal(r?.progress, 0.4);
    assert.equal(r?.isLast, false);
    assert.equal(r?.nextTitle, 'تمرین');
    assert.equal(r?.endsAt, at(17, 30));
  });

  it('goes negative when the step runs over, and knows the last step', () => {
    const b = mk({ status: 'running', currentStep: 2, stepStartedAt: at(17, 30) });
    const r = currentRun(b, at(17, 55));
    assert.ok((r?.remainingMs ?? 0) < 0);
    assert.equal(r?.progress, 1);
    assert.equal(r?.isLast, true);
    assert.equal(r?.nextTitle, null);
  });

  it('formats a countdown in Persian and never shows negative time', () => {
    assert.equal(formatCountdown(754_000), '۱۲:۳۴');
    assert.equal(formatCountdown(0), '۰۰:۰۰');
    assert.equal(formatCountdown(-5000), '۰۰:۰۰');
    assert.equal(formatCountdown(59_100), '۰۱:۰۰');
  });
});

describe('session notifications', () => {
  it('a planned session rings once at its start time (not when already past)', () => {
    const n = planBlockNotifications([mk()], at(12));
    assert.equal(n.length, 1);
    assert.equal(n[0].kind, 'start');
    assert.equal(n[0].fireAt, at(17));
    assert.ok(n[0].title.includes('ریاضی'));
    assert.deepEqual(planBlockNotifications([mk()], at(18)), []);
  });

  it('a running session gets a chime at the end of every step and a final one', () => {
    const b = mk({ status: 'running', currentStep: 0, stepStartedAt: at(17) });
    const n = planBlockNotifications([b], at(17, 1));
    assert.deepEqual(n.map((x) => [x.kind, x.fireAt]), [['step', at(17, 5)], ['step', at(17, 30)], ['end', at(17, 50)]]);
    assert.ok(n[0].title.includes('یادگیری'));
    assert.ok(n[1].title.includes('تمرین'));
  });

  it('only plans the remaining steps after moving on, and drops past ones', () => {
    const b = mk({ status: 'running', currentStep: 1, stepStartedAt: at(17, 8) });
    const n = planBlockNotifications([b], at(17, 9));
    assert.deepEqual(n.map((x) => x.kind), ['step', 'end']);
    assert.equal(n[0].fireAt, at(17, 33));
    assert.deepEqual(planBlockNotifications([b], at(19)), []);
  });

  it('ignores finished or cancelled sessions and unique ids per alert', () => {
    assert.deepEqual(planBlockNotifications([mk({ status: 'done' }), mk({ status: 'cancelled' })], at(12)), []);
    const n = planBlockNotifications([mk({ status: 'running', stepStartedAt: at(17) })], at(17, 1));
    assert.equal(new Set(n.map((x) => x.id)).size, n.length);
  });
});
