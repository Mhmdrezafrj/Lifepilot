export const BLOCK_STATUSES = ['planned', 'running', 'done', 'cancelled'] as const;
export type BlockStatus = (typeof BLOCK_STATUSES)[number];

export interface BlockStep {
  id: string;
  title: string;
  minutes: number;
  sortOrder: number;
  done: boolean;
}

/** A study session: one subject, a start time, and ordered timed steps. */
export interface StudyBlock {
  id: string;
  subjectId: string | null;
  subjectName: string | null;
  subjectColor: string | null;
  title: string;
  startAt: number;
  status: BlockStatus;
  /** Index of the step in progress (while running). */
  currentStep: number;
  /** When the current step began (epoch ms). */
  stepStartedAt: number | null;
  startedAt: number | null;
  finishedAt: number | null;
  createdAt: number;
  steps: BlockStep[];
}

export interface NewBlockInput {
  subjectId: string | null;
  title: string;
  startAt: number;
  steps: { title: string; minutes: number }[];
}
