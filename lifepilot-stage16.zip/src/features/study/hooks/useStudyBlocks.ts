import { useEffect, useMemo, useState } from 'react';
import { addDays, startOfDay } from '@/core/calendar/dates';
import { useRepositories, useServices } from '@/providers/DatabaseProvider';
import { useDataStore } from '@/shared/state/dataStore';
import type { StudyBlock } from '../models/studyBlock';

/** Sessions from yesterday onwards (so a running or just-finished one is still visible). */
export function useStudyBlocks(): { blocks: StudyBlock[]; loading: boolean } {
  const repos = useRepositories();
  const version = useDataStore((s) => s.version);
  const [blocks, setBlocks] = useState<StudyBlock[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    repos.blocks
      .list({ from: addDays(startOfDay(new Date()), -1).getTime() })
      .then((list) => {
        if (!cancelled) {
          setBlocks(list);
          setLoading(false);
        }
      })
      .catch(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [repos, version]);

  return { blocks, loading };
}

/** Session changes; every call refreshes the screens and the scheduled alerts. */
export function useBlockActions() {
  const services = useServices();
  const bump = useDataStore((s) => s.bump);
  return useMemo(() => {
    const wrap =
      <A extends unknown[], R>(fn: (...a: A) => Promise<R>) =>
      async (...a: A): Promise<R> => {
        try {
          return await fn(...a);
        } finally {
          bump();
        }
      };
    const b = services.blocks;
    return {
      create: wrap(b.create), start: wrap(b.start), nextStep: wrap(b.nextStep),
      finish: wrap(b.finish), cancel: wrap(b.cancel), delete: wrap(b.delete),
    };
  }, [services, bump]);
}
