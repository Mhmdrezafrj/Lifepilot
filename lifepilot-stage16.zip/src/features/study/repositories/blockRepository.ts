import { z } from 'zod';
import type { DbClient, SqlParam } from '../../../core/database/connection/types';
import { newId } from '../../../core/utils/id';
import type { BlockStatus, BlockStep, NewBlockInput, StudyBlock } from '../models/studyBlock';

const inputSchema = z.object({
  subjectId: z.string().min(1).nullable(),
  title: z.string().trim().min(1, 'عنوان جلسه الزامی است').max(120),
  startAt: z.number().int().nonnegative(),
  steps: z
    .array(z.object({ title: z.string().trim().min(1, 'عنوان مرحله الزامی است').max(80), minutes: z.number().int().min(1).max(180) }))
    .min(1, 'حداقل یک مرحله لازم است')
    .max(12),
});

interface BlockRow {
  id: string; subject_id: string | null; title: string; start_at: number; status: BlockStatus; current_step: number;
  step_started_at: number | null; started_at: number | null; finished_at: number | null; created_at: number;
  subject_name: string | null; subject_color: string | null;
}
interface StepRow { id: string; block_id: string; title: string; minutes: number; sort_order: number; done: number }

const SELECT = `SELECT b.*, s.name AS subject_name, s.color AS subject_color
  FROM study_blocks b LEFT JOIN study_subjects s ON s.id = b.subject_id`;

export interface BlockRepository {
  create(input: NewBlockInput): Promise<StudyBlock>;
  get(id: string): Promise<StudyBlock | null>;
  list(filter?: { statuses?: BlockStatus[]; from?: number }): Promise<StudyBlock[]>;
  /** Raw state changes (rules live in the service). */
  setState(id: string, patch: {
    status?: BlockStatus; currentStep?: number; stepStartedAt?: number | null; startedAt?: number | null; finishedAt?: number | null;
  }): Promise<boolean>;
  markStepDone(blockId: string, sortOrder: number): Promise<void>;
  delete(id: string): Promise<boolean>;
}

export function createBlockRepository(db: DbClient, options: { now?: () => number } = {}): BlockRepository {
  const now = options.now ?? (() => Date.now());

  async function hydrate(rows: BlockRow[]): Promise<StudyBlock[]> {
    if (rows.length === 0) return [];
    const ids = rows.map((r) => r.id);
    const steps = await db.getAllAsync<StepRow>(
      `SELECT * FROM study_block_steps WHERE block_id IN (${ids.map(() => '?').join(',')}) ORDER BY sort_order`, ids);
    const by = new Map<string, BlockStep[]>();
    for (const s of steps) {
      const list = by.get(s.block_id) ?? [];
      list.push({ id: s.id, title: s.title, minutes: s.minutes, sortOrder: s.sort_order, done: s.done === 1 });
      by.set(s.block_id, list);
    }
    return rows.map((r) => ({
      id: r.id, subjectId: r.subject_id, subjectName: r.subject_name, subjectColor: r.subject_color, title: r.title,
      startAt: r.start_at, status: r.status, currentStep: r.current_step, stepStartedAt: r.step_started_at,
      startedAt: r.started_at, finishedAt: r.finished_at, createdAt: r.created_at, steps: by.get(r.id) ?? [],
    }));
  }

  async function get(id: string): Promise<StudyBlock | null> {
    const row = await db.getFirstAsync<BlockRow>(`${SELECT} WHERE b.id = ?`, [id]);
    return row ? (await hydrate([row]))[0] : null;
  }

  return {
    get,

    async create(raw) {
      const input = inputSchema.parse(raw);
      const id = newId();
      await db.withTransactionAsync(async () => {
        await db.runAsync(
          'INSERT INTO study_blocks (id, subject_id, title, start_at, created_at) VALUES (?, ?, ?, ?, ?)',
          [id, input.subjectId, input.title, input.startAt, now()]);
        for (let i = 0; i < input.steps.length; i++) {
          await db.runAsync(
            'INSERT INTO study_block_steps (id, block_id, title, minutes, sort_order) VALUES (?, ?, ?, ?, ?)',
            [newId(), id, input.steps[i].title, input.steps[i].minutes, i]);
        }
      });
      const created = await get(id);
      if (!created) throw new Error('Session was not saved');
      return created;
    },

    async list(filter = {}) {
      const where: string[] = [];
      const params: SqlParam[] = [];
      if (filter.statuses && filter.statuses.length) {
        where.push(`b.status IN (${filter.statuses.map(() => '?').join(',')})`);
        params.push(...filter.statuses);
      }
      if (filter.from !== undefined) {
        where.push('b.start_at >= ?');
        params.push(filter.from);
      }
      const sql = `${SELECT}${where.length ? ` WHERE ${where.join(' AND ')}` : ''} ORDER BY b.start_at, b.id`;
      return hydrate(await db.getAllAsync<BlockRow>(sql, params));
    },

    async setState(id, p) {
      const sets: string[] = [];
      const params: SqlParam[] = [];
      const add = (col: string, v: SqlParam) => { sets.push(`${col} = ?`); params.push(v); };
      if (p.status !== undefined) add('status', p.status);
      if (p.currentStep !== undefined) add('current_step', p.currentStep);
      if (p.stepStartedAt !== undefined) add('step_started_at', p.stepStartedAt);
      if (p.startedAt !== undefined) add('started_at', p.startedAt);
      if (p.finishedAt !== undefined) add('finished_at', p.finishedAt);
      if (sets.length === 0) return false;
      params.push(id);
      return (await db.runAsync(`UPDATE study_blocks SET ${sets.join(', ')} WHERE id = ?`, params)).changes > 0;
    },

    async markStepDone(blockId, sortOrder) {
      await db.runAsync('UPDATE study_block_steps SET done = 1 WHERE block_id = ? AND sort_order = ?', [blockId, sortOrder]);
    },

    async delete(id) {
      return (await db.runAsync('DELETE FROM study_blocks WHERE id = ?', [id])).changes > 0;
    },
  };
}
