import { InvalidOperationError, NotFoundError } from '../../../core/errors';
import type { NewBlockInput, StudyBlock } from '../models/studyBlock';
import type { BlockRepository } from '../repositories/blockRepository';

export interface BlockService {
  create(input: NewBlockInput): Promise<StudyBlock>;
  /** Starts the session now: step 1 begins. */
  start(id: string): Promise<StudyBlock>;
  /** Finishes the current step and begins the next one (or ends the session after the last step). */
  nextStep(id: string): Promise<StudyBlock>;
  finish(id: string): Promise<StudyBlock>;
  cancel(id: string): Promise<StudyBlock>;
  delete(id: string): Promise<void>;
}

export function createBlockService(repo: BlockRepository, options: { now?: () => number } = {}): BlockService {
  const now = options.now ?? (() => Date.now());

  async function require(id: string): Promise<StudyBlock> {
    const b = await repo.get(id);
    if (!b) throw new NotFoundError('جلسه');
    return b;
  }
  async function reload(id: string): Promise<StudyBlock> {
    return require(id);
  }

  return {
    create: (input) => repo.create(input),

    async start(id) {
      const b = await require(id);
      if (b.status !== 'planned') throw new InvalidOperationError('این جلسه قبلاً شروع شده یا تمام شده است');
      const t = now();
      await repo.setState(id, { status: 'running', startedAt: t, currentStep: 0, stepStartedAt: t });
      return reload(id);
    },

    async nextStep(id) {
      const b = await require(id);
      if (b.status !== 'running') throw new InvalidOperationError('جلسه در حال اجرا نیست');
      const t = now();
      await repo.markStepDone(id, b.currentStep);
      if (b.currentStep >= b.steps.length - 1) {
        await repo.setState(id, { status: 'done', finishedAt: t, stepStartedAt: null });
      } else {
        await repo.setState(id, { currentStep: b.currentStep + 1, stepStartedAt: t });
      }
      return reload(id);
    },

    async finish(id) {
      const b = await require(id);
      if (b.status !== 'running') throw new InvalidOperationError('جلسه در حال اجرا نیست');
      await repo.markStepDone(id, b.currentStep);
      await repo.setState(id, { status: 'done', finishedAt: now(), stepStartedAt: null });
      return reload(id);
    },

    async cancel(id) {
      const b = await require(id);
      if (b.status === 'done' || b.status === 'cancelled') throw new InvalidOperationError('این جلسه تمام شده است');
      await repo.setState(id, { status: 'cancelled', finishedAt: now(), stepStartedAt: null });
      return reload(id);
    },

    async delete(id) {
      if (!(await repo.delete(id))) throw new NotFoundError('جلسه');
    },
  };
}
