import { toPersianDigits } from '../../../core/calendar/format';
import type { StudyBlock } from '../models/studyBlock';

export const MINUTE_MS = 60_000;
export const BLOCK_PREFIX = 'block-';
export const TOTAL_OPTIONS = [30, 45, 60, 90] as const;

const TEMPLATE = [
  { title: 'انتخاب مبحث و هدف جلسه', share: 1 / 12 },
  { title: 'یادگیری یا مرور مطالب اصلی', share: 5 / 12 },
  { title: 'تمرین با تست یا مثال', share: 1 / 3 },
  { title: 'خودآزمایی بدون جزوه', share: 1 / 6 },
];

/** Default steps for a session of `totalMinutes` (60 min -> 5 / 25 / 20 / 10), in 5-minute units. */
export function defaultSteps(totalMinutes: number): { title: string; minutes: number }[] {
  const total = Math.max(20, Math.round(totalMinutes / 5) * 5);
  const mins = TEMPLATE.map((t) => Math.max(5, Math.round((total * t.share) / 5) * 5));
  mins[1] += total - mins.reduce((a, b) => a + b, 0); // keep the sum exact
  return TEMPLATE.map((t, i) => ({ title: t.title, minutes: mins[i] }));
}

export function totalMinutes(steps: { minutes: number }[]): number {
  return steps.reduce((a, s) => a + s.minutes, 0);
}

export interface RunState {
  index: number;
  title: string;
  minutes: number;
  endsAt: number;
  /** Negative when the step ran over its time. */
  remainingMs: number;
  /** 0..1 progress inside the current step. */
  progress: number;
  isLast: boolean;
  nextTitle: string | null;
}

/** State of a running session at `now`; null when it is not running. */
export function currentRun(block: StudyBlock, now: number): RunState | null {
  if (block.status !== 'running' || block.stepStartedAt === null) return null;
  const step = block.steps[block.currentStep];
  if (!step) return null;
  const endsAt = block.stepStartedAt + step.minutes * MINUTE_MS;
  const length = step.minutes * MINUTE_MS;
  return {
    index: block.currentStep,
    title: step.title,
    minutes: step.minutes,
    endsAt,
    remainingMs: endsAt - now,
    progress: Math.min(1, Math.max(0, (now - block.stepStartedAt) / length)),
    isLast: block.currentStep === block.steps.length - 1,
    nextTitle: block.steps[block.currentStep + 1]?.title ?? null,
  };
}

/** "۱۲:۳۴" (minutes:seconds, Persian digits); never negative. */
export function formatCountdown(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return toPersianDigits(`${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`);
}

export interface BlockNotification {
  id: string;
  blockId: string;
  kind: 'start' | 'step' | 'end';
  fireAt: number;
  title: string;
  body: string;
}

const label = (b: StudyBlock) => b.subjectName ?? b.title;

/**
 * Alerts for sessions: a planned session rings at its start time; a running session gets a short chime at the
 * end of every step ("next step: ...") and a final one when it is over. Past moments are dropped.
 */
export function planBlockNotifications(blocks: StudyBlock[], now: number): BlockNotification[] {
  const out: BlockNotification[] = [];
  for (const b of blocks) {
    if (b.steps.length === 0) continue;
    if (b.status === 'planned') {
      if (b.startAt > now) {
        out.push({
          id: `${BLOCK_PREFIX}${b.id}-start`,
          blockId: b.id,
          kind: 'start',
          fireAt: b.startAt,
          title: `⏰ وقت جلسه‌ی ${label(b)}`,
          body: `مرحله‌ی اول: ${b.steps[0].title} (${toPersianDigits(b.steps[0].minutes)} دقیقه). برای شروع بزنید.`,
        });
      }
    } else if (b.status === 'running' && b.stepStartedAt !== null) {
      let t = b.stepStartedAt;
      for (let i = b.currentStep; i < b.steps.length; i++) {
        t += b.steps[i].minutes * MINUTE_MS;
        if (t <= now) continue;
        const next = b.steps[i + 1];
        out.push(
          next
            ? {
                id: `${BLOCK_PREFIX}${b.id}-step-${i + 1}`,
                blockId: b.id,
                kind: 'step',
                fireAt: t,
                title: `⏭ مرحله‌ی بعد: ${next.title}`,
                body: `${toPersianDigits(next.minutes)} دقیقه · ${label(b)}`,
              }
            : {
                id: `${BLOCK_PREFIX}${b.id}-end`,
                blockId: b.id,
                kind: 'end',
                fireAt: t,
                title: '🎉 جلسه تمام شد',
                body: `آفرین! «${label(b)}» کامل شد. مباحث تازه را برای مرور ثبت کنید.`,
              },
        );
      }
    }
  }
  return out.sort((a, b) => a.fireAt - b.fireAt);
}
