import type { DbClient } from '../core/database/connection/types';
import { createCategoryRepository } from '../features/categories/repositories/categoryRepository';
import { createReminderRepository } from '../features/reminders/repositories/reminderRepository';
import { createBlockRepository } from '../features/study/repositories/blockRepository';
import { createStudyRepository } from '../features/study/repositories/studyRepository';
import { createSettingsRepository } from '../features/settings/repositories/settingsRepository';
import { createTaskRepository } from '../features/tasks/repositories/taskRepository';

export function createRepositories(db: DbClient, options: { now?: () => number } = {}) {
  return {
    tasks: createTaskRepository(db, options),
    categories: createCategoryRepository(db, options),
    settings: createSettingsRepository(db, options),
    reminders: createReminderRepository(db),
    study: createStudyRepository(db, options),
    blocks: createBlockRepository(db, options),
  };
}

export type Repositories = ReturnType<typeof createRepositories>;
