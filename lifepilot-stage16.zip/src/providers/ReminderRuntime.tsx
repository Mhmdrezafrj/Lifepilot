import { useEffect, useRef } from 'react';
import { AppState, ToastAndroid } from 'react-native';
import * as Notifications from 'expo-notifications';
import { useRootNavigationState, useRouter } from 'expo-router';
import { forecast } from '@/features/study/services/reviewQueue';
import { planStudyReminders } from '@/features/study/services/studyPlan';
import { STUDY_PROFILE_KEY, parseStudyProfile } from '@/features/study/services/studyProfile';
import { planBlockNotifications } from '@/features/study/services/blockPlanner';
import { NUDGE_SETTINGS_KEY, parseNudgeSettings } from '@/features/nudges/services/nudgeSettings';
import { planNudges, planSummaries } from '@/features/nudges/services/nudgePlanner';
import { replaceBlockNotifications, replaceNudges, replaceStudyReminders, setupNotifications } from '@/infrastructure/notifications/expoNotificationGateway';
import { isStudyResponse, isSummaryResponse, parseBlockResponse, parseReminderResponse, ReminderResponse } from '@/infrastructure/notifications/notificationResponse';
import { useDataStore } from '@/shared/state/dataStore';
import { useRepositories, useServices } from './DatabaseProvider';

/**
 * Keeps reminders alive and reacts to them. Renders nothing.
 * 1) On start and whenever the app returns to the foreground it rebuilds every reminder from the
 *    database (covers app updates, time zone changes, cleared alarms, and permission changes).
 *    After a phone restart Android re-creates scheduled notifications by itself.
 * 2) It handles taps on a notification and its "done" / "10 minutes later" buttons.
 */
export function ReminderRuntime() {
  const repos = useRepositories();
  const services = useServices();
  const router = useRouter();
  const navState = useRootNavigationState();
  const bump = useDataStore((s) => s.bump);
  const version = useDataStore((s) => s.version);
  const lastResponse = Notifications.useLastNotificationResponse();
  const handled = useRef<string | null>(null);

  // Daily "time to review" reminders follow the study data and profile.
  useEffect(() => {
    const timer = setTimeout(() => {
      void (async () => {
        try {
          const profile = parseStudyProfile(await repos.settings.get(STUDY_PROFILE_KEY));
          const topics = await repos.study.listTopics();
          const t = Date.now();
          await replaceStudyReminders(planStudyReminders(forecast(topics, t, 7), profile, t));
        } catch {
          /* best effort */
        }
      })();
    }, 800);
    return () => clearTimeout(timer);
  }, [repos, version]);

  // Study-session alerts follow the sessions' state.
  useEffect(() => {
    const timer = setTimeout(() => {
      void (async () => {
        try {
          const blocks = await repos.blocks.list({ statuses: ['planned', 'running'] });
          await replaceBlockNotifications(planBlockNotifications(blocks, Date.now()));
        } catch {
          /* best effort */
        }
      })();
    }, 300); // short delay: a step chime must be scheduled right after the user moves on
    return () => clearTimeout(timer);
  }, [repos, version]);

  // Random extra reminders and the morning summary follow the tasks and the nudge settings.
  useEffect(() => {
    const timer = setTimeout(() => {
      void (async () => {
        try {
          const settings = parseNudgeSettings(await repos.settings.get(NUDGE_SETTINGS_KEY));
          const pending = await repos.tasks.list({ status: 'pending' });
          const t = Date.now();
          await replaceNudges(planNudges(pending, settings, t), planSummaries(pending, settings, t));
        } catch {
          /* best effort */
        }
      })();
    }, 1000);
    return () => clearTimeout(timer);
  }, [repos, version]);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') bump(); // rebuild everything when the app comes back
    });
    return () => sub.remove();
  }, [bump]);

  useEffect(() => {
    const sync = async () => {
      try {
        await setupNotifications();
        const pending = await repos.tasks.list({ status: 'pending' });
        await services.scheduler.rescheduleAll(pending);
      } catch {
        /* reminders are best effort; the app keeps working */
      }
    };
    void sync();
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') void sync();
    });
    return () => sub.remove();
  }, [repos, services]);

  useEffect(() => {
    if (!lastResponse || !navState?.key) return;
    const id = `${lastResponse.notification.request.identifier}|${lastResponse.actionIdentifier}|${lastResponse.notification.date}`;
    if (handled.current === id) return;
    handled.current = id;

    const blockId = parseBlockResponse(lastResponse.notification.request.content.data);
    if (blockId) {
      router.push(`/study/session/${blockId}`);
      return;
    }
    if (isSummaryResponse(lastResponse.notification.request.content.data)) {
      router.push('/(tabs)/tasks');
      return;
    }
    if (isStudyResponse(lastResponse.notification.request.content.data)) {
      router.push('/study/review');
      return;
    }

    const parsed = parseReminderResponse(
      lastResponse.actionIdentifier,
      lastResponse.notification.request.content.data,
      lastResponse.actionIdentifier === Notifications.DEFAULT_ACTION_IDENTIFIER,
    );
    if (!parsed) return;

    void (async () => {
      await recordEvent(parsed);
      try {
        if (parsed.kind === 'complete') {
          await services.tasks.complete(parsed.taskId);
          ToastAndroid.show('کار انجام شد ✅', ToastAndroid.SHORT);
        } else if (parsed.kind === 'snooze') {
          await services.tasks.snooze(parsed.taskId, parsed.minutes ?? 10);
          ToastAndroid.show('۱۰ دقیقه دیگر یادآوری می‌شود', ToastAndroid.SHORT);
        } else {
          router.push(`/task/${parsed.taskId}`);
        }
      } catch {
        ToastAndroid.show('این کار دیگر پیدا نشد یا قبلاً انجام شده است', ToastAndroid.SHORT);
      } finally {
        bump();
      }
    })();

    async function recordEvent(r: ReminderResponse): Promise<void> {
      try {
        const e = await repos.reminders.createEvent({
          reminderId: r.reminderId,
          taskId: r.taskId,
          scheduledAt: r.plannedFireAt ?? Date.now(),
          deliveryStatus: 'delivered',
        });
        await repos.reminders.markTriggered(e.id, r.plannedFireAt ?? Date.now(), 'delivered');
        await repos.reminders.markAcknowledged(
          e.id, Date.now(), r.kind === 'complete' ? 'completed' : r.kind === 'snooze' ? 'snoozed' : 'dismissed',
        );
      } catch {
        /* history is optional (the task or reminder may have been deleted) */
      }
    }
  }, [lastResponse, navState?.key, repos, services, router, bump]);

  return null;
}
