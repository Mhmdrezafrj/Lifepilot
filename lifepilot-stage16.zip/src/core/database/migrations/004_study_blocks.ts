import type { Migration } from './types';

const SQL = `
-- A planned study session for a subject, made of ordered timed steps.
CREATE TABLE study_blocks (
  id TEXT PRIMARY KEY NOT NULL,
  subject_id TEXT REFERENCES study_subjects(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  start_at INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','running','done','cancelled')),
  current_step INTEGER NOT NULL DEFAULT 0,
  step_started_at INTEGER,
  started_at INTEGER,
  finished_at INTEGER,
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_study_blocks_start ON study_blocks(start_at);
CREATE INDEX idx_study_blocks_status ON study_blocks(status, start_at);

CREATE TABLE study_block_steps (
  id TEXT PRIMARY KEY NOT NULL,
  block_id TEXT NOT NULL REFERENCES study_blocks(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  minutes INTEGER NOT NULL CHECK (minutes >= 1),
  sort_order INTEGER NOT NULL,
  done INTEGER NOT NULL DEFAULT 0 CHECK (done IN (0,1))
);
CREATE INDEX idx_study_block_steps_block ON study_block_steps(block_id, sort_order);
`;

export const migration004: Migration = {
  version: 4,
  name: 'study_blocks',
  up: async (db) => {
    await db.execAsync(SQL);
  },
};
