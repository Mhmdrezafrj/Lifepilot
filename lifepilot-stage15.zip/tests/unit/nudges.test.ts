import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { Task } from '../../src/features/tasks/models/task';
import {
  DEFAULT_NUDGE_SETTINGS, NudgeSettings, parseNudgeSettings, serializeNudgeSettings,
} from '../../src/features/nudges/services/nudgeSettings';
import {
  pickNudgeTimes, planNudges, planSummaries, seededRandom,
} from '../../src/features/nudges/services/nudgePlanner';
import { isSummaryResponse } from '../../src/infrastructure/notifications/notificationResponse';

const at = (d: number, h = 0, m = 0) => new Date(2026, 10, d, h, m).getTime();
const NOW = at(5, 12);
const S: NudgeSettings = { ...DEFAULT_NUDGE_SETTINGS, perTask: 3 };
const task = (over: Partial<Task>): Task => ({
  id: 't1', title: 'جلسه', description: null, dueAt: at(6, 18), hasTime: true, priority: 'medium', categoryId: null,
  status: 'pending', snoozedUntil: null, createdAt: at(4, 9), updatedAt: 0, completedAt: null, recurrenceId: null,
  tags: [], checklist: [], reminders: [], recurrence: null, ...over,
});
const hourOf = (t: number) => new Date(t).getHours() + new Date(t).getMinutes() / 60;

describe('nudge settings', () => {
  it('uses defaults for bad data and round-trips valid data', () => {
    assert.deepEqual(parseNudgeSettings(null), DEFAULT_NUDGE_SETTINGS);
    assert.deepEqual(parseNudgeSettings('x'), DEFAULT_NUDGE_SETTINGS);
    assert.equal(parseNudgeSettings('{"perTask":99}').perTask, DEFAULT_NUDGE_SETTINGS.perTask);
    assert.equal(parseNudgeSettings('{"dayStartHour":10,"dayEndHour":12}').dayStartHour, 8); // window too short
    const s = { enabled: false, perTask: 5, dayStartHour: 9, dayEndHour: 23, summaryEnabled: false, summaryHour: 7 };
    assert.deepEqual(parseNudgeSettings(serializeNudgeSettings(s)), s);
  });
});

describe('random times', () => {
  it('seeded generator is repeatable and in [0,1)', () => {
    const a = seededRandom('x'); const b = seededRandom('x'); const c = seededRandom('y');
    const xs = [a(), a(), a()]; const ys = [b(), b(), b()];
    assert.deepEqual(xs, ys);
    assert.notDeepEqual(xs, [c(), c(), c()]);
    assert.ok(xs.every((v) => v >= 0 && v < 1));
  });

  it('picks the requested number of times inside waking hours, spaced at least 45 minutes', () => {
    const times = pickNudgeTimes('seed', at(5, 0), at(6, 0), 4, S);
    assert.equal(times.length, 4);
    for (const t of times) assert.ok(hourOf(t) >= 8 && hourOf(t) < 22);
    for (let i = 1; i < times.length; i++) assert.ok(times[i] - times[i - 1] >= 45 * 60_000);
    assert.deepEqual(times, [...times].sort((x, y) => x - y));
  });

  it('is stable for the same seed and different for another', () => {
    const a = pickNudgeTimes('a', at(5), at(6), 3, S);
    assert.deepEqual(a, pickNudgeTimes('a', at(5), at(6), 3, S));
    assert.notDeepEqual(a, pickNudgeTimes('b', at(5), at(6), 3, S));
  });

  it('returns fewer times when the window is too small, and none for an empty window', () => {
    assert.ok(pickNudgeTimes('s', at(5, 8), at(5, 9), 5, S).length <= 2);
    assert.deepEqual(pickNudgeTimes('s', at(5, 23), at(6, 7), 3, S), []); // night only
    assert.deepEqual(pickNudgeTimes('s', at(6), at(5), 3, S), []);
  });
});

describe('planNudges', () => {
  it('plans extra reminders in the 24h before a timed task, never after it', () => {
    const n = planNudges([task({})], S, NOW);
    assert.ok(n.length >= 1 && n.length <= 3);
    for (const x of n) {
      assert.ok(x.fireAt > NOW);
      assert.ok(x.fireAt <= at(6, 18) - 15 * 60_000);
      assert.ok(x.fireAt >= at(5, 18));
      assert.ok(hourOf(x.fireAt) >= 8 && hourOf(x.fireAt) < 22);
      assert.equal(x.taskId, 't1');
      assert.ok(x.body.includes('جلسه'));
    }
    assert.equal(new Set(n.map((x) => x.id)).size, n.length);
  });

  it('does not move times when the schedule is rebuilt later, it only drops the ones in the past', () => {
    const early = planNudges([task({})], S, at(5, 10));
    const later = planNudges([task({})], S, at(5, 20));
    for (const x of later) assert.ok(early.some((y) => y.id === x.id && y.fireAt === x.fireAt && y.body === x.body));
  });

  it('skips completed, undated tasks, and respects off / zero', () => {
    assert.deepEqual(planNudges([task({ status: 'completed' }), task({ dueAt: null })], S, NOW), []);
    assert.deepEqual(planNudges([task({})], { ...S, enabled: false }, NOW), []);
    assert.deepEqual(planNudges([task({})], { ...S, perTask: 0 }, NOW), []);
  });

  it('gives date-only tasks up to two reminders during their day', () => {
    const n = planNudges([task({ hasTime: false, dueAt: at(5), createdAt: at(4) })], S, at(5, 7));
    assert.ok(n.length >= 1 && n.length <= 2);
    for (const x of n) {
      assert.equal(new Date(x.fireAt).getDate(), 5);
      assert.ok(x.body.includes('امروز'));
    }
  });

  it('caps the total number of notifications, nearest first', () => {
    const many = Array.from({ length: 50 }, (_, i) => task({ id: `t${i}`, dueAt: at(6, 18) }));
    const n = planNudges(many, S, NOW, 20);
    assert.equal(n.length, 20);
    assert.deepEqual(n.map((x) => x.fireAt), [...n.map((x) => x.fireAt)].sort((a, b) => a - b));
  });
});

describe('morning summary', () => {
  it('lists the day\'s tasks and counts overdue ones', () => {
    const tasks = [
      task({ id: 'a', title: 'اول', dueAt: at(6, 9) }),
      task({ id: 'b', title: 'دوم', dueAt: at(6, 15) }),
      task({ id: 'c', title: 'سوم', dueAt: at(6, 16) }),
      task({ id: 'd', title: 'چهارم', dueAt: at(6, 17) }),
      task({ id: 'old', title: 'قدیمی', dueAt: at(1, 9) }),
    ];
    const s = planSummaries(tasks, DEFAULT_NUDGE_SETTINGS, NOW);
    assert.equal(s.length, 1);
    assert.equal(s[0].fireAt, at(6, 8));
    assert.ok(s[0].body.includes('۴ کار'));
    assert.ok(s[0].body.includes('«اول»'));
    assert.ok(s[0].body.includes('۱ کار دیگر'));
  });

  it('mentions overdue tasks today, skips days without tasks, and respects the setting', () => {
    const old = task({ id: 'old', dueAt: at(1, 9) });
    const early = at(5, 6);
    const s = planSummaries([old], DEFAULT_NUDGE_SETTINGS, early);
    assert.equal(s.length, 1);
    assert.ok(s[0].body.includes('عقب‌افتاده'));
    assert.deepEqual(planSummaries([task({})], { ...DEFAULT_NUDGE_SETTINGS, summaryEnabled: false }, NOW), []);
    assert.deepEqual(planSummaries([], DEFAULT_NUDGE_SETTINGS, NOW), []);
  });

  it('recognises the summary notification', () => {
    assert.equal(isSummaryResponse({ type: 'daily-summary' }), true);
    assert.equal(isSummaryResponse({ type: 'study-review' }), false);
    assert.equal(isSummaryResponse(null), false);
  });
});
