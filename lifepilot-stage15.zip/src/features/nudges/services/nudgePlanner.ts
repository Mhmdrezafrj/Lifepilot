import { addDays, localDayNumber, startOfDay } from '../../../core/calendar/dates';
import { formatTime, toPersianDigits } from '../../../core/calendar/format';
import { formatOffset } from '../../../infrastructure/notifications/reminderText';
import type { Task } from '../../tasks/models/task';
import { isOverdue } from '../../tasks/services/taskStatus';
import type { NudgeSettings } from './nudgeSettings';

const MINUTE = 60_000;
const HOUR = 3_600_000;
const SLOT = 15 * MINUTE;
const MIN_GAP = 45 * MINUTE;
/** Timed tasks get their extra reminders in the last 24 hours before they are due. */
const LEAD = 24 * HOUR;

export const NUDGE_PREFIX = 'nudge-';
export const SUMMARY_PREFIX = 'summary-';

/** Small seeded random generator: the same seed always gives the same numbers. */
export function seededRandom(seed: string): () => number {
  let h = 1779033703 ^ seed.length;
  for (let i = 0; i < seed.length; i++) {
    h = Math.imul(h ^ seed.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  let a = h >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle<T>(items: T[], rnd: () => number): T[] {
  const a = [...items];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function inWakingHours(t: number, s: NudgeSettings): boolean {
  const d = new Date(t);
  const h = d.getHours() + d.getMinutes() / 60;
  return h >= s.dayStartHour && h < s.dayEndHour;
}

/** Random-looking but stable times inside [from, to), only in waking hours, at least 45 minutes apart. */
export function pickNudgeTimes(seed: string, from: number, to: number, count: number, s: NudgeSettings): number[] {
  if (count <= 0 || to <= from) return [];
  const slots: number[] = [];
  for (let t = Math.ceil(from / SLOT) * SLOT; t < to; t += SLOT) if (inWakingHours(t, s)) slots.push(t);
  const picked: number[] = [];
  for (const t of shuffle(slots, seededRandom(seed))) {
    if (picked.length >= count) break;
    if (picked.every((p) => Math.abs(p - t) >= MIN_GAP)) picked.push(t);
  }
  return picked.sort((a, b) => a - b);
}

export interface PlannedNudge {
  id: string;
  taskId: string;
  fireAt: number;
  title: string;
  body: string;
}

const TITLES = ['⏰ نزدیک موعد', '📌 یادآوری کار', '🔔 یادت نره'];

function nudgeBody(task: Task, fireAt: number, rnd: () => number): string {
  const due = task.dueAt as number;
  if (!task.hasTime) return `امروز باید «${task.title}» را انجام بدهی.`;
  const left = formatOffset(Math.max(1, Math.round((due - fireAt) / MINUTE)));
  const time = formatTime(new Date(due));
  const options = [
    `«${task.title}» ساعت ${time} موعد دارد؛ ${left} مانده.`,
    `یادت نرود: ${task.title} (ساعت ${time})`,
    `${left} تا «${task.title}». آماده‌ای؟`,
    `هنوز وقت داری، ولی «${task.title}» را فراموش نکن. ساعت ${time}.`,
  ];
  return options[Math.floor(rnd() * options.length)];
}

/**
 * Extra reminders at random (but stable) times for pending tasks. The same task always gets the same
 * times, so rebuilding the schedule when the app opens does not move them. Past times are dropped.
 */
export function planNudges(tasks: Task[], s: NudgeSettings, now: number, maxTotal = 100): PlannedNudge[] {
  if (!s.enabled || s.perTask <= 0) return [];
  const out: PlannedNudge[] = [];
  for (const t of tasks) {
    if (t.status !== 'pending' || t.dueAt === null) continue;
    let times: number[];
    if (t.hasTime) {
      const from = Math.max(t.dueAt - LEAD, t.createdAt + 10 * MINUTE);
      times = pickNudgeTimes(`${t.id}|${t.dueAt}`, from, t.dueAt - 15 * MINUTE, s.perTask, s);
    } else {
      const day = startOfDay(new Date(t.dueAt)).getTime();
      const from = Math.max(day, t.createdAt + 10 * MINUTE);
      times = pickNudgeTimes(`${t.id}|${day}`, from, addDays(new Date(day), 1).getTime(), Math.min(2, s.perTask), s);
    }
    times.forEach((fireAt, i) => {
      if (fireAt <= now + MINUTE) return;
      const rnd = seededRandom(`${t.id}|${t.dueAt}|msg|${i}`);
      out.push({
        id: `${NUDGE_PREFIX}${t.id}-${i}`,
        taskId: t.id,
        fireAt,
        title: TITLES[Math.floor(rnd() * TITLES.length)],
        body: nudgeBody(t, fireAt, rnd),
      });
    });
  }
  return out.sort((a, b) => a.fireAt - b.fireAt).slice(0, maxTotal);
}

export interface PlannedSummary {
  id: string;
  fireAt: number;
  title: string;
  body: string;
}

/** A morning notification for each of the next days that has tasks: "امروز ۳ کار داری: …". */
export function planSummaries(tasks: Task[], s: NudgeSettings, now: number, days = 7): PlannedSummary[] {
  if (!s.summaryEnabled) return [];
  const today = startOfDay(new Date(now));
  const out: PlannedSummary[] = [];
  for (let i = 0; i < days; i++) {
    const day = addDays(today, i);
    const dayNo = localDayNumber(day);
    const due = tasks.filter(
      (t) => t.status === 'pending' && t.dueAt !== null && localDayNumber(new Date(t.dueAt)) === dayNo,
    );
    const overdue = i === 0 ? tasks.filter((t) => isOverdue(t, now) && localDayNumber(new Date(t.dueAt as number)) < dayNo).length : 0;
    if (due.length === 0 && overdue === 0) continue;
    const fireAt = new Date(day.getFullYear(), day.getMonth(), day.getDate(), s.summaryHour, 0).getTime();
    if (fireAt <= now) continue;

    const names = due.slice(0, 3).map((t) => `«${t.title}»`).join('، ');
    const more = due.length > 3 ? ` و ${toPersianDigits(due.length - 3)} کار دیگر` : '';
    const parts: string[] = [];
    if (due.length > 0) parts.push(`امروز ${toPersianDigits(due.length)} کار داری: ${names}${more}.`);
    if (overdue > 0) parts.push(`${toPersianDigits(overdue)} کار عقب‌افتاده هم هست.`);
    out.push({ id: `${SUMMARY_PREFIX}${dayNo}`, fireAt, title: 'برنامه‌ی امروز ☀️', body: parts.join(' ') });
  }
  return out;
}
