export const NUDGE_SETTINGS_KEY = 'nudge_settings';

export interface NudgeSettings {
  /** Extra reminders at random times before a task is due. */
  enabled: boolean;
  /** How many extra reminders per task (0..5). */
  perTask: number;
  /** Waking hours: reminders only fire from dayStartHour up to dayEndHour (24h clock). */
  dayStartHour: number;
  dayEndHour: number;
  /** One notification each morning listing the day's tasks. */
  summaryEnabled: boolean;
  summaryHour: number;
}

export const DEFAULT_NUDGE_SETTINGS: NudgeSettings = {
  enabled: true,
  perTask: 3,
  dayStartHour: 8,
  dayEndHour: 22,
  summaryEnabled: true,
  summaryHour: 8,
};

export const PER_TASK_OPTIONS = [1, 2, 3, 4, 5] as const;
export const WAKING_WINDOWS = [
  { start: 7, end: 21 },
  { start: 8, end: 22 },
  { start: 9, end: 23 },
] as const;
export const SUMMARY_HOURS = [7, 8, 9, 10] as const;

const int = (v: unknown, lo: number, hi: number, fallback: number) =>
  typeof v === 'number' && Number.isInteger(v) && v >= lo && v <= hi ? v : fallback;

export function parseNudgeSettings(raw: string | null): NudgeSettings {
  if (!raw) return DEFAULT_NUDGE_SETTINGS;
  try {
    const o = JSON.parse(raw) as Record<string, unknown>;
    const start = int(o.dayStartHour, 0, 23, DEFAULT_NUDGE_SETTINGS.dayStartHour);
    const end = int(o.dayEndHour, 1, 24, DEFAULT_NUDGE_SETTINGS.dayEndHour);
    const validWindow = end - start >= 6;
    return {
      enabled: typeof o.enabled === 'boolean' ? o.enabled : DEFAULT_NUDGE_SETTINGS.enabled,
      perTask: int(o.perTask, 0, 5, DEFAULT_NUDGE_SETTINGS.perTask),
      dayStartHour: validWindow ? start : DEFAULT_NUDGE_SETTINGS.dayStartHour,
      dayEndHour: validWindow ? end : DEFAULT_NUDGE_SETTINGS.dayEndHour,
      summaryEnabled: typeof o.summaryEnabled === 'boolean' ? o.summaryEnabled : DEFAULT_NUDGE_SETTINGS.summaryEnabled,
      summaryHour: int(o.summaryHour, 0, 23, DEFAULT_NUDGE_SETTINGS.summaryHour),
    };
  } catch {
    return DEFAULT_NUDGE_SETTINGS;
  }
}

export function serializeNudgeSettings(s: NudgeSettings): string {
  return JSON.stringify(s);
}
