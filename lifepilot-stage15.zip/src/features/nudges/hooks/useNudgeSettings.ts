import { useCallback, useEffect, useState } from 'react';
import { useRepositories } from '@/providers/DatabaseProvider';
import { useDataStore } from '@/shared/state/dataStore';
import {
  DEFAULT_NUDGE_SETTINGS, NUDGE_SETTINGS_KEY, NudgeSettings, parseNudgeSettings, serializeNudgeSettings,
} from '../services/nudgeSettings';

export function useNudgeSettings(): { settings: NudgeSettings; loaded: boolean; save: (s: NudgeSettings) => Promise<void> } {
  const repo = useRepositories().settings;
  const bump = useDataStore((s) => s.bump);
  const [settings, setSettings] = useState<NudgeSettings>(DEFAULT_NUDGE_SETTINGS);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    repo
      .get(NUDGE_SETTINGS_KEY)
      .then((raw) => {
        if (!cancelled) {
          setSettings(parseNudgeSettings(raw));
          setLoaded(true);
        }
      })
      .catch(() => {
        if (!cancelled) setLoaded(true);
      });
    return () => {
      cancelled = true;
    };
  }, [repo]);

  const save = useCallback(
    async (s: NudgeSettings) => {
      await repo.set(NUDGE_SETTINGS_KEY, serializeNudgeSettings(s));
      setSettings(s);
      bump(); // the schedule is rebuilt with the new settings
    },
    [repo, bump],
  );

  return { settings, loaded, save };
}
