/** Android channel settings cannot change after creation, so changed channels get a new id. */
export const LEGACY_CHANNEL_ID = 'reminders';
export const REMINDER_CHANNEL_ID = 'reminders_v2';
export const ALARM_CHANNEL_ID = 'reminders_alarm_v1';
export const ALARM_SOUND_FILE = 'lifepilot_alarm.wav';
export const REMINDER_CATEGORY = 'task-reminder';
export const ACTION_COMPLETE = 'complete';
export const ACTION_SNOOZE = 'snooze10';
export const SNOOZE_MINUTES = 10;

export interface ReminderResponse {
  kind: 'open' | 'complete' | 'snooze';
  taskId: string;
  reminderId: string | null;
  /** When the notification was planned to fire (epoch ms), if known. */
  plannedFireAt: number | null;
  minutes?: number;
}

/**
 * Understands a tap on a reminder notification or on one of its buttons.
 * Returns null for anything that is not a valid reminder notification.
 */
export function parseReminderResponse(actionId: string, data: unknown, isDefaultAction: boolean): ReminderResponse | null {
  if (typeof data !== 'object' || data === null) return null;
  const d = data as Record<string, unknown>;
  if (typeof d.taskId !== 'string' || d.taskId === '') return null;

  const base = {
    taskId: d.taskId,
    reminderId: typeof d.reminderId === 'string' ? d.reminderId : null,
    plannedFireAt: typeof d.plannedFireAt === 'number' ? d.plannedFireAt : null,
  };
  if (actionId === ACTION_COMPLETE) return { kind: 'complete', ...base };
  if (actionId === ACTION_SNOOZE) return { kind: 'snooze', minutes: SNOOZE_MINUTES, ...base };
  if (isDefaultAction) return { kind: 'open', ...base };
  return null;
}

export const STUDY_PREFIX = 'study-';
export const STUDY_DATA_TYPE = 'study-review';

/** True for the daily "time to review" notification. */
export function isStudyResponse(data: unknown): boolean {
  return typeof data === 'object' && data !== null && (data as Record<string, unknown>).type === STUDY_DATA_TYPE;
}

export const SUMMARY_DATA_TYPE = 'daily-summary';

/** True for the morning "today's tasks" notification. */
export function isSummaryResponse(data: unknown): boolean {
  return typeof data === 'object' && data !== null && (data as Record<string, unknown>).type === SUMMARY_DATA_TYPE;
}
