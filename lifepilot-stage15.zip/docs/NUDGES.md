# Smart reminders (stage 15)
- Extra reminders at random times before each task: timed tasks get up to N (1-5) in the last 24 h, only in waking hours,
  >= 45 min apart; date-only tasks get up to 2 on their day. Times come from a seeded generator, so the same task keeps the same times
  when the schedule is rebuilt (app open / foreground / any data change). Messages vary.
- Morning summary: each morning (default 08:00) for the next 7 days that have tasks: "امروز N کار داری: «..»" plus overdue count.
- At most 100 extra notifications are scheduled (nearest first). All are normal notifications (not the alarm ring).
- Settings -> notifications -> یادآوری هوشمند. Tap: a nudge opens the task; the summary opens the tasks tab.
- Limits: schedule is rebuilt only when the app runs; if the app is not opened for days, only already scheduled ones fire.
