import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_MAX_INTERVAL_DAYS, INITIAL_SRS_STATE, MAX_EASE, MIN_EASE, Rating, SrsState, daysUntil, examMaxInterval, nextState,
} from '../../src/features/study/services/srs';

const run = (ratings: Rating[], max?: number) => {
  const out: SrsState[] = [];
  let s = INITIAL_SRS_STATE;
  for (const r of ratings) {
    s = nextState(s, r, max);
    out.push(s);
  }
  return out;
};

describe('spaced repetition', () => {
  it('starts with a 1-day first review', () => {
    assert.deepEqual(INITIAL_SRS_STATE, { intervalDays: 1, ease: 2.5, repetitions: 0, lapses: 0 });
  });

  it('good answers give 3, 7 days and then grow by the ease factor', () => {
    const s = run([2, 2, 2, 2]);
    assert.deepEqual(s.map((x) => x.intervalDays), [3, 7, 18, 45]); // 7*2.5=17.5->18, 18*2.5=45
    assert.equal(s[3].repetitions, 4);
    assert.equal(s[3].ease, 2.5);
  });

  it('easy answers grow faster and raise the ease (up to a limit)', () => {
    const s = run([3, 3, 3]);
    // third easy answer uses the ease reached after the second one: 2.5 -> 2.65 -> 2.8
    assert.deepEqual(s.map((x) => x.intervalDays), [5, 10, Math.round(10 * 2.8 * 1.3)]);
    assert.deepEqual(s.map((x) => x.ease), [2.65, 2.8, 2.95]);
    assert.ok(run(Array(30).fill(3))[29].ease <= MAX_EASE);
  });

  it('hard answers grow slowly and lower the ease', () => {
    const s = nextState({ intervalDays: 10, ease: 2.5, repetitions: 3, lapses: 0 }, 1);
    assert.equal(s.intervalDays, 12);
    assert.equal(s.ease, 2.35);
    assert.equal(s.repetitions, 4);
  });

  it('forgetting resets the progress, counts a lapse and lowers the ease', () => {
    const s = nextState({ intervalDays: 45, ease: 2.5, repetitions: 4, lapses: 1 }, 0);
    assert.deepEqual(s, { intervalDays: 1, ease: 2.3, repetitions: 0, lapses: 2 });
  });

  it('never lets the ease fall below the minimum', () => {
    let s = INITIAL_SRS_STATE;
    for (let i = 0; i < 20; i++) s = nextState(s, 0);
    assert.equal(s.ease, MIN_EASE);
    assert.equal(s.lapses, 20);
  });

  it('keeps every interval at least 1 day and within the maximum', () => {
    for (const r of [0, 1, 2, 3] as Rating[]) assert.ok(nextState(INITIAL_SRS_STATE, r).intervalDays >= 1);
    const long = run(Array(12).fill(3));
    assert.ok(long.every((x) => x.intervalDays <= DEFAULT_MAX_INTERVAL_DAYS));
    assert.equal(long[11].intervalDays, DEFAULT_MAX_INTERVAL_DAYS);
    assert.ok(run([2, 2, 2, 2], 10).every((x) => x.intervalDays <= 10));
    assert.equal(nextState(INITIAL_SRS_STATE, 3, 0).intervalDays, 1);
  });

  it('a later review of a forgotten topic starts again from 3 days', () => {
    assert.deepEqual(run([2, 2, 0, 2, 2]).map((x) => x.intervalDays), [3, 7, 1, 3, 7]);
  });
});

describe('exam date', () => {
  it('limits the gap so there are about 3 reviews before the exam', () => {
    assert.equal(examMaxInterval(null), DEFAULT_MAX_INTERVAL_DAYS);
    assert.equal(examMaxInterval(90), 30);
    assert.equal(examMaxInterval(30), 10);
    assert.equal(examMaxInterval(5), 1);
    assert.equal(examMaxInterval(0), 1);
    assert.equal(examMaxInterval(100000), DEFAULT_MAX_INTERVAL_DAYS);
  });

  it('counts whole calendar days until the exam', () => {
    const now = new Date(2026, 10, 5, 23, 0).getTime();
    assert.equal(daysUntil(new Date(2026, 10, 5).getTime(), now), 0);
    assert.equal(daysUntil(new Date(2026, 10, 6, 1).getTime(), now), 1);
    assert.equal(daysUntil(new Date(2027, 2, 10).getTime(), now), 125);
    assert.equal(daysUntil(new Date(2026, 10, 1).getTime(), now), -4);
  });
});
