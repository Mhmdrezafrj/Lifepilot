import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  QueueTopic, dueTopics, forecast, interleave, overdueDays, parseTopicList, sortByUrgency,
} from '../../src/features/study/services/reviewQueue';

const NOW = new Date(2026, 10, 5, 15, 0).getTime();
const day = (d: number) => new Date(2026, 10, d).getTime();
const topic = (id: string, over: Partial<QueueTopic> = {}): QueueTopic => ({
  id, subjectId: 's1', dueAt: day(5), ease: 2.5, lapses: 0, suspended: false, ...over,
});

describe('review queue', () => {
  it('counts late days', () => {
    assert.equal(overdueDays(day(5), NOW), 0);
    assert.equal(overdueDays(day(3), NOW), 2);
    assert.equal(overdueDays(day(9), NOW), 0);
  });

  it('keeps topics due today or late, skips future and suspended ones', () => {
    const list = [topic('a'), topic('b', { dueAt: day(2) }), topic('c', { dueAt: day(6) }), topic('d', { suspended: true })];
    assert.deepEqual(dueTopics(list, NOW).map((t) => t.id), ['a', 'b']);
  });

  it('orders by lateness, then weaker memory, then more lapses', () => {
    const list = [
      topic('today-strong', { ease: 2.8 }),
      topic('today-weak', { ease: 1.6 }),
      topic('late', { dueAt: day(2) }),
      topic('today-weak-lapses', { ease: 1.6, lapses: 3 }),
    ];
    assert.deepEqual(sortByUrgency(list, NOW).map((t) => t.id), ['late', 'today-weak-lapses', 'today-weak', 'today-strong']);
  });

  it('mixes subjects round-robin and keeps order inside each subject', () => {
    const list = [
      { id: 'm1', subjectId: 'math' }, { id: 'm2', subjectId: 'math' }, { id: 'm3', subjectId: 'math' },
      { id: 'p1', subjectId: 'phys' }, { id: 'p2', subjectId: 'phys' },
      { id: 'x1', subjectId: null },
    ];
    assert.deepEqual(interleave(list).map((t) => t.id), ['m1', 'p1', 'x1', 'm2', 'p2', 'm3']);
    assert.deepEqual(interleave([]), []);
  });

  it('forecasts the next days, counting late reviews as today', () => {
    const list = [topic('a', { dueAt: day(1) }), topic('b'), topic('c', { dueAt: day(6) }), topic('d', { dueAt: day(6) }),
      topic('e', { dueAt: day(20) }), topic('f', { suspended: true, dueAt: day(6) })];
    assert.deepEqual(forecast(list, NOW, 4), [2, 2, 0, 0]);
  });
});

describe('topic list parsing', () => {
  it('splits lines and commas, trims, removes list markers and duplicates', () => {
    assert.deepEqual(parseTopicList('فصل ۱\n- فصل ۲\n۳) فصل ۳\n\nفصل ۱'), ['فصل ۱', 'فصل ۲', 'فصل ۳']);
    assert.deepEqual(parseTopicList('حد، مشتق ، انتگرال; تابع'), ['حد', 'مشتق', 'انتگرال', 'تابع']);
  });

  it('keeps titles that only start with a number', () => {
    assert.deepEqual(parseTopicList('2 درجه معادله\n1. اول'), ['2 درجه معادله', 'اول']);
  });

  it('returns nothing for blank input', () => {
    assert.deepEqual(parseTopicList('  \n , \n'), []);
  });
});
