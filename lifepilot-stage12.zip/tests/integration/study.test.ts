import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createNodeClient } from '../helpers/nodeClient';
import { migrate, migrations } from '../../src/core/database/migrations';
import { createRepositories } from '../../src/providers/repositories';
import { createServices } from '../../src/providers/services';
import { InvalidOperationError, NotFoundError } from '../../src/core/errors';

let clock = new Date(2026, 10, 5, 10, 0).getTime();
const at = (d: number, h = 10) => new Date(2026, 10, d, h).getTime();

async function setup() {
  clock = at(5);
  const db = createNodeClient();
  await migrate(db, migrations);
  const repos = createRepositories(db, { now: () => clock });
  return { db, repos, ...createServices(repos, { now: () => clock }) };
}

async function seed() {
  const s = await setup();
  const math = await s.study.addSubject({ name: 'ریاضی', color: '#4F46E5' });
  const phys = await s.study.addSubject({ name: 'فیزیک', color: '#0EA5E9' });
  const book = await s.study.addMaterial({ subjectId: math.id, kind: 'book', title: 'ریاضی ۳ - گاج' });
  const video = await s.study.addMaterial({ subjectId: phys.id, kind: 'video', title: 'فیلم فیزیک - حرکت' });
  return { ...s, math, phys, book, video };
}

describe('study data', () => {
  it('registers subjects, materials and topics learned today, first review tomorrow', async () => {
    const { study, book } = await seed();
    const topics = await study.addLearned(book.id, 'حد\nمشتق\nانتگرال');
    assert.equal(topics.length, 3);
    for (const t of topics) {
      assert.equal(t.dueAt, at(6, 0));
      assert.equal(t.intervalDays, 1);
      assert.equal(t.repetitions, 0);
      assert.equal(t.materialKind, 'book');
      assert.equal(t.subjectName, 'ریاضی');
    }
  });

  it('rejects empty topic lists and unknown materials', async () => {
    const { study, book } = await seed();
    await assert.rejects(() => study.addLearned(book.id, '  \n '), InvalidOperationError);
    await assert.rejects(() => study.addLearned('nope', 'x'), NotFoundError);
  });

  it('validates subject and material input', async () => {
    const { study } = await seed();
    await assert.rejects(() => study.addSubject({ name: '', color: '#112233' }));
    await assert.rejects(() => study.addSubject({ name: 'x', color: 'red' }));
    await assert.rejects(() => study.addMaterial({ kind: 'book', title: ' ' }));
  });

  it('counts topics per material', async () => {
    const { study, repos, book } = await seed();
    await study.addLearned(book.id, 'a, b');
    const list = await repos.study.listMaterials();
    assert.equal(list.find((m) => m.id === book.id)?.topicCount, 2);
  });
});

describe('reviewing', () => {
  it('nothing is due today, then everything learned yesterday is due', async () => {
    const { study, book } = await seed();
    await study.addLearned(book.id, 'a\nb');
    assert.equal((await study.todayQueue()).length, 0);
    clock = at(6, 9);
    assert.equal((await study.todayQueue()).length, 2);
  });

  it('good reviews schedule 3, 7, then about 18 days and write a history', async () => {
    const { study, repos, book } = await seed();
    const [t] = await study.addLearned(book.id, 'حد');
    const days: number[] = [];
    for (const d of [6, 9, 16]) {
      clock = at(d, 18);
      const r = await study.review(t.id, 2);
      days.push(r.intervalDays);
      assert.equal(r.dueAt, new Date(2026, 10, d + r.intervalDays).getTime());
      assert.equal(r.lastReviewedAt, clock);
    }
    assert.deepEqual(days, [3, 7, 18]);
    const history = await repos.study.listReviews(t.id);
    assert.deepEqual(history.map((h) => [h.rating, h.intervalBefore, h.intervalAfter]), [[2, 1, 3], [2, 3, 7], [2, 7, 18]]);
  });

  it('forgetting brings the topic back tomorrow', async () => {
    const { study, book } = await seed();
    const [t] = await study.addLearned(book.id, 'x');
    clock = at(6);
    await study.review(t.id, 2);
    clock = at(9);
    const r = await study.review(t.id, 0);
    assert.equal(r.intervalDays, 1);
    assert.equal(r.lapses, 1);
    assert.equal(r.dueAt, new Date(2026, 10, 10).getTime());
  });

  it('removes a reviewed topic from today and rejects bad ratings or unknown topics', async () => {
    const { study, book } = await seed();
    const [t] = await study.addLearned(book.id, 'x');
    clock = at(6);
    await study.review(t.id, 3);
    assert.equal((await study.todayQueue()).length, 0);
    await assert.rejects(() => study.review(t.id, 7));
    await assert.rejects(() => study.review('nope', 2), NotFoundError);
  });

  it('shortens the gaps when the exam is close', async () => {
    const { study, book } = await seed();
    await study.setExamDate(at(5 + 21, 0)); // 21 days away -> max gap 7
    const [t] = await study.addLearned(book.id, 'x');
    let r = t;
    for (const d of [6, 9, 16]) {
      clock = at(d);
      r = await study.review(t.id, 3);
    }
    assert.ok(r.intervalDays <= 5, `interval was ${r.intervalDays}`);
  });

  it('mixes subjects in the daily queue and puts late topics first', async () => {
    const { study, book, video } = await seed();
    await study.addLearned(book.id, 'm1\nm2\nm3');
    await study.addLearned(video.id, 'p1\np2');
    clock = at(6);
    const q = await study.todayQueue();
    assert.equal(q.length, 5);
    assert.notEqual(q[0].subjectId, q[1].subjectId);
    assert.deepEqual((await study.todayQueue(2)).length, 2);
  });

  it('forecasts the coming days', async () => {
    const { study, book } = await seed();
    await study.addLearned(book.id, 'a\nb');
    assert.deepEqual(await study.forecast(3), [0, 2, 0]);
  });
});

describe('exam date and cleanup', () => {
  it('stores the exam date and refuses past dates', async () => {
    const { study } = await seed();
    assert.equal(await study.getExamDate(), null);
    await study.setExamDate(at(100, 15));
    assert.equal(await study.getExamDate(), at(100, 0));
    await assert.rejects(() => study.setExamDate(at(1)), InvalidOperationError);
    await study.setExamDate(null);
    assert.equal(await study.getExamDate(), null);
  });

  it('deleting a material removes its topics and history; deleting a subject keeps the material', async () => {
    const { study, repos, book, math } = await seed();
    const [t] = await study.addLearned(book.id, 'x');
    clock = at(6);
    await study.review(t.id, 2);
    await repos.study.deleteSubject(math.id);
    const mats = await repos.study.listMaterials();
    assert.equal(mats.find((m) => m.id === book.id)?.subjectId, null);
    assert.equal((await repos.study.getTopic(t.id))?.subjectName, null);
    await repos.study.deleteMaterial(book.id);
    assert.equal(await repos.study.getTopic(t.id), null);
    assert.deepEqual(await repos.study.listReviews(t.id), []);
  });

  it('suspended topics are left out of the queue', async () => {
    const { study, repos, book } = await seed();
    const [t] = await study.addLearned(book.id, 'x');
    clock = at(6);
    await repos.study.setSuspended(t.id, true);
    assert.equal((await study.todayQueue()).length, 0);
    await repos.study.setSuspended(t.id, false);
    assert.equal((await study.todayQueue()).length, 1);
  });
});
