# Study planner (konkur) — foundation

Data: `study_subjects`, `study_materials` (book / video / other), `study_topics` (what was learned, with its review state),
`study_reviews` (history of every self-test). Migration 003.

Method (what the research supports best): **spaced repetition** + **retrieval practice** (self-testing) + **interleaving** (mixing subjects).
- A topic learned today is reviewed tomorrow. After each self-test the student rates it: فراموش کردم / سخت بود / خوب بود / آسان بود.
- Good answers give 3, 7, then ~18, 45 … days (growth by an "ease" factor); forgetting resets to 1 day and lowers the ease.
- With an exam date, gaps are capped so each topic is still reviewed about 3 more times before the exam.
- The daily queue is ordered by lateness and weak memory, and subjects are mixed.

Not claimed: "learning styles" and personality-matched plans are not well supported by research. Personalisation (stage 14) uses the
student's own results, available hours and session length, not a personality label.
