import type { Migration } from './types';

const SQL = `
CREATE TABLE study_subjects (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  color TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE study_materials (
  id TEXT PRIMARY KEY NOT NULL,
  subject_id TEXT REFERENCES study_subjects(id) ON DELETE SET NULL,
  kind TEXT NOT NULL CHECK (kind IN ('book','video','other')),
  title TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_study_materials_subject ON study_materials(subject_id);

-- One row per thing learned (a chapter, a lesson, a topic). Review state lives here.
CREATE TABLE study_topics (
  id TEXT PRIMARY KEY NOT NULL,
  material_id TEXT NOT NULL REFERENCES study_materials(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  learned_at INTEGER NOT NULL,
  due_at INTEGER NOT NULL,
  interval_days INTEGER NOT NULL DEFAULT 1 CHECK (interval_days >= 1),
  ease REAL NOT NULL DEFAULT 2.5,
  repetitions INTEGER NOT NULL DEFAULT 0 CHECK (repetitions >= 0),
  lapses INTEGER NOT NULL DEFAULT 0 CHECK (lapses >= 0),
  last_reviewed_at INTEGER,
  suspended INTEGER NOT NULL DEFAULT 0 CHECK (suspended IN (0,1)),
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_study_topics_due ON study_topics(suspended, due_at);
CREATE INDEX idx_study_topics_material ON study_topics(material_id);

-- History of every self-test. Used to adapt the schedule and to show progress.
CREATE TABLE study_reviews (
  id TEXT PRIMARY KEY NOT NULL,
  topic_id TEXT NOT NULL REFERENCES study_topics(id) ON DELETE CASCADE,
  reviewed_at INTEGER NOT NULL,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 0 AND 3),
  interval_before INTEGER NOT NULL,
  interval_after INTEGER NOT NULL,
  ease_after REAL NOT NULL
);
CREATE INDEX idx_study_reviews_topic ON study_reviews(topic_id, reviewed_at);
CREATE INDEX idx_study_reviews_time ON study_reviews(reviewed_at);
`;

export const migration003: Migration = {
  version: 3,
  name: 'study_planner',
  up: async (db) => {
    await db.execAsync(SQL);
  },
};
