import { addDays, startOfDay } from '../../../core/calendar/dates';
import { InvalidOperationError, NotFoundError } from '../../../core/errors';
import type { SettingsRepository } from '../../settings/repositories/settingsRepository';
import type { StudyMaterial, StudySubject, StudyTopic } from '../models/study';
import type { StudyRepository } from '../repositories/studyRepository';
import { MaterialInput, SubjectInput, ratingSchema } from '../validation/studySchemas';
import { dueTopics, forecast, interleave, parseTopicList, sortByUrgency } from './reviewQueue';
import { Rating, daysUntil, examMaxInterval, nextState } from './srs';

export const EXAM_DATE_KEY = 'study_exam_date';

export interface StudyService {
  addSubject(input: SubjectInput): Promise<StudySubject>;
  addMaterial(input: MaterialInput): Promise<StudyMaterial>;
  /** Registers what was learned today (one per line or comma separated). The first review is tomorrow. */
  addLearned(materialId: string, text: string): Promise<StudyTopic[]>;
  /** Records a self-test and schedules the next review. */
  review(topicId: string, rating: number): Promise<StudyTopic>;
  /** Today's reviews: late first, weak memories first, subjects mixed. */
  todayQueue(limit?: number): Promise<StudyTopic[]>;
  /** Reviews expected on each of the next `days` days. */
  forecast(days: number): Promise<number[]>;
  getExamDate(): Promise<number | null>;
  setExamDate(examAt: number | null): Promise<void>;
}

export function createStudyService(
  repo: StudyRepository,
  settings: SettingsRepository,
  options: { now?: () => number } = {},
): StudyService {
  const now = options.now ?? (() => Date.now());

  async function getExamDate(): Promise<number | null> {
    const raw = await settings.get(EXAM_DATE_KEY);
    const n = raw === null ? NaN : Number(raw);
    return Number.isFinite(n) ? n : null;
  }

  return {
    getExamDate,

    async setExamDate(examAt) {
      if (examAt === null) {
        await settings.remove(EXAM_DATE_KEY);
        return;
      }
      if (!Number.isFinite(examAt) || examAt < startOfDay(new Date(now())).getTime()) {
        throw new InvalidOperationError('تاریخ کنکور باید امروز یا بعد از امروز باشد');
      }
      await settings.set(EXAM_DATE_KEY, String(startOfDay(new Date(examAt)).getTime()));
    },

    addSubject: (input) => repo.createSubject(input),
    addMaterial: (input) => repo.createMaterial(input),

    async addLearned(materialId, text) {
      const titles = parseTopicList(text);
      if (titles.length === 0) throw new InvalidOperationError('حداقل یک مبحث وارد کنید');
      const materials = await repo.listMaterials();
      if (!materials.some((m) => m.id === materialId)) throw new NotFoundError('منبع');
      const t = now();
      const firstDue = addDays(startOfDay(new Date(t)), 1).getTime();
      return repo.addTopics(materialId, titles, t, firstDue);
    },

    async review(topicId, rawRating) {
      const rating = ratingSchema.parse(rawRating) as Rating;
      const topic = await repo.getTopic(topicId);
      if (!topic) throw new NotFoundError('مبحث');
      const t = now();
      const exam = await getExamDate();
      const cap = examMaxInterval(exam === null ? null : Math.max(0, daysUntil(exam, t)));
      const next = nextState(
        { intervalDays: topic.intervalDays, ease: topic.ease, repetitions: topic.repetitions, lapses: topic.lapses },
        rating,
        cap,
      );
      const saved = await repo.saveReview({
        topicId,
        reviewedAt: t,
        rating,
        intervalBefore: topic.intervalDays,
        intervalAfter: next.intervalDays,
        easeAfter: next.ease,
        repetitions: next.repetitions,
        lapses: next.lapses,
        dueAt: addDays(startOfDay(new Date(t)), next.intervalDays).getTime(),
      });
      if (!saved) throw new NotFoundError('مبحث');
      return saved;
    },

    async todayQueue(limit) {
      const t = now();
      const queue = interleave(sortByUrgency(dueTopics(await repo.listTopics(), t), t));
      return limit === undefined ? queue : queue.slice(0, limit);
    },

    async forecast(days) {
      return forecast(await repo.listTopics(), now(), days);
    },
  };
}
