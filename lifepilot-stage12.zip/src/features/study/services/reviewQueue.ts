import { addDays, localDayNumber, startOfDay } from '../../../core/calendar/dates';

export interface QueueTopic {
  id: string;
  subjectId: string | null;
  dueAt: number;
  ease: number;
  lapses: number;
  suspended: boolean;
}

/** Days a review is late (0 when it is due today or later). */
export function overdueDays(dueAt: number, now: number): number {
  return Math.max(0, localDayNumber(new Date(now)) - localDayNumber(new Date(dueAt)));
}

/** Topics to review today: due today or already late. Suspended topics are skipped. */
export function dueTopics<T extends QueueTopic>(topics: T[], now: number): T[] {
  const endOfToday = addDays(startOfDay(new Date(now)), 1).getTime();
  return topics.filter((t) => !t.suspended && t.dueAt < endOfToday);
}

/** Most urgent first: later reviews first, then weaker memories (low ease, many lapses). */
export function sortByUrgency<T extends QueueTopic>(topics: T[], now: number): T[] {
  return [...topics].sort(
    (a, b) =>
      overdueDays(b.dueAt, now) - overdueDays(a.dueAt, now) ||
      a.ease - b.ease ||
      b.lapses - a.lapses ||
      a.id.localeCompare(b.id),
  );
}

/**
 * Mixes subjects (round-robin) instead of finishing one subject first. Interleaving different subjects
 * is a well-supported way to make learning stick. Urgency order is kept inside each subject.
 */
export function interleave<T extends { subjectId: string | null }>(topics: T[]): T[] {
  const groups = new Map<string, T[]>();
  for (const t of topics) {
    const key = t.subjectId ?? '';
    const g = groups.get(key);
    if (g) g.push(t);
    else groups.set(key, [t]);
  }
  const lists = [...groups.values()];
  const out: T[] = [];
  for (let i = 0; out.length < topics.length; i++) {
    for (const l of lists) if (i < l.length) out.push(l[i]);
  }
  return out;
}

/** How many reviews fall on each of the next `days` days (late ones count as today). */
export function forecast<T extends QueueTopic>(topics: T[], now: number, days: number): number[] {
  const counts = Array.from({ length: days }, () => 0);
  const today = localDayNumber(new Date(now));
  for (const t of topics) {
    if (t.suspended) continue;
    const idx = Math.max(0, localDayNumber(new Date(t.dueAt)) - today);
    if (idx < days) counts[idx]++;
  }
  return counts;
}

/** Splits pasted text into topic titles: one per line, or separated by commas / Persian commas / semicolons. */
export function parseTopicList(text: string): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const raw of text.split(/[\n\r,،;؛]+/)) {
    // drop list markers such as "-", "•", "1.", "۲)" (but keep titles that merely start with a number)
    const title = raw.replace(/^\s*(?:[-•*]|[\d۰-۹]+[.)])\s*/, '').trim();
    if (title && !seen.has(title)) {
      seen.add(title);
      out.push(title.slice(0, 160));
    }
  }
  return out;
}
