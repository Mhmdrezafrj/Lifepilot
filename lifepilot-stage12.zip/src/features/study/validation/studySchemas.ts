import { z } from 'zod';
import { MATERIAL_KINDS } from '../models/study';

export const subjectInputSchema = z.object({
  name: z.string().trim().min(1, 'نام درس الزامی است').max(40, 'نام درس بیش از حد طولانی است'),
  color: z.string().regex(/^#[0-9A-Fa-f]{6}$/, 'رنگ نامعتبر است'),
});

export const materialInputSchema = z.object({
  subjectId: z.string().min(1).nullable().optional(),
  kind: z.enum(MATERIAL_KINDS),
  title: z.string().trim().min(1, 'عنوان الزامی است').max(120, 'عنوان بیش از حد طولانی است'),
});

export const topicTitleSchema = z.string().trim().min(1).max(160);

export const ratingSchema = z.union([z.literal(0), z.literal(1), z.literal(2), z.literal(3)]);

export type SubjectInput = z.input<typeof subjectInputSchema>;
export type MaterialInput = z.input<typeof materialInputSchema>;
