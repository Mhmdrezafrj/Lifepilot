export const MATERIAL_KINDS = ['book', 'video', 'other'] as const;
export type MaterialKind = (typeof MATERIAL_KINDS)[number];

export const MATERIAL_KIND_LABELS: Record<MaterialKind, string> = {
  book: 'کتاب',
  video: 'فیلم آموزشی',
  other: 'سایر',
};

export interface StudySubject {
  id: string;
  name: string;
  color: string;
  createdAt: number;
}

export interface StudyMaterial {
  id: string;
  subjectId: string | null;
  kind: MaterialKind;
  title: string;
  createdAt: number;
  topicCount: number;
}

/** A thing the student has learned and will review on a schedule. Dates are epoch ms (local day starts for due dates). */
export interface StudyTopic {
  id: string;
  materialId: string;
  title: string;
  learnedAt: number;
  dueAt: number;
  intervalDays: number;
  ease: number;
  repetitions: number;
  lapses: number;
  lastReviewedAt: number | null;
  suspended: boolean;
  createdAt: number;
  /** From the material and its subject, for display and mixing subjects. */
  materialTitle: string;
  materialKind: MaterialKind;
  subjectId: string | null;
  subjectName: string | null;
  subjectColor: string | null;
}

export interface StudyReview {
  id: string;
  topicId: string;
  reviewedAt: number;
  rating: number;
  intervalBefore: number;
  intervalAfter: number;
  easeAfter: number;
}
