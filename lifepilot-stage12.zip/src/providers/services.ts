import { createCategoryService } from '../features/categories/services/categoryService';
import { createReminderScheduler } from '../infrastructure/notifications/reminderScheduler';
import type { ReminderScheduler } from '../infrastructure/notifications/types';
import { createStudyService } from '../features/study/services/studyService';
import { createTaskService } from '../features/tasks/services/taskService';
import type { Repositories } from './repositories';

/**
 * The reminder scheduler defaults to "unavailable" gateways in Phase 1. The notification
 * phase passes real Android gateways here; nothing else needs to change.
 */
export function createServices(
  repos: Repositories,
  options: { now?: () => number; scheduler?: ReminderScheduler } = {},
) {
  const scheduler = options.scheduler ?? createReminderScheduler({ now: options.now });
  return {
    scheduler,
    tasks: createTaskService(repos.tasks, { now: options.now, scheduler }),
    categories: createCategoryService(repos.categories),
    study: createStudyService(repos.study, repos.settings, { now: options.now }),
  };
}

export type Services = ReturnType<typeof createServices>;
