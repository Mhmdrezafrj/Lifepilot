import { useMemo, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { useRouter } from 'expo-router';
import { addDays, startOfDay } from '@/core/calendar/dates';
import { JALALI_MONTH_NAMES, formatJalaliDate, toPersianDigits } from '@/core/calendar/format';
import { dayKey, dayRangeMs, jalaliMonthRangeMs, weekDates, weekRangeMs } from '@/core/calendar/grid';
import { addJalaliMonths, dateToJalali } from '@/core/calendar/jalali';
import { useTheme } from '@/core/theme/useTheme';
import { useCategories } from '@/features/categories/hooks/useCategories';
import { CalendarHeader } from '@/features/calendar/components/CalendarHeader';
import { DayAgenda } from '@/features/calendar/components/DayAgenda';
import { MonthView } from '@/features/calendar/components/MonthView';
import { WeekView } from '@/features/calendar/components/WeekView';
import { useCalendarTasks } from '@/features/calendar/hooks/useCalendarTasks';
import { useToggleTask } from '@/features/tasks/hooks/useToggleTask';
import type { Task } from '@/features/tasks/models/task';
import { AppText } from '@/shared/components/AppText';
import { Fab } from '@/shared/components/Fab';
import { Screen } from '@/shared/components/Screen';
import { SegmentedControl } from '@/shared/components/SegmentedControl';
import { useNow } from '@/shared/hooks/useNow';

type Mode = 'day' | 'week' | 'month';

const MODE_OPTIONS: { value: Mode; label: string }[] = [
  { value: 'day', label: 'روز' },
  { value: 'week', label: 'هفته' },
  { value: 'month', label: 'ماه' },
];

const NAV_LABELS: Record<Mode, { prev: string; next: string }> = {
  day: { prev: 'روز قبل', next: 'روز بعد' },
  week: { prev: 'هفته‌ی قبل', next: 'هفته‌ی بعد' },
  month: { prev: 'ماه قبل', next: 'ماه بعد' },
};

export default function CalendarScreen() {
  const router = useRouter();
  const { spacing } = useTheme();
  const now = useNow();
  const toggle = useToggleTask();
  const { byId } = useCategories();
  const [mode, setMode] = useState<Mode>('month');
  const [selected, setSelected] = useState(() => startOfDay(new Date()));

  const range = useMemo(() => {
    if (mode === 'day') return dayRangeMs(selected);
    if (mode === 'week') return weekRangeMs(selected);
    const j = dateToJalali(selected);
    return jalaliMonthRangeMs(j.year, j.month);
  }, [mode, selected]);

  const { byDay, indicators, loading, error } = useCalendarTasks(range);

  const step = (delta: number) =>
    setSelected((s) => {
      if (mode === 'day') return addDays(s, delta);
      if (mode === 'week') return addDays(s, 7 * delta);
      return startOfDay(addJalaliMonths(s, delta));
    });

  const j = dateToJalali(selected);
  const title =
    mode === 'month'
      ? `${JALALI_MONTH_NAMES[j.month - 1]} ${toPersianDigits(j.year)}`
      : mode === 'day'
        ? formatJalaliDate(selected, { weekday: true })
        : (() => {
            const days = weekDates(selected);
            return `${formatJalaliDate(days[0], { year: false })} تا ${formatJalaliDate(days[6], { year: 'auto' })}`;
          })();

  const open = (t: Task) => router.push(`/task/${t.id}`);
  const addFor = (date: Date) => router.push(`/task/new?date=${startOfDay(date).getTime()}`);
  const dayTasks = byDay.get(dayKey(selected)) ?? [];

  return (
    <View style={{ flex: 1 }}>
      <Screen title="تقویم">
        <SegmentedControl options={MODE_OPTIONS} value={mode} onChange={setMode} />
        <CalendarHeader
          title={title}
          onPrev={() => step(-1)}
          onNext={() => step(1)}
          onToday={() => setSelected(startOfDay(new Date()))}
          prevLabel={NAV_LABELS[mode].prev}
          nextLabel={NAV_LABELS[mode].next}
        />

        {loading ? <ActivityIndicator /> : null}
        {error ? <AppText color="danger">{error}</AppText> : null}

        {mode === 'month' ? (
          <View style={{ gap: spacing.lg }}>
            <MonthView selected={selected} indicators={indicators} onSelect={setSelected} />
            <DayAgenda date={selected} tasks={dayTasks} categories={byId} now={now} onOpen={open} onToggle={toggle} onAdd={addFor} />
          </View>
        ) : null}

        {mode === 'week' ? (
          <WeekView
            selected={selected}
            byDay={byDay}
            categories={byId}
            now={now}
            onSelect={setSelected}
            onOpen={open}
            onToggle={toggle}
            onAdd={addFor}
          />
        ) : null}

        {mode === 'day' ? (
          <DayAgenda date={selected} tasks={dayTasks} categories={byId} now={now} onOpen={open} onToggle={toggle} onAdd={addFor} />
        ) : null}

        <View style={{ height: 80 }} />
      </Screen>
      <Fab onPress={() => addFor(selected)} accessibilityLabel="افزودن کار برای روز انتخاب‌شده" />
    </View>
  );
}
