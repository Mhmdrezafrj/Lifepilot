import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  buildMonthRows, dayKey, dayRangeMs, jalaliMonthRangeMs, shiftJalaliMonth, weekDates, weekRangeMs, weekStartSat,
} from '../../src/core/calendar/grid';
import { addJalaliMonths, dateToJalali, jalaliToDate } from '../../src/core/calendar/jalali';
import { buildDayIndicators, groupTasksByDay } from '../../src/features/calendar/services/dayIndicators';
import type { Task } from '../../src/features/tasks/models/task';

const t = (over: Partial<Task>): Task => ({
  id: 'x', title: 'x', description: null, dueAt: null, hasTime: false, priority: 'medium', categoryId: null,
  status: 'pending', snoozedUntil: null, createdAt: 0, updatedAt: 0, completedAt: null, recurrenceId: null,
  tags: [], checklist: [], reminders: [], recurrence: null, ...over,
});

describe('month grid', () => {
  it('starts Farvardin 1405 on Saturday (column 0) and has 31 days in 5 rows', () => {
    const rows = buildMonthRows(1405, 1);
    assert.equal(rows.length, 5);
    assert.equal(rows[0][0], 1);
    assert.equal(rows.flat().filter((x) => x !== null).length, 31);
    assert.ok(rows.every((r) => r.length === 7));
  });

  it('puts 1 Aban 1405 (a Friday) in the last column and needs 6 rows', () => {
    const rows = buildMonthRows(1405, 8);
    assert.equal(rows[0].lastIndexOf(null), 5);
    assert.equal(rows[0][6], 1);
    assert.equal(rows.length, 6);
    assert.equal(rows.flat().filter((x) => x !== null).length, 30);
  });

  it('every day lands in the column of its real weekday', () => {
    const rows = buildMonthRows(1405, 8);
    rows.forEach((row) =>
      row.forEach((d, col) => {
        if (d === null) return;
        const weekdaySatFirst = (jalaliToDate(1405, 8, d).getDay() + 1) % 7;
        assert.equal(col, weekdaySatFirst, `day ${d}`);
      }),
    );
  });

  it('shifts months across year boundaries', () => {
    assert.deepEqual(shiftJalaliMonth({ year: 1405, month: 12 }, 1), { year: 1406, month: 1 });
    assert.deepEqual(shiftJalaliMonth({ year: 1405, month: 1 }, -1), { year: 1404, month: 12 });
    assert.deepEqual(shiftJalaliMonth({ year: 1405, month: 8 }, 14), { year: 1406, month: 10 });
  });
});

describe('weeks and ranges', () => {
  const thu = new Date(2026, 10, 5, 15, 30); // Thursday 14 Aban 1405

  it('the week runs Saturday to Friday', () => {
    assert.equal(weekStartSat(thu).getTime(), new Date(2026, 9, 31).getTime());
    const days = weekDates(thu);
    assert.equal(days.length, 7);
    assert.equal(days[0].getDay(), 6);
    assert.equal(days[6].getDay(), 5);
    assert.equal(days[6].getTime(), new Date(2026, 10, 6).getTime());
  });

  it('a Saturday is the first day of its own week', () => {
    assert.equal(weekStartSat(new Date(2026, 10, 7, 9)).getTime(), new Date(2026, 10, 7).getTime());
  });

  it('computes half-open day, week and month ranges', () => {
    assert.deepEqual(dayRangeMs(thu), { start: new Date(2026, 10, 5).getTime(), end: new Date(2026, 10, 6).getTime() });
    assert.deepEqual(weekRangeMs(thu), { start: new Date(2026, 9, 31).getTime(), end: new Date(2026, 10, 7).getTime() });
    // Aban 1405: 23 Oct 2026 .. 21 Nov 2026 inclusive
    assert.deepEqual(jalaliMonthRangeMs(1405, 8), { start: new Date(2026, 9, 23).getTime(), end: new Date(2026, 10, 22).getTime() });
  });

  it('builds day keys', () => {
    assert.equal(dayKey(new Date(2026, 10, 5, 23, 59)), '2026-11-5');
  });

  it('adds Jalali months keeping time and clamping the day', () => {
    const d = addJalaliMonths(jalaliToDate(1405, 6, 31, 10, 15), 1);
    assert.deepEqual(dateToJalali(d), { year: 1405, month: 7, day: 30 });
    assert.equal(d.getHours(), 10);
    assert.deepEqual(dateToJalali(addJalaliMonths(jalaliToDate(1405, 12, 5), 1)), { year: 1406, month: 1, day: 5 });
    assert.deepEqual(dateToJalali(addJalaliMonths(jalaliToDate(1405, 1, 5), -1)), { year: 1404, month: 12, day: 5 });
  });
});

describe('day indicators', () => {
  const at = (d: number, h = 0) => new Date(2026, 10, d, h).getTime();

  it('groups tasks by day and ignores tasks without a date', () => {
    const map = groupTasksByDay([
      t({ id: 'a', dueAt: at(5, 18), hasTime: true }),
      t({ id: 'b', dueAt: at(5, 9), hasTime: true }),
      t({ id: 'c', dueAt: at(6) }),
      t({ id: 'd' }),
    ]);
    assert.deepEqual(map.get('2026-11-5')?.map((x) => x.id), ['b', 'a']);
    assert.deepEqual(map.get('2026-11-6')?.map((x) => x.id), ['c']);
    assert.equal(map.size, 2);
  });

  it('shows pending tasks first by priority, completed after, max 3 dots', () => {
    const byDay = groupTasksByDay([
      t({ id: '1', dueAt: at(5), priority: 'low' }),
      t({ id: '2', dueAt: at(5), priority: 'critical' }),
      t({ id: '3', dueAt: at(5), status: 'completed', priority: 'high' }),
      t({ id: '4', dueAt: at(5), priority: 'medium' }),
    ]);
    const ind = buildDayIndicators(byDay).get('2026-11-5');
    assert.equal(ind?.total, 4);
    assert.equal(ind?.pending, 3);
    assert.equal(ind?.completed, 1);
    assert.deepEqual(ind?.dots, [
      { priority: 'critical', done: false },
      { priority: 'medium', done: false },
      { priority: 'low', done: false },
    ]);
  });

  it('an all-completed day has only done dots', () => {
    const ind = buildDayIndicators(groupTasksByDay([t({ dueAt: at(5), status: 'completed' })])).get('2026-11-5');
    assert.deepEqual(ind?.dots, [{ priority: 'medium', done: true }]);
  });
});
