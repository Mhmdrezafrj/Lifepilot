import { addDays, startOfDay, weekdayIndexSat } from './dates';
import { jalaliMonthLength, jalaliToDate } from './jalali';

export interface MonthView {
  year: number;
  /** 1..12 */
  month: number;
}

/** Rows of 7 cells (Saturday first). A cell is the Jalali day number, or null for padding. */
export function buildMonthRows(year: number, month: number): (number | null)[][] {
  const offset = weekdayIndexSat(jalaliToDate(year, month, 1));
  const length = jalaliMonthLength(year, month);
  const cells: (number | null)[] = [
    ...Array.from({ length: offset }, () => null),
    ...Array.from({ length }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);
  const rows: (number | null)[][] = [];
  for (let i = 0; i < cells.length; i += 7) rows.push(cells.slice(i, i + 7));
  return rows;
}

export function shiftJalaliMonth(view: MonthView, delta: number): MonthView {
  const total = view.year * 12 + (view.month - 1) + delta;
  return { year: Math.floor(total / 12), month: (total % 12) + 1 };
}

/** Saturday (local midnight) of the week containing `date`. */
export function weekStartSat(date: Date): Date {
  const d = startOfDay(date);
  return addDays(d, -weekdayIndexSat(d));
}

/** The 7 days (local midnight) of the Saturday-to-Friday week containing `date`. */
export function weekDates(date: Date): Date[] {
  const start = weekStartSat(date);
  return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}

/** Half-open range [start, end) in epoch milliseconds. */
export interface TimeRange {
  start: number;
  end: number;
}

export function dayRangeMs(date: Date): TimeRange {
  const s = startOfDay(date);
  return { start: s.getTime(), end: addDays(s, 1).getTime() };
}

export function weekRangeMs(date: Date): TimeRange {
  const s = weekStartSat(date);
  return { start: s.getTime(), end: addDays(s, 7).getTime() };
}

export function jalaliMonthRangeMs(year: number, month: number): TimeRange {
  const first = jalaliToDate(year, month, 1);
  const last = jalaliToDate(year, month, jalaliMonthLength(year, month));
  return { start: first.getTime(), end: addDays(last, 1).getTime() };
}

/** Stable key for a local calendar day, e.g. "2026-11-5". */
export function dayKey(date: Date): string {
  return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
}
