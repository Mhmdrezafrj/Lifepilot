import { dayKey } from '../../../core/calendar/grid';
import { Priority, Task, comparePriorityDesc } from '../../tasks/models/task';
import { sortTimeline } from '../../dashboard/services/dashboardStats';

export interface DayDot {
  priority: Priority;
  done: boolean;
}

export interface DayIndicator {
  total: number;
  pending: number;
  completed: number;
  /** Up to 3 dots: pending tasks first (most important first), then completed ones. */
  dots: DayDot[];
}

/** Groups tasks that have a due date by local day, each day in display order. */
export function groupTasksByDay(tasks: Task[]): Map<string, Task[]> {
  const map = new Map<string, Task[]>();
  for (const t of tasks) {
    if (t.dueAt === null) continue;
    const key = dayKey(new Date(t.dueAt));
    const list = map.get(key);
    if (list) list.push(t);
    else map.set(key, [t]);
  }
  for (const [key, list] of map) map.set(key, sortTimeline(list));
  return map;
}

export function buildDayIndicators(byDay: Map<string, Task[]>): Map<string, DayIndicator> {
  const out = new Map<string, DayIndicator>();
  for (const [key, list] of byDay) {
    const pending = list.filter((t) => t.status === 'pending').sort((a, b) => comparePriorityDesc(a.priority, b.priority));
    const done = list.filter((t) => t.status === 'completed');
    const dots: DayDot[] = [
      ...pending.map((t) => ({ priority: t.priority, done: false })),
      ...done.map((t) => ({ priority: t.priority, done: true })),
    ].slice(0, 3);
    out.set(key, { total: list.length, pending: pending.length, completed: done.length, dots });
  }
  return out;
}
