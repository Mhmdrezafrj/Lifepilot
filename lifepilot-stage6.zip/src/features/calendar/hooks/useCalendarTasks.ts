import { useMemo } from 'react';
import { useTasks } from '@/features/tasks/hooks/useTasks';
import type { TimeRange } from '@/core/calendar/grid';
import { buildDayIndicators, groupTasksByDay } from '../services/dayIndicators';

/** Tasks due inside a time range, grouped by day, with per-day indicators. */
export function useCalendarTasks(range: TimeRange) {
  const { tasks, loading, error } = useTasks({ dueFrom: range.start, dueTo: range.end });
  const byDay = useMemo(() => groupTasksByDay(tasks), [tasks]);
  const indicators = useMemo(() => buildDayIndicators(byDay), [byDay]);
  return { byDay, indicators, loading, error };
}
