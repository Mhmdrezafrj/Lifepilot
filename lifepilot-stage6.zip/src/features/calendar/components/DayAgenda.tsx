import { View } from 'react-native';
import { formatJalaliDate, toPersianDigits } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import type { Category } from '@/features/categories/models/category';
import { TaskCard } from '@/features/tasks/components/TaskCard';
import type { Task } from '@/features/tasks/models/task';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';

interface Props {
  date: Date;
  tasks: Task[];
  categories: Map<string, Category>;
  now: number;
  onOpen: (task: Task) => void;
  onToggle: (task: Task) => void;
  onAdd: (date: Date) => void;
}

/** The tasks of one selected day, with a button to add a task on that day. */
export function DayAgenda({ date, tasks, categories, now, onOpen, onToggle, onAdd }: Props) {
  const { spacing } = useTheme();
  return (
    <View style={{ gap: spacing.sm }}>
      <AppText variant="heading">
        {formatJalaliDate(date, { weekday: true, year: 'auto' })}
        {tasks.length > 0 ? ` (${toPersianDigits(tasks.length)} کار)` : ''}
      </AppText>
      {tasks.length === 0 ? (
        <Card variant="flat">
          <AppText muted>برای این روز کاری ثبت نشده است.</AppText>
        </Card>
      ) : (
        tasks.map((t) => (
          <TaskCard
            key={t.id}
            task={t}
            category={t.categoryId ? categories.get(t.categoryId) : undefined}
            now={now}
            onPress={onOpen}
            onToggle={onToggle}
          />
        ))
      )}
      <Button title="افزودن کار برای این روز" variant="secondary" icon="add" onPress={() => onAdd(date)} />
    </View>
  );
}
