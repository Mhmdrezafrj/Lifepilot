import { I18nManager, View } from 'react-native';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { IconButton } from '@/shared/components/IconButton';

interface Props {
  title: string;
  onPrev: () => void;
  onNext: () => void;
  onToday: () => void;
  prevLabel: string;
  nextLabel: string;
}

export function CalendarHeader({ title, onPrev, onNext, onToday, prevLabel, nextLabel }: Props) {
  const { spacing } = useTheme();
  const rtl = I18nManager.isRTL;
  return (
    <View style={{ gap: spacing.sm }}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <IconButton icon={rtl ? 'chevron-forward' : 'chevron-back'} variant="filled" onPress={onPrev} accessibilityLabel={prevLabel} />
        <View style={{ flex: 1 }}>
          <AppText variant="heading" style={{ textAlign: 'center' }}>{title}</AppText>
        </View>
        <IconButton icon={rtl ? 'chevron-back' : 'chevron-forward'} variant="filled" onPress={onNext} accessibilityLabel={nextLabel} />
      </View>
      <Button title="امروز" variant="secondary" size="sm" icon="locate-outline" onPress={onToday} />
    </View>
  );
}
