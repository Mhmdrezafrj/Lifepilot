import { Pressable, View } from 'react-native';
import { isSameDay } from '@/core/calendar/dates';
import { WEEKDAY_NAMES, formatJalaliDate, toPersianDigits } from '@/core/calendar/format';
import { dayKey, weekDates } from '@/core/calendar/grid';
import { useTheme } from '@/core/theme/useTheme';
import type { Category } from '@/features/categories/models/category';
import { TaskCard } from '@/features/tasks/components/TaskCard';
import type { Task } from '@/features/tasks/models/task';
import { AppText } from '@/shared/components/AppText';
import { Card } from '@/shared/components/Card';
import { IconButton } from '@/shared/components/IconButton';

interface Props {
  selected: Date;
  byDay: Map<string, Task[]>;
  categories: Map<string, Category>;
  now: number;
  onSelect: (date: Date) => void;
  onOpen: (task: Task) => void;
  onToggle: (task: Task) => void;
  onAdd: (date: Date) => void;
}

export function WeekView({ selected, byDay, categories, now, onSelect, onOpen, onToggle, onAdd }: Props) {
  const { colors, spacing, radii } = useTheme();
  const today = new Date();
  return (
    <View style={{ gap: spacing.md }}>
      {weekDates(selected).map((date) => {
        const tasks = byDay.get(dayKey(date)) ?? [];
        const isSelected = isSameDay(date, selected);
        const isToday = isSameDay(date, today);
        return (
          <View key={dayKey(date)} style={{ gap: spacing.sm }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                borderRadius: radii.md,
                paddingStart: spacing.md,
                backgroundColor: isSelected ? colors.accentSoft : 'transparent',
              }}
            >
              <Pressable
                accessibilityRole="button"
                accessibilityState={{ selected: isSelected }}
                onPress={() => onSelect(date)}
                style={{ flex: 1, minHeight: 44, justifyContent: 'center' }}
              >
                <AppText variant="bodyStrong" color={isToday ? 'accent' : 'text'}>
                  {WEEKDAY_NAMES[date.getDay()]}، {formatJalaliDate(date, { year: false })}
                  {tasks.length > 0 ? `  ·  ${toPersianDigits(tasks.length)} کار` : ''}
                </AppText>
              </Pressable>
              <IconButton icon="add-circle-outline" color={colors.accent} accessibilityLabel="افزودن کار برای این روز" onPress={() => onAdd(date)} />
            </View>
            {tasks.length === 0 ? (
              <AppText variant="caption" muted style={{ paddingStart: spacing.md }}>کاری نیست</AppText>
            ) : (
              tasks.map((t) => (
                <TaskCard
                  key={t.id}
                  task={t}
                  category={t.categoryId ? categories.get(t.categoryId) : undefined}
                  now={now}
                  onPress={onOpen}
                  onToggle={onToggle}
                />
              ))
            )}
          </View>
        );
      })}
    </View>
  );
}
