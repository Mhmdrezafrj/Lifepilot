import { useMemo } from 'react';
import { Pressable, View } from 'react-native';
import { isSameDay } from '@/core/calendar/dates';
import { WEEKDAY_SHORT_SAT_FIRST, toPersianDigits } from '@/core/calendar/format';
import { buildMonthRows, dayKey } from '@/core/calendar/grid';
import { dateToJalali, jalaliToDate } from '@/core/calendar/jalali';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from '@/shared/components/AppText';
import { Card } from '@/shared/components/Card';
import type { DayIndicator } from '../services/dayIndicators';

interface Props {
  selected: Date;
  indicators: Map<string, DayIndicator>;
  onSelect: (date: Date) => void;
}

export function MonthView({ selected, indicators, onSelect }: Props) {
  const { colors, radii, spacing } = useTheme();
  const j = dateToJalali(selected);
  const rows = useMemo(() => buildMonthRows(j.year, j.month), [j.year, j.month]);
  const today = new Date();

  return (
    <Card variant="outlined" style={{ gap: spacing.xs, padding: spacing.sm }}>
      <View style={{ flexDirection: 'row' }}>
        {WEEKDAY_SHORT_SAT_FIRST.map((w, i) => (
          <View key={i} style={{ flex: 1, alignItems: 'center' }}>
            <AppText variant="label" muted>{w}</AppText>
          </View>
        ))}
      </View>

      {rows.map((row, ri) => (
        <View key={ri} style={{ flexDirection: 'row' }}>
          {row.map((d, ci) => {
            if (d === null) return <View key={ci} style={{ flex: 1, height: 56 }} />;
            const date = jalaliToDate(j.year, j.month, d);
            const isSelected = isSameDay(date, selected);
            const isToday = isSameDay(date, today);
            const ind = indicators.get(dayKey(date));
            return (
              <Pressable
                key={ci}
                accessibilityRole="button"
                accessibilityState={{ selected: isSelected }}
                accessibilityLabel={`${toPersianDigits(d)}${ind ? `، ${toPersianDigits(ind.total)} کار` : ''}`}
                onPress={() => onSelect(date)}
                style={{ flex: 1, height: 56, padding: 2 }}
              >
                <View
                  style={{
                    flex: 1,
                    borderRadius: radii.md,
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 3,
                    backgroundColor: isSelected ? colors.accentSoft : 'transparent',
                    borderWidth: isSelected || isToday ? 1.5 : 0,
                    borderColor: colors.accent,
                  }}
                >
                  <AppText variant="body" color={isToday ? 'accent' : 'text'} style={isToday ? { fontFamily: 'Vazirmatn_700Bold' } : undefined}>
                    {toPersianDigits(d)}
                  </AppText>
                  <View style={{ flexDirection: 'row', gap: 3, height: 6 }}>
                    {ind?.dots.map((dot, k) => (
                      <View
                        key={k}
                        style={{
                          width: 6,
                          height: 6,
                          borderRadius: 3,
                          backgroundColor: dot.done ? colors.textMuted : colors.priority[dot.priority],
                          opacity: dot.done ? 0.5 : 1,
                        }}
                      />
                    ))}
                  </View>
                </View>
              </Pressable>
            );
          })}
        </View>
      ))}
    </Card>
  );
}
