# Focus mode and "parking" thoughts (stage 18)
- From a pending task's editor: «حالت تمرکز». A dark full screen shows ONLY the task, its current checklist step and a timer
  (15/25/35/45/60 min). Everything else is hidden. A chime notification fires when the time is over, even with the screen locked.
- «🧠 پارک کردن فکر»: type or hold the microphone; the thought goes to the inbox with the message "ثبتش کردم و بعداً انجامش می‌دیم".
- If the task has a checklist, the first unfinished item is the "current step"; «این قدم تمام شد» ticks it.
- Limits: the screen is not kept awake automatically; if the app is closed the on-screen timer restarts (the end chime still fires).
