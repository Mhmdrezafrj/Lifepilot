import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { completeStep, currentStepIndex, focusState } from '../../src/features/focus/services/focus';

describe('focus timer', () => {
  const start = 1_000_000;
  const ends = start + 25 * 60_000;

  it('counts down and reports progress', () => {
    assert.deepEqual(focusState(ends, 25, start), { remainingMs: 25 * 60_000, progress: 0, finished: false });
    const mid = focusState(ends, 25, start + 10 * 60_000);
    assert.equal(mid.remainingMs, 15 * 60_000);
    assert.equal(mid.progress, 0.4);
    assert.equal(mid.finished, false);
  });

  it('finishes exactly at the end and never exceeds 100%', () => {
    const done = focusState(ends, 25, ends);
    assert.equal(done.finished, true);
    assert.equal(done.progress, 1);
    const over = focusState(ends, 25, ends + 60_000);
    assert.equal(over.finished, true);
    assert.equal(over.progress, 1);
    assert.ok(over.remainingMs < 0);
  });
});

describe('focus steps (checklist)', () => {
  const items = [{ title: 'a', isCompleted: true }, { title: 'b', isCompleted: false }, { title: 'c', isCompleted: false }];

  it('finds the current step', () => {
    assert.equal(currentStepIndex(items), 1);
    assert.equal(currentStepIndex([]), -1);
    assert.equal(currentStepIndex([{ title: 'x', isCompleted: true }]), -1);
  });

  it('completes one step without touching the others', () => {
    const next = completeStep(items, 1);
    assert.deepEqual(next.map((i) => i.isCompleted), [true, true, false]);
    assert.equal(currentStepIndex(next), 2);
    assert.deepEqual(items.map((i) => i.isCompleted), [true, false, false]); // input unchanged
  });
});
