export const FOCUS_OPTIONS = [15, 25, 35, 45, 60] as const;
export const FOCUS_NOTIFICATION_ID = 'focus-end';

export interface FocusState {
  /** Negative once the time is over. */
  remainingMs: number;
  /** 0..1 */
  progress: number;
  finished: boolean;
}

/** State of a focus session that started `minutes` before it ends at `endsAt`. */
export function focusState(endsAt: number, minutes: number, now: number): FocusState {
  const length = Math.max(1, minutes) * 60_000;
  const remainingMs = endsAt - now;
  return {
    remainingMs,
    progress: Math.min(1, Math.max(0, 1 - remainingMs / length)),
    finished: remainingMs <= 0,
  };
}

export interface StepItem {
  title: string;
  isCompleted: boolean;
}

/** Index of the first unfinished checklist item (the "current step"), or -1 when all are done or there are none. */
export function currentStepIndex(items: StepItem[]): number {
  return items.findIndex((i) => !i.isCompleted);
}

export function completeStep(items: StepItem[], index: number): StepItem[] {
  return items.map((it, i) => (i === index ? { title: it.title, isCompleted: true } : { title: it.title, isCompleted: it.isCompleted }));
}

export const PARKED_MESSAGE = 'باشه، نگران نباش؛ ثبتش کردم و بعداً انجامش می‌دیم 🧘';
