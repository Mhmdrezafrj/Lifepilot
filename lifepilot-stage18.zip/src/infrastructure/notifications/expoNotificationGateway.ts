import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import { toPersianDigits } from '../../core/calendar/format';
import { buildReminderContent } from './reminderText';
import { NUDGE_PREFIX, PlannedNudge, PlannedSummary, SUMMARY_PREFIX } from '../../features/nudges/services/nudgePlanner';
import { BLOCK_PREFIX, BlockNotification } from '../../features/study/services/blockPlanner';
import {
  ACTION_COMPLETE, ACTION_SNOOZE, ALARM_CHANNEL_ID, ALARM_SOUND_FILE, LEGACY_CHANNEL_ID, REMINDER_CATEGORY,
  REMINDER_CHANNEL_ID, STUDY_DATA_TYPE, STUDY_PREFIX, SUMMARY_DATA_TYPE, BLOCK_DATA_TYPE, STEP_CHANNEL_ID, STEP_SOUND_FILE,
} from './notificationResponse';
import type { NotificationGateway, PermissionState, PlannedReminder } from './types';

/** Must run once at startup (module level): decides how notifications look while the app is open. */
export function configureNotificationHandler(): void {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldPlaySound: true,
      shouldSetBadge: false,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
}

/** Creates the Android channel and the action buttons. Safe to call many times. */
export async function setupNotifications(): Promise<void> {
  if (Platform.OS !== 'android') return;
  // The first version used another channel id; remove it so old (possibly muted) settings do not linger.
  await Notifications.deleteNotificationChannelAsync(LEGACY_CHANNEL_ID).catch(() => {});

  // Normal notification: short system sound.
  await Notifications.setNotificationChannelAsync(REMINDER_CHANNEL_ID, {
    name: 'یادآوری کارها (اعلان)',
    description: 'اعلان معمولی با صدای کوتاه',
    importance: Notifications.AndroidImportance.HIGH,
    vibrationPattern: [0, 400, 200, 400],
    enableVibrate: true,
    sound: 'default',
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
  } as Notifications.NotificationChannelInput);

  // Alarm ring: 15-second tone played on the ALARM volume (rings even in silent mode).
  await Notifications.setNotificationChannelAsync(ALARM_CHANNEL_ID, {
    name: 'زنگ آلارم یادآوری',
    description: 'صدای بلند ۱۵ ثانیه‌ای با بلندی آلارم',
    importance: Notifications.AndroidImportance.MAX,
    vibrationPattern: [0, 800, 400, 800, 400, 800, 400, 800],
    enableVibrate: true,
    enableLights: true,
    lightColor: '#FF818CF8',
    sound: ALARM_SOUND_FILE,
    audioAttributes: {
      usage: Notifications.AndroidAudioUsage.ALARM,
      contentType: Notifications.AndroidAudioContentType.SONIFICATION,
    },
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
  } as Notifications.NotificationChannelInput);
  // Short chime for study-session steps (alarm volume, so it is heard in silent mode too).
  await Notifications.setNotificationChannelAsync(STEP_CHANNEL_ID, {
    name: 'مراحل جلسه‌ی مطالعه',
    description: 'آلارم کوتاه سر هر مرحله',
    importance: Notifications.AndroidImportance.HIGH,
    vibrationPattern: [0, 250, 150, 250],
    enableVibrate: true,
    sound: STEP_SOUND_FILE,
    audioAttributes: {
      usage: Notifications.AndroidAudioUsage.ALARM,
      contentType: Notifications.AndroidAudioContentType.SONIFICATION,
    },
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
  } as Notifications.NotificationChannelInput);
  await Notifications.setNotificationCategoryAsync(REMINDER_CATEGORY, [
    { identifier: ACTION_COMPLETE, buttonTitle: 'انجام شد', options: { opensAppToForeground: true } },
    { identifier: ACTION_SNOOZE, buttonTitle: '۱۰ دقیقه بعد', options: { opensAppToForeground: true } },
  ]);
}

function mapPermission(status: string): PermissionState {
  if (status === 'granted') return 'granted';
  if (status === 'denied') return 'denied';
  return 'undetermined';
}

export async function getNotificationPermission(): Promise<{ state: PermissionState; canAskAgain: boolean }> {
  if (Platform.OS !== 'android') return { state: 'unavailable', canAskAgain: false };
  const p = await Notifications.getPermissionsAsync();
  return { state: mapPermission(p.status), canAskAgain: p.canAskAgain };
}

export async function requestNotificationPermission(): Promise<{ state: PermissionState; canAskAgain: boolean }> {
  if (Platform.OS !== 'android') return { state: 'unavailable', canAskAgain: false };
  await setupNotifications(); // Android 13+ shows the prompt only once a channel exists
  const p = await Notifications.requestPermissionsAsync();
  return { state: mapPermission(p.status), canAskAgain: p.canAskAgain };
}

/** A real notification a few seconds from now, so the user can check delivery (and the ring) on their own phone. */
export async function scheduleTestNotification(seconds = 10, style: 'notification' | 'alarm' = 'notification'): Promise<void> {
  await setupNotifications();
  const alarm = style === 'alarm';
  await Notifications.scheduleNotificationAsync({
    identifier: 'lifepilot-test',
    content: {
      title: alarm ? 'تست زنگ آلارم لایف‌پایلوت ⏰' : 'اعلان آزمایشی لایف‌پایلوت',
      body: alarm ? 'اگر صدای زنگ را شنیدید، یادآوری با زنگ روی گوشی شما کار می‌کند ✅' : 'اگر این را می‌بینید، اعلان‌ها روی گوشی شما کار می‌کنند ✅',
      ...(alarm ? { sound: ALARM_SOUND_FILE } : {}),
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DATE,
      date: new Date(Date.now() + seconds * 1000),
      channelId: alarm ? ALARM_CHANNEL_ID : REMINDER_CHANNEL_ID,
    },
  });
}

/** Replaces the daily study-review notifications with a new list (a normal notification, not the alarm ring). */
export async function replaceStudyReminders(items: { id: string; fireAt: number; count: number }[]): Promise<void> {
  if (Platform.OS !== 'android') return;
  const all = await Notifications.getAllScheduledNotificationsAsync();
  for (const n of all) {
    if (n.identifier.startsWith(STUDY_PREFIX)) await Notifications.cancelScheduledNotificationAsync(n.identifier);
  }
  if (items.length === 0) return;
  await setupNotifications();
  for (const it of items) {
    await Notifications.scheduleNotificationAsync({
      identifier: it.id,
      content: {
        title: 'وقت مرور درسی 📚',
        body: `${toPersianDigits(it.count)} مبحث برای مرور امروز آماده است`,
        data: { type: STUDY_DATA_TYPE },
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: new Date(it.fireAt),
        channelId: REMINDER_CHANNEL_ID,
      },
    });
  }
}

/** A chime when the focus time is over (works even if the screen is locked). */
export async function scheduleFocusEnd(fireAt: number): Promise<void> {
  if (Platform.OS !== 'android') return;
  await setupNotifications();
  await Notifications.cancelScheduledNotificationAsync('focus-end').catch(() => {});
  await Notifications.scheduleNotificationAsync({
    identifier: 'focus-end',
    content: { title: '🎉 زمان تمرکز تمام شد', body: 'آفرین! کمی استراحت کن.', sound: STEP_SOUND_FILE },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: new Date(fireAt), channelId: STEP_CHANNEL_ID },
  });
}

export async function cancelFocusEnd(): Promise<void> {
  if (Platform.OS !== 'android') return;
  await Notifications.cancelScheduledNotificationAsync('focus-end');
}

/** Replaces the study-session alerts: a ring at the start time, and a short chime between steps. */
export async function replaceBlockNotifications(items: BlockNotification[]): Promise<void> {
  if (Platform.OS !== 'android') return;
  const all = await Notifications.getAllScheduledNotificationsAsync();
  for (const n of all) {
    if (n.identifier.startsWith(BLOCK_PREFIX)) await Notifications.cancelScheduledNotificationAsync(n.identifier);
  }
  if (items.length === 0) return;
  await setupNotifications();
  for (const it of items) {
    const start = it.kind === 'start';
    await Notifications.scheduleNotificationAsync({
      identifier: it.id,
      content: {
        title: it.title,
        body: it.body,
        data: { type: BLOCK_DATA_TYPE, blockId: it.blockId },
        sound: start ? ALARM_SOUND_FILE : STEP_SOUND_FILE,
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: new Date(it.fireAt),
        channelId: start ? ALARM_CHANNEL_ID : STEP_CHANNEL_ID,
      },
    });
  }
}

/** Replaces the random extra reminders and the morning summaries with new lists. */
export async function replaceNudges(nudges: PlannedNudge[], summaries: PlannedSummary[]): Promise<void> {
  if (Platform.OS !== 'android') return;
  const all = await Notifications.getAllScheduledNotificationsAsync();
  for (const n of all) {
    if (n.identifier.startsWith(NUDGE_PREFIX) || n.identifier.startsWith(SUMMARY_PREFIX)) {
      await Notifications.cancelScheduledNotificationAsync(n.identifier);
    }
  }
  if (nudges.length === 0 && summaries.length === 0) return;
  await setupNotifications();
  const channelId = REMINDER_CHANNEL_ID;
  for (const it of nudges) {
    await Notifications.scheduleNotificationAsync({
      identifier: it.id,
      content: { title: it.title, body: it.body, data: { taskId: it.taskId, reminderId: null, plannedFireAt: it.fireAt } },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: new Date(it.fireAt), channelId },
    });
  }
  for (const it of summaries) {
    await Notifications.scheduleNotificationAsync({
      identifier: it.id,
      content: { title: it.title, body: it.body, data: { type: SUMMARY_DATA_TYPE } },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: new Date(it.fireAt), channelId },
    });
  }
}

/**
 * NotificationGateway on top of expo-notifications. On Android it uses AlarmManager under the hood,
 * keeps scheduled notifications across phone restarts, and uses exact timing when Android allows it.
 */
export function createExpoNotificationGateway(): NotificationGateway {
  return {
    isAvailable: async () => Platform.OS === 'android',
    getPermission: async () => (await getNotificationPermission()).state,
    requestPermission: async () => (await requestNotificationPermission()).state,

    async schedule(r: PlannedReminder): Promise<void> {
      const { title, body } = buildReminderContent(r);
      await Notifications.scheduleNotificationAsync({
        identifier: r.id,
        content: {
          title,
          body,
          data: { taskId: r.taskId, reminderId: r.reminderId, plannedFireAt: r.fireAt },
          categoryIdentifier: REMINDER_CATEGORY,
          ...(r.channel === 'alarm' ? { sound: ALARM_SOUND_FILE } : {}),
        },
        trigger: {
          type: Notifications.SchedulableTriggerInputTypes.DATE,
          date: new Date(r.fireAt),
          channelId: r.channel === 'alarm' ? ALARM_CHANNEL_ID : REMINDER_CHANNEL_ID,
        },
      });
    },

    async cancel(plannedId: string): Promise<void> {
      await Notifications.cancelScheduledNotificationAsync(plannedId);
    },

    async cancelForTask(taskId: string): Promise<void> {
      const all = await Notifications.getAllScheduledNotificationsAsync();
      for (const n of all) {
        const data = n.content.data as { taskId?: unknown } | null;
        if (data && data.taskId === taskId) await Notifications.cancelScheduledNotificationAsync(n.identifier);
      }
    },
  };
}
