import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { Task } from '../../src/features/tasks/models/task';
import { SOON_MINUTES, buildQuickModel, buildTodayModel } from '../../src/features/widgets/services/widgetModel';
import { VIVID, blinkPhase, makeWidgetTheme, rowLook, vividColor } from '../../src/features/widgets/services/widgetStyle';

const NOW = new Date(2026, 10, 5, 12, 0).getTime();
const at = (h: number, m = 0) => new Date(2026, 10, 5, h, m).getTime();
const t = (over: Partial<Task>): Task => ({
  id: 'x', title: 'x', description: null, dueAt: null, hasTime: false, priority: 'medium', categoryId: null,
  status: 'pending', snoozedUntil: null, createdAt: 0, updatedAt: 0, completedAt: null, recurrenceId: null,
  tags: [], checklist: [], reminders: [], recurrence: null, ...over,
});

describe('widget urgency', () => {
  it('marks overdue, soon, normal and done tasks', () => {
    const tasks = [
      t({ id: 'o', dueAt: at(9), hasTime: true }),
      t({ id: 's', dueAt: at(13, 15), hasTime: true }),
      t({ id: 'n', dueAt: at(20), hasTime: true }),
      t({ id: 'd', dueAt: at(14), hasTime: true, status: 'completed' }),
      t({ id: 'a', dueAt: at(0) }),
    ];
    const m = buildTodayModel(tasks, tasks.filter((x) => x.status === 'pending'), NOW);
    const by = new Map(m.items.map((i) => [i.id, i]));
    assert.equal(by.get('o')?.urgency, 'overdue');
    assert.equal(by.get('s')?.urgency, 'soon');
    assert.equal(by.get('s')?.minutesLeft, 75);
    assert.equal(by.get('n')?.urgency, 'normal');
    assert.equal(by.get('d')?.urgency, 'done');
    assert.equal(by.get('a')?.urgency, 'normal'); // date-only today is not urgent
    assert.equal(SOON_MINUTES, 120);
  });

  it('counts urgent tasks (overdue + soon) from all pending tasks', () => {
    const pending = [t({ id: 'o', dueAt: at(9), hasTime: true }), t({ id: 's', dueAt: at(13), hasTime: true }), t({ id: 'n', dueAt: at(20), hasTime: true })];
    assert.equal(buildTodayModel(pending, pending, NOW).urgent, 2);
    assert.equal(buildQuickModel(pending, pending, NOW).urgent, 2);
    assert.equal(buildTodayModel([], [], NOW).urgent, 0);
  });

  it('the quick widget carries the next task urgency', () => {
    const q = buildQuickModel([], [t({ id: 's', dueAt: at(12, 30), hasTime: true })], NOW);
    assert.equal(q.next?.urgency, 'soon');
    assert.equal(q.next?.minutesLeft, 30);
  });
});

describe('widget colours and blink', () => {
  const theme = makeWidgetTheme('indigo');

  it('gives each task a stable bright colour from the palette', () => {
    assert.equal(vividColor('abc'), vividColor('abc'));
    for (const id of ['a', 'b', 'c', 'task-1', 'x'.repeat(40)]) assert.ok((VIVID as readonly string[]).includes(vividColor(id)));
    assert.ok(new Set(Array.from({ length: 40 }, (_, i) => vividColor(`id${i}`))).size >= 4);
  });

  it('the blink phase flips every minute', () => {
    const base = Math.floor(NOW / 60_000) * 60_000;
    assert.notEqual(blinkPhase(base), blinkPhase(base + 60_000));
    assert.equal(blinkPhase(base), blinkPhase(base + 30_000));
    assert.equal(blinkPhase(base), blinkPhase(base + 120_000));
  });

  it('urgent rows are bright in one phase and dim in the other', () => {
    assert.equal(rowLook('overdue', 'a', 0, 0, theme).bright, true);
    assert.equal(rowLook('overdue', 'a', 0, 1, theme).bright, false);
    assert.equal(rowLook('soon', 'a', 3, 0, theme).bright, true);
    assert.equal(rowLook('overdue', 'a', 0, 0, theme).color, theme.danger);
    assert.equal(rowLook('soon', 'a', 0, 0, theme).color, '#FFB020');
  });

  it('normal rows alternate by position; done rows never light up', () => {
    assert.equal(rowLook('normal', 'a', 0, 0, theme).bright, true);
    assert.equal(rowLook('normal', 'a', 1, 0, theme).bright, false);
    assert.equal(rowLook('normal', 'a', 0, 1, theme).bright, false);
    assert.equal(rowLook('done', 'a', 0, 0, theme).bright, false);
    assert.equal(rowLook('done', 'a', 0, 0, theme).color, theme.success);
    assert.notEqual(rowLook('normal', 'a', 0, 0, theme).bg, rowLook('normal', 'a', 1, 0, theme).bg);
  });
});
