# Home-screen widgets (stage 20: attention-grabbing)
- Rows have vivid, different colours; overdue = red, due within 2 hours = amber with a countdown ("⏳ ۴۵ دقیقه مانده"), done = green.
- "Blink": Android widgets cannot animate, so urgent rows alternate bright/dim and the pattern flips every minute; a big chip
  "🔥 N کار فوری" alternates red/amber; the quick widget card alternates red/amber when the next task is urgent.
  The picture only changes when the widget redraws: when tasks change, when the app opens/closes, and about every 30 minutes (Android limit).
- Real continuous blinking would need native code and extra battery; not implemented.
- Tapping a row opens the task; "+" and the microphone add a task.
