import React from 'react';
import { FlexWidget, ListWidget, TextWidget } from 'react-native-android-widget';
import { toPersianDigits } from '../../../core/calendar/format';
import { orderForHost, progressWidth, rgba, rowLook } from '../services/widgetStyle';
import { TodayWidgetModel, WidgetTaskItem, widgetLinks } from '../services/widgetModel';
import { WidgetRenderProps, st } from './widgetKit';

interface Props extends WidgetRenderProps {
  model: TodayWidgetModel;
}

function statusText(item: WidgetTaskItem): string {
  if (item.urgency === 'done') return 'انجام شد ✓';
  if (item.urgency === 'overdue') return '⚠️ عقب‌افتاده';
  if (item.urgency === 'soon' && item.minutesLeft !== null) return `⏳ ${toPersianDigits(item.minutesLeft)} دقیقه مانده`;
  return '';
}

function Row({ item, index, theme, hostRtl, fonts, phase }: { item: WidgetTaskItem; index: number } & WidgetRenderProps) {
  const look = rowLook(item.urgency, item.id, index, phase, theme);
  const status = statusText(item);
  const hot = item.urgency === 'overdue' || item.urgency === 'soon';

  const bar = <FlexWidget key="bar" style={st({ width: 6, height: 40, borderRadius: 3, backgroundColor: look.color })} />;
  const body = (
    <FlexWidget key="body" style={st({ flex: 1, flexDirection: 'column' })}>
      <TextWidget
        text={item.title}
        style={st({
          fontSize: 15, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right',
          color: item.urgency === 'done' ? theme.muted : '#FFFFFF',
        })}
      />
      {status ? (
        <TextWidget
          text={status}
          style={st({ fontSize: 12, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right', color: look.color })}
        />
      ) : null}
    </FlexWidget>
  );
  const time = (
    <FlexWidget
      key="time"
      style={st({ paddingHorizontal: 10, paddingVertical: 6, borderRadius: 12, backgroundColor: rgba(look.color, look.bright ? 0.55 : 0.3) })}
    >
      <TextWidget text={item.timeLabel} style={st({ fontSize: 14, fontWeight: 'bold', fontFamily: fonts.bold, color: '#FFFFFF' })} />
    </FlexWidget>
  );

  return (
    <FlexWidget
      clickAction="OPEN_URI"
      clickActionData={{ uri: widgetLinks.task(item.id) }}
      style={st({
        width: 'match_parent', flexDirection: 'row', alignItems: 'center', flexGap: 10,
        paddingHorizontal: 12, paddingVertical: 10, marginTop: 7, borderRadius: 18, backgroundColor: look.bg,
        ...(hot || look.bright ? { borderWidth: 2, borderColor: look.color } : {}),
      })}
    >
      {orderForHost([bar, body, time], hostRtl)}
    </FlexWidget>
  );
}

export function TodayWidget({ model, theme, width, hostRtl, fonts, phase }: Props) {
  const barWidth = Math.max(80, width - 28);
  const fill = progressWidth(barWidth, model.progress);

  const dateBlock = (
    <FlexWidget key="date" style={st({ flexDirection: 'column' })}>
      <TextWidget text={model.weekday} style={st({ fontSize: 12, fontFamily: fonts.regular, textAlign: 'right', color: theme.muted })} />
      <TextWidget text={model.dateLabel} style={st({ fontSize: 26, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right', color: theme.text })} />
    </FlexWidget>
  );

  const buttons = (
    <FlexWidget key="buttons" style={st({ flexDirection: 'row', alignItems: 'center', flexGap: 8 })}>
      {orderForHost(
        [
          <FlexWidget
            key="plus"
            clickAction="OPEN_URI"
            clickActionData={{ uri: widgetLinks.newTask(model.todayStart) }}
            accessibilityLabel="افزودن کار جدید"
            style={st({
              width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center',
              backgroundGradient: { from: theme.accent, to: theme.accentDeep, orientation: 'TL_BR' },
            })}
          >
            <TextWidget text="+" style={st({ fontSize: 32, fontWeight: 'bold', color: '#FFFFFF' })} />
          </FlexWidget>,
          <FlexWidget
            key="mic"
            clickAction="OPEN_URI"
            clickActionData={{ uri: widgetLinks.newTaskByVoice(model.todayStart) }}
            accessibilityLabel="افزودن کار با صدا"
            style={st({ width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.track })}
          >
            <TextWidget text="🎙" style={st({ fontSize: 21, color: '#FFFFFF' })} />
          </FlexWidget>,
        ],
        hostRtl,
      )}
    </FlexWidget>
  );

  const summary =
    model.total === 0
      ? 'برای امروز کاری ثبت نشده'
      : `${toPersianDigits(model.done)} از ${toPersianDigits(model.total)} کار انجام شد`;

  // Big attention chip: its colour alternates with the blink phase.
  const urgentChip =
    model.urgent > 0 ? (
      <FlexWidget
        key="urgent"
        clickAction="OPEN_URI"
        clickActionData={{ uri: 'lifepilot://tasks' }}
        style={st({
          paddingHorizontal: 12, paddingVertical: 5, borderRadius: 14,
          backgroundColor: phase === 0 ? theme.danger : rgba('#FFB020', 0.95),
        })}
      >
        <TextWidget
          text={`🔥 ${toPersianDigits(model.urgent)} کار فوری`}
          style={st({ fontSize: 13, fontWeight: 'bold', fontFamily: fonts.bold, color: '#10131F' })}
        />
      </FlexWidget>
    ) : (
      <FlexWidget key="urgent" style={st({ width: 1, height: 1 })} />
    );

  return (
    <FlexWidget
      style={st({
        height: 'match_parent', width: 'match_parent', flexDirection: 'column', padding: 14, borderRadius: 28,
        backgroundGradient: { from: theme.bgFrom, to: theme.bgTo, orientation: 'TL_BR' },
      })}
    >
      <FlexWidget style={st({ width: 'match_parent', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' })}>
        {orderForHost([dateBlock, buttons], hostRtl)}
      </FlexWidget>

      <FlexWidget style={st({ width: 'match_parent', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 })}>
        {orderForHost(
          [
            <TextWidget key="sum" text={summary} style={st({ fontSize: 13, fontFamily: fonts.regular, color: theme.muted })} />,
            urgentChip,
          ],
          hostRtl,
        )}
      </FlexWidget>

      <FlexWidget
        style={st({
          width: barWidth, height: 6, borderRadius: 3, marginTop: 8, backgroundColor: theme.track,
          flexDirection: 'row', justifyContent: hostRtl ? 'flex-start' : 'flex-end',
        })}
      >
        <FlexWidget style={st({ width: fill, height: 6, borderRadius: 3, backgroundColor: theme.accent })} />
      </FlexWidget>

      {model.items.length === 0 ? (
        <FlexWidget
          clickAction="OPEN_URI"
          clickActionData={{ uri: widgetLinks.newTask(model.todayStart) }}
          style={st({ flex: 1, width: 'match_parent', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' })}
        >
          <TextWidget text="✨" style={st({ fontSize: 34, color: '#FFFFFF' })} />
          <TextWidget text="امروز کاری ندارید" style={st({ fontSize: 15, fontWeight: 'bold', fontFamily: fonts.bold, color: theme.text, marginTop: 6 })} />
          <TextWidget text="برای ساختن اولین کار، همین‌جا بزنید" style={st({ fontSize: 12, fontFamily: fonts.regular, color: theme.muted, marginTop: 2 })} />
        </FlexWidget>
      ) : (
        <ListWidget style={st({ height: 'match_parent', width: 'match_parent', marginTop: 4 })}>
          {model.items.map((item, i) => (
            <Row key={item.id} item={item} index={i} theme={theme} width={width} hostRtl={hostRtl} fonts={fonts} phase={phase} />
          ))}
        </ListWidget>
      )}
    </FlexWidget>
  );
}
