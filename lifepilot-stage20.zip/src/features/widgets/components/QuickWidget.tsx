import React from 'react';
import { FlexWidget, TextWidget } from 'react-native-android-widget';
import { toPersianDigits } from '../../../core/calendar/format';
import { orderForHost, rgba } from '../services/widgetStyle';
import { QuickWidgetModel, widgetLinks } from '../services/widgetModel';
import { WidgetRenderProps, st } from './widgetKit';

interface Props extends WidgetRenderProps {
  model: QuickWidgetModel;
}

export function QuickWidget({ model, theme, hostRtl, fonts, phase }: Props) {
  const next = model.next;
  const hot = next !== null && (next.urgency === 'overdue' || next.urgency === 'soon');
  // Urgent next task: the whole card alternates between red and amber; otherwise the calm accent look.
  const gradient = hot
    ? { from: phase === 0 ? '#B91C1C' : '#B45309', to: theme.bgTo, orientation: 'TL_BR' as const }
    : { from: theme.accentDeep, to: theme.bgTo, orientation: 'TL_BR' as const };
  const hint =
    next === null
      ? ''
      : next.urgency === 'overdue'
        ? '⚠️ عقب‌افتاده'
        : next.urgency === 'soon' && next.minutesLeft !== null
          ? `⏳ ${toPersianDigits(next.minutesLeft)} دقیقه مانده`
          : '';

  const info = (
    <FlexWidget
      key="info"
      clickAction={next ? 'OPEN_URI' : 'OPEN_APP'}
      clickActionData={next ? { uri: widgetLinks.task(next.id) } : undefined}
      style={st({ flex: 1, flexDirection: 'column' })}
    >
      <TextWidget
        text={next ? (hot ? '🔥 کار فوری' : 'کار بعدی') : `${model.weekday}، ${model.dateLabel}`}
        style={st({ fontSize: 12, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right', color: hot ? '#FFFFFF' : theme.accent })}
      />
      <TextWidget
        text={next ? next.title : 'کاری در پیش ندارید'}
        style={st({ fontSize: 18, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right', color: theme.text, marginTop: 2 })}
      />
      {next ? (
        <FlexWidget style={st({ flexDirection: 'row', alignItems: 'center', flexGap: 8, marginTop: 6 })}>
          {orderForHost(
            [
              <FlexWidget key="t" style={st({ paddingHorizontal: 10, paddingVertical: 5, borderRadius: 12, backgroundColor: rgba('#FFFFFF', 0.22) })}>
                <TextWidget text={next.timeLabel} style={st({ fontSize: 14, fontWeight: 'bold', fontFamily: fonts.bold, color: '#FFFFFF' })} />
              </FlexWidget>,
              <TextWidget key="d" text={hint || next.dayLabel} style={st({ fontSize: 13, fontWeight: hint ? 'bold' : 'normal', fontFamily: hint ? fonts.bold : fonts.regular, color: hint ? '#FFFFFF' : theme.muted })} />,
            ],
            hostRtl,
          )}
        </FlexWidget>
      ) : (
        <TextWidget text="با دکمه‌ی + یک کار بسازید" style={st({ fontSize: 12, fontFamily: fonts.regular, textAlign: 'right', color: theme.muted, marginTop: 4 })} />
      )}
      <TextWidget
        text={`${toPersianDigits(model.remainingToday)} کار باقی‌مانده امروز${model.urgent > 0 ? ` · 🔥 ${toPersianDigits(model.urgent)} فوری` : ''}`}
        style={st({ fontSize: 12, fontFamily: fonts.regular, textAlign: 'right', color: model.urgent > 0 ? '#FFD166' : theme.muted, marginTop: 6 })}
      />
    </FlexWidget>
  );

  const buttons = (
    <FlexWidget key="buttons" style={st({ flexDirection: 'column', alignItems: 'center', flexGap: 8 })}>
      <FlexWidget
        clickAction="OPEN_URI"
        clickActionData={{ uri: widgetLinks.newTask(model.todayStart) }}
        accessibilityLabel="افزودن کار جدید"
        style={st({ width: 56, height: 56, borderRadius: 28, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFFFFF' })}
      >
        <TextWidget text="+" style={st({ fontSize: 34, fontWeight: 'bold', color: theme.accentDeep })} />
      </FlexWidget>
      <FlexWidget
        clickAction="OPEN_URI"
        clickActionData={{ uri: widgetLinks.newTaskByVoice(model.todayStart) }}
        accessibilityLabel="افزودن کار با صدا"
        style={st({ width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.track })}
      >
        <TextWidget text="🎙" style={st({ fontSize: 18, color: '#FFFFFF' })} />
      </FlexWidget>
    </FlexWidget>
  );

  return (
    <FlexWidget
      style={st({
        height: 'match_parent', width: 'match_parent', flexDirection: 'row', alignItems: 'center', flexGap: 12,
        padding: 14, borderRadius: 28, backgroundGradient: gradient,
      })}
    >
      {orderForHost([info, buttons], hostRtl)}
    </FlexWidget>
  );
}
