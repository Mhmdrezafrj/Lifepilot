import { AccentKey, Priority, accents, buildColors } from '../../../core/theme/colors';
import type { Urgency } from './widgetModel';

export type Hex = `#${string}`;
export type Rgba = `rgba(${number}, ${number}, ${number}, ${number})`;

const asHex = (s: string): Hex => s as Hex;

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

/** '#4F46E5' + 0.2 -> 'rgba(79, 70, 229, 0.2)' (the format Android widgets accept for transparency). */
export function rgba(hex: string, alpha: number): Rgba {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

/** Mixes a color with black. amount 0 = same, 1 = black. */
export function darken(hex: string, amount: number): Hex {
  const [r, g, b] = hexToRgb(hex).map((v) => Math.round(v * (1 - amount)));
  const to = (v: number) => v.toString(16).padStart(2, '0');
  return `#${to(r)}${to(g)}${to(b)}`.toUpperCase() as Hex;
}

/** Whether the launcher that draws the widget is right-to-left, judged from the phone's language. */
export function isRtlLocale(locale: string | undefined): boolean {
  return /^(fa|ar|he|ur|ps|ku|dv)(-|_|$)/i.test(locale ?? '');
}

/**
 * Persian reads right-to-left. `logical` lists children in Persian reading order (start first).
 * A right-to-left launcher flips rows by itself; a left-to-right launcher needs the order reversed.
 */
export function orderForHost<T>(logical: T[], hostRtl: boolean): T[] {
  return hostRtl ? logical : [...logical].reverse();
}

/** Width in dp of the filled part of a progress bar. */
export function progressWidth(total: number, ratio: number): number {
  return Math.round(Math.max(0, Math.min(1, ratio)) * Math.max(0, total));
}

export interface WidgetTheme {
  bgFrom: Hex;
  bgTo: Hex;
  text: Hex;
  muted: Hex;
  accent: Hex;
  accentDeep: Hex;
  accentSoft: Rgba;
  surface: Rgba;
  track: Rgba;
  success: Hex;
  successSoft: Rgba;
  danger: Hex;
  dangerSoft: Rgba;
  priority: Record<Priority, Hex>;
}

/** Widgets always use the dark look (it reads well on any wallpaper) in the user's accent color. */
export function makeWidgetTheme(accent: AccentKey): WidgetTheme {
  const c = buildColors('dark', accent);
  const a = accents[accent].dark;
  return {
    bgFrom: asHex('#1B2340'),
    bgTo: asHex('#0B1020'),
    text: asHex('#F3F4F6'),
    muted: asHex('#A3ABBD'),
    accent: asHex(a),
    accentDeep: darken(a, 0.45),
    accentSoft: rgba(a, 0.2),
    surface: rgba('#FFFFFF', 0.07),
    track: rgba('#FFFFFF', 0.12),
    success: asHex(c.success),
    successSoft: rgba(c.success, 0.18),
    danger: asHex(c.danger),
    dangerSoft: rgba(c.danger, 0.18),
    priority: {
      low: asHex(c.priority.low),
      medium: asHex(c.priority.medium),
      high: asHex(c.priority.high),
      critical: asHex(c.priority.critical),
    },
  };
}

/** Bright colours, one per task (stable for a task id), so the list looks lively. */
export const VIVID = ['#FF6B6B', '#FFB020', '#4ADE80', '#22D3EE', '#A78BFA', '#F472B6'] as const;

export function vividColor(id: string): Hex {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return VIVID[h % VIVID.length] as Hex;
}

/**
 * Android widgets cannot animate. To catch the eye anyway, rows alternate between a bright and a dim look,
 * and the pattern flips every minute, so each refresh looks different from the previous one.
 */
export function blinkPhase(now: number): 0 | 1 {
  return (Math.floor(now / 60_000) % 2) as 0 | 1;
}

export interface RowLook {
  color: Hex;
  bg: Rgba;
  bright: boolean;
}

export function rowLook(urgency: Urgency, id: string, index: number, phase: 0 | 1, theme: WidgetTheme): RowLook {
  const color: Hex = urgency === 'overdue' ? theme.danger : urgency === 'soon' ? asHex('#FFB020') : urgency === 'done' ? theme.success : vividColor(id);
  const bright = urgency === 'overdue' || urgency === 'soon' ? phase === 0 : urgency !== 'done' && (index + phase) % 2 === 0;
  const alpha = urgency === 'done' ? 0.08 : bright ? 0.36 : 0.14;
  return { color, bg: rgba(color, alpha), bright };
}
