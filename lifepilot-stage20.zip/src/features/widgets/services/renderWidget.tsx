import React from 'react';
import Constants from 'expo-constants';
import { QuickWidget } from '../components/QuickWidget';
import { TodayWidget } from '../components/TodayWidget';
import type { WidgetFonts } from '../components/widgetKit';
import { loadWidgetData } from './loadWidgetData';
import { blinkPhase, isRtlLocale, makeWidgetTheme } from './widgetStyle';

export const WIDGET_NAMES = { today: 'TodayWidget', quick: 'QuickWidget' } as const;

function detectHostRtl(): boolean {
  try {
    return isRtlLocale(new Intl.DateTimeFormat().resolvedOptions().locale);
  } catch {
    return false;
  }
}

/** Persian font files are bundled into the widget only when they were found at build time. */
function widgetFonts(): WidgetFonts {
  const extra = Constants.expoConfig?.extra as { widgetFonts?: boolean } | undefined;
  return extra?.widgetFonts ? { regular: 'Vazirmatn_400Regular', bold: 'Vazirmatn_700Bold' } : {};
}

/** Builds the widget picture from the real database. width is the widget width in dp, if known. */
export async function renderWidgetElement(name: string, width?: number): Promise<React.ReactElement | null> {
  const data = await loadWidgetData();
  const common = {
    theme: makeWidgetTheme(data.accent),
    width: width && width > 0 ? width : 300,
    hostRtl: detectHostRtl(),
    fonts: widgetFonts(),
    phase: blinkPhase(Date.now()),
  };
  if (name === WIDGET_NAMES.today) return <TodayWidget model={data.today} {...common} />;
  if (name === WIDGET_NAMES.quick) return <QuickWidget model={data.quick} {...common} />;
  return null;
}
