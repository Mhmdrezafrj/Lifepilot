// App entry: Expo Router, plus the home-screen widget task handler.
import 'expo-router/entry';
import { registerWidgetTaskHandler } from 'react-native-android-widget';
import { widgetTaskHandler } from './src/features/widgets/widgetTaskHandler';

registerWidgetTaskHandler(widgetTaskHandler);
