# Home-screen widgets

Two Android widgets (library: react-native-android-widget 0.20.1), drawn from the real database even when the app is closed:
- **برنامه امروز (4x4):** Persian date, progress bar, today's tasks with their time (or "همه‌روز"), overdue count, "+" and microphone buttons, tap a task to open it.
- **کار بعدی و افزودن سریع (4x2):** next task with day and time, remaining/overdue counts, big "+" and microphone buttons.

How it works
- Buttons open deep links (`lifepilot://task/new`, `...?voice=1`, `lifepilot://task/<id>`); Expo Router opens the right screen.
- The app redraws widgets after every task change (`WidgetSync`); Android also refreshes them about every 30 minutes.
- Widgets use the accent color chosen in Settings and always a dark card look.
- `app.config.js` registers the widgets and bundles the Vazirmatn font when found in node_modules.
- Row order is flipped automatically for left-to-right launchers (judged from the phone language). If the order looks reversed on your phone, tell us.

Limits: no check-off directly on the widget yet; text and layout are checked on real phones only.
