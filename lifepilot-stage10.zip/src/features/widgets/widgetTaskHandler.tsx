import type { WidgetTaskHandlerProps } from 'react-native-android-widget';
import { renderWidgetElement } from './services/renderWidget';

/**
 * Called by Android when a widget is added, resized or refreshed (about every 30 minutes).
 * It runs even when the app is closed and reads the real database.
 */
export async function widgetTaskHandler(props: WidgetTaskHandlerProps): Promise<void> {
  const info = props.widgetInfo as { widgetName: string; width?: number };
  switch (props.widgetAction) {
    case 'WIDGET_ADDED':
    case 'WIDGET_UPDATE':
    case 'WIDGET_RESIZED': {
      try {
        const element = await renderWidgetElement(info.widgetName, info.width);
        if (element) props.renderWidget(element);
      } catch {
        /* keep the previous picture if the database cannot be read right now */
      }
      break;
    }
    default:
      break; // clicks open the app through deep links; nothing else to do
  }
}
