import { AccentKey, Priority, accents, buildColors } from '../../../core/theme/colors';

export type Hex = `#${string}`;
export type Rgba = `rgba(${number}, ${number}, ${number}, ${number})`;

const asHex = (s: string): Hex => s as Hex;

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

/** '#4F46E5' + 0.2 -> 'rgba(79, 70, 229, 0.2)' (the format Android widgets accept for transparency). */
export function rgba(hex: string, alpha: number): Rgba {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

/** Mixes a color with black. amount 0 = same, 1 = black. */
export function darken(hex: string, amount: number): Hex {
  const [r, g, b] = hexToRgb(hex).map((v) => Math.round(v * (1 - amount)));
  const to = (v: number) => v.toString(16).padStart(2, '0');
  return `#${to(r)}${to(g)}${to(b)}`.toUpperCase() as Hex;
}

/** Whether the launcher that draws the widget is right-to-left, judged from the phone's language. */
export function isRtlLocale(locale: string | undefined): boolean {
  return /^(fa|ar|he|ur|ps|ku|dv)(-|_|$)/i.test(locale ?? '');
}

/**
 * Persian reads right-to-left. `logical` lists children in Persian reading order (start first).
 * A right-to-left launcher flips rows by itself; a left-to-right launcher needs the order reversed.
 */
export function orderForHost<T>(logical: T[], hostRtl: boolean): T[] {
  return hostRtl ? logical : [...logical].reverse();
}

/** Width in dp of the filled part of a progress bar. */
export function progressWidth(total: number, ratio: number): number {
  return Math.round(Math.max(0, Math.min(1, ratio)) * Math.max(0, total));
}

export interface WidgetTheme {
  bgFrom: Hex;
  bgTo: Hex;
  text: Hex;
  muted: Hex;
  accent: Hex;
  accentDeep: Hex;
  accentSoft: Rgba;
  surface: Rgba;
  track: Rgba;
  success: Hex;
  successSoft: Rgba;
  danger: Hex;
  dangerSoft: Rgba;
  priority: Record<Priority, Hex>;
}

/** Widgets always use the dark look (it reads well on any wallpaper) in the user's accent color. */
export function makeWidgetTheme(accent: AccentKey): WidgetTheme {
  const c = buildColors('dark', accent);
  const a = accents[accent].dark;
  return {
    bgFrom: asHex('#1B2340'),
    bgTo: asHex('#0B1020'),
    text: asHex('#F3F4F6'),
    muted: asHex('#A3ABBD'),
    accent: asHex(a),
    accentDeep: darken(a, 0.45),
    accentSoft: rgba(a, 0.2),
    surface: rgba('#FFFFFF', 0.07),
    track: rgba('#FFFFFF', 0.12),
    success: asHex(c.success),
    successSoft: rgba(c.success, 0.18),
    danger: asHex(c.danger),
    dangerSoft: rgba(c.danger, 0.18),
    priority: {
      low: asHex(c.priority.low),
      medium: asHex(c.priority.medium),
      high: asHex(c.priority.high),
      critical: asHex(c.priority.critical),
    },
  };
}
