import { addDays, startOfDay } from '../../../core/calendar/dates';
import type { AccentKey } from '../../../core/theme/colors';
import { openAppDatabase } from '../../../core/database/connection/expoClient';
import type { DbClient } from '../../../core/database/connection/types';
import { migrate, migrations } from '../../../core/database/migrations';
import { createRepositories } from '../../../providers/repositories';
import { SETTING_KEYS, parseAccent } from '../../settings/services/settingsKeys';
import { QuickWidgetModel, TodayWidgetModel, buildQuickModel, buildTodayModel } from './widgetModel';

export interface WidgetData {
  today: TodayWidgetModel;
  quick: QuickWidgetModel;
  accent: AccentKey;
}

// One connection is reused: the widget code can run many times inside the same process.
let dbPromise: Promise<DbClient> | null = null;
function getDb(): Promise<DbClient> {
  if (!dbPromise) {
    dbPromise = (async () => {
      const db = await openAppDatabase();
      await migrate(db, migrations); // safe if the app already did it
      return db;
    })().catch((e) => {
      dbPromise = null;
      throw e;
    });
  }
  return dbPromise;
}

/** Reads the real database (works even when the app itself is closed). */
export async function loadWidgetData(): Promise<WidgetData> {
  const repos = createRepositories(await getDb());
  const now = Date.now();
  const start = startOfDay(new Date(now));
  const [todayTasks, pending, accent] = await Promise.all([
    repos.tasks.list({ dueFrom: start.getTime(), dueTo: addDays(start, 1).getTime() }),
    repos.tasks.list({ status: 'pending' }),
    repos.settings.get(SETTING_KEYS.accent),
  ]);
  return {
    today: buildTodayModel(todayTasks, pending, now),
    quick: buildQuickModel(todayTasks, pending, now),
    accent: parseAccent(accent),
  };
}
