import { addDays, startOfDay } from '../../../core/calendar/dates';
import { WEEKDAY_NAMES, formatDayLabel, formatJalaliDate, formatTime } from '../../../core/calendar/format';
import { computeDashboardStats, pickNextTask, sortTimeline } from '../../dashboard/services/dashboardStats';
import type { Priority, Task } from '../../tasks/models/task';
import { isOverdue } from '../../tasks/services/taskStatus';

/** Everything a widget needs to draw itself. Plain data, so it is easy to test. */
export interface WidgetTaskItem {
  id: string;
  title: string;
  /** "۱۸:۳۰" or "همه‌روز" */
  timeLabel: string;
  priority: Priority;
  done: boolean;
  overdue: boolean;
}

export interface TodayWidgetModel {
  weekday: string;
  dateLabel: string;
  /** Start of today (ms), used to open "new task" on today's date. */
  todayStart: number;
  total: number;
  done: number;
  remaining: number;
  overdue: number;
  /** 0..1 */
  progress: number;
  items: WidgetTaskItem[];
}

export interface QuickWidgetModel {
  weekday: string;
  dateLabel: string;
  todayStart: number;
  remainingToday: number;
  overdue: number;
  next: (WidgetTaskItem & { dayLabel: string }) | null;
}

export const MAX_TITLE_LENGTH = 34;

export function truncateTitle(title: string, max = MAX_TITLE_LENGTH): string {
  const t = title.trim();
  return t.length <= max ? t : `${t.slice(0, max - 1).trimEnd()}…`;
}

function toItem(t: Task, now: number): WidgetTaskItem {
  return {
    id: t.id,
    title: truncateTitle(t.title),
    timeLabel: t.hasTime && t.dueAt !== null ? formatTime(new Date(t.dueAt)) : 'همه‌روز',
    priority: t.priority,
    done: t.status === 'completed',
    overdue: isOverdue(t, now),
  };
}

export function buildTodayModel(todayTasks: Task[], pendingTasks: Task[], now: number): TodayWidgetModel {
  const date = new Date(now);
  const start = startOfDay(date).getTime();
  const end = addDays(startOfDay(date), 1).getTime();
  const inToday = todayTasks.filter((t) => t.dueAt !== null && t.dueAt >= start && t.dueAt < end);
  const stats = computeDashboardStats(inToday, pendingTasks, now);
  return {
    weekday: WEEKDAY_NAMES[date.getDay()],
    dateLabel: formatJalaliDate(date, { year: false }),
    todayStart: start,
    total: stats.todayTotal,
    done: stats.completedToday,
    remaining: stats.remainingToday,
    overdue: stats.overdue,
    progress: stats.todayTotal === 0 ? 0 : stats.completedToday / stats.todayTotal,
    items: sortTimeline(inToday).map((t) => toItem(t, now)),
  };
}

export function buildQuickModel(todayTasks: Task[], pendingTasks: Task[], now: number): QuickWidgetModel {
  const date = new Date(now);
  const stats = computeDashboardStats(todayTasks, pendingTasks, now);
  const next = pickNextTask(pendingTasks, now);
  return {
    weekday: WEEKDAY_NAMES[date.getDay()],
    dateLabel: formatJalaliDate(date, { year: false }),
    todayStart: startOfDay(date).getTime(),
    remainingToday: stats.remainingToday,
    overdue: stats.overdue,
    next:
      next && next.dueAt !== null
        ? { ...toItem(next, now), dayLabel: formatDayLabel(new Date(next.dueAt), date) }
        : null,
  };
}

/** Deep links the widgets use. The app opens them through Expo Router. */
export const widgetLinks = {
  newTask: (todayStart: number) => `lifepilot://task/new?date=${todayStart}`,
  newTaskByVoice: (todayStart: number) => `lifepilot://task/new?voice=1&date=${todayStart}`,
  task: (id: string) => `lifepilot://task/${id}`,
};
