import { Platform } from 'react-native';
import { requestWidgetUpdate } from 'react-native-android-widget';
import { WIDGET_NAMES, renderWidgetElement } from './renderWidget';

/** Redraws every widget on the home screen from the current database. */
export async function updateAllWidgets(): Promise<void> {
  if (Platform.OS !== 'android') return;
  for (const widgetName of Object.values(WIDGET_NAMES)) {
    try {
      const element = await renderWidgetElement(widgetName);
      if (!element) continue;
      await requestWidgetUpdate({
        widgetName,
        renderWidget: () => element,
        widgetNotFound: () => {
          /* this widget is not on the home screen */
        },
      });
    } catch {
      /* widgets are best effort */
    }
  }
}
