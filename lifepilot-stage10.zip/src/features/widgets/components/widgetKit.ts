import type { WidgetTheme } from '../services/widgetStyle';

/**
 * Widget styles are plain objects. The library's style types are strict about color
 * formats, so styles pass through this helper and are validated by the library at runtime.
 */
export function st<T extends Record<string, unknown>>(style: T): never {
  return style as unknown as never;
}

export interface WidgetFonts {
  regular?: string;
  bold?: string;
}

export interface WidgetRenderProps {
  theme: WidgetTheme;
  /** Widget width in dp (falls back to a typical value). */
  width: number;
  /** True when the launcher draws right-to-left. */
  hostRtl: boolean;
  fonts: WidgetFonts;
}
