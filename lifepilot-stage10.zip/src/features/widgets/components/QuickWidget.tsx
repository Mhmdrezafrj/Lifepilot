import React from 'react';
import { FlexWidget, TextWidget } from 'react-native-android-widget';
import { toPersianDigits } from '../../../core/calendar/format';
import { orderForHost } from '../services/widgetStyle';
import { QuickWidgetModel, widgetLinks } from '../services/widgetModel';
import { WidgetRenderProps, st } from './widgetKit';

interface Props extends WidgetRenderProps {
  model: QuickWidgetModel;
}

export function QuickWidget({ model, theme, hostRtl, fonts }: Props) {
  const next = model.next;
  const tint = next?.overdue ? theme.dangerSoft : 'rgba(255, 255, 255, 0.16)';

  const info = (
    <FlexWidget
      key="info"
      clickAction={next ? 'OPEN_URI' : 'OPEN_APP'}
      clickActionData={next ? { uri: widgetLinks.task(next.id) } : undefined}
      style={st({ flex: 1, flexDirection: 'column' })}
    >
      <TextWidget
        text={next ? 'کار بعدی' : `${model.weekday}، ${model.dateLabel}`}
        style={st({ fontSize: 11, fontFamily: fonts.regular, textAlign: 'right', color: theme.accent })}
      />
      <TextWidget
        text={next ? next.title : 'کاری در پیش ندارید'}
        style={st({ fontSize: 17, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right', color: theme.text, marginTop: 2 })}
      />
      {next ? (
        <FlexWidget style={st({ flexDirection: 'row', alignItems: 'center', flexGap: 8, marginTop: 6 })}>
          {orderForHost(
            [
              <FlexWidget key="t" style={st({ paddingHorizontal: 9, paddingVertical: 4, borderRadius: 11, backgroundColor: tint })}>
                <TextWidget
                  text={next.timeLabel}
                  style={st({ fontSize: 13, fontWeight: 'bold', fontFamily: fonts.bold, color: '#FFFFFF' })}
                />
              </FlexWidget>,
              <TextWidget
                key="d"
                text={next.dayLabel}
                style={st({ fontSize: 12, fontFamily: fonts.regular, color: theme.muted })}
              />,
            ],
            hostRtl,
          )}
        </FlexWidget>
      ) : (
        <TextWidget
          text="با دکمه‌ی + یک کار بسازید"
          style={st({ fontSize: 12, fontFamily: fonts.regular, textAlign: 'right', color: theme.muted, marginTop: 4 })}
        />
      )}
      <TextWidget
        text={`${toPersianDigits(model.remainingToday)} کار باقی‌مانده امروز${model.overdue > 0 ? ` · ${toPersianDigits(model.overdue)} عقب‌افتاده` : ''}`}
        style={st({ fontSize: 11, fontFamily: fonts.regular, textAlign: 'right', color: model.overdue > 0 ? theme.danger : theme.muted, marginTop: 6 })}
      />
    </FlexWidget>
  );

  const buttons = (
    <FlexWidget key="buttons" style={st({ flexDirection: 'column', alignItems: 'center', flexGap: 8 })}>
      <FlexWidget
        clickAction="OPEN_URI"
        clickActionData={{ uri: widgetLinks.newTask(model.todayStart) }}
        accessibilityLabel="افزودن کار جدید"
        style={st({ width: 56, height: 56, borderRadius: 28, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFFFFF' })}
      >
        <TextWidget text="+" style={st({ fontSize: 34, fontWeight: 'bold', color: theme.accentDeep })} />
      </FlexWidget>
      <FlexWidget
        clickAction="OPEN_URI"
        clickActionData={{ uri: widgetLinks.newTaskByVoice(model.todayStart) }}
        accessibilityLabel="افزودن کار با صدا"
        style={st({ width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.track })}
      >
        <TextWidget text="🎙" style={st({ fontSize: 18, color: '#FFFFFF' })} />
      </FlexWidget>
    </FlexWidget>
  );

  return (
    <FlexWidget
      style={st({
        height: 'match_parent', width: 'match_parent', flexDirection: 'row', alignItems: 'center', flexGap: 12,
        padding: 14, borderRadius: 28,
        backgroundGradient: { from: theme.accentDeep, to: theme.bgTo, orientation: 'TL_BR' },
      })}
    >
      {orderForHost([info, buttons], hostRtl)}
    </FlexWidget>
  );
}
