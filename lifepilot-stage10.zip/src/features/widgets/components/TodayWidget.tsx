import React from 'react';
import { FlexWidget, ListWidget, TextWidget } from 'react-native-android-widget';
import { toPersianDigits } from '../../../core/calendar/format';
import { orderForHost, progressWidth } from '../services/widgetStyle';
import { TodayWidgetModel, WidgetTaskItem, widgetLinks } from '../services/widgetModel';
import { WidgetRenderProps, st } from './widgetKit';

interface Props extends WidgetRenderProps {
  model: TodayWidgetModel;
}

function Row({ item, theme, hostRtl, fonts }: { item: WidgetTaskItem } & WidgetRenderProps) {
  const tint = item.done ? theme.successSoft : item.overdue ? theme.dangerSoft : theme.accentSoft;
  const tintText = item.done ? theme.success : item.overdue ? theme.danger : theme.accent;
  const status = item.done ? 'انجام شد ✓' : item.overdue ? 'عقب‌افتاده' : '';

  const bar = (
    <FlexWidget
      key="bar"
      style={st({ width: 4, height: 36, borderRadius: 2, backgroundColor: item.done ? theme.success : theme.priority[item.priority] })}
    />
  );
  const body = (
    <FlexWidget key="body" style={st({ flex: 1, flexDirection: 'column' })}>
      <TextWidget
        text={item.title}
        style={st({
          fontSize: 14, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right',
          color: item.done ? theme.muted : theme.text,
        })}
      />
      {status ? (
        <TextWidget
          text={status}
          style={st({ fontSize: 11, fontFamily: fonts.regular, textAlign: 'right', color: item.done ? theme.success : theme.danger })}
        />
      ) : null}
    </FlexWidget>
  );
  const time = (
    <FlexWidget
      key="time"
      style={st({ paddingHorizontal: 9, paddingVertical: 5, borderRadius: 12, backgroundColor: tint })}
    >
      <TextWidget
        text={item.timeLabel}
        style={st({ fontSize: 13, fontWeight: 'bold', fontFamily: fonts.bold, color: tintText })}
      />
    </FlexWidget>
  );

  return (
    <FlexWidget
      clickAction="OPEN_URI"
      clickActionData={{ uri: widgetLinks.task(item.id) }}
      style={st({
        width: 'match_parent', flexDirection: 'row', alignItems: 'center', flexGap: 10,
        paddingHorizontal: 12, paddingVertical: 9, marginTop: 6, borderRadius: 16, backgroundColor: theme.surface,
      })}
    >
      {orderForHost([bar, body, time], hostRtl)}
    </FlexWidget>
  );
}

export function TodayWidget({ model, theme, width, hostRtl, fonts }: Props) {
  const barWidth = Math.max(80, width - 28);
  const fill = progressWidth(barWidth, model.progress);

  const dateBlock = (
    <FlexWidget key="date" style={st({ flexDirection: 'column' })}>
      <TextWidget
        text={model.weekday}
        style={st({ fontSize: 12, fontFamily: fonts.regular, textAlign: 'right', color: theme.muted })}
      />
      <TextWidget
        text={model.dateLabel}
        style={st({ fontSize: 26, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right', color: theme.text })}
      />
    </FlexWidget>
  );

  const buttons = (
    <FlexWidget key="buttons" style={st({ flexDirection: 'row', alignItems: 'center', flexGap: 8 })}>
      {orderForHost(
        [
          <FlexWidget
            key="plus"
            clickAction="OPEN_URI"
            clickActionData={{ uri: widgetLinks.newTask(model.todayStart) }}
            accessibilityLabel="افزودن کار جدید"
            style={st({
              width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center',
              backgroundGradient: { from: theme.accent, to: theme.accentDeep, orientation: 'TL_BR' },
            })}
          >
            <TextWidget text="+" style={st({ fontSize: 30, fontWeight: 'bold', color: '#FFFFFF' })} />
          </FlexWidget>,
          <FlexWidget
            key="mic"
            clickAction="OPEN_URI"
            clickActionData={{ uri: widgetLinks.newTaskByVoice(model.todayStart) }}
            accessibilityLabel="افزودن کار با صدا"
            style={st({
              width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center',
              backgroundColor: theme.track,
            })}
          >
            <TextWidget text="🎙" style={st({ fontSize: 20, color: '#FFFFFF' })} />
          </FlexWidget>,
        ],
        hostRtl,
      )}
    </FlexWidget>
  );

  const summary =
    model.total === 0
      ? 'برای امروز کاری ثبت نشده'
      : `${toPersianDigits(model.done)} از ${toPersianDigits(model.total)} کار انجام شد`;

  return (
    <FlexWidget
      style={st({
        height: 'match_parent', width: 'match_parent', flexDirection: 'column', padding: 14, borderRadius: 28,
        backgroundGradient: { from: theme.bgFrom, to: theme.bgTo, orientation: 'TL_BR' },
      })}
    >
      <FlexWidget
        style={st({ width: 'match_parent', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' })}
      >
        {orderForHost([dateBlock, buttons], hostRtl)}
      </FlexWidget>

      <FlexWidget
        style={st({ width: 'match_parent', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 })}
      >
        {orderForHost(
          [
            <TextWidget
              key="sum"
              text={summary}
              style={st({ fontSize: 12, fontFamily: fonts.regular, color: theme.muted })}
            />,
            model.overdue > 0 ? (
              <FlexWidget key="od" style={st({ paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10, backgroundColor: theme.dangerSoft })}>
                <TextWidget
                  text={`${toPersianDigits(model.overdue)} عقب‌افتاده`}
                  style={st({ fontSize: 11, fontWeight: 'bold', fontFamily: fonts.bold, color: theme.danger })}
                />
              </FlexWidget>
            ) : (
              <FlexWidget key="od" style={st({ width: 1, height: 1 })} />
            ),
          ],
          hostRtl,
        )}
      </FlexWidget>

      <FlexWidget
        style={st({
          width: barWidth, height: 6, borderRadius: 3, marginTop: 8, backgroundColor: theme.track,
          flexDirection: 'row', justifyContent: hostRtl ? 'flex-start' : 'flex-end',
        })}
      >
        <FlexWidget style={st({ width: fill, height: 6, borderRadius: 3, backgroundColor: theme.accent })} />
      </FlexWidget>

      {model.items.length === 0 ? (
        <FlexWidget
          clickAction="OPEN_URI"
          clickActionData={{ uri: widgetLinks.newTask(model.todayStart) }}
          style={st({ flex: 1, width: 'match_parent', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' })}
        >
          <TextWidget text="✨" style={st({ fontSize: 34, color: '#FFFFFF' })} />
          <TextWidget
            text="امروز کاری ندارید"
            style={st({ fontSize: 15, fontWeight: 'bold', fontFamily: fonts.bold, color: theme.text, marginTop: 6 })}
          />
          <TextWidget
            text="برای ساختن اولین کار، همین‌جا بزنید"
            style={st({ fontSize: 12, fontFamily: fonts.regular, color: theme.muted, marginTop: 2 })}
          />
        </FlexWidget>
      ) : (
        <ListWidget style={st({ height: 'match_parent', width: 'match_parent', marginTop: 4 })}>
          {model.items.map((item) => (
            <Row key={item.id} item={item} theme={theme} width={width} hostRtl={hostRtl} fonts={fonts} />
          ))}
        </ListWidget>
      )}
    </FlexWidget>
  );
}
