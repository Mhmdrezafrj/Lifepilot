import { useEffect } from 'react';
import { AppState } from 'react-native';
import { updateAllWidgets } from '@/features/widgets/services/updateWidgets';
import { useThemeSettings } from '@/core/theme/useTheme';
import { useDataStore } from '@/shared/state/dataStore';

/** Redraws the home-screen widgets whenever tasks change, the accent color changes, or the app leaves the foreground. */
export function WidgetSync() {
  const version = useDataStore((s) => s.version);
  const { accent } = useThemeSettings();

  useEffect(() => {
    const timer = setTimeout(() => void updateAllWidgets(), 500); // wait for the database write to settle
    return () => clearTimeout(timer);
  }, [version, accent]);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s !== 'active') void updateAllWidgets();
    });
    return () => sub.remove();
  }, []);

  return null;
}
