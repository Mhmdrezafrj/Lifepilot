import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { Task } from '../../src/features/tasks/models/task';
import {
  MAX_TITLE_LENGTH, buildQuickModel, buildTodayModel, truncateTitle, widgetLinks,
} from '../../src/features/widgets/services/widgetModel';

const NOW = new Date(2026, 10, 5, 12, 0).getTime(); // Thursday 14 Aban 1405
const at = (d: number, h = 0, m = 0) => new Date(2026, 10, d, h, m).getTime();
const t = (over: Partial<Task>): Task => ({
  id: 'x', title: 'x', description: null, dueAt: null, hasTime: false, priority: 'medium', categoryId: null,
  status: 'pending', snoozedUntil: null, createdAt: 0, updatedAt: 0, completedAt: null, recurrenceId: null,
  tags: [], checklist: [], reminders: [], recurrence: null, ...over,
});

describe('today widget model', () => {
  it('shows the Persian date and weekday', () => {
    const m = buildTodayModel([], [], NOW);
    assert.equal(m.weekday, 'پنج‌شنبه');
    assert.equal(m.dateLabel, '۱۴ آبان');
    assert.equal(m.todayStart, at(5));
  });

  it('is empty and at 0% when there are no tasks', () => {
    const m = buildTodayModel([], [], NOW);
    assert.deepEqual([m.total, m.done, m.remaining, m.overdue, m.progress, m.items.length], [0, 0, 0, 0, 0, 0]);
  });

  it("lists today's tasks with their time, all-day tasks first", () => {
    const today = [
      t({ id: 'b', title: 'جلسه', dueAt: at(5, 18, 30), hasTime: true, priority: 'high' }),
      t({ id: 'a', title: 'ورزش', dueAt: at(5, 9, 0), hasTime: true }),
      t({ id: 'c', title: 'خرید', dueAt: at(5) }),
    ];
    const m = buildTodayModel(today, today, NOW);
    assert.deepEqual(m.items.map((i) => [i.id, i.timeLabel]), [['c', 'همه‌روز'], ['a', '۰۹:۰۰'], ['b', '۱۸:۳۰']]);
    assert.equal(m.items[2].priority, 'high');
  });

  it('counts done, remaining, overdue and progress', () => {
    const today = [
      t({ id: '1', dueAt: at(5, 9), hasTime: true, status: 'completed' }),
      t({ id: '2', dueAt: at(5, 8), hasTime: true }), // passed -> overdue
      t({ id: '3', dueAt: at(5, 20), hasTime: true }),
      t({ id: '4', dueAt: at(5, 21), hasTime: true }),
    ];
    const pending = [today[1], today[2], today[3], t({ id: '5', dueAt: at(1, 9), hasTime: true })];
    const m = buildTodayModel(today, pending, NOW);
    assert.equal(m.total, 4);
    assert.equal(m.done, 1);
    assert.equal(m.remaining, 3);
    assert.equal(m.overdue, 2);
    assert.equal(m.progress, 0.25);
    assert.equal(m.items.find((i) => i.id === '1')?.done, true);
    assert.equal(m.items.find((i) => i.id === '2')?.overdue, true);
    assert.equal(m.items.find((i) => i.id === '3')?.overdue, false);
  });

  it('ignores tasks that are not due today', () => {
    const m = buildTodayModel([t({ dueAt: at(6, 9), hasTime: true })], [], NOW);
    assert.equal(m.total, 0);
    assert.equal(m.items.length, 0);
  });

  it('shortens very long titles', () => {
    const long = 'ا'.repeat(80);
    const cut = truncateTitle(long);
    assert.equal(cut.length, MAX_TITLE_LENGTH);
    assert.ok(cut.endsWith('…'));
    assert.equal(truncateTitle('  کوتاه  '), 'کوتاه');
  });
});

describe('quick widget model', () => {
  it('finds the next task with a day label', () => {
    const pending = [
      t({ id: 'later', title: 'فردا', dueAt: at(6, 10), hasTime: true }),
      t({ id: 'soon', title: 'بعدازظهر', dueAt: at(5, 15, 30), hasTime: true }),
      t({ id: 'old', dueAt: at(1, 9), hasTime: true }),
    ];
    const m = buildQuickModel([pending[1]], pending, NOW);
    assert.equal(m.next?.id, 'soon');
    assert.equal(m.next?.timeLabel, '۱۵:۳۰');
    assert.equal(m.next?.dayLabel, 'امروز');
    assert.equal(m.remainingToday, 1);
    assert.equal(m.overdue, 1);
  });

  it("labels tomorrow's task", () => {
    const m = buildQuickModel([], [t({ id: 'x', dueAt: at(6, 10), hasTime: true })], NOW);
    assert.equal(m.next?.dayLabel, 'فردا');
  });

  it('has no next task when nothing is ahead', () => {
    assert.equal(buildQuickModel([], [], NOW).next, null);
    assert.equal(buildQuickModel([], [t({ dueAt: at(1, 9), hasTime: true })], NOW).next, null);
  });
});

describe('widget deep links', () => {
  it('opens the new-task screen, optionally on today with voice', () => {
    assert.equal(widgetLinks.newTask(123), 'lifepilot://task/new?date=123');
    assert.equal(widgetLinks.newTaskByVoice(123), 'lifepilot://task/new?voice=1&date=123');
    assert.equal(widgetLinks.task('abc'), 'lifepilot://task/abc');
  });
});
