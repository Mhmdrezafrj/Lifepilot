import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  darken, isRtlLocale, makeWidgetTheme, orderForHost, progressWidth, rgba,
} from '../../src/features/widgets/services/widgetStyle';

describe('widget style helpers', () => {
  it('converts hex colors to rgba', () => {
    assert.equal(rgba('#4F46E5', 0.2), 'rgba(79, 70, 229, 0.2)');
    assert.equal(rgba('#FFFFFF', 0.07), 'rgba(255, 255, 255, 0.07)');
  });

  it('darkens a color towards black', () => {
    assert.equal(darken('#FFFFFF', 0), '#FFFFFF');
    assert.equal(darken('#FFFFFF', 1), '#000000');
    assert.equal(darken('#808080', 0.5), '#404040');
  });

  it('detects right-to-left phone languages', () => {
    for (const l of ['fa-IR', 'fa', 'ar-SA', 'he-IL', 'ur_PK']) assert.equal(isRtlLocale(l), true, l);
    for (const l of ['en-US', 'de-DE', 'fr', '', undefined]) assert.equal(isRtlLocale(l), false, String(l));
  });

  it('reverses children for left-to-right launchers only', () => {
    assert.deepEqual(orderForHost(['a', 'b', 'c'], true), ['a', 'b', 'c']);
    assert.deepEqual(orderForHost(['a', 'b', 'c'], false), ['c', 'b', 'a']);
  });

  it('computes progress bar widths safely', () => {
    assert.equal(progressWidth(200, 0.5), 100);
    assert.equal(progressWidth(200, 0), 0);
    assert.equal(progressWidth(200, 1.5), 200);
    assert.equal(progressWidth(200, -1), 0);
    assert.equal(progressWidth(-5, 0.5), 0);
  });

  it('builds a theme in the chosen accent', () => {
    const t = makeWidgetTheme('teal');
    assert.equal(t.accent.toLowerCase(), '#2dd4bf');
    assert.match(t.accentSoft, /^rgba\(45, 212, 191, 0\.2\)$/);
    assert.match(t.accentDeep, /^#[0-9A-F]{6}$/);
    assert.equal(Object.keys(t.priority).length, 4);
  });
});
