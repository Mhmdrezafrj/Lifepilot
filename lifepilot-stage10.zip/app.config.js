// Adds the home-screen widgets to the app.json configuration.
const fs = require('fs');
const path = require('path');

const FONT_DIR = './node_modules/@expo-google-fonts/vazirmatn';
const FONT_FILES = ['400Regular/Vazirmatn_400Regular.ttf', '700Bold/Vazirmatn_700Bold.ttf'].map((f) => `${FONT_DIR}/${f}`);

module.exports = ({ config }) => {
  // Persian font in the widgets, only if the files exist (otherwise the system font is used).
  const fontsFound = FONT_FILES.every((f) => fs.existsSync(path.resolve(f)));

  const widgetPlugin = [
    'react-native-android-widget',
    {
      fonts: fontsFound ? FONT_FILES : [],
      widgets: [
        {
          name: 'TodayWidget',
          label: 'برنامه امروز',
          description: 'کارهای امروز با ساعت، و افزودن سریع کار',
          minWidth: '250dp',
          minHeight: '250dp',
          targetCellWidth: 4,
          targetCellHeight: 4,
          previewImage: './assets/widget-preview/today.png',
          updatePeriodMillis: 1800000,
        },
        {
          name: 'QuickWidget',
          label: 'کار بعدی و افزودن سریع',
          description: 'کار بعدی شما و دکمه‌ی افزودن کار با متن یا صدا',
          minWidth: '250dp',
          minHeight: '110dp',
          targetCellWidth: 4,
          targetCellHeight: 2,
          previewImage: './assets/widget-preview/quick.png',
          updatePeriodMillis: 1800000,
        },
      ],
    },
  ];

  return {
    ...config,
    plugins: [...(config.plugins || []), widgetPlugin],
    extra: { ...(config.extra || {}), widgetFonts: fontsFound },
  };
};
