import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { ZodError } from 'zod';
import { createNodeClient } from '../helpers/nodeClient';
import { migrate, migrations } from '../../src/core/database/migrations';
import { createRepositories } from '../../src/providers/repositories';
import { createServices } from '../../src/providers/services';
import { InvalidOperationError, NotFoundError, describeError } from '../../src/core/errors';

const NOW = new Date(2026, 10, 5, 12, 0).getTime();
const at = (d: number, h = 9, m = 0) => new Date(2026, 10, d, h, m).getTime();

async function setup(now = NOW) {
  const db = createNodeClient();
  await migrate(db, migrations);
  const repos = createRepositories(db, { now: () => now });
  const { tasks } = createServices(repos, { now: () => now });
  return { db, repos, tasks };
}

describe('task service: status', () => {
  it('completes and reopens, and refuses repeated transitions', async () => {
    const { tasks } = await setup();
    const t = await tasks.create({ title: 'x' });
    const { completed, next } = await tasks.complete(t.id);
    assert.equal(completed.status, 'completed');
    assert.ok(completed.completedAt);
    assert.equal(next, null);
    await assert.rejects(() => tasks.complete(t.id), InvalidOperationError);
    const reopened = await tasks.reopen(t.id);
    assert.equal(reopened.status, 'pending');
    assert.equal(reopened.completedAt, null);
    await assert.rejects(() => tasks.reopen(t.id), InvalidOperationError);
  });

  it('throws NotFoundError for unknown ids', async () => {
    const { tasks } = await setup();
    await assert.rejects(() => tasks.complete('nope'), NotFoundError);
    await assert.rejects(() => tasks.update('nope', { title: 'x' }), NotFoundError);
    await assert.rejects(() => tasks.delete('nope'), NotFoundError);
    await assert.rejects(() => tasks.duplicate('nope'), NotFoundError);
  });
});

describe('task service: editing', () => {
  it('updates fields', async () => {
    const { tasks } = await setup();
    const t = await tasks.create({ title: 'a', priority: 'low' });
    const u = await tasks.update(t.id, { title: 'b', priority: 'critical', tags: ['x'] });
    assert.equal(u.title, 'b');
    assert.equal(u.priority, 'critical');
    assert.deepEqual(u.tags, ['x']);
  });

  it('requires a date for recurring tasks', async () => {
    const { tasks } = await setup();
    await assert.rejects(() => tasks.create({ title: 'x', recurrence: { frequency: 'daily' } }), InvalidOperationError);
    const t = await tasks.create({ title: 'x', dueAt: at(6), recurrence: { frequency: 'daily' } });
    await assert.rejects(() => tasks.update(t.id, { dueAt: null }), InvalidOperationError);
    await assert.rejects(() => tasks.reschedule(t.id, null, false), InvalidOperationError);
    const noRec = await tasks.update(t.id, { dueAt: null, recurrence: null });
    assert.equal(noRec.dueAt, null);
  });

  it('reports validation problems in Persian', async () => {
    const { tasks } = await setup();
    await assert.rejects(
      () => tasks.create({ title: '   ' }),
      (e: unknown) => e instanceof ZodError && describeError(e) === 'عنوان الزامی است',
    );
  });
});

describe('task service: snooze, reschedule, duplicate, delete', () => {
  it('snoozes a pending task to now + minutes', async () => {
    const { tasks } = await setup();
    const t = await tasks.create({ title: 'x', dueAt: at(5, 9), hasTime: true });
    const s = await tasks.snooze(t.id, 60);
    assert.equal(s.dueAt, NOW + 60 * 60_000);
    assert.equal(s.snoozedUntil, NOW + 60 * 60_000);
    assert.equal(s.hasTime, true);
    assert.equal(s.status, 'pending');
  });

  it('rejects bad snooze input and snoozing completed tasks', async () => {
    const { tasks } = await setup();
    const t = await tasks.create({ title: 'x' });
    await assert.rejects(() => tasks.snooze(t.id, 0), InvalidOperationError);
    await assert.rejects(() => tasks.snooze(t.id, 1.5), InvalidOperationError);
    await tasks.complete(t.id);
    await assert.rejects(() => tasks.snooze(t.id, 10), InvalidOperationError);
  });

  it('reschedules pending tasks and clears the snooze', async () => {
    const { tasks } = await setup();
    const t = await tasks.create({ title: 'x', dueAt: at(5), hasTime: true });
    await tasks.snooze(t.id, 30);
    const r = await tasks.reschedule(t.id, at(9, 0), false);
    assert.equal(r.dueAt, at(9, 0));
    assert.equal(r.hasTime, false);
    assert.equal(r.snoozedUntil, null);
    await tasks.complete(t.id);
    await assert.rejects(() => tasks.reschedule(t.id, at(10), false), InvalidOperationError);
  });

  it('duplicates a task with a fresh id, reset checklist and no completion', async () => {
    const { tasks } = await setup();
    const t = await tasks.create({
      title: 'x', tags: ['a'], checklist: [{ title: 'one', isCompleted: true }], reminders: [{ offsetMinutes: 5 }],
      dueAt: at(6), hasTime: true, categoryId: 'cat_work', recurrence: { frequency: 'daily' },
    });
    await tasks.complete(t.id);
    const copy = await tasks.duplicate(t.id);
    assert.notEqual(copy.id, t.id);
    assert.equal(copy.title, 'x (کپی)');
    assert.equal(copy.status, 'pending');
    assert.equal(copy.completedAt, null);
    assert.deepEqual(copy.tags, ['a']);
    assert.equal(copy.checklist[0].isCompleted, false);
    assert.equal(copy.reminders.length, 1);
    assert.equal(copy.categoryId, 'cat_work');
    assert.notEqual(copy.recurrenceId, t.recurrenceId);
  });

  it('deletes a task', async () => {
    const { tasks, repos } = await setup();
    const t = await tasks.create({ title: 'x' });
    await tasks.delete(t.id);
    assert.equal(await repos.tasks.getById(t.id), null);
  });
});

describe('task service: recurring tasks', () => {
  it('completing creates the next occurrence with copied details and a reset checklist', async () => {
    const { tasks, repos } = await setup();
    const t = await tasks.create({
      title: 'ورزش', dueAt: at(6, 18, 30), hasTime: true, priority: 'high', categoryId: 'cat_health', tags: ['t'],
      checklist: [{ title: 'گرم کردن' }], reminders: [{ offsetMinutes: 10 }], recurrence: { frequency: 'daily' },
    });
    const { completed, next } = await tasks.complete(t.id);
    assert.equal(completed.status, 'completed');
    assert.ok(next);
    assert.equal(next?.dueAt, at(7, 18, 30));
    assert.equal(next?.status, 'pending');
    assert.equal(next?.priority, 'high');
    assert.equal(next?.categoryId, 'cat_health');
    assert.deepEqual(next?.tags, ['t']);
    assert.equal(next?.checklist[0].isCompleted, false);
    assert.equal(next?.reminders.length, 1);
    assert.equal(next?.recurrence?.frequency, 'daily');
    assert.equal(await repos.tasks.count(), 2);
  });

  it('skips occurrences already in the past when completed late', async () => {
    const { tasks } = await setup();
    const t = await tasks.create({ title: 'x', dueAt: at(1, 9), hasTime: true, recurrence: { frequency: 'daily' } });
    const { next } = await tasks.complete(t.id);
    assert.equal(next?.dueAt, at(6, 9)); // 2..5 Nov 09:00 are before "now" (5 Nov 12:00)
  });

  it('stops after max occurrences', async () => {
    const { tasks, repos } = await setup();
    const t = await tasks.create({ title: 'x', dueAt: at(6), recurrence: { frequency: 'daily', maxOccurrences: 2 } });
    const first = await tasks.complete(t.id);
    assert.equal(first.next?.recurrence?.maxOccurrences, 1);
    const second = await tasks.complete(first.next!.id);
    assert.equal(second.next, null);
    assert.equal(await repos.tasks.count(), 2);
  });

  it('stops after the end date', async () => {
    const { tasks } = await setup();
    const t = await tasks.create({ title: 'x', dueAt: at(6), recurrence: { frequency: 'daily', endsAt: at(6, 23) } });
    assert.equal((await tasks.complete(t.id)).next, null);
  });

  it('does not create an occurrence for reopen or for non-recurring tasks', async () => {
    const { tasks, repos } = await setup();
    const t = await tasks.create({ title: 'x', dueAt: at(6) });
    await tasks.complete(t.id);
    await tasks.reopen(t.id);
    assert.equal(await repos.tasks.count(), 1);
  });
});
