import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  formatDayLabel, formatDue, formatJalaliDate, formatTime, formatTimeParts, toPersianDigits,
} from '../../src/core/calendar/format';

const now = new Date(2026, 10, 5, 12, 0); // Thu 14 Aban 1405

describe('persian formatting', () => {
  it('converts digits', () => {
    assert.equal(toPersianDigits(2026), '۲۰۲۶');
    assert.equal(toPersianDigits('12:30'), '۱۲:۳۰');
  });

  it('formats time with zero padding', () => {
    assert.equal(formatTime(new Date(2026, 0, 1, 7, 5)), '۰۷:۰۵');
    assert.equal(formatTimeParts(18, 0), '۱۸:۰۰');
  });

  it('formats a Jalali date with weekday and year', () => {
    assert.equal(formatJalaliDate(now, { weekday: true }), 'پنج‌شنبه ۱۴ آبان ۱۴۰۵');
    assert.equal(formatJalaliDate(now, { year: false }), '۱۴ آبان');
  });

  it('shows the year only when it differs in auto mode', () => {
    assert.equal(formatJalaliDate(new Date(2026, 10, 20), { year: 'auto', now }), '۲۹ آبان');
    assert.equal(formatJalaliDate(new Date(2027, 5, 1), { year: 'auto', now }), '۱۱ خرداد ۱۴۰۶');
  });

  it('labels today, tomorrow and yesterday', () => {
    assert.equal(formatDayLabel(new Date(2026, 10, 5, 23, 59), now), 'امروز');
    assert.equal(formatDayLabel(new Date(2026, 10, 6), now), 'فردا');
    assert.equal(formatDayLabel(new Date(2026, 10, 4), now), 'دیروز');
  });

  it('formats task due labels', () => {
    assert.equal(formatDue(null, false, now.getTime()), 'بدون تاریخ');
    assert.equal(formatDue(new Date(2026, 10, 6, 18, 30).getTime(), true, now.getTime()), 'فردا ۱۸:۳۰');
    assert.equal(formatDue(new Date(2026, 10, 6).getTime(), false, now.getTime()), 'فردا');
  });
});
