import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { nextOccurrence, RecurrenceRule } from '../../src/features/tasks/services/recurrence';
import { dateToJalali, jalaliToDate } from '../../src/core/calendar/jalali';

const rule = (r: Partial<RecurrenceRule> & Pick<RecurrenceRule, 'frequency'>): RecurrenceRule => ({
  intervalCount: 1, weekdays: [], endsAt: null, ...r,
});
const at = (y: number, m: number, d: number, h = 9, min = 0) => new Date(y, m - 1, d, h, min).getTime();
const day = (ms: number | null) => {
  assert.notEqual(ms, null);
  const d = new Date(ms as number);
  return [d.getFullYear(), d.getMonth() + 1, d.getDate(), d.getHours(), d.getMinutes()];
};

describe('recurrence', () => {
  it('daily adds the interval and keeps the time', () => {
    assert.deepEqual(day(nextOccurrence(at(2026, 11, 5, 18, 30), rule({ frequency: 'daily' }))), [2026, 11, 6, 18, 30]);
    assert.deepEqual(day(nextOccurrence(at(2026, 12, 31), rule({ frequency: 'daily', intervalCount: 3 }))), [2027, 1, 3, 9, 0]);
  });

  it('weekly without weekdays adds whole weeks', () => {
    assert.deepEqual(day(nextOccurrence(at(2026, 11, 5), rule({ frequency: 'weekly' }))), [2026, 11, 12, 9, 0]);
    assert.deepEqual(day(nextOccurrence(at(2026, 11, 5), rule({ frequency: 'weekly', intervalCount: 2 }))), [2026, 11, 19, 9, 0]);
  });

  it('weekly with weekdays picks the next selected day', () => {
    // Thu 5 Nov 2026; Mon(1) and Wed(3) -> next is Mon 9 Nov
    assert.deepEqual(day(nextOccurrence(at(2026, 11, 5), rule({ frequency: 'weekly', weekdays: [1, 3] }))), [2026, 11, 9, 9, 0]);
    // Mon 9 Nov -> Wed 11 Nov
    assert.deepEqual(day(nextOccurrence(at(2026, 11, 9), rule({ frequency: 'weekly', weekdays: [1, 3] }))), [2026, 11, 11, 9, 0]);
  });

  it('weekly with weekdays can continue within the same Persian week', () => {
    // Sat 7 Nov 2026 with Sat(6) and Mon(1): Monday 9 Nov is in the same Sat-Fri week
    assert.deepEqual(day(nextOccurrence(at(2026, 11, 7), rule({ frequency: 'weekly', weekdays: [6, 1] }))), [2026, 11, 9, 9, 0]);
  });

  it('weekly every 2 weeks skips the in-between week', () => {
    // Wed 4 Nov with Wed only, interval 2 -> Wed 18 Nov
    assert.deepEqual(day(nextOccurrence(at(2026, 11, 4), rule({ frequency: 'weekly', weekdays: [3], intervalCount: 2 }))), [2026, 11, 18, 9, 0]);
  });

  it('monthly follows Jalali months and clamps the day', () => {
    // 31 Shahrivar 1405 -> Mehr has 30 days -> 30 Mehr 1405
    const due = jalaliToDate(1405, 6, 31, 10, 15).getTime();
    const next = new Date(nextOccurrence(due, rule({ frequency: 'monthly' })) as number);
    assert.deepEqual(dateToJalali(next), { year: 1405, month: 7, day: 30 });
    assert.equal(next.getHours(), 10);
    assert.equal(next.getMinutes(), 15);
  });

  it('monthly rolls over the year and supports intervals', () => {
    const due = jalaliToDate(1405, 11, 15).getTime();
    assert.deepEqual(dateToJalali(new Date(nextOccurrence(due, rule({ frequency: 'monthly', intervalCount: 2 })) as number)),
      { year: 1406, month: 1, day: 15 });
  });

  it('yearly keeps the Jalali day and clamps Esfand 30', () => {
    const leapDue = jalaliToDate(1403, 12, 30).getTime();
    assert.deepEqual(dateToJalali(new Date(nextOccurrence(leapDue, rule({ frequency: 'yearly' })) as number)),
      { year: 1404, month: 12, day: 29 });
    const due = jalaliToDate(1405, 8, 14).getTime();
    assert.deepEqual(dateToJalali(new Date(nextOccurrence(due, rule({ frequency: 'yearly' })) as number)),
      { year: 1406, month: 8, day: 14 });
  });

  it('stops after the end date', () => {
    const ends = at(2026, 11, 10);
    assert.notEqual(nextOccurrence(at(2026, 11, 5), rule({ frequency: 'daily', endsAt: ends })), null);
    assert.equal(nextOccurrence(at(2026, 11, 10), rule({ frequency: 'daily', endsAt: ends })), null);
  });
});
