import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { emptyForm, formFromTask, formToInput, hasAdvancedContent } from '../../src/features/tasks/components/taskFormModel';
import { createTaskInputSchema } from '../../src/features/tasks/validation/taskSchemas';
import type { Task } from '../../src/features/tasks/models/task';

describe('task form model', () => {
  it('builds a valid minimal input', () => {
    const f = { ...emptyForm(), title: 'خرید' };
    const input = formToInput(f);
    assert.equal(input.dueAt, null);
    assert.equal(input.hasTime, false);
    assert.equal(createTaskInputSchema.parse(input).title, 'خرید');
  });

  it('combines date and time into one timestamp', () => {
    const f = { ...emptyForm(new Date(2026, 10, 5, 15, 40)), title: 'x', time: { hour: 18, minute: 30 } };
    const input = formToInput(f);
    assert.equal(input.dueAt, new Date(2026, 10, 5, 18, 30).getTime());
    assert.equal(input.hasTime, true);
  });

  it('a date without a time is stored at local midnight and is date-only', () => {
    const input = formToInput({ ...emptyForm(new Date(2026, 10, 5, 15, 40)), title: 'x' });
    assert.equal(input.dueAt, new Date(2026, 10, 5).getTime());
    assert.equal(input.hasTime, false);
  });

  it('drops reminders when there is no time', () => {
    const noTime = formToInput({ ...emptyForm(new Date(2026, 10, 5)), title: 'x', reminderOffsets: [10] });
    assert.deepEqual(noTime.reminders, []);
    const withTime = formToInput({ ...emptyForm(new Date(2026, 10, 5)), title: 'x', time: { hour: 9, minute: 0 }, reminderOffsets: [10, 60] });
    assert.deepEqual(withTime.reminders?.map((r) => r.offsetMinutes), [10, 60]);
  });

  it('only sends weekdays for weekly recurrence', () => {
    const base = { ...emptyForm(new Date(2026, 10, 5)), title: 'x', recurrenceWeekdays: [1, 3] };
    assert.deepEqual(formToInput({ ...base, recurrenceFrequency: 'weekly' }).recurrence?.weekdays, [1, 3]);
    assert.deepEqual(formToInput({ ...base, recurrenceFrequency: 'daily' }).recurrence?.weekdays, []);
    assert.equal(formToInput(base).recurrence, null);
  });

  it('round-trips a stored task', () => {
    const due = new Date(2026, 10, 5, 18, 30).getTime();
    const task: Task = {
      id: 'x', title: 'جلسه', description: 'd', dueAt: due, hasTime: true, priority: 'high', categoryId: 'cat_work',
      status: 'pending', snoozedUntil: null, createdAt: 0, updatedAt: 0, completedAt: null, recurrenceId: 'r',
      tags: ['a'], checklist: [{ id: 'c', title: 'one', isCompleted: true, sortOrder: 0 }],
      reminders: [{ id: 'm', taskId: 'x', offsetMinutes: 30, channel: 'notification', enabled: true, repeatIntervalMinutes: null, maxRepeats: null }],
      recurrence: { id: 'r', frequency: 'weekly', intervalCount: 2, weekdays: [1], endsAt: null, maxOccurrences: null },
    };
    const form = formFromTask(task);
    assert.deepEqual(form.time, { hour: 18, minute: 30 });
    assert.equal(form.recurrenceInterval, 2);
    const input = formToInput(form);
    assert.equal(input.dueAt, due);
    assert.equal(input.priority, 'high');
    assert.deepEqual(input.checklist, [{ title: 'one', isCompleted: true }]);
    assert.equal(hasAdvancedContent(form), true);
    assert.equal(hasAdvancedContent(emptyForm()), false);
  });
});
