import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { Task } from '../../src/features/tasks/models/task';
import { canTransition, groupActiveTasks, isOverdue, timeState } from '../../src/features/tasks/services/taskStatus';

const now = new Date(2026, 10, 5, 12, 0).getTime();
const at = (d: number, h = 0, m = 0) => new Date(2026, 10, d, h, m).getTime();

const t = (over: Partial<Task>): Task => ({
  id: 'x', title: 'x', description: null, dueAt: null, hasTime: false, priority: 'medium', categoryId: null,
  status: 'pending', snoozedUntil: null, createdAt: 0, updatedAt: 0, completedAt: null, recurrenceId: null,
  tags: [], checklist: [], reminders: [], recurrence: null, ...over,
});

describe('overdue detection', () => {
  it('is false without a due date or when completed', () => {
    assert.equal(isOverdue(t({}), now), false);
    assert.equal(isOverdue(t({ dueAt: at(1), hasTime: true, status: 'completed' }), now), false);
  });

  it('timed tasks become overdue as soon as the time passes', () => {
    assert.equal(isOverdue(t({ dueAt: at(5, 11, 59), hasTime: true }), now), true);
    assert.equal(isOverdue(t({ dueAt: at(5, 12, 0), hasTime: true }), now), false);
    assert.equal(isOverdue(t({ dueAt: at(5, 12, 1), hasTime: true }), now), false);
  });

  it('date-only tasks are overdue only after their day ends', () => {
    assert.equal(isOverdue(t({ dueAt: at(5), hasTime: false }), now), false);
    assert.equal(isOverdue(t({ dueAt: at(4), hasTime: false }), now), true);
    assert.equal(isOverdue(t({ dueAt: at(5), hasTime: false }), at(6, 0, 0)), true);
  });
});

describe('time state and grouping', () => {
  it('classifies tasks', () => {
    assert.equal(timeState(t({ status: 'completed', dueAt: at(1) }), now), 'completed');
    assert.equal(timeState(t({}), now), 'unscheduled');
    assert.equal(timeState(t({ dueAt: at(3), hasTime: true }), now), 'overdue');
    assert.equal(timeState(t({ dueAt: at(5, 20, 0), hasTime: true }), now), 'today');
    assert.equal(timeState(t({ dueAt: at(5), hasTime: false }), now), 'today');
    assert.equal(timeState(t({ dueAt: at(6), hasTime: false }), now), 'upcoming');
  });

  it('a timed task earlier today that has passed is overdue, not today', () => {
    assert.equal(timeState(t({ dueAt: at(5, 8, 0), hasTime: true }), now), 'overdue');
  });

  it('groups pending tasks and keeps their order', () => {
    const tasks = [
      t({ id: 'a', dueAt: at(2), hasTime: true }),
      t({ id: 'b', dueAt: at(5, 18), hasTime: true }),
      t({ id: 'c', dueAt: at(9) }),
      t({ id: 'd' }),
      t({ id: 'e', dueAt: at(1), hasTime: true }),
    ];
    const g = groupActiveTasks(tasks, now);
    assert.deepEqual(g.overdue.map((x) => x.id), ['a', 'e']);
    assert.deepEqual(g.today.map((x) => x.id), ['b']);
    assert.deepEqual(g.upcoming.map((x) => x.id), ['c']);
    assert.deepEqual(g.unscheduled.map((x) => x.id), ['d']);
  });
});

describe('status transitions', () => {
  it('allows pending <-> completed only', () => {
    assert.equal(canTransition('pending', 'completed'), true);
    assert.equal(canTransition('completed', 'pending'), true);
    assert.equal(canTransition('pending', 'pending'), false);
    assert.equal(canTransition('completed', 'completed'), false);
  });
});
