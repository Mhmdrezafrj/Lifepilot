import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  dateToJalali, gregorianToJalali, isJalaliLeapYear, jalaliMonthLength, jalaliToDate, jalaliToGregorian,
} from '../../src/core/calendar/jalali';

describe('jalali conversion', () => {
  it('matches known Nowruz dates', () => {
    const known: [number, [number, number, number]][] = [
      [1399, [2020, 3, 20]], [1400, [2021, 3, 21]], [1401, [2022, 3, 21]], [1402, [2023, 3, 21]],
      [1403, [2024, 3, 20]], [1404, [2025, 3, 21]], [1405, [2026, 3, 21]],
    ];
    for (const [jy, [gy, gm, gd]] of known) {
      assert.deepEqual(jalaliToGregorian(jy, 1, 1), { year: gy, month: gm, day: gd }, `Nowruz ${jy}`);
      assert.deepEqual(gregorianToJalali(gy, gm, gd), { year: jy, month: 1, day: 1 });
    }
  });

  it('converts today (5 Nov 2026) to 14 Aban 1405', () => {
    assert.deepEqual(gregorianToJalali(2026, 11, 5), { year: 1405, month: 8, day: 14 });
    assert.deepEqual(jalaliToGregorian(1405, 8, 14), { year: 2026, month: 11, day: 5 });
  });

  it('knows leap years', () => {
    const leaps = [1399, 1403, 1408, 1412, 1416, 1420];
    for (const y of leaps) assert.equal(isJalaliLeapYear(y), true, String(y));
    for (const y of [1400, 1401, 1402, 1404, 1405, 1406, 1407]) assert.equal(isJalaliLeapYear(y), false, String(y));
  });

  it('has the right month lengths', () => {
    for (let m = 1; m <= 6; m++) assert.equal(jalaliMonthLength(1405, m), 31);
    for (let m = 7; m <= 11; m++) assert.equal(jalaliMonthLength(1405, m), 30);
    assert.equal(jalaliMonthLength(1405, 12), 29);
    assert.equal(jalaliMonthLength(1403, 12), 30);
    assert.throws(() => jalaliMonthLength(1405, 13));
  });

  it('rejects invalid dates', () => {
    assert.throws(() => jalaliToGregorian(1405, 12, 30)); // 1405 is not leap
    assert.throws(() => jalaliToGregorian(1405, 7, 31));
    assert.throws(() => jalaliToGregorian(1405, 1, 0));
  });

  it('round-trips every day from 1300 to 1500', () => {
    for (let jy = 1300; jy <= 1500; jy++) {
      for (let jm = 1; jm <= 12; jm++) {
        const len = jalaliMonthLength(jy, jm);
        for (let jd = 1; jd <= len; jd++) {
          const g = jalaliToGregorian(jy, jm, jd);
          assert.deepEqual(gregorianToJalali(g.year, g.month, g.day), { year: jy, month: jm, day: jd });
        }
      }
    }
  });

  it('agrees with the ICU Persian calendar for every day from 1300 to 1500', () => {
    const fmt = new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn', {
      year: 'numeric', month: 'numeric', day: 'numeric', timeZone: 'UTC',
    });
    const start = Date.UTC(1921, 2, 1);
    const end = Date.UTC(2123, 2, 31);
    for (let t = start; t <= end; t += 86_400_000) {
      const d = new Date(t);
      const parts = fmt.formatToParts(d);
      const get = (type: string) => Number(parts.find((p) => p.type === type)?.value);
      const icu = { year: get('relatedYear') || get('year'), month: get('month'), day: get('day') };
      const mine = gregorianToJalali(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate());
      if (mine.year < 1300 || mine.year > 1500) continue;
      assert.deepEqual(mine, icu, `at ${d.toISOString()}`);
    }
  });

  it('converts local Date objects', () => {
    const d = new Date(2026, 10, 5, 18, 30);
    assert.deepEqual(dateToJalali(d), { year: 1405, month: 8, day: 14 });
    const back = jalaliToDate(1405, 8, 14, 18, 30);
    assert.equal(back.getFullYear(), 2026);
    assert.equal(back.getMonth(), 10);
    assert.equal(back.getDate(), 5);
    assert.equal(back.getHours(), 18);
    assert.equal(back.getMinutes(), 30);
  });
});
