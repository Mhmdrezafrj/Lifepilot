import { I18nManager } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen } from '@/shared/components/Screen';
import { Card } from '@/shared/components/Card';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { useDbInfo } from '@/providers/DatabaseProvider';

export default function HomeScreen() {
  const db = useDbInfo();
  const router = useRouter();
  return (
    <Screen title="لایف‌پایلوت">
      <Card>
        <AppText variant="heading">مدیریت کارها فعال شد ✅</AppText>
        <AppText muted>
          از تب «کارها» یا دکمه‌ی زیر می‌توانید کار بسازید، ویرایش کنید، انجام دهید یا به تعویق بیندازید. داشبورد واقعی در مرحله ۵ می‌آید.
        </AppText>
        <Button title="کار جدید" icon="add" onPress={() => router.push('/task/new')} />
      </Card>
      <Card variant="outlined">
        <AppText variant="bodyStrong">بررسی فنی (برای تست روی گوشی)</AppText>
        <AppText muted>جهت راست‌به‌چپ: {I18nManager.isRTL ? 'فعال ✅' : 'غیرفعال ❌'}</AppText>
        <AppText muted>نسخه‌ی ساختار پایگاه داده: {db.schemaVersion}</AppText>
        <AppText muted>دفعات اجرای برنامه: {db.launchCount}</AppText>
      </Card>
    </Screen>
  );
}
