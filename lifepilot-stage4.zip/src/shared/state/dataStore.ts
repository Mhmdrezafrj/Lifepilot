import { create } from 'zustand';

/**
 * Tiny global store. `version` goes up after every successful data change so
 * screens that read from the database know to reload.
 */
interface DataState {
  version: number;
  bump: () => void;
}

export const useDataStore = create<DataState>((set) => ({
  version: 0,
  bump: () => set((s) => ({ version: s.version + 1 })),
}));
