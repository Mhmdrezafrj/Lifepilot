import { useEffect, useMemo, useState } from 'react';
import { I18nManager, Modal, Pressable, View } from 'react-native';
import { isSameDay, weekdayIndexSat } from '@/core/calendar/dates';
import { JALALI_MONTH_NAMES, WEEKDAY_SHORT_SAT_FIRST, toPersianDigits } from '@/core/calendar/format';
import { dateToJalali, jalaliMonthLength, jalaliToDate } from '@/core/calendar/jalali';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from './AppText';
import { Button } from './Button';
import { IconButton } from './IconButton';

interface Props {
  visible: boolean;
  value: Date | null;
  onSelect: (date: Date) => void;
  onClear?: () => void;
  onClose: () => void;
}

export function JalaliDatePicker({ visible, value, onSelect, onClear, onClose }: Props) {
  const { colors, radii, spacing } = useTheme();
  const [view, setView] = useState({ year: 1405, month: 1 });

  useEffect(() => {
    if (visible) {
      const j = dateToJalali(value ?? new Date());
      setView({ year: j.year, month: j.month });
    }
  }, [visible, value]);

  const rows = useMemo(() => {
    const first = jalaliToDate(view.year, view.month, 1);
    const offset = weekdayIndexSat(first);
    const length = jalaliMonthLength(view.year, view.month);
    const cells: (number | null)[] = [
      ...Array.from({ length: offset }, () => null),
      ...Array.from({ length }, (_, i) => i + 1),
    ];
    while (cells.length % 7 !== 0) cells.push(null);
    const out: (number | null)[][] = [];
    for (let i = 0; i < cells.length; i += 7) out.push(cells.slice(i, i + 7));
    return out;
  }, [view]);

  const shift = (delta: number) =>
    setView((v) => {
      const total = v.year * 12 + (v.month - 1) + delta;
      return { year: Math.floor(total / 12), month: (total % 12) + 1 };
    });

  const today = new Date();
  const rtl = I18nManager.isRTL;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable
        style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: 'center', padding: spacing.xl }}
        onPress={onClose}
      >
        <Pressable
          onPress={() => {}}
          style={{ backgroundColor: colors.surface, borderRadius: radii.xl, padding: spacing.lg, gap: spacing.md }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <IconButton
              icon={rtl ? 'chevron-forward' : 'chevron-back'}
              onPress={() => shift(-1)}
              accessibilityLabel="ماه قبل"
            />
            <View style={{ flex: 1 }}>
              <AppText variant="heading" style={{ textAlign: 'center' }}>
                {JALALI_MONTH_NAMES[view.month - 1]} {toPersianDigits(view.year)}
              </AppText>
            </View>
            <IconButton
              icon={rtl ? 'chevron-back' : 'chevron-forward'}
              onPress={() => shift(1)}
              accessibilityLabel="ماه بعد"
            />
          </View>

          <View style={{ flexDirection: 'row' }}>
            {WEEKDAY_SHORT_SAT_FIRST.map((w, i) => (
              <View key={i} style={{ flex: 1, alignItems: 'center' }}>
                <AppText variant="label" muted>{w}</AppText>
              </View>
            ))}
          </View>

          {rows.map((row, ri) => (
            <View key={ri} style={{ flexDirection: 'row' }}>
              {row.map((d, ci) => {
                if (d === null) return <View key={ci} style={{ flex: 1, height: 44 }} />;
                const date = jalaliToDate(view.year, view.month, d);
                const selected = value !== null && isSameDay(date, value);
                const isToday = isSameDay(date, today);
                return (
                  <Pressable
                    key={ci}
                    accessibilityRole="button"
                    accessibilityLabel={`${toPersianDigits(d)} ${JALALI_MONTH_NAMES[view.month - 1]}`}
                    onPress={() => onSelect(date)}
                    style={{ flex: 1, height: 44, alignItems: 'center', justifyContent: 'center' }}
                  >
                    <View
                      style={{
                        width: 38,
                        height: 38,
                        borderRadius: radii.pill,
                        alignItems: 'center',
                        justifyContent: 'center',
                        backgroundColor: selected ? colors.accent : 'transparent',
                        borderWidth: isToday && !selected ? 1.5 : 0,
                        borderColor: colors.accent,
                      }}
                    >
                      <AppText variant="body" color={selected ? 'textOnAccent' : 'text'}>
                        {toPersianDigits(d)}
                      </AppText>
                    </View>
                  </Pressable>
                );
              })}
            </View>
          ))}

          <View style={{ flexDirection: 'row', gap: spacing.sm, flexWrap: 'wrap' }}>
            <Button title="امروز" variant="secondary" size="sm" onPress={() => onSelect(new Date())} />
            {onClear ? <Button title="حذف تاریخ" variant="ghost" size="sm" onPress={onClear} /> : null}
            <Button title="بستن" variant="ghost" size="sm" onPress={onClose} />
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}
