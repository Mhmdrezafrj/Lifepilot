import { useEffect, useRef, useState } from 'react';
import { Modal, Pressable, ScrollView, View } from 'react-native';
import { toPersianDigits } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from './AppText';
import { Button } from './Button';

const ITEM_HEIGHT = 44;
const pad = (n: number) => toPersianDigits(String(n).padStart(2, '0'));

function Column({ items, selected, onSelect }: { items: number[]; selected: number; onSelect: (n: number) => void }) {
  const { colors, radii } = useTheme();
  const ref = useRef<ScrollView>(null);
  const index = Math.max(0, items.indexOf(selected));
  return (
    <ScrollView
      ref={ref}
      style={{ height: ITEM_HEIGHT * 5, flex: 1 }}
      showsVerticalScrollIndicator={false}
      onLayout={() => ref.current?.scrollTo({ y: Math.max(0, (index - 2) * ITEM_HEIGHT), animated: false })}
    >
      {items.map((n) => (
        <Pressable
          key={n}
          accessibilityRole="button"
          onPress={() => onSelect(n)}
          style={{
            height: ITEM_HEIGHT,
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: radii.md,
            backgroundColor: n === selected ? colors.accentSoft : 'transparent',
          }}
        >
          <AppText variant="heading" color={n === selected ? 'accent' : 'text'}>{pad(n)}</AppText>
        </Pressable>
      ))}
    </ScrollView>
  );
}

interface Props {
  visible: boolean;
  value: { hour: number; minute: number } | null;
  onConfirm: (hour: number, minute: number) => void;
  onClose: () => void;
}

export function TimePicker({ visible, value, onConfirm, onClose }: Props) {
  const { colors, radii, spacing } = useTheme();
  const [hour, setHour] = useState(9);
  const [minute, setMinute] = useState(0);

  useEffect(() => {
    if (visible) {
      setHour(value?.hour ?? 9);
      setMinute(value?.minute ?? 0);
    }
  }, [visible, value]);

  const hours = Array.from({ length: 24 }, (_, i) => i);
  const baseMinutes = Array.from({ length: 12 }, (_, i) => i * 5);
  const minutes = baseMinutes.includes(minute) ? baseMinutes : [...baseMinutes, minute].sort((a, b) => a - b);

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable
        style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: 'center', padding: spacing.xl }}
        onPress={onClose}
      >
        <Pressable
          onPress={() => {}}
          style={{ backgroundColor: colors.surface, borderRadius: radii.xl, padding: spacing.lg, gap: spacing.md }}
        >
          <AppText variant="heading" style={{ textAlign: 'center' }}>انتخاب ساعت</AppText>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
            <Column items={hours} selected={hour} onSelect={setHour} />
            <AppText variant="title">:</AppText>
            <Column items={minutes} selected={minute} onSelect={setMinute} />
          </View>
          <View style={{ flexDirection: 'row', gap: spacing.sm }}>
            <Button title="تأیید" size="sm" onPress={() => onConfirm(hour, minute)} />
            <Button title="بستن" variant="ghost" size="sm" onPress={onClose} />
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}
