import { Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/core/theme/useTheme';
import { IconName } from '@/shared/types/icon';

interface Props {
  onPress: () => void;
  accessibilityLabel: string;
  icon?: IconName;
}

/** Floating action button, placed at the bottom-end corner of its parent. */
export function Fab({ onPress, accessibilityLabel, icon = 'add' }: Props) {
  const { colors, radii, elevation, spacing } = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      onPress={onPress}
      style={({ pressed }) => [
        {
          position: 'absolute',
          bottom: spacing.xl,
          end: spacing.xl,
          width: 60,
          height: 60,
          borderRadius: radii.pill,
          backgroundColor: colors.accent,
          alignItems: 'center',
          justifyContent: 'center',
          opacity: pressed ? 0.85 : 1,
        },
        elevation.lg,
      ]}
    >
      <Ionicons name={icon} size={30} color={colors.textOnAccent} />
    </Pressable>
  );
}
