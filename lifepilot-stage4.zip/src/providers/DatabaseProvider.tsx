import { ReactNode, createContext, useContext, useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { openAppDatabase } from '@/core/database/connection/expoClient';
import { LATEST_SCHEMA_VERSION, migrate, migrations } from '@/core/database/migrations';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from '@/shared/components/AppText';
import { Repositories, createRepositories } from './repositories';
import { Services, createServices } from './services';

export interface DbInfo {
  schemaVersion: number;
  /** How many times the app has been opened (stored in the database). */
  launchCount: number;
  categoryCount: number;
  taskCount: number;
}

interface DbContextValue {
  repos: Repositories;
  services: Services;
  info: DbInfo;
}

type State =
  | { status: 'loading' }
  | { status: 'ready'; value: DbContextValue }
  | { status: 'error'; message: string };

const DbContext = createContext<DbContextValue | null>(null);

export function DatabaseProvider({ children }: { children: ReactNode }) {
  const { colors, spacing } = useTheme();
  const [state, setState] = useState<State>({ status: 'loading' });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const db = await openAppDatabase();
        await migrate(db, migrations);
        const repos = createRepositories(db);
        const services = createServices(repos);

        const previous = Number((await repos.settings.get('launch_count')) ?? '0');
        const launchCount = (Number.isFinite(previous) ? previous : 0) + 1;
        await repos.settings.set('launch_count', String(launchCount));

        const info: DbInfo = {
          schemaVersion: LATEST_SCHEMA_VERSION,
          launchCount,
          categoryCount: await repos.categories.count(),
          taskCount: await repos.tasks.count(),
        };
        if (!cancelled) setState({ status: 'ready', value: { repos, services, info } });
      } catch (e) {
        if (!cancelled) setState({ status: 'error', message: e instanceof Error ? e.message : String(e) });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (state.status === 'ready') {
    return <DbContext.Provider value={state.value}>{children}</DbContext.Provider>;
  }

  return (
    <View
      style={{
        flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.md,
        padding: spacing.xl, backgroundColor: colors.bg,
      }}
    >
      {state.status === 'loading' ? (
        <ActivityIndicator color={colors.accent} />
      ) : (
        <>
          <AppText variant="heading" color="danger">خطا در باز کردن پایگاه داده</AppText>
          <AppText muted style={{ textAlign: 'center' }}>{state.message}</AppText>
        </>
      )}
    </View>
  );
}

function useDb(): DbContextValue {
  const ctx = useContext(DbContext);
  if (!ctx) throw new Error('Database hooks must be used inside DatabaseProvider');
  return ctx;
}

export const useRepositories = (): Repositories => useDb().repos;
export const useServices = (): Services => useDb().services;
export const useDbInfo = (): DbInfo => useDb().info;
