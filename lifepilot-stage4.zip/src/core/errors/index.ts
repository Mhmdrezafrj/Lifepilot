import { ZodError } from 'zod';

export class NotFoundError extends Error {
  constructor(what = 'کار') {
    super(`${what} پیدا نشد`);
    this.name = 'NotFoundError';
  }
}

/** The action is not allowed in the current state (e.g. completing a completed task). */
export class InvalidOperationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InvalidOperationError';
  }
}

/** A user-friendly Persian message for any error. */
export function describeError(e: unknown): string {
  if (e instanceof ZodError) return e.issues[0]?.message ?? 'اطلاعات واردشده معتبر نیست';
  if (e instanceof NotFoundError || e instanceof InvalidOperationError) return e.message;
  return 'خطای ناشناخته‌ای رخ داد';
}
