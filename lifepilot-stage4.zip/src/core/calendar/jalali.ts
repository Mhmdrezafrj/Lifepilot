/**
 * Jalali (Persian / Solar Hijri) calendar arithmetic.
 *
 * Uses the 33-year leap cycle, which matches the official Iranian calendar for
 * the years the app is meant for (verified against ICU in the tests).
 * Anchor: 1 Farvardin 1400 = 21 March 2021.
 * Dates are plain calendar dates; timestamps stay UTC milliseconds elsewhere.
 */
const DAY_MS = 86_400_000;
const ANCHOR_YEAR = 1400;
const ANCHOR_UTC = Date.UTC(2021, 2, 21);
const LEAP_RESIDUES = new Set([1, 5, 9, 13, 17, 22, 26, 30]);

export interface CalendarDate {
  year: number;
  /** 1..12 */
  month: number;
  day: number;
}
export type JalaliDate = CalendarDate;
export type GregorianDate = CalendarDate;

export function isJalaliLeapYear(year: number): boolean {
  return LEAP_RESIDUES.has(((year % 33) + 33) % 33);
}

export function jalaliMonthLength(year: number, month: number): number {
  if (!Number.isInteger(month) || month < 1 || month > 12) throw new RangeError(`Invalid Jalali month ${month}`);
  if (month <= 6) return 31;
  if (month <= 11) return 30;
  return isJalaliLeapYear(year) ? 30 : 29;
}

/** Days from 1 Farvardin 1400 to 1 Farvardin of `year` (negative for earlier years). */
function daysToYearStart(year: number): number {
  let days = 0;
  if (year >= ANCHOR_YEAR) {
    for (let y = ANCHOR_YEAR; y < year; y++) days += isJalaliLeapYear(y) ? 366 : 365;
  } else {
    for (let y = year; y < ANCHOR_YEAR; y++) days -= isJalaliLeapYear(y) ? 366 : 365;
  }
  return days;
}

function daysToMonthStart(year: number, month: number): number {
  let days = 0;
  for (let m = 1; m < month; m++) days += jalaliMonthLength(year, m);
  return days;
}

export function jalaliToGregorian(year: number, month: number, day: number): GregorianDate {
  if (!Number.isInteger(year) || !Number.isInteger(day) || day < 1 || day > jalaliMonthLength(year, month)) {
    throw new RangeError(`Invalid Jalali date ${year}/${month}/${day}`);
  }
  const n = daysToYearStart(year) + daysToMonthStart(year, month) + (day - 1);
  const d = new Date(ANCHOR_UTC + n * DAY_MS);
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate() };
}

export function gregorianToJalali(year: number, month: number, day: number): JalaliDate {
  const n = Math.round((Date.UTC(year, month - 1, day) - ANCHOR_UTC) / DAY_MS);
  let jy = ANCHOR_YEAR + Math.floor(n / 365.2422);
  while (daysToYearStart(jy) > n) jy--;
  while (daysToYearStart(jy + 1) <= n) jy++;
  let rest = n - daysToYearStart(jy);
  let jm = 1;
  while (rest >= jalaliMonthLength(jy, jm)) {
    rest -= jalaliMonthLength(jy, jm);
    jm++;
  }
  return { year: jy, month: jm, day: rest + 1 };
}

/** Jalali date of a Date, using the device's local calendar day. */
export function dateToJalali(date: Date): JalaliDate {
  return gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
}

/** Local Date for a Jalali day (time defaults to midnight). */
export function jalaliToDate(year: number, month: number, day: number, hour = 0, minute = 0): Date {
  const g = jalaliToGregorian(year, month, day);
  return new Date(g.year, g.month - 1, g.day, hour, minute, 0, 0);
}
