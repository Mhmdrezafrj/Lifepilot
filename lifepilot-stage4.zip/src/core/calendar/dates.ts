export const DAY_MS = 86_400_000;
export const MINUTE_MS = 60_000;

export function startOfDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0);
}

/** Adds whole calendar days in local time, keeping the time of day (safe across DST changes). */
export function addDays(date: Date, days: number): Date {
  return new Date(
    date.getFullYear(), date.getMonth(), date.getDate() + days,
    date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds(),
  );
}

export function isSameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

/** Days since 1970-01-01 of the local calendar day. */
export function localDayNumber(date: Date): number {
  return Math.round(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) / DAY_MS);
}

/** 0 = Saturday .. 6 = Friday (the Persian week). */
export function weekdayIndexSat(date: Date): number {
  return (date.getDay() + 1) % 7;
}

/** Index of the Saturday-to-Friday week containing the date. */
export function weekIndexSat(date: Date): number {
  return Math.floor((localDayNumber(date) - 2) / 7);
}
