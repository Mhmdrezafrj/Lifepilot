import { addDays, isSameDay, startOfDay } from './dates';
import { dateToJalali } from './jalali';

export const JALALI_MONTH_NAMES = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];

/** Indexed by Date.getDay() (0 = Sunday). */
export const WEEKDAY_NAMES = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه'];

/** One-letter headers for a Saturday-first calendar grid. */
export const WEEKDAY_SHORT_SAT_FIRST = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

export function toPersianDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
}

export function formatTime(date: Date): string {
  const h = String(date.getHours()).padStart(2, '0');
  const m = String(date.getMinutes()).padStart(2, '0');
  return toPersianDigits(`${h}:${m}`);
}

export function formatTimeParts(hour: number, minute: number): string {
  return toPersianDigits(`${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`);
}

export interface JalaliFormatOptions {
  weekday?: boolean;
  /** 'auto' shows the year only when it differs from `now`'s year. */
  year?: boolean | 'auto';
  now?: Date;
}

/** e.g. "پنج‌شنبه ۱۴ آبان ۱۴۰۵" */
export function formatJalaliDate(date: Date, opts: JalaliFormatOptions = {}): string {
  const j = dateToJalali(date);
  const parts: string[] = [];
  if (opts.weekday) parts.push(WEEKDAY_NAMES[date.getDay()]);
  parts.push(toPersianDigits(j.day), JALALI_MONTH_NAMES[j.month - 1]);
  const showYear =
    opts.year === 'auto' ? dateToJalali(opts.now ?? new Date()).year !== j.year : opts.year !== false;
  if (showYear) parts.push(toPersianDigits(j.year));
  return parts.join(' ');
}

/** "امروز" / "فردا" / "دیروز" or a short Jalali date. */
export function formatDayLabel(date: Date, now: Date): string {
  if (isSameDay(date, now)) return 'امروز';
  if (isSameDay(date, addDays(startOfDay(now), 1))) return 'فردا';
  if (isSameDay(date, addDays(startOfDay(now), -1))) return 'دیروز';
  return formatJalaliDate(date, { year: 'auto', now });
}

/** Label for a task's due date, e.g. "فردا ۱۸:۳۰", "۱۴ آبان", or "بدون تاریخ". */
export function formatDue(dueAt: number | null, hasTime: boolean, now: number): string {
  if (dueAt === null) return 'بدون تاریخ';
  const d = new Date(dueAt);
  const label = formatDayLabel(d, new Date(now));
  return hasTime ? `${label} ${formatTime(d)}` : label;
}
