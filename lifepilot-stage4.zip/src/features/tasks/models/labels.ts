import type { Priority, RecurrenceFrequency } from './task';

export const PRIORITY_LABELS: Record<Priority, string> = {
  low: 'کم',
  medium: 'متوسط',
  high: 'زیاد',
  critical: 'بحرانی',
};

export const FREQUENCY_LABELS: Record<RecurrenceFrequency, string> = {
  daily: 'روزانه',
  weekly: 'هفتگی',
  monthly: 'ماهانه',
  yearly: 'سالانه',
};

/** Reminder choices (minutes before the due time). Stored only; delivery arrives in a later phase. */
export const REMINDER_OPTIONS: { offset: number; label: string }[] = [
  { offset: 0, label: 'سر وقت' },
  { offset: 10, label: '۱۰ دقیقه قبل' },
  { offset: 30, label: '۳۰ دقیقه قبل' },
  { offset: 60, label: '۱ ساعت قبل' },
  { offset: 1440, label: '۱ روز قبل' },
];
