import { addDays, startOfDay } from '../../../core/calendar/dates';
import type { Task, TaskStatus } from '../models/task';

export type TaskTimeState = 'completed' | 'overdue' | 'today' | 'upcoming' | 'unscheduled';

type Timed = Pick<Task, 'status' | 'dueAt' | 'hasTime'>;

/**
 * Overdue is derived, never stored. A task with a time is overdue once that time
 * passes; a date-only task is overdue only after its day has ended.
 */
export function isOverdue(task: Timed, now: number): boolean {
  if (task.status !== 'pending' || task.dueAt === null) return false;
  if (task.hasTime) return task.dueAt < now;
  return addDays(startOfDay(new Date(task.dueAt)), 1).getTime() <= now;
}

export function timeState(task: Timed, now: number): TaskTimeState {
  if (task.status === 'completed') return 'completed';
  if (task.dueAt === null) return 'unscheduled';
  if (isOverdue(task, now)) return 'overdue';
  const todayStart = startOfDay(new Date(now)).getTime();
  const tomorrowStart = addDays(startOfDay(new Date(now)), 1).getTime();
  return task.dueAt >= todayStart && task.dueAt < tomorrowStart ? 'today' : 'upcoming';
}

export function canTransition(from: TaskStatus, to: TaskStatus): boolean {
  return from !== to; // pending <-> completed
}

export interface GroupedTasks {
  overdue: Task[];
  today: Task[];
  upcoming: Task[];
  unscheduled: Task[];
}

/** Groups pending tasks for list display (input order is kept inside each group). */
export function groupActiveTasks(tasks: Task[], now: number): GroupedTasks {
  const groups: GroupedTasks = { overdue: [], today: [], upcoming: [], unscheduled: [] };
  for (const t of tasks) {
    const s = timeState(t, now);
    if (s === 'overdue') groups.overdue.push(t);
    else if (s === 'today') groups.today.push(t);
    else if (s === 'upcoming') groups.upcoming.push(t);
    else if (s === 'unscheduled') groups.unscheduled.push(t);
  }
  return groups;
}

