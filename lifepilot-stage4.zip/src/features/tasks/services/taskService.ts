import { InvalidOperationError, NotFoundError } from '../../../core/errors';
import type { Task } from '../models/task';
import type { TaskRepository } from '../repositories/taskRepository';
import type { CreateTaskInput, UpdateTaskInput } from '../validation/taskSchemas';
import { nextOccurrence } from './recurrence';
import { canTransition } from './taskStatus';

export type TaskPatch = Omit<UpdateTaskInput, 'status' | 'snoozedUntil'>;

export interface TaskService {
  create(input: CreateTaskInput): Promise<Task>;
  update(id: string, patch: TaskPatch): Promise<Task>;
  /** Completes a task. For recurring tasks, also creates the next upcoming occurrence. */
  complete(id: string): Promise<{ completed: Task; next: Task | null }>;
  reopen(id: string): Promise<Task>;
  /** Moves a pending task to `minutes` from now. */
  snooze(id: string, minutes: number): Promise<Task>;
  reschedule(id: string, dueAt: number | null, hasTime: boolean): Promise<Task>;
  duplicate(id: string): Promise<Task>;
  delete(id: string): Promise<void>;
}

const RECURRENCE_NEEDS_DATE = 'برای تکرار، تاریخ کار را مشخص کنید';

function toInput(t: Task, overrides: Partial<CreateTaskInput> = {}): CreateTaskInput {
  return {
    title: t.title,
    description: t.description,
    dueAt: t.dueAt,
    hasTime: t.hasTime,
    priority: t.priority,
    categoryId: t.categoryId,
    tags: t.tags,
    checklist: t.checklist.map((c) => ({ title: c.title, isCompleted: false })),
    reminders: t.reminders.map((r) => ({
      offsetMinutes: r.offsetMinutes,
      channel: r.channel,
      enabled: r.enabled,
      repeatIntervalMinutes: r.repeatIntervalMinutes,
      maxRepeats: r.maxRepeats,
    })),
    recurrence: t.recurrence
      ? {
          frequency: t.recurrence.frequency,
          intervalCount: t.recurrence.intervalCount,
          weekdays: t.recurrence.weekdays,
          endsAt: t.recurrence.endsAt,
          maxOccurrences: t.recurrence.maxOccurrences,
        }
      : null,
    ...overrides,
  };
}

export function createTaskService(repo: TaskRepository, options: { now?: () => number } = {}): TaskService {
  const now = options.now ?? (() => Date.now());

  async function requireTask(id: string): Promise<Task> {
    const task = await repo.getById(id);
    if (!task) throw new NotFoundError();
    return task;
  }

  function assertStatusChange(task: Task, to: Task['status']): void {
    if (!canTransition(task.status, to)) {
      throw new InvalidOperationError(to === 'completed' ? 'این کار قبلاً انجام شده است' : 'این کار هنوز انجام نشده است');
    }
  }

  async function create(input: CreateTaskInput): Promise<Task> {
    if (input.recurrence && (input.dueAt === null || input.dueAt === undefined)) {
      throw new InvalidOperationError(RECURRENCE_NEEDS_DATE);
    }
    return repo.create(input);
  }

  async function update(id: string, patch: TaskPatch): Promise<Task> {
    const existing = await requireTask(id);
    const dueAt = patch.dueAt !== undefined ? patch.dueAt : existing.dueAt;
    const recurrence = patch.recurrence !== undefined ? patch.recurrence : existing.recurrence;
    if (recurrence && dueAt === null) throw new InvalidOperationError(RECURRENCE_NEEDS_DATE);
    // A manual date change replaces any earlier snooze.
    const updated = await repo.update(id, patch.dueAt !== undefined ? { ...patch, snoozedUntil: null } : patch);
    if (!updated) throw new NotFoundError();
    return updated;
  }

  async function complete(id: string): Promise<{ completed: Task; next: Task | null }> {
    const task = await requireTask(id);
    assertStatusChange(task, 'completed');

    let next: Task | null = null;
    if (task.recurrence && task.dueAt !== null) {
      const rule = {
        frequency: task.recurrence.frequency,
        intervalCount: task.recurrence.intervalCount,
        weekdays: task.recurrence.weekdays,
        endsAt: task.recurrence.endsAt,
      };
      const ts = now();
      let nextDue = nextOccurrence(task.dueAt, rule);
      // Skip occurrences that are already in the past (task completed late).
      for (let i = 0; nextDue !== null && nextDue <= ts && i < 1000; i++) nextDue = nextOccurrence(nextDue, rule);

      const remaining = task.recurrence.maxOccurrences === null ? null : task.recurrence.maxOccurrences - 1;
      if (nextDue !== null && (remaining === null || remaining >= 1)) {
        next = await repo.create(
          toInput(task, {
            dueAt: nextDue,
            recurrence: { ...rule, maxOccurrences: remaining },
          }),
        );
      }
    }

    try {
      const completed = await repo.update(id, { status: 'completed' });
      if (!completed) throw new NotFoundError();
      return { completed, next };
    } catch (e) {
      if (next) await repo.delete(next.id); // do not leave a stray occurrence behind
      throw e;
    }
  }

  async function reopen(id: string): Promise<Task> {
    const task = await requireTask(id);
    assertStatusChange(task, 'pending');
    const updated = await repo.update(id, { status: 'pending' });
    if (!updated) throw new NotFoundError();
    return updated;
  }

  async function snooze(id: string, minutes: number): Promise<Task> {
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 10080) {
      throw new InvalidOperationError('مدت تعویق نامعتبر است');
    }
    const task = await requireTask(id);
    if (task.status !== 'pending') throw new InvalidOperationError('فقط کارهای انجام‌نشده را می‌توان به تعویق انداخت');
    const until = now() + minutes * 60_000;
    const updated = await repo.update(id, { dueAt: until, hasTime: true, snoozedUntil: until });
    if (!updated) throw new NotFoundError();
    return updated;
  }

  async function reschedule(id: string, dueAt: number | null, hasTime: boolean): Promise<Task> {
    const task = await requireTask(id);
    if (task.status !== 'pending') throw new InvalidOperationError('ابتدا کار را دوباره باز کنید');
    if (task.recurrence && dueAt === null) throw new InvalidOperationError(RECURRENCE_NEEDS_DATE);
    const updated = await repo.update(id, { dueAt, hasTime: dueAt === null ? false : hasTime, snoozedUntil: null });
    if (!updated) throw new NotFoundError();
    return updated;
  }

  async function duplicate(id: string): Promise<Task> {
    const task = await requireTask(id);
    return repo.create(toInput(task, { title: `${task.title} (کپی)` }));
  }

  async function remove(id: string): Promise<void> {
    const ok = await repo.delete(id);
    if (!ok) throw new NotFoundError();
  }

  return { create, update, complete, reopen, snooze, reschedule, duplicate, delete: remove };
}
