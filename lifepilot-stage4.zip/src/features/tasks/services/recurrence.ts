import { addDays, weekIndexSat } from '../../../core/calendar/dates';
import { dateToJalali, jalaliMonthLength, jalaliToDate } from '../../../core/calendar/jalali';
import type { RecurrenceFrequency } from '../models/task';

export interface RecurrenceRule {
  frequency: RecurrenceFrequency;
  intervalCount: number;
  /** 0 = Sunday .. 6 = Saturday; only used for weekly rules. */
  weekdays: number[];
  endsAt: number | null;
}

function addJalaliMonths(base: Date, months: number): Date {
  const j = dateToJalali(base);
  const total = j.year * 12 + (j.month - 1) + months;
  const year = Math.floor(total / 12);
  const month = (total % 12) + 1;
  const day = Math.min(j.day, jalaliMonthLength(year, month)); // 31 -> 30, Esfand 30 -> 29
  return jalaliToDate(year, month, day, base.getHours(), base.getMinutes());
}

function nextWeekly(base: Date, rule: RecurrenceRule): Date {
  if (rule.weekdays.length === 0) return addDays(base, 7 * rule.intervalCount);
  const baseWeek = weekIndexSat(base);
  for (let k = 1; k <= 7 * rule.intervalCount + 7; k++) {
    const candidate = addDays(base, k);
    if (!rule.weekdays.includes(candidate.getDay())) continue;
    if ((weekIndexSat(candidate) - baseWeek) % rule.intervalCount === 0) return candidate;
  }
  return addDays(base, 7 * rule.intervalCount);
}

/**
 * The occurrence after `dueAt`, or null if the rule has ended.
 * Time of day is preserved. Monthly and yearly rules follow the Jalali calendar.
 */
export function nextOccurrence(dueAt: number, rule: RecurrenceRule): number | null {
  const base = new Date(dueAt);
  let next: Date;
  switch (rule.frequency) {
    case 'daily':
      next = addDays(base, rule.intervalCount);
      break;
    case 'weekly':
      next = nextWeekly(base, rule);
      break;
    case 'monthly':
      next = addJalaliMonths(base, rule.intervalCount);
      break;
    case 'yearly':
      next = addJalaliMonths(base, 12 * rule.intervalCount);
      break;
  }
  const t = next.getTime();
  if (rule.endsAt !== null && t > rule.endsAt) return null;
  return t;
}
