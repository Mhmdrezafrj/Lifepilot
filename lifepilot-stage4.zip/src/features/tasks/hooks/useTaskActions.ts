import { useMemo } from 'react';
import { useServices } from '@/providers/DatabaseProvider';
import { useDataStore } from '@/shared/state/dataStore';
import type { TaskService } from '../services/taskService';

/** TaskService whose successful changes automatically refresh every screen showing tasks. */
export function useTaskActions(): TaskService {
  const { tasks } = useServices();
  const bump = useDataStore((s) => s.bump);
  return useMemo<TaskService>(() => {
    const wrap =
      <A extends unknown[], R>(fn: (...a: A) => Promise<R>) =>
      async (...a: A): Promise<R> => {
        try {
          return await fn(...a);
        } finally {
          bump(); // refresh even after an error: the database may have changed partially
        }
      };
    return {
      create: wrap(tasks.create),
      update: wrap(tasks.update),
      complete: wrap(tasks.complete),
      reopen: wrap(tasks.reopen),
      snooze: wrap(tasks.snooze),
      reschedule: wrap(tasks.reschedule),
      duplicate: wrap(tasks.duplicate),
      delete: wrap(tasks.delete),
    };
  }, [tasks, bump]);
}
