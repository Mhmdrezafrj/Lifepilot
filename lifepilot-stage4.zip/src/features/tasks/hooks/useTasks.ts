import { useEffect, useState } from 'react';
import { useRepositories } from '@/providers/DatabaseProvider';
import { useDataStore } from '@/shared/state/dataStore';
import type { Task, TaskFilter } from '../models/task';

export function useTasks(filter: TaskFilter = {}): { tasks: Task[]; loading: boolean; error: string | null } {
  const { tasks: repo } = useRepositories();
  const version = useDataStore((s) => s.version);
  const key = JSON.stringify(filter);
  const [state, setState] = useState<{ tasks: Task[]; loading: boolean; error: string | null }>({
    tasks: [],
    loading: true,
    error: null,
  });

  useEffect(() => {
    let cancelled = false;
    repo
      .list(JSON.parse(key) as TaskFilter)
      .then((tasks) => {
        if (!cancelled) setState({ tasks, loading: false, error: null });
      })
      .catch(() => {
        if (!cancelled) setState((s) => ({ ...s, loading: false, error: 'خواندن کارها با خطا روبه‌رو شد' }));
      });
    return () => {
      cancelled = true;
    };
  }, [repo, key, version]);

  return state;
}

export function useTask(id: string | null): { task: Task | null; loading: boolean } {
  const { tasks: repo } = useRepositories();
  const version = useDataStore((s) => s.version);
  const [state, setState] = useState<{ task: Task | null; loading: boolean }>({ task: null, loading: id !== null });

  useEffect(() => {
    if (id === null) {
      setState({ task: null, loading: false });
      return;
    }
    let cancelled = false;
    repo
      .getById(id)
      .then((task) => {
        if (!cancelled) setState({ task, loading: false });
      })
      .catch(() => {
        if (!cancelled) setState({ task: null, loading: false });
      });
    return () => {
      cancelled = true;
    };
  }, [repo, id, version]);

  return state;
}
