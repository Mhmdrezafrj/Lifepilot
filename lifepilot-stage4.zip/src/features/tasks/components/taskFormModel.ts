import { startOfDay } from '../../../core/calendar/dates';
import type { Priority, RecurrenceFrequency, Task } from '../models/task';
import type { CreateTaskInput } from '../validation/taskSchemas';

export interface FormState {
  title: string;
  description: string;
  /** Local start of the due day, or null when there is no date. */
  date: Date | null;
  time: { hour: number; minute: number } | null;
  priority: Priority;
  categoryId: string | null;
  tags: string[];
  checklist: { title: string; isCompleted: boolean }[];
  reminderOffsets: number[];
  recurrenceFrequency: RecurrenceFrequency | null;
  recurrenceWeekdays: number[];
  recurrenceInterval: number;
}

export function emptyForm(date: Date | null = null): FormState {
  return {
    title: '',
    description: '',
    date: date ? startOfDay(date) : null,
    time: null,
    priority: 'medium',
    categoryId: null,
    tags: [],
    checklist: [],
    reminderOffsets: [],
    recurrenceFrequency: null,
    recurrenceWeekdays: [],
    recurrenceInterval: 1,
  };
}

export function formFromTask(t: Task): FormState {
  const due = t.dueAt === null ? null : new Date(t.dueAt);
  return {
    title: t.title,
    description: t.description ?? '',
    date: due ? startOfDay(due) : null,
    time: due && t.hasTime ? { hour: due.getHours(), minute: due.getMinutes() } : null,
    priority: t.priority,
    categoryId: t.categoryId,
    tags: t.tags,
    checklist: t.checklist.map((c) => ({ title: c.title, isCompleted: c.isCompleted })),
    reminderOffsets: t.reminders.map((r) => r.offsetMinutes),
    recurrenceFrequency: t.recurrence ? t.recurrence.frequency : null,
    recurrenceWeekdays: t.recurrence ? t.recurrence.weekdays : [],
    recurrenceInterval: t.recurrence ? t.recurrence.intervalCount : 1,
  };
}

/** Whether the form has anything that lives in the "more options" section. */
export function hasAdvancedContent(f: FormState): boolean {
  return (
    f.description.trim().length > 0 || f.tags.length > 0 || f.checklist.length > 0 || f.recurrenceFrequency !== null
  );
}

export function formToInput(f: FormState): CreateTaskInput {
  const date = f.date;
  const dueAt = date
    ? new Date(date.getFullYear(), date.getMonth(), date.getDate(), f.time?.hour ?? 0, f.time?.minute ?? 0).getTime()
    : null;
  const hasTime = date !== null && f.time !== null;
  return {
    title: f.title,
    description: f.description,
    dueAt,
    hasTime,
    priority: f.priority,
    categoryId: f.categoryId,
    tags: f.tags,
    checklist: f.checklist,
    // Reminders are relative to a time of day, so they only apply when a time is set.
    reminders: hasTime ? f.reminderOffsets.map((o) => ({ offsetMinutes: o, channel: 'notification' as const, enabled: true })) : [],
    recurrence: f.recurrenceFrequency
      ? {
          frequency: f.recurrenceFrequency,
          intervalCount: f.recurrenceInterval,
          weekdays: f.recurrenceFrequency === 'weekly' ? f.recurrenceWeekdays : [],
        }
      : null,
  };
}

/** Date helper for quick chips: the Jalali "today" etc. are plain local days. */
export function dayOffsetFromToday(offset: number, now: Date = new Date()): Date {
  return new Date(now.getFullYear(), now.getMonth(), now.getDate() + offset);
}

