import { memo } from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { formatDue, toPersianDigits } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import type { Category } from '@/features/categories/models/category';
import { AppText } from '@/shared/components/AppText';
import { Badge } from '@/shared/components/Badge';
import { Card } from '@/shared/components/Card';
import type { Task } from '../models/task';
import { PRIORITY_LABELS } from '../models/labels';
import { isOverdue } from '../services/taskStatus';

interface Props {
  task: Task;
  category?: Category;
  now: number;
  onPress: (task: Task) => void;
  onToggle: (task: Task) => void;
}

export const TaskCard = memo(function TaskCard({ task, category, now, onPress, onToggle }: Props) {
  const { colors, spacing, iconSizes } = useTheme();
  const done = task.status === 'completed';
  const overdue = isOverdue(task, now);
  const doneCount = task.checklist.filter((c) => c.isCompleted).length;
  const ring = colors.priority[task.priority];

  return (
    <Card onPress={() => onPress(task)} accessibilityLabel={task.title}>
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: spacing.md }}>
        <Pressable
          accessibilityRole="checkbox"
          accessibilityState={{ checked: done }}
          accessibilityLabel={done ? 'بازگشایی کار' : 'انجام شد'}
          hitSlop={12}
          onPress={() => onToggle(task)}
          style={{
            width: 28,
            height: 28,
            marginTop: 2,
            borderRadius: 14,
            borderWidth: 2,
            borderColor: done ? colors.accent : ring,
            backgroundColor: done ? colors.accent : 'transparent',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {done ? <Ionicons name="checkmark" size={iconSizes.md} color={colors.textOnAccent} /> : null}
        </Pressable>

        <View style={{ flex: 1, gap: spacing.xs }}>
          <AppText
            variant="bodyStrong"
            muted={done}
            style={done ? { textDecorationLine: 'line-through' } : undefined}
            numberOfLines={2}
          >
            {task.title}
          </AppText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: spacing.sm }}>
            {task.dueAt !== null ? (
              <AppText variant="caption" color={overdue ? 'danger' : 'textMuted'}>
                {formatDue(task.dueAt, task.hasTime, now)}
              </AppText>
            ) : null}
            {category ? (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.xs }}>
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: category.color }} />
                <AppText variant="caption" muted>{category.name}</AppText>
              </View>
            ) : null}
            {task.priority !== 'medium' ? <Badge label={PRIORITY_LABELS[task.priority]} color={ring} /> : null}
            {task.checklist.length > 0 ? (
              <AppText variant="caption" muted>
                {toPersianDigits(doneCount)}/{toPersianDigits(task.checklist.length)} مورد
              </AppText>
            ) : null}
            {task.recurrence ? <Ionicons name="repeat" size={iconSizes.sm} color={colors.textMuted} /> : null}
          </View>
        </View>
      </View>
    </Card>
  );
});
