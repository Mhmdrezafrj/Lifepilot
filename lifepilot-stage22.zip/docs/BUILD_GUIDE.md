# راهنمای ساخت APK با گیت‌هاب

## یک‌بار آماده‌سازی
1. یک ریپازیتوری در گیت‌هاب بسازید (Public یا Private).
2. همه‌ی فایل‌های `lifepilot-stage1.zip` تا `lifepilot-stage22.zip` را **بدون باز کردن** در ریشه‌ی ریپازیتوری آپلود کنید (Add file → Upload files). ZIPها به ترتیب شماره روی هم باز می‌شوند و فایل جدیدتر جایگزین قدیمی‌تر می‌شود. نسخه‌ی اصلاح‌شده‌ی `lifepilot-stage17.zip` را حتماً بگذارید.
3. فایل `.github/workflows/build-apk.yml` را بسازید (Add file → Create new file، نام کامل را در کادر بنویسید) و متن زیر را بچسبانید. هیچ کلید یا رمزی لازم نیست.

```yaml
name: Build Android APK

on:
  workflow_dispatch:
  push:
    branches: [main]

permissions:
  contents: write

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 60
    env:
      GRADLE_OPTS: -Dorg.gradle.jvmargs=-Xmx4g
      NPM_CONFIG_LEGACY_PEER_DEPS: "true"
    steps:
      - uses: actions/checkout@v4
      - name: Unpack project zips
        run: |
          mkdir project
          for z in $(ls lifepilot-stage*.zip | sort -V); do unzip -o -q "$z" -d project; done
      - uses: actions/setup-node@v4
        with:
          node-version: 22
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - name: Install dependencies
        working-directory: project
        run: npm install --no-audit --no-fund
      - name: Align package versions with the Expo SDK
        working-directory: project
        run: npx expo install --fix || echo "expo install --fix failed, continuing"
      - name: Type check
        working-directory: project
        run: npx tsc --noEmit
      - name: Run tests
        working-directory: project
        continue-on-error: true
        run: npm test
      - name: Generate native Android project
        working-directory: project
        run: npx expo prebuild --platform android --no-install
      - name: Build release APK
        working-directory: project/android
        run: |
          chmod +x gradlew
          ./gradlew assembleRelease --no-daemon -PreactNativeArchitectures=arm64-v8a,armeabi-v7a
      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: LifePilot-apk
          path: project/android/app/build/outputs/apk/release/*.apk
          if-no-files-found: error
      - name: Publish APK to a GitHub Release
        uses: softprops/action-gh-release@v2
        with:
          tag_name: build-${{ github.run_number }}
          name: LifePilot build ${{ github.run_number }}
          files: project/android/app/build/outputs/apk/release/*.apk
```

## ساخت و دریافت
- با هر Commit ساخته می‌شود (۱۵ تا ۲۵ دقیقه). پیشرفت در تب **Actions**. می‌توانید چند ZIP را یک‌جا آپلود کنید تا فقط یک بیلد بگیرید.
- APK: **Releases** ← آخرین مورد ← `app-release.apk`، یا Actions ← اجرا ← Artifacts ← `LifePilot-apk`.
- نصب: فایل را باز کنید و «نصب از منابع ناشناس» را برای مرورگر/فایل‌منیجر مجاز کنید. نصب روی نسخه‌ی قبلی، داده‌ها را نگه می‌دارد.

## اگر بیلد قرمز شد
روی اجرای قرمز ← روی کادر build ← مرحله‌ی دارای ضربدر قرمز ← **چند خط اول و آخر خطا** را کپی کنید.
- «Type check» قرمز: خطای تایپ در یک فایل؛ نام فایل و خط را بفرستید.
- «Install dependencies» قرمز: معمولاً نام یا نسخه‌ی یک بسته.
- «Generate native Android project» قرمز: معمولاً تنظیم افزونه‌ها (فونت‌های ویجت، صداها).
- «Build release APK» قرمز: خطای نیتیو؛ ۳۰ خط آخر لاگ را بفرستید.
- مرحله‌ی «Run tests» عمداً مانع ساخت نیست؛ ضربدر قرمز آن را هم گزارش کنید.

## بعد از نصب (چک‌لیست گوشی)
1. تنظیمات ← اعلان‌ها: فعال‌سازی، «تست زنگ آلارم» با صفحه‌ی قفل.
2. گوشی‌های شیائومی/هوآوی/اوپو: شروع خودکار روشن، باتری «بدون محدودیت»، قفل برنامه در لیست اخیر.
3. افزودن ویجت از لانچر (Widgets ← LifePilot).
4. تنظیمات ← هوش مصنوعی: کلید DeepSeek و «آزمایش اتصال».
