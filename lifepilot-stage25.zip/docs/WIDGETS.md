# Home-screen widgets (stage 23)
Six widgets (react-native-android-widget), all read the real database, even when the app is closed.
Tasks: **برنامه امروز** (4x4), **کار بعدی و افزودن سریع** (4x2), **کارهای رنگارنگ** (4x4, new: big bright pills on black).
Study: **مرور درسی امروز** (4x2: big number, 7-day bars, streak, exam days), **مرور درس‌ها (رنگارنگ)** (4x4: one pill per subject
with today's reviews), **جلسه‌ی مطالعه** (4x3: running/next session with its steps, exam countdown).

Tick square: every task row (برنامه امروز and کارهای رنگارنگ) has a small square. Tapping it runs `COMPLETE_TASK` in the widget task handler:
the task is completed through the normal task service (its scheduled reminders and random extra reminders are cancelled, the next occurrence
of a repeating task is created), then the widget is redrawn without it, and the other widgets are refreshed. The app list updates when the app is opened.

Limits: widgets redraw on task changes, on app open/close and about every 30 minutes (Android). Countdown texts are "as of the last redraw".
The row order (right/left) is guessed from the phone language. A tap on the small square needs a steady finger: it is a small target.

## Stage 23-24 changes
- Pills widget: compact header (date + small white "+" = quick capture), thinner pills (about 25% less), more spacing, tiny all-day label, explicit title width, no pin emoji.
- Tick square: instant tick, then task completed (its notifications cancelled) and removed from every widget.
- Undated quick captures (inbox) are listed after today's tasks, without day or time.

## Stage 25
- "+" is at the bottom-right corner of the colourful widget and opens only a small quick-capture sheet; after saving (or closing) the app steps away to the home screen. (A sheet drawn directly over the launcher without starting the app would need a native Android dialog-activity: not implemented.)
- Tick square moved to the very corner; the tick is drawn at once from the last data (no database wait), then the real update removes the task.
- Settings -> ویجت‌ها: show/hide the "همه‌روز" label; coloured border around every widget (colour changes on every redraw; Android cannot redraw a widget exactly when the screen turns on).
