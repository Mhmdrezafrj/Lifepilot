import type { WidgetTaskHandlerProps } from 'react-native-android-widget';
import { renderWidgetElement } from './services/renderWidget';
import { updateAllWidgets } from './services/updateWidgets';
import { completeFromWidget } from './services/widgetActions';

/**
 * Called by Android when a widget is added, resized, refreshed (about every 30 minutes) or when the small square
 * next to a task is tapped. It runs even when the app is closed and reads the real database.
 */
export async function widgetTaskHandler(props: WidgetTaskHandlerProps): Promise<void> {
  const info = props.widgetInfo as { widgetName: string; width?: number };
  const draw = async (checked?: string[]) => {
    const element = await renderWidgetElement(info.widgetName, info.width, checked);
    if (element) props.renderWidget(element);
  };

  switch (props.widgetAction) {
    case 'WIDGET_ADDED':
    case 'WIDGET_UPDATE':
    case 'WIDGET_RESIZED': {
      try {
        await draw();
      } catch {
        /* keep the previous picture if the database cannot be read right now */
      }
      break;
    }
    case 'WIDGET_CLICK': {
      if (props.clickAction === 'COMPLETE_TASK') {
        const id = (props.clickActionData as { id?: unknown } | undefined)?.id;
        try {
          if (typeof id === 'string') {
            await draw([id]); // instant feedback: the square shows a tick
            await completeFromWidget(id);
          }
          await draw(); // then the finished task disappears
          void updateAllWidgets(); // and from the other widgets
        } catch {
          /* ignore: the next refresh shows the real state */
        }
      }
      break; // other taps open the app through deep links
    }
    default:
      break;
  }
}
