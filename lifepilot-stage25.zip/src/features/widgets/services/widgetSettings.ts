import { VIVID } from './widgetStyle';

export const WIDGET_SETTINGS_KEY = 'widget_settings';

export interface WidgetSettings {
  /** Show the small "همه‌روز" label on tasks that have a day but no time. */
  showAllDay: boolean;
  /** A coloured line around every widget whose colour changes each time the widget is redrawn. */
  border: boolean;
}

export const DEFAULT_WIDGET_SETTINGS: WidgetSettings = { showAllDay: true, border: false };

export function parseWidgetSettings(raw: string | null): WidgetSettings {
  if (!raw) return DEFAULT_WIDGET_SETTINGS;
  try {
    const o = JSON.parse(raw) as Record<string, unknown>;
    return {
      showAllDay: typeof o.showAllDay === 'boolean' ? o.showAllDay : DEFAULT_WIDGET_SETTINGS.showAllDay,
      border: typeof o.border === 'boolean' ? o.border : DEFAULT_WIDGET_SETTINGS.border,
    };
  } catch {
    return DEFAULT_WIDGET_SETTINGS;
  }
}

export function serializeWidgetSettings(s: WidgetSettings): string {
  return JSON.stringify(s);
}

/**
 * The border colour for a redraw: changes every 20 seconds, so each redraw (task change, app opened or closed,
 * the system's periodic refresh) usually shows a different colour. Android does not let a widget react to the screen
 * turning on, so this is the closest possible behaviour.
 */
export function borderColorAt(now: number): string {
  return VIVID[Math.floor(now / 20_000) % VIVID.length];
}
