import React from 'react';
import Constants from 'expo-constants';
import { PillsWidget } from '../components/PillsWidget';
import { QuickWidget } from '../components/QuickWidget';
import { StudyPillsWidget } from '../components/StudyPillsWidget';
import { StudyReviewWidget } from '../components/StudyReviewWidget';
import { StudySessionWidget } from '../components/StudySessionWidget';
import { TodayWidget } from '../components/TodayWidget';
import { WidgetFrame } from '../components/WidgetFrame';
import type { WidgetFonts } from '../components/widgetKit';
import { loadStudyWidgetData } from './loadStudyData';
import { WidgetData, loadWidgetData, loadWidgetSettings } from './loadWidgetData';
import { buildPillsModel } from './pillsModel';
import { borderColorAt } from './widgetSettings';
import { blinkPhase, isRtlLocale, makeWidgetTheme } from './widgetStyle';

export const WIDGET_NAMES = {
  today: 'TodayWidget',
  quick: 'QuickWidget',
  pills: 'PillsWidget',
  studyReview: 'StudyReviewWidget',
  studyPills: 'StudyPillsWidget',
  studySession: 'StudySessionWidget',
} as const;

function detectHostRtl(): boolean {
  try {
    return isRtlLocale(new Intl.DateTimeFormat().resolvedOptions().locale);
  } catch {
    return false;
  }
}

/** Persian font files are bundled into the widget only when they were found at build time. */
function widgetFonts(): WidgetFonts {
  const extra = Constants.expoConfig?.extra as { widgetFonts?: boolean } | undefined;
  return extra?.widgetFonts ? { regular: 'Vazirmatn_400Regular', bold: 'Vazirmatn_700Bold' } : {};
}

// The last task data: used to redraw instantly when a task is ticked (no database wait), before the real update.
let lastTaskData: WidgetData | null = null;

/** Builds the widget picture from the real database. width is the widget width in dp, if known. */
export async function renderWidgetElement(name: string, width?: number, checked?: string[]): Promise<React.ReactElement | null> {
  const base = {
    checked,
    width: width && width > 0 ? width : 300,
    hostRtl: detectHostRtl(),
    fonts: widgetFonts(),
    phase: blinkPhase(Date.now()),
  };
  const settings = await loadWidgetSettings();
  const frame = (el: React.ReactElement) => (settings.border ? <WidgetFrame color={borderColorAt(Date.now())}>{el}</WidgetFrame> : el);

  if (name === WIDGET_NAMES.studyReview || name === WIDGET_NAMES.studyPills || name === WIDGET_NAMES.studySession) {
    const data = await loadStudyWidgetData();
    const common = { ...base, theme: makeWidgetTheme(data.accent) };
    if (name === WIDGET_NAMES.studyReview) return frame(<StudyReviewWidget model={data.review} {...common} />);
    if (name === WIDGET_NAMES.studyPills) return frame(<StudyPillsWidget pills={data.pills} total={data.review.dueCount} {...common} />);
    return frame(<StudySessionWidget session={data.session} examDays={data.review.examDays} {...common} />);
  }

  const data = checked && checked.length > 0 && lastTaskData ? lastTaskData : await loadWidgetData();
  lastTaskData = data;
  const common = { ...base, theme: makeWidgetTheme(data.accent) };
  // The "همه‌روز" label can be switched off in Settings.
  const todayModel = settings.showAllDay
    ? data.today
    : { ...data.today, items: data.today.items.map((i) => (i.timeLabel === 'همه‌روز' ? { ...i, timeLabel: '' } : i)) };
  if (name === WIDGET_NAMES.today) return frame(<TodayWidget model={todayModel} {...common} />);
  if (name === WIDGET_NAMES.quick) return frame(<QuickWidget model={data.quick} {...common} />);
  if (name === WIDGET_NAMES.pills) return frame(<PillsWidget model={buildPillsModel(data.today, { showAllDay: settings.showAllDay })} {...common} />);
  return null;
}
