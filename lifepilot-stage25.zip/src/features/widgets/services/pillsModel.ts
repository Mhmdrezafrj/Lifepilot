import type { TodayWidgetModel, Urgency } from './widgetModel';

/** The bright colours of the "pill" design, in the order they are used (neighbouring rows always differ). */
export const PILL_COLORS = ['#F2F230', '#22D45E', '#FF7A2F', '#7C8CFF', '#FF8FC7', '#FF5A5A', '#9CCBFF', '#D45DE0'] as const;
export const PILL_TEXT = '#0B0B0B';

export interface PillItem {
  id: string;
  title: string;
  /** Shown at the end of the pill: the time, or "همه‌روز". */
  trailing: string;
  color: string;
  urgency: Urgency;
}

export interface PillsModel {
  weekday: string;
  dateLabel: string;
  todayStart: number;
  /** Tasks still to do (finished tasks are not shown). */
  items: PillItem[];
  done: number;
  total: number;
}

export function pillColor(index: number): string {
  return PILL_COLORS[((index % PILL_COLORS.length) + PILL_COLORS.length) % PILL_COLORS.length];
}

/** Pill rows from today's model: pending tasks only, each with the next colour of the palette. */
export function buildPillsModel(today: TodayWidgetModel, opts: { showAllDay?: boolean } = {}): PillsModel {
  const showAllDay = opts.showAllDay ?? true;
  const pending = today.items.filter((i) => i.urgency !== 'done');
  return {
    weekday: today.weekday,
    dateLabel: today.dateLabel,
    todayStart: today.todayStart,
    done: today.done,
    total: today.total,
    items: pending.map((i, idx) => ({
      id: i.id,
      title: i.urgency === 'overdue' || i.urgency === 'soon' ? `🔥 ${i.title}` : i.title,
      trailing: !showAllDay && i.timeLabel === 'همه‌روز' ? '' : i.timeLabel,
      color: pillColor(idx),
      urgency: i.urgency,
    })),
  };
}
