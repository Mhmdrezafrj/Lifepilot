import React from 'react';
import { FlexWidget, ListWidget, TextWidget } from 'react-native-android-widget';
import { toPersianDigits } from '../../../core/calendar/format';
import { PILL_TEXT, PillItem, PillsModel } from '../services/pillsModel';
import { widgetLinks } from '../services/widgetModel';
import { orderForHost, rgba } from '../services/widgetStyle';
import { WidgetRenderProps, st } from './widgetKit';

interface Props extends WidgetRenderProps {
  model: PillsModel;
}

function Pill({ item, hostRtl, fonts, width, checked }: { item: PillItem } & Pick<WidgetRenderProps, 'hostRtl' | 'fonts' | 'width' | 'checked'>) {
  const ticked = checked?.includes(item.id) ?? false;
  const trailingW = item.trailing ? Math.min(70, item.trailing.length * 8 + 6) : 0;
  // Explicit width for the title: the widget cannot measure Persian text reliably, so it must not be left to "flex".
  const titleW = Math.max(90, width - 24 - 12 - 30 - trailingW - 14);

  // The small square sits at the very corner. Tapping it completes the task; it is drawn ticked at once.
  const check = (
    <FlexWidget
      key="check"
      clickAction="COMPLETE_TASK"
      clickActionData={{ id: item.id }}
      accessibilityLabel="انجام شد"
      style={st({ width: 30, height: 30, alignItems: 'center', justifyContent: 'center' })}
    >
      <FlexWidget
        style={st({
          width: 20, height: 20, borderRadius: 6, borderWidth: 3, borderColor: PILL_TEXT, alignItems: 'center', justifyContent: 'center',
          backgroundColor: ticked ? PILL_TEXT : rgba('#FFFFFF', 0.35),
        })}
      >
        {ticked ? <TextWidget text="✓" style={st({ fontSize: 12, fontWeight: 'bold', color: '#FFFFFF' })} /> : null}
      </FlexWidget>
    </FlexWidget>
  );
  const title = (
    <FlexWidget key="title" style={st({ width: titleW })}>
      <TextWidget
        text={item.title}
        style={st({ fontSize: 20, fontWeight: 'bold', fontFamily: fonts.bold, color: PILL_TEXT, textAlign: 'right' })}
      />
    </FlexWidget>
  );
  const trailing = item.trailing ? (
    <TextWidget key="trail" text={item.trailing} style={st({ fontSize: 11, fontFamily: fonts.regular, color: rgba('#0B0B0B', 0.7) })} />
  ) : (
    <FlexWidget key="trail" style={st({ width: 1, height: 1 })} />
  );
  return (
    <FlexWidget
      clickAction="OPEN_URI"
      clickActionData={{ uri: widgetLinks.task(item.id) }}
      style={st({
        width: 'match_parent', flexDirection: 'row', alignItems: 'center', flexGap: 6,
        paddingHorizontal: 6, paddingVertical: 6, marginTop: 14, borderRadius: 28,
        backgroundColor: ticked ? rgba(item.color, 0.45) : item.color,
      })}
    >
      {orderForHost([check, title, trailing], hostRtl)}
    </FlexWidget>
  );
}

/** Big, bright, rounded rows on black: one pill per task, a square to tick it off, and "+" in the bottom-right corner. */
export function PillsWidget({ model, hostRtl, fonts, width, checked }: Props) {
  const plus = (
    <FlexWidget
      clickAction="OPEN_URI"
      clickActionData={{ uri: widgetLinks.capture }}
      accessibilityLabel="ثبت سریع کار"
      style={st({ width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFFFFF' })}
    >
      <TextWidget text="+" style={st({ fontSize: 26, fontWeight: 'bold', color: '#000000' })} />
    </FlexWidget>
  );

  return (
    <FlexWidget style={st({ height: 'match_parent', width: 'match_parent', flexDirection: 'column', padding: 12, borderRadius: 32, backgroundColor: '#000000' })}>
      <FlexWidget style={st({ width: 'match_parent', flexDirection: 'column', paddingHorizontal: 4 })}>
        <TextWidget text={model.weekday} style={st({ fontSize: 10, fontFamily: fonts.regular, textAlign: 'right', color: '#9AA3B2' })} />
        <TextWidget text={model.dateLabel} style={st({ fontSize: 14, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right', color: '#FFFFFF' })} />
        <TextWidget
          text={model.total === 0 ? 'برای امروز کاری ثبت نشده' : `${toPersianDigits(model.done)} از ${toPersianDigits(model.total)} انجام شد`}
          style={st({ fontSize: 10, fontFamily: fonts.regular, textAlign: 'right', color: '#9AA3B2' })}
        />
      </FlexWidget>

      <FlexWidget style={st({ flex: 1, width: 'match_parent' })}>
        {model.items.length === 0 ? (
          <FlexWidget style={st({ height: 'match_parent', width: 'match_parent', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' })}>
            <TextWidget text={model.total > 0 ? '🎉' : '✨'} style={st({ fontSize: 40, color: '#FFFFFF' })} />
            <TextWidget
              text={model.total > 0 ? 'همه‌ی کارهای امروز انجام شد' : 'با + کار جدید بنویسید'}
              style={st({ fontSize: 16, fontWeight: 'bold', fontFamily: fonts.bold, color: '#FFFFFF', marginTop: 6 })}
            />
          </FlexWidget>
        ) : (
          <ListWidget style={st({ height: 'match_parent', width: 'match_parent' })}>
            {model.items.map((item) => (
              <Pill key={item.id} item={item} hostRtl={hostRtl} fonts={fonts} width={width} checked={checked} />
            ))}
          </ListWidget>
        )}
      </FlexWidget>

      <FlexWidget style={st({ width: 'match_parent', flexDirection: 'row', justifyContent: hostRtl ? 'flex-start' : 'flex-end', paddingTop: 6 })}>
        {plus}
      </FlexWidget>
    </FlexWidget>
  );
}
