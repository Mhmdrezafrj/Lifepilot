import React from 'react';
import { FlexWidget } from 'react-native-android-widget';
import { st } from './widgetKit';

/** A coloured line around a widget (a coloured background with the widget inset by a few dp). */
export function WidgetFrame({ color, children }: { color: string; children: React.ReactNode }) {
  return (
    <FlexWidget style={st({ width: 'match_parent', height: 'match_parent', padding: 3, borderRadius: 36, backgroundColor: color })}>
      {children}
    </FlexWidget>
  );
}
