import { useCallback, useEffect, useState } from 'react';
import { useRepositories } from '@/providers/DatabaseProvider';
import { useDataStore } from '@/shared/state/dataStore';
import {
  DEFAULT_WIDGET_SETTINGS, WIDGET_SETTINGS_KEY, WidgetSettings, parseWidgetSettings, serializeWidgetSettings,
} from '../services/widgetSettings';

/** Widget options saved on the phone; saving redraws the widgets (WidgetSync listens to the data version). */
export function useWidgetSettings(): { settings: WidgetSettings; save: (s: WidgetSettings) => Promise<void> } {
  const repo = useRepositories().settings;
  const bump = useDataStore((s) => s.bump);
  const [settings, setSettings] = useState<WidgetSettings>(DEFAULT_WIDGET_SETTINGS);

  useEffect(() => {
    let cancelled = false;
    repo
      .get(WIDGET_SETTINGS_KEY)
      .then((raw) => {
        if (!cancelled) setSettings(parseWidgetSettings(raw));
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [repo]);

  const save = useCallback(
    async (s: WidgetSettings) => {
      await repo.set(WIDGET_SETTINGS_KEY, serializeWidgetSettings(s));
      setSettings(s);
      bump();
    },
    [repo, bump],
  );
  return { settings, save };
}
