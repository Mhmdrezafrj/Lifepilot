/** Persian-capable fonts bundled with the app (Google Fonts). Vazirmatn is the default. */
export type FontKey =
  | 'vazirmatn' | 'hamishe' | 'sarvenaz' | 'rastin' | 'lalezar' | 'lalezarGrunge' | 'lalezarCircle' | 'craft'
  | 'notoSans' | 'plex' | 'cairo' | 'tajawal' | 'naskh';

// The "Digi" fonts are files bundled in assets/fonts. Some have a single weight, so all three weights use that file.
export const FONT_KEYS: FontKey[] = [
  'vazirmatn', 'hamishe', 'sarvenaz', 'rastin', 'lalezar', 'lalezarGrunge', 'lalezarCircle', 'craft',
  'notoSans', 'plex', 'cairo', 'tajawal', 'naskh',
];

export const FONT_LABELS: Record<FontKey, string> = {
  vazirmatn: 'وزیرمتن (پیش‌فرض)',
  hamishe: 'دیجی همیشه',
  sarvenaz: 'دیجی سروناز',
  rastin: 'دیجی راستین',
  lalezar: 'دیجی لاله‌زار',
  lalezarGrunge: 'دیجی لاله‌زار گرانج',
  lalezarCircle: 'دیجی لاله‌زار دایره',
  craft: 'دیجی کرافت',
  notoSans: 'نوتو سنس عربی',
  plex: 'آی‌بی‌ام پلکس',
  cairo: 'کایرو',
  tajawal: 'تجوال',
  naskh: 'نوتو نسخ',
};

const PREFIX: Record<FontKey, string> = {
  hamishe: '', sarvenaz: '', rastin: '', lalezar: '', lalezarGrunge: '', lalezarCircle: '', craft: '',
  vazirmatn: 'Vazirmatn',
  notoSans: 'NotoSansArabic',
  plex: 'IBMPlexSansArabic',
  cairo: 'Cairo',
  tajawal: 'Tajawal',
  naskh: 'NotoNaskhArabic',
};

export interface FontFamilies {
  regular: string;
  medium: string;
  bold: string;
}

const one = (family: string): FontFamilies => ({ regular: family, medium: family, bold: family });

const CUSTOM: Partial<Record<FontKey, FontFamilies>> = {
  hamishe: { regular: 'Digi_Hamishe_Regular', medium: 'Digi_Hamishe_Regular', bold: 'Digi_Hamishe_Bold' },
  sarvenaz: one('Digi_Sarvenaz'),
  rastin: one('Digi_Rastin_Bold'),
  lalezar: one('Digi_Lalezar_Plus'),
  lalezarGrunge: one('Digi_Lalezar_Plus_Grunge'),
  lalezarCircle: one('Digi_Lalezar_Plus_Circle'),
  craft: one('Digi_Craft_Ultra_Black'),
};

export function familiesFor(key: FontKey): FontFamilies {
  const custom = CUSTOM[key];
  if (custom) return custom;
  const p = PREFIX[key];
  return { regular: `${p}_400Regular`, medium: `${p}_500Medium`, bold: `${p}_700Bold` };
}

export function parseFontKey(raw: string | null): FontKey {
  return FONT_KEYS.find((k) => k === raw) ?? 'vazirmatn';
}
