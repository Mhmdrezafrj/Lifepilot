import { BackHandler, View } from 'react-native';
import { CaptureSheet } from '@/features/capture/components/QuickCapture';

/**
 * Opened from the widgets ("+"): only the small quick-capture sheet. When it is closed or the task is saved,
 * the app steps away and you are back on the home screen.
 */
export default function CaptureScreen() {
  return (
    <View style={{ flex: 1 }}>
      <CaptureSheet visible onClose={() => BackHandler.exitApp()} />
    </View>
  );
}
