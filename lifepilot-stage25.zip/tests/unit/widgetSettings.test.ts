import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { Task } from '../../src/features/tasks/models/task';
import { buildPillsModel } from '../../src/features/widgets/services/pillsModel';
import { buildTodayModel } from '../../src/features/widgets/services/widgetModel';
import {
  DEFAULT_WIDGET_SETTINGS, borderColorAt, parseWidgetSettings, serializeWidgetSettings,
} from '../../src/features/widgets/services/widgetSettings';
import { VIVID } from '../../src/features/widgets/services/widgetStyle';

const NOW = new Date(2026, 10, 5, 12, 0).getTime();
const task = (over: Partial<Task>): Task => ({
  id: 'x', title: 'x', description: null, dueAt: null, hasTime: false, priority: 'medium', categoryId: null,
  status: 'pending', snoozedUntil: null, createdAt: 0, updatedAt: 0, completedAt: null, recurrenceId: null,
  tags: [], checklist: [], reminders: [], recurrence: null, ...over,
});

describe('widget settings', () => {
  it('defaults: all-day label shown, border off; bad data falls back', () => {
    assert.deepEqual(DEFAULT_WIDGET_SETTINGS, { showAllDay: true, border: false });
    assert.deepEqual(parseWidgetSettings(null), DEFAULT_WIDGET_SETTINGS);
    assert.deepEqual(parseWidgetSettings('nope'), DEFAULT_WIDGET_SETTINGS);
    assert.deepEqual(parseWidgetSettings('{"showAllDay":"x","border":1}'), DEFAULT_WIDGET_SETTINGS);
  });

  it('round-trips', () => {
    const s = { showAllDay: false, border: true };
    assert.deepEqual(parseWidgetSettings(serializeWidgetSettings(s)), s);
  });

  it('the border colour changes every 20 seconds and comes from the palette', () => {
    const base = Math.floor(NOW / 20_000) * 20_000;
    assert.notEqual(borderColorAt(base), borderColorAt(base + 20_000));
    assert.equal(borderColorAt(base), borderColorAt(base + 19_000));
    for (let i = 0; i < 12; i++) assert.ok((VIVID as readonly string[]).includes(borderColorAt(base + i * 20_000)));
    assert.ok(new Set(Array.from({ length: VIVID.length }, (_, i) => borderColorAt(base + i * 20_000))).size === VIVID.length);
  });
});

describe('the all-day label on pills', () => {
  const tasks = [
    task({ id: 'a', title: 'روزانه', dueAt: new Date(2026, 10, 5).getTime() }),
    task({ id: 'b', title: 'ساعتی', dueAt: new Date(2026, 10, 5, 18).getTime(), hasTime: true }),
    task({ id: 'c', title: 'بدون روز' }),
  ];
  const today = buildTodayModel(tasks, tasks, NOW, [tasks[2]]);

  it('is shown by default', () => {
    assert.deepEqual(buildPillsModel(today).items.map((i) => i.trailing), ['همه‌روز', '۱۸:۰۰', '']);
  });

  it('can be removed without touching times or undated tasks', () => {
    const m = buildPillsModel(today, { showAllDay: false });
    assert.deepEqual(m.items.map((i) => i.trailing), ['', '۱۸:۰۰', '']);
    assert.deepEqual(m.items.map((i) => i.id), ['a', 'b', 'c']);
  });
});
