import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { formatJalaliDate, formatTimeParts, toPersianDigits } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import { useStudyData } from '@/features/study/hooks/useStudyData';
import { useStudyProfile } from '@/features/study/hooks/useStudyProfile';
import { useStudyStats } from '@/features/study/hooks/useStudyStats';
import { daysUntil } from '@/features/study/services/srs';
import { buildAdvice, buildWeeklyPlan, weakestTopics } from '@/features/study/services/studyPlan';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Screen } from '@/shared/components/Screen';

export default function StudyPlanScreen() {
  const router = useRouter();
  const { colors, spacing } = useTheme();
  const { topics, exam, now } = useStudyData();
  const { profile } = useStudyProfile();
  const stats = useStudyStats();

  const plan = buildWeeklyPlan(topics, profile, now);
  const weak = weakestTopics(topics);
  const examDays = exam === null ? null : daysUntil(exam, now);
  const advice = buildAdvice({ stats, plan, profile, examDays, topicCount: topics.length, weakCount: weak.length });
  const recall = stats.recallRate === null ? '—' : `${toPersianDigits(Math.round(stats.recallRate * 100))}٪`;

  return (
    <Screen title="برنامه‌ی هفتگی و پیشرفت" onBack={() => router.back()}>
      <Card>
        <AppText variant="bodyStrong">پیشرفت شما</AppText>
        <View style={{ flexDirection: 'row', gap: spacing.md }}>
          <View style={{ flex: 1 }}>
            <AppText variant="title">{toPersianDigits(stats.reviewsLast7)}</AppText>
            <AppText variant="caption" muted>مرور در ۷ روز اخیر</AppText>
          </View>
          <View style={{ flex: 1 }}>
            <AppText variant="title">{recall}</AppText>
            <AppText variant="caption" muted>یادآوری موفق (۱۴ روز)</AppText>
          </View>
          <View style={{ flex: 1 }}>
            <AppText variant="title">{toPersianDigits(stats.streakDays)}</AppText>
            <AppText variant="caption" muted>روز پشت‌سرهم</AppText>
          </View>
        </View>
        {examDays !== null && examDays >= 0 ? (
          <AppText variant="caption" muted>{toPersianDigits(examDays)} روز تا کنکور</AppText>
        ) : (
          <AppText variant="caption" muted>تاریخ کنکور ثبت نشده است (در تنظیمات مطالعه).</AppText>
        )}
      </Card>

      <View style={{ gap: spacing.sm }}>
        <AppText variant="heading">۷ روز آینده</AppText>
        <AppText variant="caption" muted>
          هر جلسه: {toPersianDigits(profile.sessionMinutes)} دقیقه تمرکز + ۵ دقیقه استراحت (هر ۴ جلسه ۱۵ دقیقه). زمان هر مرور حدود ۳ دقیقه حساب شده است.
        </AppText>
        {plan.map((d, i) => (
          <Card key={d.date} variant={d.overloaded ? 'outlined' : 'flat'} style={d.overloaded ? { borderColor: colors.danger } : undefined}>
            <AppText variant="bodyStrong" color={i === 0 ? 'accent' : 'text'}>
              {i === 0 ? 'امروز · ' : ''}{formatJalaliDate(new Date(d.date), { weekday: true, year: false })}
            </AppText>
            {d.count === 0 ? (
              <AppText variant="caption" muted>مرور ندارید</AppText>
            ) : (
              <>
                <AppText muted>
                  {toPersianDigits(d.count)} مرور · حدود {toPersianDigits(d.minutes)} دقیقه · {toPersianDigits(d.sessions)} جلسه
                </AppText>
                <AppText variant="caption" muted>پیشنهاد شروع: ساعت {formatTimeParts(d.startHour, 0)}</AppText>
                {d.overloaded ? (
                  <AppText variant="caption" color="danger">
                    روز سنگین: بیش از {toPersianDigits(profile.dailyMinutes)} دقیقه. مرور را به جلسه‌های کوتاه تقسیم کنید.
                  </AppText>
                ) : null}
              </>
            )}
          </Card>
        ))}
      </View>

      {weak.length > 0 ? (
        <View style={{ gap: spacing.sm }}>
          <AppText variant="heading">مباحث ضعیف شما</AppText>
          {weak.map((t) => (
            <Card key={t.id} variant="outlined">
              <AppText variant="bodyStrong">{t.title}</AppText>
              <AppText variant="caption" muted>
                {t.materialTitle}
                {t.lapses > 0 ? ` · ${toPersianDigits(t.lapses)} بار فراموش‌شده` : ''}
              </AppText>
            </Card>
          ))}
        </View>
      ) : null}

      <View style={{ gap: spacing.sm }}>
        <AppText variant="heading">پیشنهادها</AppText>
        {advice.map((a, i) => (
          <Card key={i} variant="flat"><AppText>{a}</AppText></Card>
        ))}
        <AppText variant="caption" muted>
          این پیشنهادها فقط از نتیجه‌ی مرورهای خودتان و زمان‌هایی که ثبت کرده‌اید ساخته می‌شوند. هرچه بیشتر مرور کنید دقیق‌تر می‌شوند.
        </AppText>
      </View>

      <Button title="تنظیمات مطالعه" icon="options-outline" variant="secondary" onPress={() => router.push('/study/profile')} />
    </Screen>
  );
}
