import { useEffect, useState } from 'react';
import { Alert, View } from 'react-native';
import { useRouter } from 'expo-router';
import { formatJalaliDate, formatTimeParts, toPersianDigits } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { useTheme } from '@/core/theme/useTheme';
import { useNotificationPermission } from '@/features/reminders/hooks/useNotificationPermission';
import { useStudyData } from '@/features/study/hooks/useStudyData';
import { useStudyProfile } from '@/features/study/hooks/useStudyProfile';
import { daysUntil } from '@/features/study/services/srs';
import {
  CHRONOTYPES, CHRONOTYPE_HOURS, CHRONOTYPE_LABELS, DAILY_OPTIONS, SESSION_OPTIONS, StudyProfile,
} from '@/features/study/services/studyProfile';
import { useServices } from '@/providers/DatabaseProvider';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Chip } from '@/shared/components/Chip';
import { JalaliDatePicker } from '@/shared/components/JalaliDatePicker';
import { Screen } from '@/shared/components/Screen';
import { useDataStore } from '@/shared/state/dataStore';

export default function StudyProfileScreen() {
  const router = useRouter();
  const { spacing } = useTheme();
  const services = useServices();
  const bump = useDataStore((s) => s.bump);
  const { exam, now } = useStudyData();
  const { profile, loaded, save } = useStudyProfile();
  const notif = useNotificationPermission();
  const [form, setForm] = useState<StudyProfile>(profile);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (loaded) setForm(profile);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loaded]);

  const setExam = async (ms: number | null) => {
    try {
      await services.study.setExamDate(ms);
    } catch (e) {
      Alert.alert('خطا', describeError(e));
    } finally {
      bump();
      setPickerOpen(false);
    }
  };

  const toggleReminders = (on: boolean) => {
    setForm((f) => ({ ...f, remindersOn: on }));
    if (on && notif.state !== 'granted') void notif.request();
  };

  const submit = async () => {
    setSaving(true);
    try {
      await save(form);
      router.back();
    } catch (e) {
      Alert.alert('خطا', describeError(e));
      setSaving(false);
    }
  };

  const examDays = exam === null ? null : daysUntil(exam, now);

  return (
    <Screen title="تنظیمات مطالعه" subtitle="برنامه با همین اطلاعات و نتیجه‌ی واقعی مرورهایتان ساخته می‌شود" onBack={() => router.back()}>
      <Card variant="outlined">
        <AppText variant="bodyStrong">تاریخ کنکور</AppText>
        <AppText muted>
          {exam === null
            ? 'ثبت نشده'
            : `${formatJalaliDate(new Date(exam), { weekday: true })} (${examDays !== null && examDays >= 0 ? `${toPersianDigits(examDays)} روز دیگر` : 'گذشته'})`}
        </AppText>
        <AppText variant="caption" muted>
          هرچه به کنکور نزدیک‌تر شوید، فاصله‌ی مرورها کوتاه‌تر می‌شود تا هر مبحث قبل از آزمون حدود ۳ بار دیگر مرور شود.
        </AppText>
        <View style={{ flexDirection: 'row', gap: spacing.sm, flexWrap: 'wrap' }}>
          <Button title={exam === null ? 'انتخاب تاریخ' : 'تغییر تاریخ'} size="sm" icon="calendar-outline" onPress={() => setPickerOpen(true)} />
          {exam !== null ? <Button title="حذف تاریخ" size="sm" variant="ghost" onPress={() => void setExam(null)} /> : null}
        </View>
      </Card>

      <Card variant="outlined">
        <AppText variant="bodyStrong">چه ساعتی بهترین تمرکز را دارید؟</AppText>
        <AppText variant="caption" muted>برای پیشنهاد ساعت شروع مرور و ساعت یادآوری روزانه استفاده می‌شود. هر وقت خواستید عوضش کنید.</AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          {CHRONOTYPES.map((c) => (
            <Chip
              key={c}
              label={`${CHRONOTYPE_LABELS[c]} (${formatTimeParts(CHRONOTYPE_HOURS[c], 0)})`}
              selected={form.chronotype === c}
              onPress={() => setForm((f) => ({ ...f, chronotype: c }))}
            />
          ))}
        </View>
      </Card>

      <Card variant="outlined">
        <AppText variant="bodyStrong">طول هر جلسه‌ی تمرکز</AppText>
        <AppText variant="caption" muted>بعد از هر جلسه ۵ دقیقه استراحت و بعد از ۴ جلسه ۱۵ دقیقه استراحت (روش پومودورو).</AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          {SESSION_OPTIONS.map((m) => (
            <Chip key={m} label={`${toPersianDigits(m)} دقیقه`} selected={form.sessionMinutes === m} onPress={() => setForm((f) => ({ ...f, sessionMinutes: m }))} />
          ))}
        </View>
      </Card>

      <Card variant="outlined">
        <AppText variant="bodyStrong">چقدر زمان برای مرور روزانه دارید؟</AppText>
        <AppText variant="caption" muted>اگر مرورهای یک روز از این بیشتر شود، در برنامه‌ی هفتگی «روز سنگین» علامت می‌خورد.</AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          {DAILY_OPTIONS.map((m) => (
            <Chip key={m} label={`${toPersianDigits(m)} دقیقه`} selected={form.dailyMinutes === m} onPress={() => setForm((f) => ({ ...f, dailyMinutes: m }))} />
          ))}
        </View>
      </Card>

      <Card variant="outlined">
        <AppText variant="bodyStrong">یادآوری روزانه‌ی مرور</AppText>
        <AppText variant="caption" muted>
          هر روز که مرور دارید، در ساعت انتخابی یک اعلان «وقت مرور» می‌آید. اعلان‌ها بعد از هر بار باز شدن برنامه برای ۷ روز آینده تنظیم می‌شوند.
        </AppText>
        <View style={{ flexDirection: 'row', gap: spacing.sm }}>
          <Chip label="روشن" icon="notifications-outline" selected={form.remindersOn} onPress={() => toggleReminders(true)} />
          <Chip label="خاموش" selected={!form.remindersOn} onPress={() => toggleReminders(false)} />
        </View>
        {form.remindersOn && (notif.state === 'denied' || notif.state === 'undetermined') ? (
          <AppText variant="caption" color="danger">اعلان‌ها برای برنامه فعال نیست؛ از تنظیمات › اعلان‌ها فعالش کنید.</AppText>
        ) : null}
      </Card>

      <Button title="ذخیره" size="lg" fullWidth loading={saving} onPress={() => void submit()} />

      <JalaliDatePicker
        visible={pickerOpen}
        value={exam === null ? null : new Date(exam)}
        onSelect={(d) => void setExam(d.getTime())}
        onClear={() => void setExam(null)}
        onClose={() => setPickerOpen(false)}
      />
    </Screen>
  );
}
