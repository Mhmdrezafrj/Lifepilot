import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { STUDY_DATA_TYPE, STUDY_PREFIX, isStudyResponse } from '../../src/infrastructure/notifications/notificationResponse';

describe('study reminder notifications', () => {
  it('recognises the daily review notification', () => {
    assert.equal(isStudyResponse({ type: STUDY_DATA_TYPE }), true);
    assert.equal(isStudyResponse({ type: 'other' }), false);
    assert.equal(isStudyResponse({ taskId: 't' }), false);
    assert.equal(isStudyResponse(null), false);
    assert.equal(isStudyResponse('study-review'), false);
  });

  it('uses an identifier prefix that task reminders never use', () => {
    assert.equal(STUDY_PREFIX, 'study-');
  });
});
