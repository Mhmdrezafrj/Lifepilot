import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_STUDY_PROFILE, STUDY_PROFILE_KEY, parseStudyProfile, serializeStudyProfile,
} from '../../src/features/study/services/studyProfile';
import {
  buildAdvice, buildWeeklyPlan, planStudyReminders, studyStats, weakestTopics,
} from '../../src/features/study/services/studyPlan';
import type { QueueTopic } from '../../src/features/study/services/reviewQueue';

const NOW = new Date(2026, 10, 5, 12, 0).getTime();
const day = (d: number, h = 0) => new Date(2026, 10, d, h).getTime();
const topic = (id: string, over: Partial<QueueTopic> = {}): QueueTopic => ({
  id, subjectId: 's', dueAt: day(5), ease: 2.5, lapses: 0, suspended: false, ...over,
});
const profile = { ...DEFAULT_STUDY_PROFILE, chronotype: 'evening' as const, sessionMinutes: 25, dailyMinutes: 30, remindersOn: true };

describe('study profile', () => {
  it('uses defaults for missing or broken data', () => {
    assert.deepEqual(parseStudyProfile(null), DEFAULT_STUDY_PROFILE);
    assert.deepEqual(parseStudyProfile('not json'), DEFAULT_STUDY_PROFILE);
    assert.deepEqual(parseStudyProfile('{"chronotype":"x","sessionMinutes":7,"dailyMinutes":5,"remindersOn":"yes"}'), DEFAULT_STUDY_PROFILE);
    assert.equal(STUDY_PROFILE_KEY, 'study_profile');
  });

  it('round-trips a valid profile', () => {
    const p = { chronotype: 'morning' as const, sessionMinutes: 45, dailyMinutes: 120, remindersOn: true };
    assert.deepEqual(parseStudyProfile(serializeStudyProfile(p)), p);
  });
});

describe('weekly plan', () => {
  it('counts reviews, minutes and sessions per day and flags overloaded days', () => {
    const topics = [...Array.from({ length: 12 }, (_, i) => topic(`t${i}`)), topic('x', { dueAt: day(7) })];
    const plan = buildWeeklyPlan(topics, profile, NOW);
    assert.equal(plan.length, 7);
    assert.equal(plan[0].date, day(5));
    assert.deepEqual([plan[0].count, plan[0].minutes, plan[0].sessions, plan[0].overloaded], [12, 36, 2, true]);
    assert.deepEqual([plan[2].count, plan[2].minutes, plan[2].sessions, plan[2].overloaded], [1, 3, 1, false]);
    assert.deepEqual([plan[1].count, plan[1].sessions], [0, 0]);
    assert.equal(plan[0].startHour, 19);
  });
});

describe('weak topics and stats', () => {
  it('lists the most forgotten topics first and skips suspended ones', () => {
    const list = [topic('ok'), topic('a', { lapses: 1 }), topic('b', { lapses: 3 }), topic('c', { ease: 1.8 }), topic('s', { lapses: 9, suspended: true })];
    assert.deepEqual(weakestTopics(list).map((t) => t.id), ['b', 'a', 'c']);
    assert.equal(weakestTopics(list, 1).length, 1);
  });

  it('computes recall rate, weekly count and streak', () => {
    const r = (d: number, rating: number) => ({ reviewedAt: day(d, 10), rating });
    const reviews = [r(5, 2), r(5, 3), r(4, 0), r(3, 1), r(2, 2), r(1, 3)];
    const s = studyStats(reviews, NOW);
    assert.equal(s.totalReviews, 6);
    assert.equal(s.reviewsLast7, 6);
    assert.equal(s.recallRate, 4 / 6);
    assert.equal(s.streakDays, 5);
  });

  it('has no recall rate with too few reviews; streak may count through yesterday', () => {
    const s = studyStats([{ reviewedAt: day(4, 9), rating: 2 }], NOW);
    assert.equal(s.recallRate, null);
    assert.equal(s.streakDays, 1);
    assert.equal(studyStats([{ reviewedAt: day(2, 9), rating: 2 }], NOW).streakDays, 0);
    assert.deepEqual(studyStats([], NOW), { totalReviews: 0, reviewsLast7: 0, recallRate: null, streakDays: 0 });
  });
});

describe('advice', () => {
  const base = {
    stats: { totalReviews: 0, reviewsLast7: 0, recallRate: null, streakDays: 0 },
    plan: buildWeeklyPlan([], profile, NOW), profile, examDays: null, topicCount: 5, weakCount: 0,
  };

  it('asks to register topics first when there are none', () => {
    assert.equal(buildAdvice({ ...base, topicCount: 0 }).length, 1);
  });

  it('says there is not enough data yet before any reviews', () => {
    assert.match(buildAdvice(base)[0], /داده‌ی کافی/);
  });

  it('reacts to a low recall rate, a heavy week, a near exam and weak topics', () => {
    const heavyPlan = buildWeeklyPlan(Array.from({ length: 12 }, (_, i) => topic(`t${i}`)), profile, NOW);
    const tips = buildAdvice({
      ...base, plan: heavyPlan, examDays: 20, weakCount: 2,
      stats: { totalReviews: 30, reviewsLast7: 12, recallRate: 0.5, streakDays: 4 },
    });
    assert.ok(tips.some((t) => t.includes('سخت یا فراموش‌شده')));
    assert.ok(tips.some((t) => t.includes('بیش از')));
    assert.ok(tips.some((t) => t.includes('تا کنکور')));
    assert.ok(tips.some((t) => t.includes('مبحث ضعیف')));
    assert.ok(tips.some((t) => t.includes('پشت‌سرهم')));
  });

  it('notes when reviews are easy', () => {
    const tips = buildAdvice({ ...base, stats: { totalReviews: 40, reviewsLast7: 20, recallRate: 0.95, streakDays: 0 } });
    assert.ok(tips.some((t) => t.includes('آسان')));
    assert.ok(tips.some((t) => t.includes('ریتم')));
  });
});

describe('daily study reminders', () => {
  it('plans one reminder per day with reviews, at the chosen hour, only in the future', () => {
    const items = planStudyReminders([4, 0, 2, 0, 0, 0, 1], profile, NOW);
    assert.deepEqual(items.map((i) => [i.fireAt, i.count]), [[day(5, 19), 4], [day(7, 19), 2], [day(11, 19), 1]]);
    assert.equal(new Set(items.map((i) => i.id)).size, 3);
  });

  it('skips a time that has already passed today', () => {
    const late = new Date(2026, 10, 5, 20, 0).getTime();
    assert.deepEqual(planStudyReminders([3, 2], profile, late).map((i) => i.count), [2]);
  });

  it('plans nothing when reminders are off', () => {
    assert.deepEqual(planStudyReminders([3, 2], { ...profile, remindersOn: false }, NOW), []);
  });
});
