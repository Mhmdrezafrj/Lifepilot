import { useCallback, useEffect, useState } from 'react';
import { useRepositories } from '@/providers/DatabaseProvider';
import { useDataStore } from '@/shared/state/dataStore';
import {
  DEFAULT_STUDY_PROFILE, STUDY_PROFILE_KEY, StudyProfile, parseStudyProfile, serializeStudyProfile,
} from '../services/studyProfile';

export function useStudyProfile(): { profile: StudyProfile; loaded: boolean; save: (p: StudyProfile) => Promise<void> } {
  const { settings } = useRepositories();
  const bump = useDataStore((s) => s.bump);
  const version = useDataStore((s) => s.version);
  const [profile, setProfile] = useState<StudyProfile>(DEFAULT_STUDY_PROFILE);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    settings
      .get(STUDY_PROFILE_KEY)
      .then((raw) => {
        if (!cancelled) {
          setProfile(parseStudyProfile(raw));
          setLoaded(true);
        }
      })
      .catch(() => {
        if (!cancelled) setLoaded(true);
      });
    return () => {
      cancelled = true;
    };
  }, [settings, version]);

  const save = useCallback(
    async (p: StudyProfile) => {
      await settings.set(STUDY_PROFILE_KEY, serializeStudyProfile(p));
      setProfile(p);
      bump(); // study reminders and plans follow the new profile
    },
    [settings, bump],
  );

  return { profile, loaded, save };
}
