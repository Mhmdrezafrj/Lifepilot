import { useEffect, useState } from 'react';
import { addDays, startOfDay } from '@/core/calendar/dates';
import { useRepositories } from '@/providers/DatabaseProvider';
import { useDataStore } from '@/shared/state/dataStore';
import { StudyStats, studyStats } from '../services/studyPlan';

const EMPTY: StudyStats = { totalReviews: 0, reviewsLast7: 0, recallRate: null, streakDays: 0 };

/** Progress numbers from the real review history (last 60 days). */
export function useStudyStats(): StudyStats {
  const repos = useRepositories();
  const version = useDataStore((s) => s.version);
  const [stats, setStats] = useState<StudyStats>(EMPTY);

  useEffect(() => {
    let cancelled = false;
    const now = Date.now();
    repos.study
      .listReviewsSince(addDays(startOfDay(new Date(now)), -60).getTime())
      .then((reviews) => {
        if (!cancelled) setStats(studyStats(reviews, now));
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [repos, version]);

  return stats;
}
