import type { DbClient, SqlParam } from '../../../core/database/connection/types';
import { newId } from '../../../core/utils/id';
import type { MaterialKind, StudyMaterial, StudyReview, StudySubject, StudyTopic } from '../models/study';
import {
  MaterialInput, SubjectInput, materialInputSchema, subjectInputSchema, topicTitleSchema,
} from '../validation/studySchemas';

interface TopicRow {
  id: string; material_id: string; title: string; learned_at: number; due_at: number; interval_days: number;
  ease: number; repetitions: number; lapses: number; last_reviewed_at: number | null; suspended: number;
  created_at: number; material_title: string; material_kind: MaterialKind; subject_id: string | null;
  subject_name: string | null; subject_color: string | null;
}

const TOPIC_SELECT = `
  SELECT t.*, m.title AS material_title, m.kind AS material_kind, m.subject_id AS subject_id,
         s.name AS subject_name, s.color AS subject_color
  FROM study_topics t
  JOIN study_materials m ON m.id = t.material_id
  LEFT JOIN study_subjects s ON s.id = m.subject_id`;

const toTopic = (r: TopicRow): StudyTopic => ({
  id: r.id, materialId: r.material_id, title: r.title, learnedAt: r.learned_at, dueAt: r.due_at,
  intervalDays: r.interval_days, ease: r.ease, repetitions: r.repetitions, lapses: r.lapses,
  lastReviewedAt: r.last_reviewed_at, suspended: r.suspended === 1, createdAt: r.created_at,
  materialTitle: r.material_title, materialKind: r.material_kind, subjectId: r.subject_id,
  subjectName: r.subject_name, subjectColor: r.subject_color,
});

export interface NewReview {
  topicId: string;
  reviewedAt: number;
  rating: number;
  intervalBefore: number;
  intervalAfter: number;
  easeAfter: number;
  repetitions: number;
  lapses: number;
  dueAt: number;
}

export interface StudyRepository {
  createSubject(input: SubjectInput): Promise<StudySubject>;
  listSubjects(): Promise<StudySubject[]>;
  deleteSubject(id: string): Promise<boolean>;

  createMaterial(input: MaterialInput): Promise<StudyMaterial>;
  listMaterials(): Promise<StudyMaterial[]>;
  deleteMaterial(id: string): Promise<boolean>;

  /** Adds topics learned at `learnedAt`; the first review is due at `firstDueAt`. Returns the created topics. */
  addTopics(materialId: string, titles: string[], learnedAt: number, firstDueAt: number): Promise<StudyTopic[]>;
  getTopic(id: string): Promise<StudyTopic | null>;
  listTopics(filter?: { materialId?: string }): Promise<StudyTopic[]>;
  setSuspended(id: string, suspended: boolean): Promise<boolean>;
  deleteTopic(id: string): Promise<boolean>;

  /** Saves a finished review: updates the topic's schedule and writes the history row, atomically. */
  saveReview(review: NewReview): Promise<StudyTopic | null>;
  listReviews(topicId: string): Promise<StudyReview[]>;
  countReviewsSince(since: number): Promise<number>;
  /** Ratings of all reviews since a date (for progress and advice). */
  listReviewsSince(since: number): Promise<{ reviewedAt: number; rating: number }[]>;
}

export function createStudyRepository(db: DbClient, options: { now?: () => number } = {}): StudyRepository {
  const now = options.now ?? (() => Date.now());

  async function getTopic(id: string): Promise<StudyTopic | null> {
    const row = await db.getFirstAsync<TopicRow>(`${TOPIC_SELECT} WHERE t.id = ?`, [id]);
    return row ? toTopic(row) : null;
  }

  return {
    getTopic,

    async createSubject(raw) {
      const input = subjectInputSchema.parse(raw);
      const id = newId();
      const createdAt = now();
      await db.runAsync('INSERT INTO study_subjects (id, name, color, created_at) VALUES (?, ?, ?, ?)',
        [id, input.name, input.color, createdAt]);
      return { id, name: input.name, color: input.color, createdAt };
    },

    async listSubjects() {
      const rows = await db.getAllAsync<{ id: string; name: string; color: string; created_at: number }>(
        'SELECT * FROM study_subjects ORDER BY created_at, name');
      return rows.map((r) => ({ id: r.id, name: r.name, color: r.color, createdAt: r.created_at }));
    },

    async deleteSubject(id) {
      const res = await db.runAsync('DELETE FROM study_subjects WHERE id = ?', [id]); // materials keep existing, without a subject
      return res.changes > 0;
    },

    async createMaterial(raw) {
      const input = materialInputSchema.parse(raw);
      const id = newId();
      const createdAt = now();
      await db.runAsync(
        'INSERT INTO study_materials (id, subject_id, kind, title, created_at) VALUES (?, ?, ?, ?, ?)',
        [id, input.subjectId ?? null, input.kind, input.title, createdAt]);
      return { id, subjectId: input.subjectId ?? null, kind: input.kind, title: input.title, createdAt, topicCount: 0 };
    },

    async listMaterials() {
      const rows = await db.getAllAsync<{
        id: string; subject_id: string | null; kind: MaterialKind; title: string; created_at: number; topic_count: number;
      }>(`SELECT m.*, (SELECT COUNT(*) FROM study_topics t WHERE t.material_id = m.id) AS topic_count
          FROM study_materials m ORDER BY m.created_at DESC, m.title`);
      return rows.map((r) => ({
        id: r.id, subjectId: r.subject_id, kind: r.kind, title: r.title, createdAt: r.created_at, topicCount: r.topic_count,
      }));
    },

    async deleteMaterial(id) {
      const res = await db.runAsync('DELETE FROM study_materials WHERE id = ?', [id]); // cascades topics and reviews
      return res.changes > 0;
    },

    async addTopics(materialId, titles, learnedAt, firstDueAt) {
      const clean = titles.map((t) => topicTitleSchema.parse(t));
      const ids: string[] = [];
      await db.withTransactionAsync(async () => {
        for (const title of clean) {
          const id = newId();
          ids.push(id);
          await db.runAsync(
            `INSERT INTO study_topics (id, material_id, title, learned_at, due_at, created_at)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [id, materialId, title, learnedAt, firstDueAt, now()]);
        }
      });
      const out: StudyTopic[] = [];
      for (const id of ids) {
        const t = await getTopic(id);
        if (t) out.push(t);
      }
      return out;
    },

    async listTopics(filter = {}) {
      const params: SqlParam[] = [];
      let sql = TOPIC_SELECT;
      if (filter.materialId !== undefined) {
        sql += ' WHERE t.material_id = ?';
        params.push(filter.materialId);
      }
      sql += ' ORDER BY t.due_at, t.created_at, t.id';
      return (await db.getAllAsync<TopicRow>(sql, params)).map(toTopic);
    },

    async setSuspended(id, suspended) {
      const res = await db.runAsync('UPDATE study_topics SET suspended = ? WHERE id = ?', [suspended ? 1 : 0, id]);
      return res.changes > 0;
    },

    async deleteTopic(id) {
      const res = await db.runAsync('DELETE FROM study_topics WHERE id = ?', [id]);
      return res.changes > 0;
    },

    async saveReview(r) {
      const existing = await db.getFirstAsync<{ id: string }>('SELECT id FROM study_topics WHERE id = ?', [r.topicId]);
      if (!existing) return null;
      await db.withTransactionAsync(async () => {
        await db.runAsync(
          `UPDATE study_topics SET interval_days = ?, ease = ?, repetitions = ?, lapses = ?, due_at = ?, last_reviewed_at = ?
           WHERE id = ?`,
          [r.intervalAfter, r.easeAfter, r.repetitions, r.lapses, r.dueAt, r.reviewedAt, r.topicId]);
        await db.runAsync(
          `INSERT INTO study_reviews (id, topic_id, reviewed_at, rating, interval_before, interval_after, ease_after)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [newId(), r.topicId, r.reviewedAt, r.rating, r.intervalBefore, r.intervalAfter, r.easeAfter]);
      });
      return getTopic(r.topicId);
    },

    async listReviews(topicId) {
      const rows = await db.getAllAsync<{
        id: string; topic_id: string; reviewed_at: number; rating: number; interval_before: number;
        interval_after: number; ease_after: number;
      }>('SELECT * FROM study_reviews WHERE topic_id = ? ORDER BY reviewed_at, id', [topicId]);
      return rows.map((r) => ({
        id: r.id, topicId: r.topic_id, reviewedAt: r.reviewed_at, rating: r.rating,
        intervalBefore: r.interval_before, intervalAfter: r.interval_after, easeAfter: r.ease_after,
      }));
    },

    async listReviewsSince(since) {
      const rows = await db.getAllAsync<{ reviewed_at: number; rating: number }>(
        'SELECT reviewed_at, rating FROM study_reviews WHERE reviewed_at >= ? ORDER BY reviewed_at', [since]);
      return rows.map((x) => ({ reviewedAt: x.reviewed_at, rating: x.rating }));
    },

    async countReviewsSince(since) {
      const row = await db.getFirstAsync<{ n: number }>('SELECT COUNT(*) AS n FROM study_reviews WHERE reviewed_at >= ?', [since]);
      return row?.n ?? 0;
    },
  };
}
