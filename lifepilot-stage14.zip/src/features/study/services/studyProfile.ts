export const STUDY_PROFILE_KEY = 'study_profile';

export type Chronotype = 'morning' | 'afternoon' | 'evening' | 'night';

export const CHRONOTYPES: Chronotype[] = ['morning', 'afternoon', 'evening', 'night'];
export const CHRONOTYPE_LABELS: Record<Chronotype, string> = {
  morning: 'صبح‌ها',
  afternoon: 'بعدازظهرها',
  evening: 'عصر و شب‌ها',
  night: 'آخر شب',
};
/** The hour (24h) at which the daily review is suggested for each choice. */
export const CHRONOTYPE_HOURS: Record<Chronotype, number> = { morning: 8, afternoon: 15, evening: 19, night: 21 };

export const SESSION_OPTIONS = [25, 35, 45, 60] as const;
export const DAILY_OPTIONS = [30, 60, 90, 120, 180] as const;

/** What the student tells us about their own routine. Nothing here is a personality label. */
export interface StudyProfile {
  chronotype: Chronotype;
  /** Length of one focused session (minutes), followed by a short break. */
  sessionMinutes: number;
  /** Minutes per day available for reviewing. */
  dailyMinutes: number;
  /** Daily notification when reviews are due. */
  remindersOn: boolean;
}

export const DEFAULT_STUDY_PROFILE: StudyProfile = {
  chronotype: 'evening',
  sessionMinutes: 35,
  dailyMinutes: 90,
  remindersOn: false,
};

export function parseStudyProfile(raw: string | null): StudyProfile {
  if (!raw) return DEFAULT_STUDY_PROFILE;
  try {
    const o = JSON.parse(raw) as Record<string, unknown>;
    return {
      chronotype: CHRONOTYPES.find((c) => c === o.chronotype) ?? DEFAULT_STUDY_PROFILE.chronotype,
      sessionMinutes: SESSION_OPTIONS.find((s) => s === o.sessionMinutes) ?? DEFAULT_STUDY_PROFILE.sessionMinutes,
      dailyMinutes: DAILY_OPTIONS.find((d) => d === o.dailyMinutes) ?? DEFAULT_STUDY_PROFILE.dailyMinutes,
      remindersOn: o.remindersOn === true,
    };
  } catch {
    return DEFAULT_STUDY_PROFILE;
  }
}

export function serializeStudyProfile(p: StudyProfile): string {
  return JSON.stringify(p);
}
