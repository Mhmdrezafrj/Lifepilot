import { addDays, localDayNumber, startOfDay } from '../../../core/calendar/dates';
import { toPersianDigits } from '../../../core/calendar/format';
import { CHRONOTYPE_HOURS, StudyProfile } from './studyProfile';
import { QueueTopic, forecast } from './reviewQueue';

/** Rough time for one self-test review. */
export const MINUTES_PER_REVIEW = 3;

export interface PlanDay {
  /** Start of the day (ms). */
  date: number;
  count: number;
  minutes: number;
  /** Focus sessions of the chosen length needed for the day. */
  sessions: number;
  /** More minutes needed than the student said is available. */
  overloaded: boolean;
  startHour: number;
}

/** The next 7 days: how many reviews, how long, how many sessions, and when to start. */
export function buildWeeklyPlan(topics: QueueTopic[], profile: StudyProfile, now: number): PlanDay[] {
  const today = startOfDay(new Date(now));
  return forecast(topics, now, 7).map((count, i) => {
    const minutes = count * MINUTES_PER_REVIEW;
    return {
      date: addDays(today, i).getTime(),
      count,
      minutes,
      sessions: minutes === 0 ? 0 : Math.ceil(minutes / profile.sessionMinutes),
      overloaded: minutes > profile.dailyMinutes,
      startHour: CHRONOTYPE_HOURS[profile.chronotype],
    };
  });
}

/** Topics the student struggles with most (forgotten often or low ease), worst first. */
export function weakestTopics<T extends { id: string; ease: number; lapses: number; suspended: boolean }>(
  topics: T[],
  limit = 5,
): T[] {
  return topics
    .filter((t) => !t.suspended && (t.lapses > 0 || t.ease < 2.3))
    .sort((a, b) => b.lapses - a.lapses || a.ease - b.ease || a.id.localeCompare(b.id))
    .slice(0, limit);
}

export interface StudyStats {
  totalReviews: number;
  reviewsLast7: number;
  /** Share (0..1) of the last 14 days' reviews answered "good" or "easy"; null with fewer than 5 reviews. */
  recallRate: number | null;
  /** Days in a row with at least one review (today may still be pending). */
  streakDays: number;
}

export function studyStats(reviews: { reviewedAt: number; rating: number }[], now: number): StudyStats {
  const today = localDayNumber(new Date(now));
  const days = new Set(reviews.map((r) => localDayNumber(new Date(r.reviewedAt))));
  let streak = 0;
  for (let d = days.has(today) ? today : today - 1; days.has(d); d--) streak++;

  const last14 = reviews.filter((r) => today - localDayNumber(new Date(r.reviewedAt)) < 14);
  return {
    totalReviews: reviews.length,
    reviewsLast7: reviews.filter((r) => today - localDayNumber(new Date(r.reviewedAt)) < 7).length,
    recallRate: last14.length < 5 ? null : last14.filter((r) => r.rating >= 2).length / last14.length,
    streakDays: streak,
  };
}

export interface AdviceInput {
  stats: StudyStats;
  plan: PlanDay[];
  profile: StudyProfile;
  /** Days until the exam, or null when no exam date is set. */
  examDays: number | null;
  topicCount: number;
  weakCount: number;
}

/**
 * Tips based only on the student's own numbers (recall rate, workload, exam distance).
 * Evidence-based generic habits are used; no personality typing.
 */
export function buildAdvice(i: AdviceInput): string[] {
  const tips: string[] = [];
  if (i.topicCount === 0) return ['ابتدا مباحثی را که یاد گرفته‌اید ثبت کنید تا برنامه‌ی مرور ساخته شود.'];

  const heavy = i.plan.filter((d) => d.overloaded);
  if (i.stats.recallRate === null) {
    tips.push('هنوز داده‌ی کافی برای شخصی‌سازی نیست. چند روز مرور کنید؛ برنامه با نتیجه‌ی واقعی شما دقیق‌تر می‌شود.');
  } else if (i.stats.recallRate < 0.6) {
    tips.push(
      `${toPersianDigits(Math.round((1 - i.stats.recallRate) * 100))}٪ مرورهای اخیرتان سخت یا فراموش‌شده بوده. قبل از نگاه‌کردن به کتاب، حتماً از حفظ بگویید یا بنویسید و مباحث ضعیف را در جلسه‌های کوتاه‌تر ولی بیشتر ببینید.`,
    );
  } else if (i.stats.recallRate >= 0.9) {
    tips.push('بیشتر مرورها برایتان آسان است؛ فاصله‌ها خودکار بلندتر می‌شوند. می‌توانید زمان بیشتری را به یادگیری مباحث جدید بدهید.');
  }

  if (heavy.length > 0) {
    tips.push(
      `${toPersianDigits(heavy.length)} روز از هفته بیش از ${toPersianDigits(i.profile.dailyMinutes)} دقیقه مرور دارد. مرور را در جلسه‌های ${toPersianDigits(i.profile.sessionMinutes)} دقیقه‌ای با استراحت کوتاه تقسیم کنید و آن روزها مبحث جدید کمتر ثبت کنید.`,
    );
  }
  if (i.examDays !== null && i.examDays >= 0 && i.examDays <= 30) {
    tips.push(`تا کنکور ${toPersianDigits(i.examDays)} روز مانده؛ فاصله‌ی مرورها کوتاه شده است. روی مباحث ضعیف تمرکز کنید و آزمون کامل بدهید.`);
  }
  if (i.weakCount > 0) {
    tips.push(`${toPersianDigits(i.weakCount)} مبحث ضعیف دارید (زیاد فراموش‌شده). در فهرست زیر هستند؛ برایشان خلاصه‌ی خودتان را بنویسید و با مثال تمرین کنید.`);
  }
  if (i.stats.streakDays >= 3) tips.push(`${toPersianDigits(i.stats.streakDays)} روز پشت‌سرهم مرور کرده‌اید؛ ادامه دهید.`);
  else if (i.stats.streakDays === 0 && i.stats.totalReviews > 0) tips.push('امروز یک مرور کوتاه انجام دهید تا ریتم حفظ شود.');
  return tips;
}

export interface StudyReminderItem {
  id: string;
  fireAt: number;
  count: number;
}

/** One reminder per upcoming day that has reviews, at the student's chosen hour. Empty when reminders are off. */
export function planStudyReminders(counts: number[], profile: StudyProfile, now: number): StudyReminderItem[] {
  if (!profile.remindersOn) return [];
  const today = startOfDay(new Date(now));
  const hour = CHRONOTYPE_HOURS[profile.chronotype];
  const out: StudyReminderItem[] = [];
  counts.forEach((count, i) => {
    if (count <= 0) return;
    const day = addDays(today, i);
    const fireAt = new Date(day.getFullYear(), day.getMonth(), day.getDate(), hour, 0).getTime();
    if (fireAt > now) out.push({ id: `study-${localDayNumber(day)}`, fireAt, count });
  });
  return out;
}
