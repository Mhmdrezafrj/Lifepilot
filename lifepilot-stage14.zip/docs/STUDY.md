# Study planner (konkur)

Data: `study_subjects`, `study_materials` (book / video / other), `study_topics` (what was learned, with its review state),
`study_reviews` (history of every self-test).

Method (best-supported by research): **spaced repetition** + **retrieval practice** (self-testing) + **interleaving** (mixing subjects).
- A topic learned today is reviewed tomorrow. After each self-test the student rates it: فراموش کردم / سخت بود / خوب بود / آسان بود.
- Good answers give 3, 7, then ~18, 45 … days; forgetting resets to 1 day and lowers the "ease" (so weak topics come back more often).
- With an exam date, gaps are capped so each topic is still reviewed about 3 more times before the exam.
- The daily queue is ordered by lateness and weak memory, and subjects are mixed.

Personalisation (stage 14) uses only what the student states and their own results:
- Study settings: exam date, best time of day (sets the suggested start hour and the reminder hour), focus-session length, minutes available per day.
- Weekly plan: reviews, minutes, sessions (Pomodoro) per day; heavy days flagged.
- Progress: reviews in 7 days, recall rate over 14 days, streak. Advice is generated from these numbers.
- Daily "time to review" notification: scheduled for the next 7 days whenever the app opens or data changes (only days with reviews).

Not claimed: "learning styles" and personality-matched plans are not well supported by research, so they are not used.
Limits: minutes per review is a fixed estimate (3 min); reminders stop if the app is not opened for a week.
