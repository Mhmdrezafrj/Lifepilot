import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { CaptureSheet } from '@/features/capture/components/QuickCapture';

/** Opened from the widgets ("+"): the quick capture sheet, nothing else. */
export default function CaptureScreen() {
  const router = useRouter();
  return (
    <View style={{ flex: 1 }}>
      <CaptureSheet visible onClose={() => (router.canGoBack() ? router.back() : router.replace('/(tabs)'))} />
    </View>
  );
}
