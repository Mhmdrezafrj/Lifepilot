import { Screen } from '@/shared/components/Screen';
import { Card } from '@/shared/components/Card';
import { AppText } from '@/shared/components/AppText';

export default function CalendarScreen() {
  return (
    <Screen title="تقویم">
      <Card variant="outlined">
        <AppText muted>تقویم شمسی (روز، هفته، ماه) هنوز پیاده‌سازی نشده است. مرحله ۶.</AppText>
      </Card>
    </Screen>
  );
}
