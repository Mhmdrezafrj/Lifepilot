import { I18nManager } from 'react-native';
import { Screen } from '@/shared/components/Screen';
import { Card } from '@/shared/components/Card';
import { AppText } from '@/shared/components/AppText';

export default function HomeScreen() {
  return (
    <Screen title="لایف‌پایلوت">
      <Card>
        <AppText variant="heading">پروژه آماده است ✅</AppText>
        <AppText muted>
          سیستم طراحی (رنگ، تایپوگرافی، تم و کامپوننت‌ها) اضافه شد. داشبورد واقعی (تسک‌ها و آمار) در مرحله ۵ می‌آید.
        </AppText>
      </Card>
      <Card variant="outlined">
        <AppText variant="bodyStrong">بررسی فنی (برای تست روی گوشی)</AppText>
        <AppText muted>جهت راست‌به‌چپ: {I18nManager.isRTL ? 'فعال ✅' : 'غیرفعال ❌'}</AppText>
        <AppText muted>فونت وزیرمتن: این متن با وزیرمتن نوشته شده است. Latin text: Vazirmatn 123</AppText>
      </Card>
    </Screen>
  );
}
