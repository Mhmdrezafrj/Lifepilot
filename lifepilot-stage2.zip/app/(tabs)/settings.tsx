import Constants from 'expo-constants';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { View } from 'react-native';
import { Screen } from '@/shared/components/Screen';
import { Card } from '@/shared/components/Card';
import { AppText } from '@/shared/components/AppText';
import { useTheme } from '@/core/theme/useTheme';

export default function SettingsScreen() {
  const router = useRouter();
  const { colors, iconSizes, spacing } = useTheme();
  return (
    <Screen title="تنظیمات">
      <Card variant="outlined">
        <AppText variant="bodyStrong">درباره</AppText>
        <AppText muted>نسخه برنامه: {Constants.expoConfig?.version ?? '—'}</AppText>
        <AppText muted>شناسه بسته: com.lifepilot.personalassistant</AppText>
      </Card>
      <Card onPress={() => router.push('/design-showcase')} accessibilityLabel="نمایشگاه طراحی">
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
          <Ionicons name="color-palette-outline" size={iconSizes.lg} color={colors.accent} />
          <View style={{ flex: 1 }}>
            <AppText variant="bodyStrong">نمایشگاه طراحی (ابزار توسعه)</AppText>
            <AppText variant="caption" muted>پیش‌نمایش تم، رنگ و کامپوننت‌ها</AppText>
          </View>
        </View>
      </Card>
      <Card variant="outlined">
        <AppText muted>گزینه‌های ظاهر، اعلان و حریم خصوصی در مرحله ۷ اضافه می‌شوند.</AppText>
      </Card>
    </Screen>
  );
}
