import { useState } from 'react';
import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { useTheme, useThemeSettings } from '@/core/theme/useTheme';
import { AccentKey, ThemeMode, accents } from '@/core/theme/colors';
import { FontSizeKey, TextVariant, fontScales } from '@/core/theme/typography';
import { Screen } from '@/shared/components/Screen';
import { Card } from '@/shared/components/Card';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Chip } from '@/shared/components/Chip';
import { Badge } from '@/shared/components/Badge';
import { TextField } from '@/shared/components/TextField';
import { SegmentedControl } from '@/shared/components/SegmentedControl';
import { EmptyState } from '@/shared/components/EmptyState';
import { IconButton } from '@/shared/components/IconButton';
import { Divider } from '@/shared/components/Divider';

const modeOptions: { value: ThemeMode; label: string }[] = [
  { value: 'light', label: 'روشن' },
  { value: 'dark', label: 'تیره' },
  { value: 'system', label: 'سیستم' },
];

const variants: { v: TextVariant; label: string }[] = [
  { v: 'display', label: 'عنوان بزرگ' },
  { v: 'title', label: 'عنوان صفحه' },
  { v: 'heading', label: 'سرتیتر بخش' },
  { v: 'body', label: 'متن معمولی برای توضیحات' },
  { v: 'bodyStrong', label: 'متن پررنگ‌تر' },
  { v: 'label', label: 'برچسب' },
  { v: 'caption', label: 'متن کوچک Caption 123' },
];

export default function DesignShowcase() {
  const router = useRouter();
  const theme = useTheme();
  const { colors, spacing, radii } = theme;
  const { mode, setMode, accent, setAccent, fontSize, setFontSize } = useThemeSettings();
  const [text, setText] = useState('');
  const [chip, setChip] = useState(true);

  const sizeOptions = (Object.keys(fontScales) as FontSizeKey[]).map((k) => ({ value: k, label: fontScales[k].label }));

  return (
    <Screen
      title="نمایشگاه طراحی"
      subtitle="تغییرات فقط تا بستن برنامه می‌مانند؛ ذخیره‌ی دائمی در مرحله ۷ است"
      onBack={() => router.back()}
    >
      <Card>
        <AppText variant="heading">ظاهر</AppText>
        <SegmentedControl options={modeOptions} value={mode} onChange={setMode} />
        <AppText variant="label" muted>رنگ اصلی</AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          {(Object.keys(accents) as AccentKey[]).map((k) => (
            <Chip key={k} label={accents[k].label} selected={accent === k} color={accents[k][theme.scheme]} onPress={() => setAccent(k)} />
          ))}
        </View>
        <AppText variant="label" muted>اندازه‌ی متن</AppText>
        <SegmentedControl options={sizeOptions} value={fontSize} onChange={setFontSize} />
      </Card>

      <Card>
        <AppText variant="heading">تایپوگرافی</AppText>
        {variants.map(({ v, label }) => (
          <AppText key={v} variant={v}>{label}</AppText>
        ))}
      </Card>

      <Card>
        <AppText variant="heading">دکمه‌ها</AppText>
        <Button title="اصلی" icon="add" onPress={() => {}} />
        <Button title="ثانویه" variant="secondary" onPress={() => {}} />
        <Button title="حاشیه‌دار" variant="ghost" onPress={() => {}} />
        <Button title="حذف" variant="danger" icon="trash-outline" onPress={() => {}} />
        <Button title="در حال بارگذاری" loading onPress={() => {}} />
        <Button title="غیرفعال" disabled onPress={() => {}} />
        <View style={{ flexDirection: 'row', gap: spacing.sm }}>
          <IconButton icon="mic-outline" variant="filled" accessibilityLabel="میکروفون" onPress={() => {}} />
          <IconButton icon="notifications-outline" accessibilityLabel="اعلان" onPress={() => {}} />
        </View>
      </Card>

      <Card>
        <AppText variant="heading">چیپ و نشان</AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          <Chip label="کار" icon="briefcase-outline" selected={chip} onPress={() => setChip(!chip)} />
          <Chip label="شخصی" icon="person-outline" selected={!chip} onPress={() => setChip(!chip)} />
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          <Badge label="کم" color={colors.priority.low} />
          <Badge label="متوسط" color={colors.priority.medium} />
          <Badge label="زیاد" color={colors.priority.high} />
          <Badge label="بحرانی" color={colors.priority.critical} />
        </View>
      </Card>

      <Card>
        <AppText variant="heading">ورودی متن</AppText>
        <TextField label="عنوان" placeholder="مثلاً: خرید نان" value={text} onChangeText={setText} />
        <TextField label="توضیحات" placeholder="اختیاری" multiline helper="این یک متن راهنما است" />
        <TextField label="با خطا" error="این فیلد الزامی است" defaultValue="" />
      </Card>

      <Card variant="flat">
        <AppText variant="heading">رنگ‌ها</AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          {[colors.accent, colors.success, colors.warning, colors.danger, colors.info, colors.surface, colors.surfaceAlt, colors.border].map((c, i) => (
            <View key={i} style={{ width: 40, height: 40, borderRadius: radii.md, backgroundColor: c, borderWidth: 1, borderColor: colors.border }} />
          ))}
        </View>
        <Divider />
        <AppText variant="caption" muted>کارت تخت (flat) / برجسته (elevated) / حاشیه‌دار (outlined)</AppText>
      </Card>

      <Card variant="outlined">
        <EmptyState
          icon="checkmark-done-outline"
          title="هنوز کاری ندارید"
          description="نمونه‌ی حالت خالی. اولین کار خود را بسازید."
          actionLabel="افزودن کار"
          onAction={() => {}}
        />
      </Card>
    </Screen>
  );
}
