import { ReactNode } from 'react';
import { Pressable, StyleProp, View, ViewStyle } from 'react-native';
import { useTheme } from '@/core/theme/useTheme';

interface Props {
  children: ReactNode;
  variant?: 'elevated' | 'outlined' | 'flat';
  onPress?: () => void;
  accessibilityLabel?: string;
  style?: StyleProp<ViewStyle>;
}

export function Card({ children, variant = 'elevated', onPress, accessibilityLabel, style }: Props) {
  const { colors, radii, spacing, elevation, isDark } = useTheme();

  const base: ViewStyle = {
    backgroundColor: variant === 'flat' ? colors.surfaceAlt : colors.surface,
    borderRadius: radii.lg,
    padding: spacing.lg,
    gap: spacing.sm,
    ...(variant === 'outlined' || (variant === 'elevated' && isDark)
      ? { borderWidth: 1, borderColor: colors.border }
      : {}),
    ...(variant === 'elevated' ? elevation.sm : {}),
  };

  if (onPress) {
    return (
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={accessibilityLabel}
        onPress={onPress}
        style={({ pressed }) => [base, pressed && { opacity: 0.85 }, style]}
      >
        {children}
      </Pressable>
    );
  }
  return <View style={[base, style]}>{children}</View>;
}
