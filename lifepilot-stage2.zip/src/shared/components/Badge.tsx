import { View } from 'react-native';
import { useTheme } from '@/core/theme/useTheme';
import { withAlpha } from '@/core/theme/colors';
import { AppText } from './AppText';

export function Badge({ label, color }: { label: string; color?: string }) {
  const { colors, radii, spacing } = useTheme();
  const c = color ?? colors.accent;
  return (
    <View
      style={{
        alignSelf: 'flex-start',
        paddingHorizontal: spacing.md,
        paddingVertical: 2,
        borderRadius: radii.pill,
        backgroundColor: withAlpha(c, 0.16),
      }}
    >
      <AppText variant="caption" style={{ color: c }}>{label}</AppText>
    </View>
  );
}
