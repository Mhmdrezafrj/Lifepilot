import { Pressable, View } from 'react-native';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from './AppText';

interface Props<T extends string> {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}

export function SegmentedControl<T extends string>({ options, value, onChange }: Props<T>) {
  const { colors, radii, spacing, elevation } = useTheme();
  return (
    <View
      style={{
        flexDirection: 'row',
        backgroundColor: colors.surfaceAlt,
        borderRadius: radii.md,
        padding: 4,
        gap: 4,
      }}
    >
      {options.map((o) => {
        const selected = o.value === value;
        return (
          <Pressable
            key={o.value}
            accessibilityRole="button"
            accessibilityState={{ selected }}
            onPress={() => onChange(o.value)}
            style={[
              {
                flex: 1,
                minHeight: 40,
                borderRadius: radii.sm,
                alignItems: 'center',
                justifyContent: 'center',
                paddingHorizontal: spacing.xs,
              },
              selected && { backgroundColor: colors.surface, ...elevation.sm },
            ]}
          >
            <AppText variant="label" color={selected ? 'accent' : 'textMuted'}>{o.label}</AppText>
          </Pressable>
        );
      })}
    </View>
  );
}
