import { ReactNode } from 'react';
import { I18nManager, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from './AppText';
import { IconButton } from './IconButton';

interface Props {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  children: ReactNode;
}

export function Screen({ title, subtitle, onBack, children }: Props) {
  const { colors, spacing } = useTheme();
  const insets = useSafeAreaInsets();
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.bg }}
      contentContainerStyle={{
        paddingTop: insets.top + spacing.lg,
        paddingBottom: insets.bottom + spacing.xxxl,
        paddingHorizontal: spacing.xl,
        gap: spacing.lg,
      }}
      keyboardShouldPersistTaps="handled"
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
        {onBack ? (
          <IconButton
            icon={I18nManager.isRTL ? 'arrow-forward' : 'arrow-back'}
            onPress={onBack}
            accessibilityLabel="بازگشت"
            variant="filled"
          />
        ) : null}
        <View style={{ flex: 1 }}>
          <AppText variant="title">{title}</AppText>
          {subtitle ? <AppText muted variant="label">{subtitle}</AppText> : null}
        </View>
      </View>
      {children}
    </ScrollView>
  );
}
