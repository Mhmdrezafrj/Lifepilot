import { Text, TextProps } from 'react-native';
import { useTheme } from '@/core/theme/useTheme';
import { TextVariant } from '@/core/theme/typography';

export type TextColorKey = 'text' | 'textMuted' | 'accent' | 'success' | 'warning' | 'danger' | 'textOnAccent';

interface Props extends TextProps {
  variant?: TextVariant;
  muted?: boolean;
  color?: TextColorKey;
}

export function AppText({ variant = 'body', muted, color, style, ...rest }: Props) {
  const theme = useTheme();
  const c = theme.colors[color ?? (muted ? 'textMuted' : 'text')];
  return (
    <Text
      {...rest}
      style={[theme.text(variant), { color: c, textAlign: 'left', writingDirection: 'rtl' }, style]}
    />
  );
}
