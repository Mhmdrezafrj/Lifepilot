import { useState } from 'react';
import { TextInput, TextInputProps, View } from 'react-native';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from './AppText';

interface Props extends TextInputProps {
  label?: string;
  error?: string;
  helper?: string;
}

export function TextField({ label, error, helper, multiline, style, onFocus, onBlur, ...rest }: Props) {
  const theme = useTheme();
  const { colors, radii, spacing } = theme;
  const [focused, setFocused] = useState(false);

  const borderColor = error ? colors.danger : focused ? colors.accent : colors.border;

  return (
    <View style={{ gap: spacing.xs }}>
      {label ? <AppText variant="label" muted>{label}</AppText> : null}
      <TextInput
        {...rest}
        multiline={multiline}
        accessibilityLabel={rest.accessibilityLabel ?? label}
        placeholderTextColor={colors.textMuted}
        selectionColor={colors.accent}
        onFocus={(e) => {
          setFocused(true);
          onFocus?.(e);
        }}
        onBlur={(e) => {
          setFocused(false);
          onBlur?.(e);
        }}
        style={[
          theme.text('body'),
          {
            color: colors.text,
            backgroundColor: colors.surface,
            borderWidth: 1.5,
            borderColor,
            borderRadius: radii.md,
            paddingHorizontal: spacing.lg,
            paddingVertical: spacing.md,
            minHeight: multiline ? 104 : 48,
            textAlignVertical: multiline ? 'top' : 'center',
          },
          style,
        ]}
      />
      {error ? (
        <AppText variant="caption" color="danger">{error}</AppText>
      ) : helper ? (
        <AppText variant="caption" muted>{helper}</AppText>
      ) : null}
    </View>
  );
}
