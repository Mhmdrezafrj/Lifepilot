import { Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/core/theme/useTheme';
import { IconName } from '@/shared/types/icon';

interface Props {
  icon: IconName;
  onPress: () => void;
  accessibilityLabel: string;
  variant?: 'plain' | 'filled';
  color?: string;
}

export function IconButton({ icon, onPress, accessibilityLabel, variant = 'plain', color }: Props) {
  const { colors, radii, iconSizes, touchTarget } = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      onPress={onPress}
      hitSlop={6}
      style={({ pressed }) => ({
        width: touchTarget,
        height: touchTarget,
        borderRadius: radii.pill,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: variant === 'filled' ? colors.surfaceAlt : 'transparent',
        opacity: pressed ? 0.7 : 1,
      })}
    >
      <Ionicons name={icon} size={iconSizes.lg} color={color ?? colors.text} />
    </Pressable>
  );
}
