// Kept for compatibility: InfoCard is now just an outlined Card.
import { ComponentProps } from 'react';
import { Card } from './Card';

export function InfoCard(props: Omit<ComponentProps<typeof Card>, 'variant'>) {
  return <Card variant="outlined" {...props} />;
}
