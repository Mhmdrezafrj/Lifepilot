import { Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/core/theme/useTheme';
import { IconName } from '@/shared/types/icon';
import { AppText } from './AppText';

interface Props {
  label: string;
  selected?: boolean;
  onPress?: () => void;
  icon?: IconName;
  /** Optional custom color (e.g. a category color). Defaults to the accent. */
  color?: string;
}

export function Chip({ label, selected, onPress, icon, color }: Props) {
  const { colors, radii, spacing, iconSizes } = useTheme();
  const active = color ?? colors.accent;
  const fg = selected ? colors.textOnAccent : colors.text;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: !!selected }}
      disabled={!onPress}
      onPress={onPress}
      style={({ pressed }) => ({
        minHeight: 38,
        paddingHorizontal: spacing.lg,
        borderRadius: radii.pill,
        flexDirection: 'row',
        alignItems: 'center',
        gap: spacing.xs,
        backgroundColor: selected ? active : colors.surfaceAlt,
        borderWidth: 1,
        borderColor: selected ? active : colors.border,
        opacity: pressed ? 0.8 : 1,
      })}
    >
      {icon ? <Ionicons name={icon} size={iconSizes.sm} color={fg} /> : null}
      <AppText variant="label" style={{ color: fg }}>{label}</AppText>
    </Pressable>
  );
}
