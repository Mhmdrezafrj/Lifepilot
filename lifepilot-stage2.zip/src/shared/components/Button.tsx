import { ActivityIndicator, Pressable } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/core/theme/useTheme';
import { IconName } from '@/shared/types/icon';
import { AppText } from './AppText';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

interface Props {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  icon?: IconName;
  loading?: boolean;
  disabled?: boolean;
  fullWidth?: boolean;
  accessibilityLabel?: string;
}

export function Button({
  title,
  onPress,
  variant = 'primary',
  size = 'md',
  icon,
  loading,
  disabled,
  fullWidth,
  accessibilityLabel,
}: Props) {
  const { colors, radii, spacing, iconSizes } = useTheme();
  const scale = useSharedValue(1);
  const animatedStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const isDisabled = !!(disabled || loading);

  const look = {
    primary: { bg: colors.accent, fg: colors.textOnAccent, border: 'transparent' },
    secondary: { bg: colors.accentSoft, fg: colors.accent, border: 'transparent' },
    ghost: { bg: 'transparent', fg: colors.accent, border: colors.border },
    danger: { bg: colors.danger, fg: '#FFFFFF', border: 'transparent' },
  }[variant];

  const minHeight = size === 'sm' ? 40 : size === 'lg' ? 56 : 48;

  return (
    <AnimatedPressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel ?? title}
      accessibilityState={{ disabled: isDisabled, busy: !!loading }}
      disabled={isDisabled}
      onPress={onPress}
      onPressIn={() => {
        scale.value = withSpring(0.97);
      }}
      onPressOut={() => {
        scale.value = withSpring(1);
      }}
      style={[
        {
          minHeight,
          paddingHorizontal: size === 'sm' ? spacing.lg : spacing.xl,
          borderRadius: radii.lg,
          backgroundColor: look.bg,
          borderWidth: 1,
          borderColor: look.border,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: spacing.sm,
          alignSelf: fullWidth ? 'stretch' : 'flex-start',
          opacity: isDisabled ? 0.5 : 1,
        },
        animatedStyle,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={look.fg} />
      ) : icon ? (
        <Ionicons name={icon} size={iconSizes.md} color={look.fg} />
      ) : null}
      <AppText variant="bodyStrong" style={{ color: look.fg }}>
        {title}
      </AppText>
    </AnimatedPressable>
  );
}
