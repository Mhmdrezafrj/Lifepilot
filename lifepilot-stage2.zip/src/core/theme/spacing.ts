import { ViewStyle } from 'react-native';

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 28, xxxl: 40 } as const;

export const radii = { sm: 8, md: 12, lg: 18, xl: 24, pill: 999 } as const;

export const iconSizes = { sm: 16, md: 20, lg: 24, xl: 32 } as const;

/** Minimum comfortable touch target (dp). */
export const touchTarget = 48;

export const elevation: Record<'none' | 'sm' | 'md' | 'lg', ViewStyle> = {
  none: {},
  sm: { shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 4, shadowOffset: { width: 0, height: 2 }, elevation: 2 },
  md: { shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 5 },
  lg: { shadowColor: '#000', shadowOpacity: 0.18, shadowRadius: 18, shadowOffset: { width: 0, height: 8 }, elevation: 10 },
};
