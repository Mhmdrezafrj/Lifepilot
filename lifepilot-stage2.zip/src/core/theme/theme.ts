import { TextStyle } from 'react-native';
import { AccentKey, ColorTokens, Scheme, buildColors } from './colors';
import { elevation, iconSizes, radii, spacing, touchTarget } from './spacing';
import { TextVariant, textVariants } from './typography';

export interface Theme {
  scheme: Scheme;
  isDark: boolean;
  colors: ColorTokens;
  spacing: typeof spacing;
  radii: typeof radii;
  elevation: typeof elevation;
  iconSizes: typeof iconSizes;
  touchTarget: number;
  fontScale: number;
  /** Text style (font, size, line height) for a typography variant, scaled by the user's font size setting. */
  text: (variant: TextVariant) => TextStyle;
}

export function createTheme(scheme: Scheme, accent: AccentKey, fontScale: number): Theme {
  return {
    scheme,
    isDark: scheme === 'dark',
    colors: buildColors(scheme, accent),
    spacing,
    radii,
    elevation,
    iconSizes,
    touchTarget,
    fontScale,
    text: (variant) => {
      const v = textVariants[variant];
      return {
        fontFamily: v.fontFamily,
        fontSize: Math.round(v.fontSize * fontScale),
        lineHeight: Math.round(v.lineHeight * fontScale),
      };
    },
  };
}
