export type ThemeMode = 'light' | 'dark' | 'system';
export type Scheme = 'light' | 'dark';
export type AccentKey = 'indigo' | 'teal' | 'rose' | 'amber' | 'emerald';
export type Priority = 'low' | 'medium' | 'high' | 'critical';

export const accents: Record<AccentKey, { label: string; light: string; dark: string }> = {
  indigo: { label: 'بنفش', light: '#4F46E5', dark: '#818CF8' },
  teal: { label: 'فیروزه‌ای', light: '#0F766E', dark: '#2DD4BF' },
  rose: { label: 'صورتی', light: '#BE123C', dark: '#FB7185' },
  amber: { label: 'کهربایی', light: '#B45309', dark: '#FBBF24' },
  emerald: { label: 'سبز', light: '#047857', dark: '#34D399' },
};

export interface ColorTokens {
  bg: string;
  surface: string;
  surfaceAlt: string;
  border: string;
  text: string;
  textMuted: string;
  textOnAccent: string;
  accent: string;
  accentSoft: string;
  success: string;
  warning: string;
  danger: string;
  info: string;
  overlay: string;
  priority: Record<Priority, string>;
}

/** Adds an alpha channel to a 6-digit hex color. alpha is 0..1 */
export function withAlpha(hex: string, alpha: number): string {
  const a = Math.round(Math.min(1, Math.max(0, alpha)) * 255)
    .toString(16)
    .padStart(2, '0');
  return `${hex}${a}`;
}

const light = {
  bg: '#F6F7FB',
  surface: '#FFFFFF',
  surfaceAlt: '#EEF0F6',
  border: '#E3E6EE',
  text: '#111827',
  textMuted: '#5B6475',
  success: '#15803D',
  warning: '#B45309',
  danger: '#DC2626',
  info: '#0369A1',
  overlay: 'rgba(15, 23, 42, 0.45)',
  priority: { low: '#64748B', medium: '#2563EB', high: '#D97706', critical: '#DC2626' },
};

const dark = {
  bg: '#0B1020',
  surface: '#151B2E',
  surfaceAlt: '#1E2640',
  border: '#2A3350',
  text: '#F3F4F6',
  textMuted: '#A3ABBD',
  success: '#4ADE80',
  warning: '#FBBF24',
  danger: '#F87171',
  info: '#38BDF8',
  overlay: 'rgba(0, 0, 0, 0.6)',
  priority: { low: '#94A3B8', medium: '#60A5FA', high: '#FBBF24', critical: '#F87171' },
};

export function buildColors(scheme: Scheme, accentKey: AccentKey): ColorTokens {
  const base = scheme === 'dark' ? dark : light;
  const accent = accents[accentKey][scheme];
  return {
    ...base,
    accent,
    accentSoft: withAlpha(accent, scheme === 'dark' ? 0.22 : 0.12),
    textOnAccent: scheme === 'dark' ? '#0B1020' : '#FFFFFF',
  };
}

/** Palette offered for category colors (stage 5). */
export const categoryPalette = [
  '#4F46E5', '#0EA5E9', '#14B8A6', '#22C55E',
  '#EAB308', '#F97316', '#EF4444', '#EC4899',
];
