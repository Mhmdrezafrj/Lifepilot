export const fontFamilies = {
  regular: 'Vazirmatn_400Regular',
  medium: 'Vazirmatn_500Medium',
  bold: 'Vazirmatn_700Bold',
} as const;

export type TextVariant = 'display' | 'title' | 'heading' | 'body' | 'bodyStrong' | 'label' | 'caption';

// Persian script needs generous line height (~1.6x).
export const textVariants: Record<TextVariant, { fontFamily: string; fontSize: number; lineHeight: number }> = {
  display: { fontFamily: fontFamilies.bold, fontSize: 32, lineHeight: 50 },
  title: { fontFamily: fontFamilies.bold, fontSize: 24, lineHeight: 38 },
  heading: { fontFamily: fontFamilies.bold, fontSize: 18, lineHeight: 30 },
  body: { fontFamily: fontFamilies.regular, fontSize: 15, lineHeight: 26 },
  bodyStrong: { fontFamily: fontFamilies.medium, fontSize: 15, lineHeight: 26 },
  label: { fontFamily: fontFamilies.medium, fontSize: 13, lineHeight: 22 },
  caption: { fontFamily: fontFamilies.regular, fontSize: 12, lineHeight: 20 },
};

export type FontSizeKey = 'small' | 'normal' | 'large' | 'xlarge';

export const fontScales: Record<FontSizeKey, { label: string; scale: number }> = {
  small: { label: 'کوچک', scale: 0.9 },
  normal: { label: 'معمولی', scale: 1 },
  large: { label: 'بزرگ', scale: 1.15 },
  xlarge: { label: 'خیلی بزرگ', scale: 1.3 },
};
