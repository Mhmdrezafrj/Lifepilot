// Deprecated: replaced by the design system (colors.ts, theme.ts). Intentionally empty.
export {};
