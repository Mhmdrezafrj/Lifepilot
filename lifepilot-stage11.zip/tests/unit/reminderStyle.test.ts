import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { parseReminderStyle, SETTING_KEYS } from '../../src/features/settings/services/settingsKeys';
import { emptyForm, formFromTask, formToInput } from '../../src/features/tasks/components/taskFormModel';
import type { Task } from '../../src/features/tasks/models/task';
import { planReminders } from '../../src/infrastructure/notifications/reminderPlanner';

describe('reminder style', () => {
  it('defaults to the alarm ring unless "notification" is saved', () => {
    assert.equal(parseReminderStyle(null), 'alarm');
    assert.equal(parseReminderStyle('alarm'), 'alarm');
    assert.equal(parseReminderStyle('weird'), 'alarm');
    assert.equal(parseReminderStyle('notification'), 'notification');
    assert.equal(SETTING_KEYS.reminderStyle, 'reminder_style');
  });

  it('the form sends the chosen style with every reminder', () => {
    const base = { ...emptyForm(new Date(2026, 10, 5)), title: 'x', time: { hour: 9, minute: 0 }, reminderOffsets: [0, 10] };
    assert.deepEqual(formToInput({ ...base, reminderChannel: 'alarm' }).reminders?.map((r) => r.channel), ['alarm', 'alarm']);
    assert.deepEqual(formToInput({ ...base, reminderChannel: 'notification' }).reminders?.map((r) => r.channel), ['notification', 'notification']);
  });

  it('editing a task keeps its style, and the planner passes it on', () => {
    const due = new Date(2026, 10, 5, 18, 0).getTime();
    const task: Task = {
      id: 't', title: 'x', description: null, dueAt: due, hasTime: true, priority: 'medium', categoryId: null,
      status: 'pending', snoozedUntil: null, createdAt: 0, updatedAt: 0, completedAt: null, recurrenceId: null,
      tags: [], checklist: [], recurrence: null,
      reminders: [{ id: 'r', taskId: 't', offsetMinutes: 0, channel: 'alarm', enabled: true, repeatIntervalMinutes: null, maxRepeats: null }],
    };
    assert.equal(formFromTask(task).reminderChannel, 'alarm');
    assert.equal(planReminders(task, new Date(2026, 10, 5, 12).getTime())[0].channel, 'alarm');
  });
});
