import { useCallback, useEffect, useState } from 'react';
import { useRepositories } from '@/providers/DatabaseProvider';
import type { ReminderChannel } from '@/features/tasks/models/task';
import {
  SETTING_KEYS, parseDefaultReminder, parseReminderStyle, serializeDefaultReminder,
} from '../services/settingsKeys';

/** Default reminder (minutes before the due time) pre-selected for new tasks. */
export function useDefaultReminder(): {
  offset: number | null;
  style: ReminderChannel;
  loaded: boolean;
  save: (offset: number | null) => Promise<void>;
  saveStyle: (style: ReminderChannel) => Promise<void>;
} {
  const { settings } = useRepositories();
  const [offset, setOffset] = useState<number | null>(null);
  const [style, setStyle] = useState<ReminderChannel>('alarm');
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    Promise.all([settings.get(SETTING_KEYS.defaultReminder), settings.get(SETTING_KEYS.reminderStyle)])
      .then(([raw, rawStyle]) => {
        if (!cancelled) {
          setOffset(parseDefaultReminder(raw));
          setStyle(parseReminderStyle(rawStyle));
          setLoaded(true);
        }
      })
      .catch(() => {
        if (!cancelled) setLoaded(true);
      });
    return () => {
      cancelled = true;
    };
  }, [settings]);

  const save = useCallback(
    async (value: number | null) => {
      await settings.set(SETTING_KEYS.defaultReminder, serializeDefaultReminder(value));
      setOffset(value);
    },
    [settings],
  );

  const saveStyle = useCallback(
    async (value: ReminderChannel) => {
      await settings.set(SETTING_KEYS.reminderStyle, value);
      setStyle(value);
    },
    [settings],
  );

  return { offset, style, loaded, save, saveStyle };
}
