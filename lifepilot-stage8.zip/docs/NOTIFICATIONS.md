# Reminders: what exists and what is next

## Exists in Phase 1 (tested, no delivery)
- Reminder settings are stored with each task (`reminders` table): offset, channel (notification | alarm), repeat interval, max repeats.
- `infrastructure/notifications/types.ts` defines `ReminderScheduler`, `NotificationGateway`, `AlarmGateway`.
- `reminderPlanner.ts` (pure) turns a task into concrete fire times.
- `reminderScheduler.ts` routes those times to the gateways and reports what was skipped and why.
- `unavailableGateways.ts`: the default gateways in this build. They say "unavailable" and refuse to schedule.
- `reminderRepository.ts` stores what happened to each reminder in `reminder_events` (scheduled / triggered / acknowledged).
- The task service already calls the scheduler on create / edit / complete / reopen / snooze / reschedule / duplicate / delete.

## NOT implemented (nothing is delivered today)
No notification, no alarm, no sound or vibration is ever produced by this build.
JavaScript timers and Expo background tasks are NOT used and must not be used for alarms (not reliable).

## Next phase: how to plug in real delivery
1. A native Kotlin module (Expo module via prebuild) implementing `AlarmGateway` with
   `AlarmManager.setExactAndAllowWhileIdle`, and `NotificationGateway` with `NotificationManager` + channels.
2. Android permissions: `POST_NOTIFICATIONS` (Android 13+), `SCHEDULE_EXACT_ALARM` / `USE_EXACT_ALARM`
   (exact alarms), `RECEIVE_BOOT_COMPLETED`, optionally `USE_FULL_SCREEN_INTENT` for alarm-style screens.
3. Receivers: BOOT_COMPLETED, TIMEZONE_CHANGED, TIME_SET, and `ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED`
   must call `rescheduleAll()` from the database (the database is the source of truth).
4. Notification actions (complete / snooze 10 min) write `reminder_events` and call the task service.
5. Test on real devices with Doze, battery optimization, and Chinese-ROM autostart restrictions (Xiaomi, Huawei, Oppo).
6. Pass the new gateways into `createServices(repos, { scheduler: createReminderScheduler({ notifications, alarms }) })`.
