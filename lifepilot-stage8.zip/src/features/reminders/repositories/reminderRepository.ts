import { z } from 'zod';
import type { DbClient, SqlParam } from '../../../core/database/connection/types';
import { newId } from '../../../core/utils/id';

export const REMINDER_ACTIONS = ['completed', 'snoozed', 'dismissed'] as const;
export type ReminderAction = (typeof REMINDER_ACTIONS)[number];

export const DELIVERY_STATUSES = ['scheduled', 'delivered', 'failed', 'missed'] as const;
export type DeliveryStatus = (typeof DELIVERY_STATUSES)[number];

export interface ReminderEvent {
  id: string;
  /** Null when the reminder itself was deleted (e.g. the task's reminders were edited). */
  reminderId: string | null;
  taskId: string;
  scheduledAt: number;
  triggeredAt: number | null;
  acknowledgedAt: number | null;
  action: ReminderAction | null;
  deliveryStatus: DeliveryStatus | null;
}

interface EventRow {
  id: string; reminder_id: string | null; task_id: string; scheduled_at: number;
  triggered_at: number | null; acknowledged_at: number | null; action: ReminderAction | null;
  delivery_status: DeliveryStatus | null;
}

const toEvent = (r: EventRow): ReminderEvent => ({
  id: r.id, reminderId: r.reminder_id, taskId: r.task_id, scheduledAt: r.scheduled_at,
  triggeredAt: r.triggered_at, acknowledgedAt: r.acknowledged_at, action: r.action, deliveryStatus: r.delivery_status,
});

const createSchema = z.object({
  reminderId: z.string().min(1).nullable().optional(),
  taskId: z.string().min(1),
  scheduledAt: z.number().int().nonnegative(),
  deliveryStatus: z.enum(DELIVERY_STATUSES).default('scheduled'),
});
export type CreateReminderEventInput = z.input<typeof createSchema>;

/**
 * Persistent record of what happened to each reminder. The delivery layer (next phase)
 * writes here, so state survives restarts and can be rebuilt after a reboot.
 */
export interface ReminderRepository {
  createEvent(input: CreateReminderEventInput): Promise<ReminderEvent>;
  getEvent(id: string): Promise<ReminderEvent | null>;
  markTriggered(id: string, at: number, status?: DeliveryStatus): Promise<ReminderEvent | null>;
  markAcknowledged(id: string, at: number, action: ReminderAction): Promise<ReminderEvent | null>;
  listForTask(taskId: string): Promise<ReminderEvent[]>;
  /** Events that fired but the user has not responded to yet. */
  listUnacknowledged(): Promise<ReminderEvent[]>;
}

export function createReminderRepository(db: DbClient): ReminderRepository {
  async function getEvent(id: string): Promise<ReminderEvent | null> {
    const row = await db.getFirstAsync<EventRow>('SELECT * FROM reminder_events WHERE id = ?', [id]);
    return row ? toEvent(row) : null;
  }

  async function update(id: string, sets: string[], params: SqlParam[]): Promise<ReminderEvent | null> {
    const res = await db.runAsync(`UPDATE reminder_events SET ${sets.join(', ')} WHERE id = ?`, [...params, id]);
    return res.changes > 0 ? getEvent(id) : null;
  }

  return {
    getEvent,

    async createEvent(raw) {
      const input = createSchema.parse(raw);
      const id = newId();
      await db.runAsync(
        `INSERT INTO reminder_events (id, reminder_id, task_id, scheduled_at, delivery_status)
         VALUES (?, ?, ?, ?, ?)`,
        [id, input.reminderId ?? null, input.taskId, input.scheduledAt, input.deliveryStatus],
      );
      const created = await getEvent(id);
      if (!created) throw new Error('Reminder event was not saved');
      return created;
    },

    async markTriggered(id, at, status = 'delivered') {
      return update(id, ['triggered_at = ?', 'delivery_status = ?'], [at, z.enum(DELIVERY_STATUSES).parse(status)]);
    },

    async markAcknowledged(id, at, action) {
      return update(id, ['acknowledged_at = ?', 'action = ?'], [at, z.enum(REMINDER_ACTIONS).parse(action)]);
    },

    async listForTask(taskId) {
      const rows = await db.getAllAsync<EventRow>(
        'SELECT * FROM reminder_events WHERE task_id = ? ORDER BY scheduled_at, id', [taskId]);
      return rows.map(toEvent);
    },

    async listUnacknowledged() {
      const rows = await db.getAllAsync<EventRow>(
        `SELECT * FROM reminder_events
         WHERE triggered_at IS NOT NULL AND acknowledged_at IS NULL ORDER BY triggered_at, id`);
      return rows.map(toEvent);
    },
  };
}
