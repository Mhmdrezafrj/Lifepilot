import type { AlarmGateway, NotificationGateway } from './types';

/**
 * Gateways for builds where real delivery is not implemented yet (Phase 1).
 * They report "unavailable" honestly and refuse to schedule, so nothing pretends to work.
 */
const notImplemented = (what: string) => new Error(`${what} is not implemented yet (reminder delivery is a later phase)`);

export const unavailableNotificationGateway: NotificationGateway = {
  isAvailable: async () => false,
  getPermission: async () => 'unavailable',
  requestPermission: async () => 'unavailable',
  schedule: async () => {
    throw notImplemented('NotificationGateway.schedule');
  },
  cancel: async () => {},
  cancelForTask: async () => {},
};

export const unavailableAlarmGateway: AlarmGateway = {
  isAvailable: async () => false,
  canScheduleExact: async () => false,
  openExactAlarmSettings: async () => {
    throw notImplemented('AlarmGateway.openExactAlarmSettings');
  },
  scheduleExact: async () => {
    throw notImplemented('AlarmGateway.scheduleExact');
  },
  cancel: async () => {},
  cancelForTask: async () => {},
};
