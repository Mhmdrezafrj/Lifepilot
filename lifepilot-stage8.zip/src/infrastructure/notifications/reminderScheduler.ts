import type { Task } from '../../features/tasks/models/task';
import { planReminders } from './reminderPlanner';
import type {
  AlarmGateway, NotificationGateway, ReminderScheduler, ScheduleReport, SkipReason,
} from './types';
import { unavailableAlarmGateway, unavailableNotificationGateway } from './unavailableGateways';

interface Options {
  notifications?: NotificationGateway;
  alarms?: AlarmGateway;
  now?: () => number;
}

/**
 * Routes planned reminders to the gateways. Nothing here knows about Android:
 * with the default "unavailable" gateways it plans, skips everything, and reports why.
 * An alarm that cannot be exact falls back to a normal notification when possible.
 */
export function createReminderScheduler(options: Options = {}): ReminderScheduler {
  const notifications = options.notifications ?? unavailableNotificationGateway;
  const alarms = options.alarms ?? unavailableAlarmGateway;
  const now = options.now ?? (() => Date.now());

  async function cancelTask(taskId: string): Promise<void> {
    await notifications.cancelForTask(taskId);
    await alarms.cancelForTask(taskId);
  }

  async function scheduleTask(task: Task): Promise<ScheduleReport> {
    await cancelTask(task.id); // replace any earlier plan for this task
    const plan = planReminders(task, now());
    const reasons = new Set<SkipReason>();
    let scheduled = 0;

    const notifyReady = plan.length > 0 && (await notifications.isAvailable());
    const notifyPermitted = notifyReady && (await notifications.getPermission()) === 'granted';
    const exactReady = plan.some((p) => p.channel === 'alarm') && (await alarms.isAvailable()) && (await alarms.canScheduleExact());

    for (const p of plan) {
      if (p.channel === 'alarm' && exactReady) {
        await alarms.scheduleExact(p);
        scheduled++;
        continue;
      }
      if (p.channel === 'alarm') reasons.add('exact-alarm-unavailable');
      // ordinary notification (or alarm that fell back to one)
      if (!notifyReady) {
        reasons.add('gateway-unavailable');
      } else if (!notifyPermitted) {
        reasons.add('permission-not-granted');
      } else {
        await notifications.schedule(p);
        scheduled++;
        continue;
      }
    }

    return { planned: plan.length, scheduled, skipped: plan.length - scheduled, reasons: [...reasons] };
  }

  async function rescheduleAll(tasks: Task[]): Promise<ScheduleReport> {
    const total: ScheduleReport = { planned: 0, scheduled: 0, skipped: 0, reasons: [] };
    const reasons = new Set<SkipReason>();
    for (const t of tasks) {
      const r = await scheduleTask(t);
      total.planned += r.planned;
      total.scheduled += r.scheduled;
      total.skipped += r.skipped;
      r.reasons.forEach((x) => reasons.add(x));
    }
    total.reasons = [...reasons];
    return total;
  }

  return { scheduleTask, cancelTask, rescheduleAll };
}
