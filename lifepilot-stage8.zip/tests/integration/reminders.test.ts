import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createNodeClient } from '../helpers/nodeClient';
import { migrate, migrations } from '../../src/core/database/migrations';
import { createRepositories } from '../../src/providers/repositories';
import { createServices } from '../../src/providers/services';
import type { ReminderScheduler, ScheduleReport } from '../../src/infrastructure/notifications/types';
import type { Task } from '../../src/features/tasks/models/task';

const NOW = new Date(2026, 10, 5, 12, 0).getTime();
const at = (d: number, h = 18) => new Date(2026, 10, d, h).getTime();
const EMPTY: ScheduleReport = { planned: 0, scheduled: 0, skipped: 0, reasons: [] };

async function setup(scheduler?: ReminderScheduler) {
  const db = createNodeClient();
  await migrate(db, migrations);
  const repos = createRepositories(db, { now: () => NOW });
  return { db, repos, ...createServices(repos, { now: () => NOW, scheduler }) };
}

function recordingScheduler() {
  const log: string[] = [];
  const scheduler: ReminderScheduler = {
    scheduleTask: async (t: Task) => { log.push(`schedule:${t.title}:${t.status}`); return EMPTY; },
    cancelTask: async (id: string) => { log.push(`cancel:${id}`); },
    rescheduleAll: async () => EMPTY,
  };
  return { log, scheduler };
}

describe('reminder events repository', () => {
  it('records the whole life of a reminder: scheduled, triggered, acknowledged', async () => {
    const { repos, tasks } = await setup();
    const t = await tasks.create({ title: 'x', dueAt: at(6), hasTime: true, reminders: [{ offsetMinutes: 10 }] });
    const e = await repos.reminders.createEvent({ reminderId: t.reminders[0].id, taskId: t.id, scheduledAt: at(6) - 600_000 });
    assert.equal(e.deliveryStatus, 'scheduled');
    assert.equal(e.triggeredAt, null);

    const fired = await repos.reminders.markTriggered(e.id, at(6) - 600_000);
    assert.equal(fired?.deliveryStatus, 'delivered');
    assert.deepEqual((await repos.reminders.listUnacknowledged()).map((x) => x.id), [e.id]);

    const done = await repos.reminders.markAcknowledged(e.id, at(6) - 500_000, 'snoozed');
    assert.equal(done?.action, 'snoozed');
    assert.deepEqual(await repos.reminders.listUnacknowledged(), []);
    assert.equal((await repos.reminders.listForTask(t.id)).length, 1);
  });

  it('does not list reminders that never fired as unacknowledged', async () => {
    const { repos, tasks } = await setup();
    const t = await tasks.create({ title: 'x' });
    await repos.reminders.createEvent({ taskId: t.id, scheduledAt: 1 });
    assert.deepEqual(await repos.reminders.listUnacknowledged(), []);
  });

  it('rejects invalid input and unknown tasks', async () => {
    const { repos, tasks } = await setup();
    const t = await tasks.create({ title: 'x' });
    await assert.rejects(() => repos.reminders.createEvent({ taskId: 'missing', scheduledAt: 1 }));
    await assert.rejects(() => repos.reminders.createEvent({ taskId: t.id, scheduledAt: -5 }));
    const e = await repos.reminders.createEvent({ taskId: t.id, scheduledAt: 1 });
    // @ts-expect-error invalid action on purpose
    await assert.rejects(() => repos.reminders.markAcknowledged(e.id, 2, 'ignored'));
    assert.equal(await repos.reminders.markTriggered('nope', 1), null);
  });

  it('keeps the history when a task edit replaces its reminders, and removes it with the task', async () => {
    const { repos, tasks } = await setup();
    const t = await tasks.create({ title: 'x', dueAt: at(6), hasTime: true, reminders: [{ offsetMinutes: 10 }] });
    const e = await repos.reminders.createEvent({ reminderId: t.reminders[0].id, taskId: t.id, scheduledAt: 1 });
    await tasks.update(t.id, { reminders: [{ offsetMinutes: 30 }] }); // old reminder row is replaced
    assert.equal((await repos.reminders.getEvent(e.id))?.reminderId, null);
    await tasks.delete(t.id);
    assert.equal(await repos.reminders.getEvent(e.id), null);
  });
});

describe('task service keeps the reminder scheduler in sync', () => {
  it('schedules on create/update/reopen/snooze/reschedule/duplicate and cancels on complete/delete', async () => {
    const { log, scheduler } = recordingScheduler();
    const { tasks } = await setup(scheduler);
    const t = await tasks.create({ title: 'A', dueAt: at(6), hasTime: true });
    await tasks.update(t.id, { title: 'B' });
    await tasks.snooze(t.id, 30);
    await tasks.reschedule(t.id, at(7), true);
    await tasks.duplicate(t.id);
    await tasks.complete(t.id);
    await tasks.reopen(t.id);
    await tasks.delete(t.id);
    assert.deepEqual(log, [
      'schedule:A:pending', 'schedule:B:pending', 'schedule:B:pending', 'schedule:B:pending',
      'schedule:B (کپی):pending', `cancel:${t.id}`, 'schedule:B:pending', `cancel:${t.id}`,
    ]);
  });

  it('completing a recurring task cancels it and schedules the next occurrence', async () => {
    const { log, scheduler } = recordingScheduler();
    const { tasks } = await setup(scheduler);
    const t = await tasks.create({ title: 'R', dueAt: at(6), hasTime: true, recurrence: { frequency: 'daily' } });
    log.length = 0;
    const { next } = await tasks.complete(t.id);
    assert.deepEqual(log, [`cancel:${t.id}`, 'schedule:R:pending']);
    assert.ok(next);
  });

  it('a failing scheduler never breaks saving a task', async () => {
    const broken: ReminderScheduler = {
      scheduleTask: async () => { throw new Error('boom'); },
      cancelTask: async () => { throw new Error('boom'); },
      rescheduleAll: async () => { throw new Error('boom'); },
    };
    const { tasks, repos } = await setup(broken);
    const t = await tasks.create({ title: 'x', dueAt: at(6), hasTime: true });
    await tasks.update(t.id, { title: 'y' });
    await tasks.complete(t.id);
    await tasks.delete(t.id);
    assert.equal(await repos.tasks.count(), 0);
  });

  it('works with the default (unavailable) scheduler without errors', async () => {
    const { tasks } = await setup();
    const t = await tasks.create({ title: 'x', dueAt: at(6), hasTime: true, reminders: [{ offsetMinutes: 5 }] });
    assert.equal(t.reminders.length, 1);
  });
});
