import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { Reminder, Task } from '../../src/features/tasks/models/task';
import { createReminderScheduler } from '../../src/infrastructure/notifications/reminderScheduler';
import type {
  AlarmGateway, NotificationGateway, PermissionState, PlannedReminder,
} from '../../src/infrastructure/notifications/types';
import { unavailableAlarmGateway, unavailableNotificationGateway } from '../../src/infrastructure/notifications/unavailableGateways';

const NOW = new Date(2026, 10, 5, 12, 0).getTime();
const rem = (over: Partial<Reminder>): Reminder => ({
  id: 'r1', taskId: 't1', offsetMinutes: 0, channel: 'notification', enabled: true,
  repeatIntervalMinutes: null, maxRepeats: null, ...over,
});
const task = (reminders: Reminder[]): Task => ({
  id: 't1', title: 'x', description: null, dueAt: new Date(2026, 10, 5, 18, 0).getTime(), hasTime: true,
  priority: 'medium', categoryId: null, status: 'pending', snoozedUntil: null, createdAt: 0, updatedAt: 0,
  completedAt: null, recurrenceId: null, tags: [], checklist: [], reminders, recurrence: null,
});

function fakeGateways(opts: { notify?: boolean; permission?: PermissionState; alarm?: boolean; exact?: boolean } = {}) {
  const calls = { notified: [] as PlannedReminder[], alarmed: [] as PlannedReminder[], cancelled: [] as string[] };
  const notifications: NotificationGateway = {
    isAvailable: async () => opts.notify ?? true,
    getPermission: async () => opts.permission ?? 'granted',
    requestPermission: async () => 'granted',
    schedule: async (r) => { calls.notified.push(r); },
    cancel: async () => {},
    cancelForTask: async (id) => { calls.cancelled.push(`n:${id}`); },
  };
  const alarms: AlarmGateway = {
    isAvailable: async () => opts.alarm ?? true,
    canScheduleExact: async () => opts.exact ?? true,
    openExactAlarmSettings: async () => {},
    scheduleExact: async (r) => { calls.alarmed.push(r); },
    cancel: async () => {},
    cancelForTask: async (id) => { calls.cancelled.push(`a:${id}`); },
  };
  return { notifications, alarms, calls };
}

describe('reminder scheduler', () => {
  it('sends notifications to the notification gateway and alarms to the alarm gateway', async () => {
    const g = fakeGateways();
    const s = createReminderScheduler({ ...g, now: () => NOW });
    const report = await s.scheduleTask(task([rem({ id: 'n' }), rem({ id: 'a', channel: 'alarm', offsetMinutes: 5 })]));
    assert.deepEqual(report, { planned: 2, scheduled: 2, skipped: 0, reasons: [] });
    assert.deepEqual(g.calls.notified.map((r) => r.reminderId), ['n']);
    assert.deepEqual(g.calls.alarmed.map((r) => r.reminderId), ['a']);
  });

  it('cancels the earlier plan of the task before scheduling again', async () => {
    const g = fakeGateways();
    const s = createReminderScheduler({ ...g, now: () => NOW });
    await s.scheduleTask(task([rem({})]));
    assert.deepEqual(g.calls.cancelled, ['n:t1', 'a:t1']);
  });

  it('falls back to a notification when exact alarms are not allowed', async () => {
    const g = fakeGateways({ exact: false });
    const s = createReminderScheduler({ ...g, now: () => NOW });
    const report = await s.scheduleTask(task([rem({ id: 'a', channel: 'alarm' })]));
    assert.equal(g.calls.alarmed.length, 0);
    assert.equal(g.calls.notified.length, 1);
    assert.equal(report.scheduled, 1);
  });

  it('skips and explains when notification permission is missing', async () => {
    const g = fakeGateways({ permission: 'denied' });
    const report = await createReminderScheduler({ ...g, now: () => NOW }).scheduleTask(task([rem({})]));
    assert.deepEqual(report, { planned: 1, scheduled: 0, skipped: 1, reasons: ['permission-not-granted'] });
    assert.equal(g.calls.notified.length, 0);
  });

  it('with the default unavailable gateways it plans but delivers nothing, and says why', async () => {
    const s = createReminderScheduler({ now: () => NOW });
    const report = await s.scheduleTask(task([rem({}), rem({ id: 'a', channel: 'alarm' })]));
    assert.equal(report.planned, 2);
    assert.equal(report.scheduled, 0);
    assert.equal(report.skipped, 2);
    assert.ok(report.reasons.includes('gateway-unavailable'));
    assert.ok(report.reasons.includes('exact-alarm-unavailable'));
  });

  it('unavailable gateways report unavailable and refuse to schedule (no fake delivery)', async () => {
    assert.equal(await unavailableNotificationGateway.isAvailable(), false);
    assert.equal(await unavailableNotificationGateway.getPermission(), 'unavailable');
    assert.equal(await unavailableAlarmGateway.isAvailable(), false);
    assert.equal(await unavailableAlarmGateway.canScheduleExact(), false);
    const r: PlannedReminder = { id: 'x:0', reminderId: 'x', taskId: 't', taskTitle: 't', fireAt: 1, channel: 'notification', repeatIndex: 0 };
    await assert.rejects(() => unavailableNotificationGateway.schedule(r), /not implemented/);
    await assert.rejects(() => unavailableAlarmGateway.scheduleExact(r), /not implemented/);
  });

  it('rescheduleAll rebuilds the plan for every task and sums the report', async () => {
    const g = fakeGateways();
    const s = createReminderScheduler({ ...g, now: () => NOW });
    const t2 = { ...task([rem({ id: 'r2' })]), id: 't2' };
    const report = await s.rescheduleAll([task([rem({})]), t2]);
    assert.deepEqual(report, { planned: 2, scheduled: 2, skipped: 0, reasons: [] });
  });

  it('cancelTask cancels in both gateways', async () => {
    const g = fakeGateways();
    await createReminderScheduler(g).cancelTask('t9');
    assert.deepEqual(g.calls.cancelled, ['n:t9', 'a:t9']);
  });
});
