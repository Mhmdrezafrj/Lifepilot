import { Screen } from '@/shared/components/Screen';
import { InfoCard } from '@/shared/components/InfoCard';
import { AppText } from '@/shared/components/AppText';

export default function CalendarScreen() {
  return (
    <Screen title="تقویم">
      <InfoCard>
        <AppText muted>تقویم شمسی (روز، هفته، ماه) هنوز پیاده‌سازی نشده است. مرحله ۶.</AppText>
      </InfoCard>
    </Screen>
  );
}
