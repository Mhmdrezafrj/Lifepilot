import Constants from 'expo-constants';
import { Screen } from '@/shared/components/Screen';
import { InfoCard } from '@/shared/components/InfoCard';
import { AppText } from '@/shared/components/AppText';

export default function SettingsScreen() {
  return (
    <Screen title="تنظیمات">
      <InfoCard>
        <AppText weight="medium">درباره</AppText>
        <AppText muted>نسخه برنامه: {Constants.expoConfig?.version ?? '—'}</AppText>
        <AppText muted>شناسه بسته: com.lifepilot.personalassistant</AppText>
      </InfoCard>
      <InfoCard>
        <AppText muted>گزینه‌های ظاهر، اعلان و حریم خصوصی در مرحله ۷ اضافه می‌شوند.</AppText>
      </InfoCard>
    </Screen>
  );
}
