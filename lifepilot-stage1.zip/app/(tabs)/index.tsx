import { I18nManager } from 'react-native';
import { Screen } from '@/shared/components/Screen';
import { InfoCard } from '@/shared/components/InfoCard';
import { AppText } from '@/shared/components/AppText';

export default function HomeScreen() {
  return (
    <Screen title="لایف‌پایلوت">
      <InfoCard>
        <AppText weight="bold" size={17}>پروژه آماده است ✅</AppText>
        <AppText muted>
          اسکلت برنامه ساخته شد. داشبورد واقعی (تسک‌ها و آمار) در مرحله ۵ اضافه می‌شود.
        </AppText>
      </InfoCard>
      <InfoCard>
        <AppText weight="medium">بررسی فنی (برای تست روی گوشی)</AppText>
        <AppText muted>
          جهت راست‌به‌چپ: {I18nManager.isRTL ? 'فعال ✅' : 'غیرفعال ❌'}
        </AppText>
        <AppText muted>فونت وزیرمتن: این متن با وزیرمتن نوشته شده است. Latin text: Vazirmatn 123</AppText>
      </InfoCard>
    </Screen>
  );
}
