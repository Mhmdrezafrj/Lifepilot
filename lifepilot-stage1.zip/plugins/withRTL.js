// Config plugin: forces RTL at the native Android level from the very first launch.
const { withMainApplication } = require('@expo/config-plugins');

const MARKER = 'LifePilot RTL';

module.exports = function withRTL(config) {
  return withMainApplication(config, (cfg) => {
    let src = cfg.modResults.contents;
    if (src.includes(MARKER)) return cfg;

    const snippet =
      `    // ${MARKER}\n` +
      `    com.facebook.react.modules.i18nmanager.I18nUtil.getInstance().allowRTL(this, true)\n` +
      `    com.facebook.react.modules.i18nmanager.I18nUtil.getInstance().forceRTL(this, true)\n`;

    const re = /super\.onCreate\(\)\s*\n/;
    if (!re.test(src)) {
      console.warn('[withRTL] super.onCreate() not found; RTL falls back to JS-level forceRTL.');
      return cfg;
    }
    cfg.modResults.contents = src.replace(re, (m) => m + snippet);
    return cfg;
  });
};
