import { useColorScheme } from 'react-native';
import { palette, Palette } from './palette';

export function useTheme(): { colors: Palette; isDark: boolean } {
  const scheme = useColorScheme();
  const isDark = scheme === 'dark';
  return { colors: isDark ? palette.dark : palette.light, isDark };
}
