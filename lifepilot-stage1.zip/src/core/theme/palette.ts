// Temporary minimal palette. Stage 2 replaces this with the full design system.
export const palette = {
  light: { bg: '#F6F7FB', card: '#FFFFFF', text: '#111827', sub: '#6B7280', accent: '#4F46E5', border: '#E5E7EB' },
  dark: { bg: '#0B1020', card: '#151B2E', text: '#F3F4F6', sub: '#9CA3AF', accent: '#818CF8', border: '#262D45' },
};

export type Palette = typeof palette.light;
