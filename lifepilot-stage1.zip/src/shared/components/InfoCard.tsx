import { ReactNode } from 'react';
import { View, StyleSheet } from 'react-native';
import { useTheme } from '@/core/theme/useTheme';

export function InfoCard({ children }: { children: ReactNode }) {
  const { colors } = useTheme();
  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 18, borderWidth: 1, padding: 16, gap: 8 },
});
