import { Text, TextProps, StyleSheet } from 'react-native';
import { useTheme } from '@/core/theme/useTheme';

type Weight = 'regular' | 'medium' | 'bold';
const fonts: Record<Weight, string> = {
  regular: 'Vazirmatn_400Regular',
  medium: 'Vazirmatn_500Medium',
  bold: 'Vazirmatn_700Bold',
};

interface Props extends TextProps {
  weight?: Weight;
  size?: number;
  muted?: boolean;
}

export function AppText({ weight = 'regular', size = 15, muted, style, ...rest }: Props) {
  const { colors } = useTheme();
  return (
    <Text
      {...rest}
      style={[
        styles.base,
        { fontFamily: fonts[weight], fontSize: size, color: muted ? colors.sub : colors.text },
        style,
      ]}
    />
  );
}

const styles = StyleSheet.create({
  base: { textAlign: 'left', writingDirection: 'rtl' },
});
