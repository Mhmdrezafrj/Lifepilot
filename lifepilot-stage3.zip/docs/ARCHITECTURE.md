# LifePilot architecture notes

## Data layer (stage 3)
- SQLite is the single source of truth; the app works fully offline.
- `DbClient` (src/core/database/connection/types.ts) is a tiny async interface.
  expo-sqlite implements it in the app, node:sqlite implements it in tests, so the
  same SQL and repositories are tested without a phone.
- Schema changes are migrations (src/core/database/migrations), versioned with
  `PRAGMA user_version`. Each migration runs in a transaction. Never edit an old
  migration after release; add a new one.
- UI code never writes SQL. Screens use repositories through `useRepositories()`.
- All timestamps are UTC epoch milliseconds. "Overdue" is derived from `due_at`,
  not stored, and overdue tasks are never deleted automatically.
- IDs are random UUIDs (strings). Booleans are stored as 0/1.
- Input is validated with Zod inside the repositories, so invalid data cannot reach the DB.
- Tables `reminder_events` and `behavior_events` exist for later phases and are not written yet.

## Folder note
Routes live in the root `app/` folder (Expo Router). Do not create `src/app/`, it would conflict.
