import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createTaskInputSchema, updateTaskInputSchema } from '../../src/features/tasks/validation/taskSchemas';
import { createCategoryInputSchema } from '../../src/features/categories/validation/categorySchemas';
import { PRIORITIES, comparePriorityDesc, priorityRank } from '../../src/features/tasks/models/task';

describe('task validation', () => {
  it('requires a non-empty title and trims it', () => {
    assert.throws(() => createTaskInputSchema.parse({ title: '   ' }));
    assert.equal(createTaskInputSchema.parse({ title: '  خرید نان  ' }).title, 'خرید نان');
  });

  it('applies defaults: medium priority, no tags, no checklist, no reminders', () => {
    const t = createTaskInputSchema.parse({ title: 'x' });
    assert.equal(t.priority, 'medium');
    assert.deepEqual(t.tags, []);
    assert.deepEqual(t.checklist, []);
    assert.deepEqual(t.reminders, []);
    assert.equal(t.hasTime, false);
  });

  it('rejects invalid priority values', () => {
    assert.throws(() => createTaskInputSchema.parse({ title: 'x', priority: 'urgent' }));
  });

  it('accepts all four priorities', () => {
    for (const p of PRIORITIES) assert.equal(createTaskInputSchema.parse({ title: 'x', priority: p }).priority, p);
  });

  it('trims and de-duplicates tags, rejects more than 10', () => {
    const t = createTaskInputSchema.parse({ title: 'x', tags: [' a ', 'a', 'b'] });
    assert.deepEqual(t.tags, ['a', 'b']);
    assert.throws(() => createTaskInputSchema.parse({ title: 'x', tags: Array.from({ length: 11 }, (_, i) => `t${i}`) }));
  });

  it('turns an empty description into null', () => {
    assert.equal(createTaskInputSchema.parse({ title: 'x', description: '   ' }).description, null);
  });

  it('validates reminders', () => {
    assert.throws(() => createTaskInputSchema.parse({ title: 'x', reminders: [{ offsetMinutes: -5 }] }));
    const ok = createTaskInputSchema.parse({ title: 'x', reminders: [{ offsetMinutes: 10 }] });
    assert.equal(ok.reminders[0].channel, 'notification');
    assert.equal(ok.reminders[0].enabled, true);
  });

  it('validates recurrence and normalizes weekdays', () => {
    const t = createTaskInputSchema.parse({ title: 'x', recurrence: { frequency: 'weekly', weekdays: [3, 1, 3] } });
    assert.deepEqual(t.recurrence?.weekdays, [1, 3]);
    assert.equal(t.recurrence?.intervalCount, 1);
    assert.throws(() => createTaskInputSchema.parse({ title: 'x', recurrence: { frequency: 'hourly' } }));
    assert.throws(() => createTaskInputSchema.parse({ title: 'x', recurrence: { frequency: 'weekly', weekdays: [7] } }));
  });

  it('update schema keeps fields untouched when omitted', () => {
    const p = updateTaskInputSchema.parse({ title: 'new' });
    assert.equal(p.priority, undefined);
    assert.equal(p.tags, undefined);
    assert.throws(() => updateTaskInputSchema.parse({ status: 'deleted' }));
  });
});

describe('category validation', () => {
  it('requires a name and a #RRGGBB color', () => {
    assert.throws(() => createCategoryInputSchema.parse({ name: '', color: '#112233' }));
    assert.throws(() => createCategoryInputSchema.parse({ name: 'a', color: 'red' }));
    assert.equal(createCategoryInputSchema.parse({ name: ' کار ', color: '#112233' }).name, 'کار');
  });
});

describe('priority handling', () => {
  it('ranks low < medium < high < critical', () => {
    assert.ok(priorityRank.low < priorityRank.medium);
    assert.ok(priorityRank.medium < priorityRank.high);
    assert.ok(priorityRank.high < priorityRank.critical);
  });

  it('sorts most important first', () => {
    const sorted = [...PRIORITIES].sort(comparePriorityDesc);
    assert.deepEqual(sorted, ['critical', 'high', 'medium', 'low']);
  });
});
