import { DatabaseSync } from 'node:sqlite';
import type { DbClient, SqlParam } from '../../src/core/database/connection/types';

export interface NodeClient extends DbClient {
  close(): void;
}

/** DbClient backed by Node's built-in SQLite, used to test real SQL without a phone. */
export function createNodeClient(path: string = ':memory:'): NodeClient {
  const db = new DatabaseSync(path);
  db.exec('PRAGMA foreign_keys = ON');
  return {
    async execAsync(sql: string): Promise<void> {
      db.exec(sql);
    },
    async runAsync(sql: string, params: SqlParam[] = []): Promise<{ changes: number }> {
      const r = db.prepare(sql).run(...params);
      return { changes: Number(r.changes) };
    },
    async getAllAsync<T>(sql: string, params: SqlParam[] = []): Promise<T[]> {
      return db.prepare(sql).all(...params) as unknown as T[];
    },
    async getFirstAsync<T>(sql: string, params: SqlParam[] = []): Promise<T | null> {
      const r = db.prepare(sql).get(...params);
      return (r ?? null) as unknown as T | null;
    },
    async withTransactionAsync(fn: () => Promise<void>): Promise<void> {
      db.exec('BEGIN');
      try {
        await fn();
        db.exec('COMMIT');
      } catch (e) {
        db.exec('ROLLBACK');
        throw e;
      }
    },
    close(): void {
      db.close();
    },
  };
}
