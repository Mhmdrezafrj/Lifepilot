import { I18nManager } from 'react-native';
import { Screen } from '@/shared/components/Screen';
import { Card } from '@/shared/components/Card';
import { AppText } from '@/shared/components/AppText';
import { useDbInfo } from '@/providers/DatabaseProvider';

export default function HomeScreen() {
  const db = useDbInfo();
  return (
    <Screen title="لایف‌پایلوت">
      <Card>
        <AppText variant="heading">پایگاه داده آماده است ✅</AppText>
        <AppText muted>
          ذخیره‌سازی محلی (SQLite) فعال شد. مدیریت تسک در مرحله ۴ و داشبورد واقعی در مرحله ۵ می‌آید.
        </AppText>
      </Card>
      <Card variant="outlined">
        <AppText variant="bodyStrong">بررسی فنی (برای تست روی گوشی)</AppText>
        <AppText muted>جهت راست‌به‌چپ: {I18nManager.isRTL ? 'فعال ✅' : 'غیرفعال ❌'}</AppText>
        <AppText muted>نسخه‌ی ساختار پایگاه داده: {db.schemaVersion}</AppText>
        <AppText muted>تعداد دسته‌بندی‌ها: {db.categoryCount}</AppText>
        <AppText muted>تعداد تسک‌ها: {db.taskCount}</AppText>
        <AppText muted>دفعات اجرای برنامه: {db.launchCount}</AppText>
        <AppText variant="caption" muted>
          با بستن کامل برنامه و باز کردن دوباره، «دفعات اجرا» باید یکی بیشتر شود (اثبات ماندگاری داده).
        </AppText>
      </Card>
    </Screen>
  );
}
