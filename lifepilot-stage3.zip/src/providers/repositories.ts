import type { DbClient } from '../core/database/connection/types';
import { createCategoryRepository } from '../features/categories/repositories/categoryRepository';
import { createSettingsRepository } from '../features/settings/repositories/settingsRepository';
import { createTaskRepository } from '../features/tasks/repositories/taskRepository';

export function createRepositories(db: DbClient, options: { now?: () => number } = {}) {
  return {
    tasks: createTaskRepository(db, options),
    categories: createCategoryRepository(db, options),
    settings: createSettingsRepository(db, options),
  };
}

export type Repositories = ReturnType<typeof createRepositories>;
