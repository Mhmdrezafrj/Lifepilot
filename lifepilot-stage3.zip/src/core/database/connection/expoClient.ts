import { SQLiteDatabase, openDatabaseAsync } from 'expo-sqlite';
import type { DbClient, SqlParam } from './types';

export const DATABASE_NAME = 'lifepilot.db';

export function createExpoClient(db: SQLiteDatabase): DbClient {
  return {
    execAsync: (sql: string) => db.execAsync(sql),
    runAsync: async (sql: string, params: SqlParam[] = []) => {
      const result = await db.runAsync(sql, params);
      return { changes: result.changes };
    },
    getAllAsync: <T>(sql: string, params: SqlParam[] = []) => db.getAllAsync<T>(sql, params),
    getFirstAsync: <T>(sql: string, params: SqlParam[] = []) => db.getFirstAsync<T>(sql, params),
    withTransactionAsync: (fn: () => Promise<void>) => db.withTransactionAsync(fn),
  };
}

export async function openAppDatabase(): Promise<DbClient> {
  const db = await openDatabaseAsync(DATABASE_NAME);
  // Per-connection settings: write-ahead log for safety/speed, enforce foreign keys.
  await db.execAsync('PRAGMA journal_mode = WAL;');
  await db.execAsync('PRAGMA foreign_keys = ON;');
  return createExpoClient(db);
}
