/** Values SQLite can bind. Booleans must be stored as 0/1. */
export type SqlParam = string | number | null;

/**
 * Minimal async database interface used by all repositories.
 * Implemented by expo-sqlite in the app and by node:sqlite in tests,
 * so business/data logic never imports a native module directly.
 */
export interface DbClient {
  execAsync(sql: string): Promise<void>;
  runAsync(sql: string, params?: SqlParam[]): Promise<{ changes: number }>;
  getAllAsync<T>(sql: string, params?: SqlParam[]): Promise<T[]>;
  getFirstAsync<T>(sql: string, params?: SqlParam[]): Promise<T | null>;
  /** Runs fn inside a transaction: commit on success, rollback if fn throws. */
  withTransactionAsync(fn: () => Promise<void>): Promise<void>;
}
