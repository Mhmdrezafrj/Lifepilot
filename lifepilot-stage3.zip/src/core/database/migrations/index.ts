import { migration001 } from './001_initial';
import { migration002 } from './002_seed_categories';
import type { Migration } from './types';

export const migrations: Migration[] = [migration001, migration002];
export const LATEST_SCHEMA_VERSION = migrations[migrations.length - 1].version;
export { migrate } from './runner';
export type { Migration } from './types';
