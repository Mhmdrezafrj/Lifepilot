import type { DbClient } from '../connection/types';
import type { Migration } from './types';

/**
 * Applies pending migrations in order. Each migration and its version bump
 * run in one transaction, so a failure leaves the database at the previous
 * version with no partial changes. Never drops data on its own.
 */
export async function migrate(db: DbClient, migrations: Migration[]): Promise<{ from: number; to: number }> {
  for (let i = 0; i < migrations.length; i++) {
    const v = migrations[i].version;
    if (!Number.isInteger(v) || v < 1 || (i > 0 && v <= migrations[i - 1].version)) {
      throw new Error(`Invalid migration order at index ${i} (version ${v})`);
    }
  }

  const row = await db.getFirstAsync<{ user_version: number }>('PRAGMA user_version');
  const current = row?.user_version ?? 0;
  const latest = migrations.length ? migrations[migrations.length - 1].version : 0;

  if (current > latest) {
    throw new Error(`Database version ${current} is newer than this app supports (${latest}).`);
  }

  for (const m of migrations) {
    if (m.version <= current) continue;
    await db.withTransactionAsync(async () => {
      await m.up(db);
      await db.execAsync(`PRAGMA user_version = ${m.version}`);
    });
  }
  return { from: current, to: latest };
}
