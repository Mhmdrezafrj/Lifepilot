import type { Migration } from './types';

const SQL = `
CREATE TABLE categories (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  color TEXT NOT NULL,
  icon TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);

CREATE TABLE recurrences (
  id TEXT PRIMARY KEY NOT NULL,
  frequency TEXT NOT NULL CHECK (frequency IN ('daily','weekly','monthly','yearly')),
  interval_count INTEGER NOT NULL DEFAULT 1 CHECK (interval_count >= 1),
  weekdays TEXT,
  ends_at INTEGER,
  max_occurrences INTEGER CHECK (max_occurrences IS NULL OR max_occurrences >= 1)
);

CREATE TABLE tasks (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  due_at INTEGER,
  has_time INTEGER NOT NULL DEFAULT 0 CHECK (has_time IN (0,1)),
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low','medium','high','critical')),
  category_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed')),
  snoozed_until INTEGER,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  completed_at INTEGER,
  recurrence_id TEXT REFERENCES recurrences(id) ON DELETE SET NULL
);
CREATE INDEX idx_tasks_due_at ON tasks(due_at);
CREATE INDEX idx_tasks_status_due ON tasks(status, due_at);
CREATE INDEX idx_tasks_category ON tasks(category_id);
CREATE INDEX idx_tasks_recurrence ON tasks(recurrence_id);

CREATE TABLE task_tags (
  task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  tag TEXT NOT NULL,
  PRIMARY KEY (task_id, tag)
);
CREATE INDEX idx_task_tags_tag ON task_tags(tag);

CREATE TABLE task_checklist_items (
  id TEXT PRIMARY KEY NOT NULL,
  task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  is_completed INTEGER NOT NULL DEFAULT 0 CHECK (is_completed IN (0,1)),
  sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_checklist_task ON task_checklist_items(task_id, sort_order);

CREATE TABLE reminders (
  id TEXT PRIMARY KEY NOT NULL,
  task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  offset_minutes INTEGER NOT NULL DEFAULT 0 CHECK (offset_minutes >= 0),
  channel TEXT NOT NULL DEFAULT 'notification' CHECK (channel IN ('notification','alarm')),
  enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0,1)),
  repeat_interval_minutes INTEGER CHECK (repeat_interval_minutes IS NULL OR repeat_interval_minutes >= 1),
  max_repeats INTEGER CHECK (max_repeats IS NULL OR max_repeats >= 1)
);
CREATE INDEX idx_reminders_task ON reminders(task_id);

-- Prepared for the notification phase; written by the reminder engine later.
CREATE TABLE reminder_events (
  id TEXT PRIMARY KEY NOT NULL,
  reminder_id TEXT REFERENCES reminders(id) ON DELETE SET NULL,
  task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  scheduled_at INTEGER NOT NULL,
  triggered_at INTEGER,
  acknowledged_at INTEGER,
  action TEXT,
  delivery_status TEXT
);
CREATE INDEX idx_reminder_events_reminder ON reminder_events(reminder_id);
CREATE INDEX idx_reminder_events_task ON reminder_events(task_id);
CREATE INDEX idx_reminder_events_scheduled ON reminder_events(scheduled_at);

-- Prepared for future behavior analysis. No inference is done in Phase 1.
CREATE TABLE behavior_events (
  id TEXT PRIMARY KEY NOT NULL,
  event_type TEXT NOT NULL,
  task_id TEXT REFERENCES tasks(id) ON DELETE SET NULL,
  payload TEXT,
  occurred_at INTEGER NOT NULL
);
CREATE INDEX idx_behavior_events_time ON behavior_events(occurred_at);
CREATE INDEX idx_behavior_events_type ON behavior_events(event_type, occurred_at);

CREATE TABLE app_settings (
  key TEXT PRIMARY KEY NOT NULL,
  value TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
`;

export const migration001: Migration = {
  version: 1,
  name: 'initial_schema',
  up: async (db) => {
    await db.execAsync(SQL);
  },
};
