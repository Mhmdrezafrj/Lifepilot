import type { DbClient } from '../connection/types';

export interface Migration {
  /** Strictly increasing integer, stored in PRAGMA user_version. */
  version: number;
  name: string;
  up: (db: DbClient) => Promise<void>;
}
