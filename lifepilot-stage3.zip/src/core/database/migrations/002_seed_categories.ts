import type { Migration } from './types';

// Fixed IDs keep the seed idempotent. Users may rename/delete these later.
const DEFAULTS: { id: string; name: string; color: string; icon: string }[] = [
  { id: 'cat_work', name: 'کار', color: '#4F46E5', icon: 'briefcase-outline' },
  { id: 'cat_personal', name: 'شخصی', color: '#0EA5E9', icon: 'person-outline' },
  { id: 'cat_study', name: 'تحصیل', color: '#14B8A6', icon: 'school-outline' },
  { id: 'cat_health', name: 'سلامت', color: '#22C55E', icon: 'heart-outline' },
  { id: 'cat_shopping', name: 'خرید', color: '#F97316', icon: 'cart-outline' },
  { id: 'cat_family', name: 'خانواده', color: '#EC4899', icon: 'people-outline' },
  { id: 'cat_other', name: 'سایر', color: '#64748B', icon: 'ellipsis-horizontal-circle-outline' },
];

export const migration002: Migration = {
  version: 2,
  name: 'seed_default_categories',
  up: async (db) => {
    for (let i = 0; i < DEFAULTS.length; i++) {
      const c = DEFAULTS[i];
      await db.runAsync(
        `INSERT OR IGNORE INTO categories (id, name, color, icon, sort_order, created_at)
         VALUES (?, ?, ?, ?, ?, CAST(strftime('%s','now') AS INTEGER) * 1000)`,
        [c.id, c.name, c.color, c.icon, i],
      );
    }
  },
};
