import type { DbClient, SqlParam } from '../../../core/database/connection/types';
import { newId } from '../../../core/utils/id';
import type {
  ChecklistItem,
  Priority,
  Recurrence,
  Reminder,
  ReminderChannel,
  RecurrenceFrequency,
  Task,
  TaskFilter,
  TaskStatus,
} from '../models/task';
import {
  CreateTaskInput,
  ParsedRecurrence,
  UpdateTaskInput,
  createTaskInputSchema,
  updateTaskInputSchema,
} from '../validation/taskSchemas';

export interface TaskRepository {
  create(input: CreateTaskInput): Promise<Task>;
  getById(id: string): Promise<Task | null>;
  update(id: string, patch: UpdateTaskInput): Promise<Task | null>;
  /** Permanently deletes a task and its tags, checklist and reminders. Returns false if not found. */
  delete(id: string): Promise<boolean>;
  list(filter?: TaskFilter): Promise<Task[]>;
  count(): Promise<number>;
}

interface TaskRow {
  id: string;
  title: string;
  description: string | null;
  due_at: number | null;
  has_time: number;
  priority: Priority;
  category_id: string | null;
  status: TaskStatus;
  snoozed_until: number | null;
  created_at: number;
  updated_at: number;
  completed_at: number | null;
  recurrence_id: string | null;
}

interface ChecklistRow { id: string; task_id: string; title: string; is_completed: number; sort_order: number }
interface ReminderRow {
  id: string; task_id: string; offset_minutes: number; channel: ReminderChannel; enabled: number;
  repeat_interval_minutes: number | null; max_repeats: number | null;
}
interface RecurrenceRow {
  id: string; frequency: RecurrenceFrequency; interval_count: number; weekdays: string | null;
  ends_at: number | null; max_occurrences: number | null;
}

function group<T>(items: T[], key: (t: T) => string): Map<string, T[]> {
  const map = new Map<string, T[]>();
  for (const item of items) {
    const k = key(item);
    const bucket = map.get(k);
    if (bucket) bucket.push(item);
    else map.set(k, [item]);
  }
  return map;
}

async function insertRecurrence(db: DbClient, id: string, r: ParsedRecurrence): Promise<void> {
  await db.runAsync(
    `INSERT INTO recurrences (id, frequency, interval_count, weekdays, ends_at, max_occurrences)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [id, r.frequency, r.intervalCount, r.weekdays && r.weekdays.length ? r.weekdays.join(',') : null, r.endsAt ?? null, r.maxOccurrences ?? null],
  );
}

async function replaceTags(db: DbClient, taskId: string, tags: string[]): Promise<void> {
  await db.runAsync('DELETE FROM task_tags WHERE task_id = ?', [taskId]);
  for (const tag of tags) {
    await db.runAsync('INSERT INTO task_tags (task_id, tag) VALUES (?, ?)', [taskId, tag]);
  }
}

async function replaceChecklist(
  db: DbClient,
  taskId: string,
  items: { title: string; isCompleted: boolean }[],
): Promise<void> {
  await db.runAsync('DELETE FROM task_checklist_items WHERE task_id = ?', [taskId]);
  for (let i = 0; i < items.length; i++) {
    await db.runAsync(
      'INSERT INTO task_checklist_items (id, task_id, title, is_completed, sort_order) VALUES (?, ?, ?, ?, ?)',
      [newId(), taskId, items[i].title, items[i].isCompleted ? 1 : 0, i],
    );
  }
}

async function replaceReminders(
  db: DbClient,
  taskId: string,
  reminders: {
    offsetMinutes: number; channel: ReminderChannel; enabled: boolean;
    repeatIntervalMinutes?: number | null; maxRepeats?: number | null;
  }[],
): Promise<void> {
  await db.runAsync('DELETE FROM reminders WHERE task_id = ?', [taskId]);
  for (const r of reminders) {
    await db.runAsync(
      `INSERT INTO reminders (id, task_id, offset_minutes, channel, enabled, repeat_interval_minutes, max_repeats)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [newId(), taskId, r.offsetMinutes, r.channel, r.enabled ? 1 : 0, r.repeatIntervalMinutes ?? null, r.maxRepeats ?? null],
    );
  }
}

async function hydrate(db: DbClient, rows: TaskRow[]): Promise<Task[]> {
  if (rows.length === 0) return [];
  const ids = rows.map((r) => r.id);
  const ph = ids.map(() => '?').join(',');

  const tagRows = await db.getAllAsync<{ task_id: string; tag: string }>(
    `SELECT task_id, tag FROM task_tags WHERE task_id IN (${ph}) ORDER BY tag`, ids);
  const checkRows = await db.getAllAsync<ChecklistRow>(
    `SELECT * FROM task_checklist_items WHERE task_id IN (${ph}) ORDER BY sort_order`, ids);
  const remRows = await db.getAllAsync<ReminderRow>(
    `SELECT * FROM reminders WHERE task_id IN (${ph}) ORDER BY offset_minutes DESC`, ids);

  const recIds = [...new Set(rows.map((r) => r.recurrence_id).filter((x): x is string => x !== null))];
  const recRows = recIds.length
    ? await db.getAllAsync<RecurrenceRow>(
        `SELECT * FROM recurrences WHERE id IN (${recIds.map(() => '?').join(',')})`, recIds)
    : [];

  const tagsBy = group(tagRows, (t) => t.task_id);
  const checkBy = group(checkRows, (c) => c.task_id);
  const remBy = group(remRows, (r) => r.task_id);
  const recById = new Map(recRows.map((r) => [r.id, r]));

  return rows.map((r): Task => {
    const checklist: ChecklistItem[] = (checkBy.get(r.id) ?? []).map((c) => ({
      id: c.id, title: c.title, isCompleted: c.is_completed === 1, sortOrder: c.sort_order,
    }));
    const reminders: Reminder[] = (remBy.get(r.id) ?? []).map((m) => ({
      id: m.id, taskId: m.task_id, offsetMinutes: m.offset_minutes, channel: m.channel,
      enabled: m.enabled === 1, repeatIntervalMinutes: m.repeat_interval_minutes, maxRepeats: m.max_repeats,
    }));
    const rec = r.recurrence_id ? recById.get(r.recurrence_id) : undefined;
    const recurrence: Recurrence | null = rec
      ? {
          id: rec.id, frequency: rec.frequency, intervalCount: rec.interval_count,
          weekdays: rec.weekdays ? rec.weekdays.split(',').map(Number) : [],
          endsAt: rec.ends_at, maxOccurrences: rec.max_occurrences,
        }
      : null;
    return {
      id: r.id, title: r.title, description: r.description, dueAt: r.due_at, hasTime: r.has_time === 1,
      priority: r.priority, categoryId: r.category_id, status: r.status, snoozedUntil: r.snoozed_until,
      createdAt: r.created_at, updatedAt: r.updated_at, completedAt: r.completed_at, recurrenceId: r.recurrence_id,
      tags: (tagsBy.get(r.id) ?? []).map((t) => t.tag), checklist, reminders, recurrence,
    };
  });
}

export function createTaskRepository(db: DbClient, options: { now?: () => number } = {}): TaskRepository {
  const now = options.now ?? (() => Date.now());

  async function getById(id: string): Promise<Task | null> {
    const row = await db.getFirstAsync<TaskRow>('SELECT * FROM tasks WHERE id = ?', [id]);
    if (!row) return null;
    const [task] = await hydrate(db, [row]);
    return task;
  }

  async function create(raw: CreateTaskInput): Promise<Task> {
    const input = createTaskInputSchema.parse(raw);
    const id = newId();
    const ts = now();

    await db.withTransactionAsync(async () => {
      let recurrenceId: string | null = null;
      if (input.recurrence) {
        recurrenceId = newId();
        await insertRecurrence(db, recurrenceId, input.recurrence);
      }
      await db.runAsync(
        `INSERT INTO tasks (id, title, description, due_at, has_time, priority, category_id, status,
                            snoozed_until, created_at, updated_at, completed_at, recurrence_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NULL, ?, ?, NULL, ?)`,
        [id, input.title, input.description ?? null, input.dueAt ?? null, input.hasTime ? 1 : 0,
         input.priority, input.categoryId ?? null, ts, ts, recurrenceId],
      );
      await replaceTags(db, id, input.tags);
      await replaceChecklist(db, id, input.checklist);
      await replaceReminders(db, id, input.reminders);
    });

    const created = await getById(id);
    if (!created) throw new Error('Task was not saved');
    return created;
  }

  async function update(id: string, rawPatch: UpdateTaskInput): Promise<Task | null> {
    const p = updateTaskInputSchema.parse(rawPatch);
    const existing = await db.getFirstAsync<TaskRow>('SELECT * FROM tasks WHERE id = ?', [id]);
    if (!existing) return null;
    const ts = now();

    await db.withTransactionAsync(async () => {
      const sets: string[] = ['updated_at = ?'];
      const params: SqlParam[] = [ts];
      const set = (column: string, value: SqlParam) => {
        sets.push(`${column} = ?`);
        params.push(value);
      };

      if (p.title !== undefined) set('title', p.title);
      if (p.description !== undefined) set('description', p.description);
      if (p.dueAt !== undefined) set('due_at', p.dueAt);
      if (p.hasTime !== undefined) set('has_time', p.hasTime ? 1 : 0);
      if (p.priority !== undefined) set('priority', p.priority);
      if (p.categoryId !== undefined) set('category_id', p.categoryId);
      if (p.snoozedUntil !== undefined) set('snoozed_until', p.snoozedUntil);
      if (p.status !== undefined) {
        set('status', p.status);
        set('completed_at', p.status === 'completed' ? existing.completed_at ?? ts : null);
      }
      if (p.recurrence !== undefined) {
        if (existing.recurrence_id) {
          await db.runAsync('DELETE FROM recurrences WHERE id = ?', [existing.recurrence_id]);
        }
        if (p.recurrence === null) {
          set('recurrence_id', null);
        } else {
          const rid = newId();
          await insertRecurrence(db, rid, p.recurrence);
          set('recurrence_id', rid);
        }
      }

      params.push(id);
      await db.runAsync(`UPDATE tasks SET ${sets.join(', ')} WHERE id = ?`, params);

      if (p.tags !== undefined) await replaceTags(db, id, p.tags);
      if (p.checklist !== undefined) await replaceChecklist(db, id, p.checklist);
      if (p.reminders !== undefined) await replaceReminders(db, id, p.reminders);
    });

    return getById(id);
  }

  async function remove(id: string): Promise<boolean> {
    const existing = await db.getFirstAsync<{ recurrence_id: string | null }>(
      'SELECT recurrence_id FROM tasks WHERE id = ?', [id]);
    if (!existing) return false;
    await db.withTransactionAsync(async () => {
      await db.runAsync('DELETE FROM tasks WHERE id = ?', [id]); // cascades tags/checklist/reminders
      if (existing.recurrence_id) {
        await db.runAsync('DELETE FROM recurrences WHERE id = ?', [existing.recurrence_id]);
      }
    });
    return true;
  }

  async function list(filter: TaskFilter = {}): Promise<Task[]> {
    const where: string[] = [];
    const params: SqlParam[] = [];
    if (filter.status !== undefined) { where.push('status = ?'); params.push(filter.status); }
    if (filter.categoryId === null) where.push('category_id IS NULL');
    else if (filter.categoryId !== undefined) { where.push('category_id = ?'); params.push(filter.categoryId); }
    if (filter.dueFrom !== undefined) { where.push('due_at >= ?'); params.push(filter.dueFrom); }
    if (filter.dueTo !== undefined) { where.push('due_at < ?'); params.push(filter.dueTo); }

    let sql = 'SELECT * FROM tasks';
    if (where.length) sql += ` WHERE ${where.join(' AND ')}`;
    sql += ' ORDER BY due_at IS NULL, due_at ASC, created_at ASC';
    if (filter.limit !== undefined) { sql += ' LIMIT ?'; params.push(filter.limit); }

    const rows = await db.getAllAsync<TaskRow>(sql, params);
    return hydrate(db, rows);
  }

  async function count(): Promise<number> {
    const row = await db.getFirstAsync<{ n: number }>('SELECT COUNT(*) AS n FROM tasks');
    return row?.n ?? 0;
  }

  return { create, getById, update, delete: remove, list, count };
}
