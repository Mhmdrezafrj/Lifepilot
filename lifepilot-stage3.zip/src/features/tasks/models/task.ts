export const PRIORITIES = ['low', 'medium', 'high', 'critical'] as const;
export type Priority = (typeof PRIORITIES)[number];

export const priorityRank: Record<Priority, number> = { low: 0, medium: 1, high: 2, critical: 3 };

/** Sorts most important first. */
export function comparePriorityDesc(a: Priority, b: Priority): number {
  return priorityRank[b] - priorityRank[a];
}

export const TASK_STATUSES = ['pending', 'completed'] as const;
export type TaskStatus = (typeof TASK_STATUSES)[number];

export const REMINDER_CHANNELS = ['notification', 'alarm'] as const;
export type ReminderChannel = (typeof REMINDER_CHANNELS)[number];

export const RECURRENCE_FREQUENCIES = ['daily', 'weekly', 'monthly', 'yearly'] as const;
export type RecurrenceFrequency = (typeof RECURRENCE_FREQUENCIES)[number];

export interface ChecklistItem {
  id: string;
  title: string;
  isCompleted: boolean;
  sortOrder: number;
}

export interface Reminder {
  id: string;
  taskId: string;
  /** Minutes before the due time. */
  offsetMinutes: number;
  channel: ReminderChannel;
  enabled: boolean;
  repeatIntervalMinutes: number | null;
  maxRepeats: number | null;
}

export interface Recurrence {
  id: string;
  frequency: RecurrenceFrequency;
  intervalCount: number;
  /** 0 = Sunday .. 6 = Saturday (used for weekly patterns). */
  weekdays: number[];
  endsAt: number | null;
  maxOccurrences: number | null;
}

/** All timestamps are UTC epoch milliseconds. "Overdue" is derived, never stored. */
export interface Task {
  id: string;
  title: string;
  description: string | null;
  dueAt: number | null;
  hasTime: boolean;
  priority: Priority;
  categoryId: string | null;
  status: TaskStatus;
  snoozedUntil: number | null;
  createdAt: number;
  updatedAt: number;
  completedAt: number | null;
  recurrenceId: string | null;
  tags: string[];
  checklist: ChecklistItem[];
  reminders: Reminder[];
  recurrence: Recurrence | null;
}

export interface TaskFilter {
  status?: TaskStatus;
  /** Pass null to match tasks without a category. */
  categoryId?: string | null;
  /** Inclusive lower bound on due_at. */
  dueFrom?: number;
  /** Exclusive upper bound on due_at. */
  dueTo?: number;
  limit?: number;
}
