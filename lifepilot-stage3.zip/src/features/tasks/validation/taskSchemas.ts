import { z } from 'zod';
import { PRIORITIES, RECURRENCE_FREQUENCIES, REMINDER_CHANNELS, TASK_STATUSES } from '../models/task';

export const prioritySchema = z.enum(PRIORITIES);
export const taskStatusSchema = z.enum(TASK_STATUSES);

const titleSchema = z.string().trim().min(1, 'عنوان الزامی است').max(200, 'عنوان بیش از حد طولانی است');

// Empty description is stored as null.
const descriptionSchema = z
  .string()
  .trim()
  .max(2000, 'توضیحات بیش از حد طولانی است')
  .transform((s) => (s.length > 0 ? s : null));

const timestampSchema = z.number().int().nonnegative();

const tagsSchema = z
  .array(z.string().trim().min(1).max(30))
  .max(10)
  .transform((arr) => [...new Set(arr)]);

const checklistInputSchema = z.object({
  title: z.string().trim().min(1).max(200),
  isCompleted: z.boolean().default(false),
});

export const reminderInputSchema = z.object({
  offsetMinutes: z.number().int().min(0).max(525600),
  channel: z.enum(REMINDER_CHANNELS).default('notification'),
  enabled: z.boolean().default(true),
  repeatIntervalMinutes: z.number().int().min(1).nullable().optional(),
  maxRepeats: z.number().int().min(1).max(100).nullable().optional(),
});

export const recurrenceInputSchema = z.object({
  frequency: z.enum(RECURRENCE_FREQUENCIES),
  intervalCount: z.number().int().min(1).max(365).default(1),
  weekdays: z
    .array(z.number().int().min(0).max(6))
    .max(7)
    .transform((a) => [...new Set(a)].sort((x, y) => x - y))
    .optional(),
  endsAt: timestampSchema.nullable().optional(),
  maxOccurrences: z.number().int().min(1).nullable().optional(),
});

export const createTaskInputSchema = z.object({
  title: titleSchema,
  description: descriptionSchema.nullable().optional(),
  dueAt: timestampSchema.nullable().optional(),
  hasTime: z.boolean().default(false),
  priority: prioritySchema.default('medium'),
  categoryId: z.string().min(1).nullable().optional(),
  tags: tagsSchema.default([]),
  checklist: z.array(checklistInputSchema).max(50).default([]),
  reminders: z.array(reminderInputSchema).max(10).default([]),
  recurrence: recurrenceInputSchema.nullable().optional(),
});

export const updateTaskInputSchema = z.object({
  title: titleSchema.optional(),
  description: descriptionSchema.nullable().optional(),
  dueAt: timestampSchema.nullable().optional(),
  hasTime: z.boolean().optional(),
  priority: prioritySchema.optional(),
  categoryId: z.string().min(1).nullable().optional(),
  status: taskStatusSchema.optional(),
  snoozedUntil: timestampSchema.nullable().optional(),
  tags: tagsSchema.optional(),
  checklist: z.array(checklistInputSchema).max(50).optional(),
  reminders: z.array(reminderInputSchema).max(10).optional(),
  recurrence: recurrenceInputSchema.nullable().optional(),
});

export type CreateTaskInput = z.input<typeof createTaskInputSchema>;
export type UpdateTaskInput = z.input<typeof updateTaskInputSchema>;
export type ParsedRecurrence = z.output<typeof recurrenceInputSchema>;
