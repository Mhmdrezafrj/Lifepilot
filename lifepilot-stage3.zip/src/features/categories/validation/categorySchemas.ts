import { z } from 'zod';

const nameSchema = z.string().trim().min(1, 'نام دسته الزامی است').max(40, 'نام دسته بیش از حد طولانی است');
const colorSchema = z.string().regex(/^#[0-9A-Fa-f]{6}$/, 'رنگ نامعتبر است');

export const createCategoryInputSchema = z.object({
  name: nameSchema,
  color: colorSchema,
  icon: z.string().min(1).max(60).nullable().optional(),
});

export const updateCategoryInputSchema = z.object({
  name: nameSchema.optional(),
  color: colorSchema.optional(),
  icon: z.string().min(1).max(60).nullable().optional(),
});

export type CreateCategoryInput = z.input<typeof createCategoryInputSchema>;
export type UpdateCategoryInput = z.input<typeof updateCategoryInputSchema>;
