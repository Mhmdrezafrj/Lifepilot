import type { DbClient } from '../../../core/database/connection/types';

export interface SettingsRepository {
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
  remove(key: string): Promise<void>;
}

export function createSettingsRepository(db: DbClient, options: { now?: () => number } = {}): SettingsRepository {
  const now = options.now ?? (() => Date.now());
  return {
    async get(key) {
      const row = await db.getFirstAsync<{ value: string }>('SELECT value FROM app_settings WHERE key = ?', [key]);
      return row ? row.value : null;
    },
    async set(key, value) {
      await db.runAsync(
        `INSERT INTO app_settings (key, value, updated_at) VALUES (?, ?, ?)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
        [key, value, now()],
      );
    },
    async remove(key) {
      await db.runAsync('DELETE FROM app_settings WHERE key = ?', [key]);
    },
  };
}
