import { addDays, startOfDay } from '../../../core/calendar/dates';
import type { AccentKey } from '../../../core/theme/colors';
import { createRepositories } from '../../../providers/repositories';
import { SETTING_KEYS, parseAccent } from '../../settings/services/settingsKeys';
import { EXAM_DATE_KEY } from '../../study/services/studyService';
import { getDb } from './loadWidgetData';
import {
  SessionModel, StudyReviewModel, SubjectPill, buildSessionModel, buildStudyReviewModel, buildSubjectPills,
} from './studyWidgetModel';

export interface StudyWidgetData {
  review: StudyReviewModel;
  pills: SubjectPill[];
  session: SessionModel | null;
  accent: AccentKey;
}

/** Reads the study data from the real database (works when the app is closed). */
export async function loadStudyWidgetData(): Promise<StudyWidgetData> {
  const repos = createRepositories(await getDb());
  const now = Date.now();
  const [topics, reviews, blocks, examRaw, accent] = await Promise.all([
    repos.study.listTopics(),
    repos.study.listReviewsSince(addDays(startOfDay(new Date(now)), -60).getTime()),
    repos.blocks.list({ statuses: ['planned', 'running'] }),
    repos.settings.get(EXAM_DATE_KEY),
    repos.settings.get(SETTING_KEYS.accent),
  ]);
  const exam = examRaw !== null && Number.isFinite(Number(examRaw)) ? Number(examRaw) : null;
  return {
    review: buildStudyReviewModel(topics, reviews, exam, now),
    pills: buildSubjectPills(topics, now),
    session: buildSessionModel(blocks, now),
    accent: parseAccent(accent),
  };
}
