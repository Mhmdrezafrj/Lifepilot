import React from 'react';
import Constants from 'expo-constants';
import { PillsWidget } from '../components/PillsWidget';
import { QuickWidget } from '../components/QuickWidget';
import { StudyPillsWidget } from '../components/StudyPillsWidget';
import { StudyReviewWidget } from '../components/StudyReviewWidget';
import { StudySessionWidget } from '../components/StudySessionWidget';
import { TodayWidget } from '../components/TodayWidget';
import type { WidgetFonts } from '../components/widgetKit';
import { loadStudyWidgetData } from './loadStudyData';
import { loadWidgetData } from './loadWidgetData';
import { buildPillsModel } from './pillsModel';
import { blinkPhase, isRtlLocale, makeWidgetTheme } from './widgetStyle';

export const WIDGET_NAMES = {
  today: 'TodayWidget',
  quick: 'QuickWidget',
  pills: 'PillsWidget',
  studyReview: 'StudyReviewWidget',
  studyPills: 'StudyPillsWidget',
  studySession: 'StudySessionWidget',
} as const;

function detectHostRtl(): boolean {
  try {
    return isRtlLocale(new Intl.DateTimeFormat().resolvedOptions().locale);
  } catch {
    return false;
  }
}

/** Persian font files are bundled into the widget only when they were found at build time. */
function widgetFonts(): WidgetFonts {
  const extra = Constants.expoConfig?.extra as { widgetFonts?: boolean } | undefined;
  return extra?.widgetFonts ? { regular: 'Vazirmatn_400Regular', bold: 'Vazirmatn_700Bold' } : {};
}

/** Builds the widget picture from the real database. width is the widget width in dp, if known. */
export async function renderWidgetElement(name: string, width?: number): Promise<React.ReactElement | null> {
  const base = {
    width: width && width > 0 ? width : 300,
    hostRtl: detectHostRtl(),
    fonts: widgetFonts(),
    phase: blinkPhase(Date.now()),
  };

  if (name === WIDGET_NAMES.studyReview || name === WIDGET_NAMES.studyPills || name === WIDGET_NAMES.studySession) {
    const data = await loadStudyWidgetData();
    const common = { ...base, theme: makeWidgetTheme(data.accent) };
    if (name === WIDGET_NAMES.studyReview) return <StudyReviewWidget model={data.review} {...common} />;
    if (name === WIDGET_NAMES.studyPills) return <StudyPillsWidget pills={data.pills} total={data.review.dueCount} {...common} />;
    return <StudySessionWidget session={data.session} examDays={data.review.examDays} {...common} />;
  }

  const data = await loadWidgetData();
  const common = { ...base, theme: makeWidgetTheme(data.accent) };
  if (name === WIDGET_NAMES.today) return <TodayWidget model={data.today} {...common} />;
  if (name === WIDGET_NAMES.quick) return <QuickWidget model={data.quick} {...common} />;
  if (name === WIDGET_NAMES.pills) return <PillsWidget model={buildPillsModel(data.today)} {...common} />;
  return null;
}
