import { startOfDay } from '../../../core/calendar/dates';
import { formatDayLabel, formatTime } from '../../../core/calendar/format';
import type { StudyBlock } from '../../study/models/studyBlock';
import type { StudyTopic } from '../../study/models/study';
import { dueTopics, forecast } from '../../study/services/reviewQueue';
import { currentRun } from '../../study/services/blockPlanner';
import { daysUntil } from '../../study/services/srs';
import { studyStats } from '../../study/services/studyPlan';

export interface StudyReviewModel {
  dueCount: number;
  /** Reviews on each of the next 7 days (index 0 = today). */
  upcoming: number[];
  streakDays: number;
  /** Days until the exam, or null when not set / already passed. */
  examDays: number | null;
}

export function buildStudyReviewModel(
  topics: StudyTopic[],
  reviews: { reviewedAt: number; rating: number }[],
  exam: number | null,
  now: number,
): StudyReviewModel {
  const days = exam === null ? null : daysUntil(exam, now);
  return {
    dueCount: dueTopics(topics, now).length,
    upcoming: forecast(topics, now, 7),
    streakDays: studyStats(reviews, now).streakDays,
    examDays: days !== null && days >= 0 ? days : null,
  };
}

export interface SubjectPill {
  key: string;
  name: string;
  count: number;
}

/** Today's reviews grouped by subject, the biggest group first. */
export function buildSubjectPills(topics: StudyTopic[], now: number): SubjectPill[] {
  const groups = new Map<string, SubjectPill>();
  for (const t of dueTopics(topics, now)) {
    const key = t.subjectId ?? 'none';
    const g = groups.get(key) ?? { key, name: t.subjectName ?? 'بدون درس', count: 0 };
    g.count++;
    groups.set(key, g);
  }
  return [...groups.values()].sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}

export interface SessionModel {
  id: string;
  title: string;
  status: 'running' | 'planned';
  /** "امروز ۱۷:۰۰" */
  startLabel: string;
  steps: { title: string; minutes: number; done: boolean; current: boolean }[];
  /** While running: where the student is (as of the moment the widget was drawn). */
  run: { index: number; total: number; stepTitle: string; remainingMinutes: number } | null;
}

/** The running session, otherwise the next planned one from today on; null when there is none. */
export function buildSessionModel(blocks: StudyBlock[], now: number): SessionModel | null {
  const running = blocks.find((b) => b.status === 'running');
  const today = startOfDay(new Date(now)).getTime();
  const next = blocks
    .filter((b) => b.status === 'planned' && b.startAt >= today)
    .sort((a, b) => a.startAt - b.startAt)[0];
  const b = running ?? next;
  if (!b) return null;
  const r = currentRun(b, now);
  return {
    id: b.id,
    title: b.subjectName ?? b.title,
    status: running ? 'running' : 'planned',
    startLabel: `${formatDayLabel(new Date(b.startAt), new Date(now))} ${formatTime(new Date(b.startAt))}`,
    steps: b.steps.map((s, i) => ({ title: s.title, minutes: s.minutes, done: s.done, current: r !== null && i === r.index })),
    run: r ? { index: r.index, total: b.steps.length, stepTitle: r.title, remainingMinutes: Math.max(0, Math.ceil(r.remainingMs / 60_000)) } : null,
  };
}

export const studyLinks = {
  review: 'lifepilot://study/review',
  newSession: 'lifepilot://study/session-new',
  session: (id: string) => `lifepilot://study/session/${id}`,
};
