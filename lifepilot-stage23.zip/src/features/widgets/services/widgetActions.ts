import { InvalidOperationError } from '../../../core/errors';
import { createExpoNotificationGateway } from '../../../infrastructure/notifications/expoNotificationGateway';
import { createReminderScheduler } from '../../../infrastructure/notifications/reminderScheduler';
import { createRepositories } from '../../../providers/repositories';
import { createServices } from '../../../providers/services';
import { getDb } from './loadWidgetData';

/**
 * Called when the small square next to a task is tapped on a widget: marks the task done.
 * The real scheduler is used, so the task's reminders (and random extra reminders) are cancelled,
 * and the next occurrence of a repeating task is scheduled.
 */
export async function completeFromWidget(taskId: string): Promise<void> {
  const repos = createRepositories(await getDb());
  const scheduler = createReminderScheduler({ notifications: createExpoNotificationGateway() });
  const services = createServices(repos, { scheduler });
  try {
    await services.tasks.complete(taskId);
  } catch (e) {
    if (e instanceof InvalidOperationError) return; // already done
    throw e;
  }
}
