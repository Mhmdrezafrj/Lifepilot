import React from 'react';
import { FlexWidget, TextWidget } from 'react-native-android-widget';
import { toPersianDigits } from '../../../core/calendar/format';
import { SessionModel, studyLinks } from '../services/studyWidgetModel';
import { orderForHost, rgba } from '../services/widgetStyle';
import { WidgetRenderProps, st } from './widgetKit';

interface Props extends WidgetRenderProps {
  session: SessionModel | null;
  examDays: number | null;
}

/** The running (or next) study session with its steps, and the days left to the exam. */
export function StudySessionWidget({ session, examDays, theme, hostRtl, fonts }: Props) {
  const exam =
    examDays !== null ? (
      <FlexWidget key="exam" style={st({ paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12, backgroundColor: rgba('#7C8CFF', 0.95) })}>
        <TextWidget text={`🎯 ${toPersianDigits(examDays)} روز تا کنکور`} style={st({ fontSize: 12, fontWeight: 'bold', fontFamily: fonts.bold, color: '#0B0B0B' })} />
      </FlexWidget>
    ) : null;

  return (
    <FlexWidget
      clickAction="OPEN_URI"
      clickActionData={{ uri: session ? studyLinks.session(session.id) : studyLinks.newSession }}
      style={st({
        height: 'match_parent', width: 'match_parent', flexDirection: 'column', padding: 16, borderRadius: 30,
        backgroundGradient: { from: session?.status === 'running' ? '#14532D' : '#1E3A8A', to: '#05070F', orientation: 'TL_BR' },
      })}
    >
      {session === null ? (
        <FlexWidget style={st({ flex: 1, width: 'match_parent', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', flexGap: 6 })}>
          <TextWidget text="⏱️" style={st({ fontSize: 34, color: '#FFFFFF' })} />
          <TextWidget text="جلسه‌ای برنامه‌ریزی نشده" style={st({ fontSize: 16, fontWeight: 'bold', fontFamily: fonts.bold, color: '#FFFFFF' })} />
          <TextWidget text="برای ساختن جلسه‌ی مطالعه اینجا بزنید" style={st({ fontSize: 12, fontFamily: fonts.regular, color: theme.muted })} />
          {exam}
        </FlexWidget>
      ) : (
        <>
          <FlexWidget style={st({ width: 'match_parent', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' })}>
            {orderForHost(
              [
                <TextWidget key="t" text={`${session.status === 'running' ? '▶ ' : '⏰ '}${session.title}`} style={st({ fontSize: 22, fontWeight: 'bold', fontFamily: fonts.bold, color: '#FFFFFF' })} />,
                exam ?? <FlexWidget key="e" style={st({ width: 1, height: 1 })} />,
              ],
              hostRtl,
            )}
          </FlexWidget>
          <TextWidget
            text={
              session.run
                ? `مرحله‌ی ${toPersianDigits(session.run.index + 1)} از ${toPersianDigits(session.run.total)} · ${toPersianDigits(session.run.remainingMinutes)} دقیقه مانده`
                : session.startLabel
            }
            style={st({ fontSize: 14, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right', color: session.run ? '#4ADE80' : '#FFD166', marginTop: 2 })}
          />
          {session.steps.slice(0, 5).map((s, i) => (
            <FlexWidget
              key={i}
              style={st({
                width: 'match_parent', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 6,
                paddingHorizontal: 12, paddingVertical: 7, borderRadius: 14,
                backgroundColor: s.current ? rgba('#4ADE80', 0.35) : rgba('#FFFFFF', 0.08),
              })}
            >
              {orderForHost(
                [
                  <TextWidget key="a" text={`${s.done ? '✓' : s.current ? '▶' : '○'} ${s.title}`} style={st({ fontSize: 14, fontWeight: s.current ? 'bold' : 'normal', fontFamily: s.current ? fonts.bold : fonts.regular, color: s.done ? theme.muted : '#FFFFFF' })} />,
                  <TextWidget key="b" text={`${toPersianDigits(s.minutes)} د`} style={st({ fontSize: 13, fontFamily: fonts.regular, color: theme.muted })} />,
                ],
                hostRtl,
              )}
            </FlexWidget>
          ))}
        </>
      )}
    </FlexWidget>
  );
}
