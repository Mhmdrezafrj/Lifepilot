import React from 'react';
import { FlexWidget, TextWidget } from 'react-native-android-widget';
import { toPersianDigits } from '../../../core/calendar/format';
import { StudyReviewModel, studyLinks } from '../services/studyWidgetModel';
import { orderForHost, rgba } from '../services/widgetStyle';
import { WidgetRenderProps, st } from './widgetKit';

interface Props extends WidgetRenderProps {
  model: StudyReviewModel;
}

/** A big number (today's reviews), the next 7 days as bars, the streak and the days to the exam. */
export function StudyReviewWidget({ model, theme, hostRtl, fonts }: Props) {
  const max = Math.max(1, ...model.upcoming);

  const number = (
    <FlexWidget key="num" style={st({ flexDirection: 'column' })}>
      <TextWidget
        text={toPersianDigits(model.dueCount)}
        style={st({ fontSize: 60, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right', color: model.dueCount > 0 ? '#F2F230' : '#22D45E' })}
      />
      <TextWidget
        text={model.dueCount > 0 ? 'مبحث برای مرور امروز' : 'مرور امروز تمام شد 🎉'}
        style={st({ fontSize: 14, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right', color: '#FFFFFF' })}
      />
      <FlexWidget style={st({ flexDirection: 'row', flexGap: 8, marginTop: 6 })}>
        {orderForHost(
          [
            model.streakDays > 0 ? (
              <FlexWidget key="s" style={st({ paddingHorizontal: 9, paddingVertical: 4, borderRadius: 12, backgroundColor: rgba('#FF7A2F', 0.9) })}>
                <TextWidget text={`🔥 ${toPersianDigits(model.streakDays)} روز`} style={st({ fontSize: 12, fontWeight: 'bold', fontFamily: fonts.bold, color: '#0B0B0B' })} />
              </FlexWidget>
            ) : (
              <FlexWidget key="s" style={st({ width: 1, height: 1 })} />
            ),
            model.examDays !== null ? (
              <FlexWidget key="e" style={st({ paddingHorizontal: 9, paddingVertical: 4, borderRadius: 12, backgroundColor: rgba('#7C8CFF', 0.95) })}>
                <TextWidget text={`🎯 ${toPersianDigits(model.examDays)} روز تا کنکور`} style={st({ fontSize: 12, fontWeight: 'bold', fontFamily: fonts.bold, color: '#0B0B0B' })} />
              </FlexWidget>
            ) : (
              <FlexWidget key="e" style={st({ width: 1, height: 1 })} />
            ),
          ],
          hostRtl,
        )}
      </FlexWidget>
    </FlexWidget>
  );

  const bars = (
    <FlexWidget key="bars" style={st({ flexDirection: 'row', alignItems: 'flex-end', flexGap: 6 })}>
      {orderForHost(
        model.upcoming.map((n, i) => (
          <FlexWidget key={i} style={st({ flexDirection: 'column', alignItems: 'center', flexGap: 3 })}>
            <TextWidget text={toPersianDigits(n)} style={st({ fontSize: 11, fontFamily: fonts.regular, color: '#9AA3B2' })} />
            <FlexWidget style={st({ width: 14, height: Math.max(6, Math.round((n / max) * 52)), borderRadius: 7, backgroundColor: i === 0 ? '#F2F230' : '#7C8CFF' })} />
          </FlexWidget>
        )),
        hostRtl,
      )}
    </FlexWidget>
  );

  return (
    <FlexWidget
      clickAction="OPEN_URI"
      clickActionData={{ uri: studyLinks.review }}
      style={st({
        height: 'match_parent', width: 'match_parent', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
        padding: 16, borderRadius: 30, backgroundGradient: { from: '#1B2340', to: '#05070F', orientation: 'TL_BR' },
      })}
    >
      {orderForHost([number, bars], hostRtl)}
    </FlexWidget>
  );
}
