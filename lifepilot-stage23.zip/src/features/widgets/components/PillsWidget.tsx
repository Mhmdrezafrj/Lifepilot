import React from 'react';
import { FlexWidget, ListWidget, TextWidget } from 'react-native-android-widget';
import { toPersianDigits } from '../../../core/calendar/format';
import { PILL_TEXT, PillItem, PillsModel } from '../services/pillsModel';
import { widgetLinks } from '../services/widgetModel';
import { orderForHost, rgba } from '../services/widgetStyle';
import { WidgetRenderProps, st } from './widgetKit';

interface Props extends WidgetRenderProps {
  model: PillsModel;
}

function Pill({ item, hostRtl, fonts }: { item: PillItem } & Pick<WidgetRenderProps, 'hostRtl' | 'fonts'>) {
  // The small square: tapping it completes the task and it disappears from the widget.
  const check = (
    <FlexWidget
      key="check"
      clickAction="COMPLETE_TASK"
      clickActionData={{ id: item.id }}
      accessibilityLabel="انجام شد"
      style={st({ width: 42, height: 42, alignItems: 'center', justifyContent: 'center' })}
    >
      <FlexWidget style={st({ width: 26, height: 26, borderRadius: 8, borderWidth: 3, borderColor: PILL_TEXT, backgroundColor: rgba('#FFFFFF', 0.35) })} />
    </FlexWidget>
  );
  const title = (
    <FlexWidget key="title" style={st({ flex: 1 })}>
      <TextWidget
        text={item.title}
        style={st({ fontSize: 21, fontWeight: 'bold', fontFamily: fonts.bold, color: PILL_TEXT, textAlign: 'right' })}
      />
    </FlexWidget>
  );
  const trailing = (
    <TextWidget key="trail" text={item.trailing} style={st({ fontSize: 18, fontWeight: 'bold', fontFamily: fonts.bold, color: PILL_TEXT })} />
  );
  return (
    <FlexWidget
      clickAction="OPEN_URI"
      clickActionData={{ uri: widgetLinks.task(item.id) }}
      style={st({
        width: 'match_parent', flexDirection: 'row', alignItems: 'center', flexGap: 8,
        paddingHorizontal: 14, paddingVertical: 9, marginTop: 8, borderRadius: 34, backgroundColor: item.color,
      })}
    >
      {orderForHost([check, title, trailing], hostRtl)}
    </FlexWidget>
  );
}

/** Big, bright, rounded rows on black: one pill per task, with a square to tick it off. */
export function PillsWidget({ model, hostRtl, fonts }: Props) {
  const head = (
    <FlexWidget key="head" style={st({ flexDirection: 'column' })}>
      <TextWidget text={model.weekday} style={st({ fontSize: 13, fontFamily: fonts.regular, textAlign: 'right', color: '#9AA3B2' })} />
      <TextWidget text={model.dateLabel} style={st({ fontSize: 26, fontWeight: 'bold', fontFamily: fonts.bold, textAlign: 'right', color: '#FFFFFF' })} />
    </FlexWidget>
  );
  const plus = (
    <FlexWidget
      key="plus"
      clickAction="OPEN_URI"
      clickActionData={{ uri: widgetLinks.newTask(model.todayStart) }}
      accessibilityLabel="افزودن کار جدید"
      style={st({ width: 50, height: 50, borderRadius: 25, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFFFFF' })}
    >
      <TextWidget text="+" style={st({ fontSize: 34, fontWeight: 'bold', color: '#000000' })} />
    </FlexWidget>
  );

  return (
    <FlexWidget style={st({ height: 'match_parent', width: 'match_parent', flexDirection: 'column', padding: 12, borderRadius: 32, backgroundColor: '#000000' })}>
      <FlexWidget style={st({ width: 'match_parent', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 4 })}>
        {orderForHost([head, plus], hostRtl)}
      </FlexWidget>
      <TextWidget
        text={model.total === 0 ? 'برای امروز کاری ثبت نشده' : `${toPersianDigits(model.done)} از ${toPersianDigits(model.total)} انجام شد`}
        style={st({ fontSize: 13, fontFamily: fonts.regular, textAlign: 'right', color: '#9AA3B2', marginTop: 2, marginRight: 4 })}
      />
      {model.items.length === 0 ? (
        <FlexWidget
          clickAction="OPEN_URI"
          clickActionData={{ uri: widgetLinks.newTask(model.todayStart) }}
          style={st({ flex: 1, width: 'match_parent', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' })}
        >
          <TextWidget text={model.total > 0 ? '🎉' : '✨'} style={st({ fontSize: 40, color: '#FFFFFF' })} />
          <TextWidget
            text={model.total > 0 ? 'همه‌ی کارهای امروز انجام شد' : 'برای ساختن اولین کار، اینجا بزنید'}
            style={st({ fontSize: 16, fontWeight: 'bold', fontFamily: fonts.bold, color: '#FFFFFF', marginTop: 6 })}
          />
        </FlexWidget>
      ) : (
        <ListWidget style={st({ height: 'match_parent', width: 'match_parent' })}>
          {model.items.map((item) => (
            <Pill key={item.id} item={item} hostRtl={hostRtl} fonts={fonts} />
          ))}
        </ListWidget>
      )}
    </FlexWidget>
  );
}
