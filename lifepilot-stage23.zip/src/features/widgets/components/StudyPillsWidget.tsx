import React from 'react';
import { FlexWidget, ListWidget, TextWidget } from 'react-native-android-widget';
import { toPersianDigits } from '../../../core/calendar/format';
import { PILL_TEXT, pillColor } from '../services/pillsModel';
import { SubjectPill, studyLinks } from '../services/studyWidgetModel';
import { orderForHost } from '../services/widgetStyle';
import { WidgetRenderProps, st } from './widgetKit';

interface Props extends WidgetRenderProps {
  pills: SubjectPill[];
  total: number;
}

/** One big colourful pill per subject with today's number of reviews. */
export function StudyPillsWidget({ pills, total, hostRtl, fonts }: Props) {
  return (
    <FlexWidget
      clickAction="OPEN_URI"
      clickActionData={{ uri: studyLinks.review }}
      style={st({ height: 'match_parent', width: 'match_parent', flexDirection: 'column', padding: 12, borderRadius: 32, backgroundColor: '#000000' })}
    >
      <FlexWidget style={st({ width: 'match_parent', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 4 })}>
        {orderForHost(
          [
            <TextWidget key="t" text="مرور امروز" style={st({ fontSize: 24, fontWeight: 'bold', fontFamily: fonts.bold, color: '#FFFFFF' })} />,
            <TextWidget key="n" text={toPersianDigits(total)} style={st({ fontSize: 30, fontWeight: 'bold', fontFamily: fonts.bold, color: '#F2F230' })} />,
          ],
          hostRtl,
        )}
      </FlexWidget>
      {pills.length === 0 ? (
        <FlexWidget style={st({ flex: 1, width: 'match_parent', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' })}>
          <TextWidget text="🎉" style={st({ fontSize: 40, color: '#FFFFFF' })} />
          <TextWidget text="مرور امروز تمام شد" style={st({ fontSize: 16, fontWeight: 'bold', fontFamily: fonts.bold, color: '#FFFFFF', marginTop: 6 })} />
        </FlexWidget>
      ) : (
        <ListWidget style={st({ height: 'match_parent', width: 'match_parent' })}>
          {pills.map((p, i) => (
            <FlexWidget
              key={p.key}
              clickAction="OPEN_URI"
              clickActionData={{ uri: studyLinks.review }}
              style={st({
                width: 'match_parent', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
                paddingHorizontal: 20, paddingVertical: 14, marginTop: 8, borderRadius: 34, backgroundColor: pillColor(i),
              })}
            >
              {orderForHost(
                [
                  <TextWidget key="n" text={p.name} style={st({ fontSize: 22, fontWeight: 'bold', fontFamily: fonts.bold, color: PILL_TEXT })} />,
                  <TextWidget key="c" text={toPersianDigits(p.count)} style={st({ fontSize: 22, fontWeight: 'bold', fontFamily: fonts.bold, color: PILL_TEXT })} />,
                ],
                hostRtl,
              )}
            </FlexWidget>
          ))}
        </ListWidget>
      )}
    </FlexWidget>
  );
}
