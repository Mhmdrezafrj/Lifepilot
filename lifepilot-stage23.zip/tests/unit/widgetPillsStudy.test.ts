import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { Task } from '../../src/features/tasks/models/task';
import type { StudyTopic } from '../../src/features/study/models/study';
import type { StudyBlock } from '../../src/features/study/models/studyBlock';
import { buildTodayModel } from '../../src/features/widgets/services/widgetModel';
import { PILL_COLORS, buildPillsModel, pillColor } from '../../src/features/widgets/services/pillsModel';
import { buildSessionModel, buildStudyReviewModel, buildSubjectPills, studyLinks } from '../../src/features/widgets/services/studyWidgetModel';

const NOW = new Date(2026, 10, 5, 12, 0).getTime();
const at = (d: number, h = 0, m = 0) => new Date(2026, 10, d, h, m).getTime();
const task = (over: Partial<Task>): Task => ({
  id: 'x', title: 'x', description: null, dueAt: null, hasTime: false, priority: 'medium', categoryId: null,
  status: 'pending', snoozedUntil: null, createdAt: 0, updatedAt: 0, completedAt: null, recurrenceId: null,
  tags: [], checklist: [], reminders: [], recurrence: null, ...over,
});
const topic = (id: string, over: Partial<StudyTopic> = {}): StudyTopic => ({
  id, materialId: 'm', title: id, learnedAt: 0, dueAt: at(5), intervalDays: 1, ease: 2.5, repetitions: 0, lapses: 0,
  lastReviewedAt: null, suspended: false, createdAt: 0, materialTitle: 'کتاب', materialKind: 'book',
  subjectId: 's1', subjectName: 'ریاضی', subjectColor: '#4F46E5', ...over,
});

describe('pill widget model', () => {
  it('shows only pending tasks, with distinct neighbouring colours and the time at the end', () => {
    const tasks = [
      task({ id: 'a', title: 'الف', dueAt: at(5, 9), hasTime: true, status: 'completed' }),
      task({ id: 'b', title: 'ب', dueAt: at(5, 18), hasTime: true }),
      task({ id: 'c', title: 'ج', dueAt: at(5) }),
      task({ id: 'd', title: 'د', dueAt: at(5, 20), hasTime: true }),
    ];
    const m = buildPillsModel(buildTodayModel(tasks, tasks.filter((t) => t.status === 'pending'), NOW));
    assert.deepEqual(m.items.map((i) => i.id), ['c', 'b', 'd']);
    assert.deepEqual(m.items.map((i) => i.trailing), ['همه‌روز', '۱۸:۰۰', '۲۰:۰۰']);
    for (let i = 1; i < m.items.length; i++) assert.notEqual(m.items[i].color, m.items[i - 1].color);
    assert.equal(m.done, 1);
    assert.equal(m.total, 4);
  });

  it('marks urgent tasks with a flame and never shows finished ones', () => {
    const tasks = [task({ id: 'o', title: 'قدیمی', dueAt: at(5, 8), hasTime: true }), task({ id: 'd', status: 'completed', dueAt: at(5) })];
    const m = buildPillsModel(buildTodayModel(tasks, [tasks[0]], NOW));
    assert.equal(m.items.length, 1);
    assert.ok(m.items[0].title.startsWith('🔥'));
  });

  it('cycles through the palette', () => {
    assert.equal(pillColor(0), PILL_COLORS[0]);
    assert.equal(pillColor(PILL_COLORS.length), PILL_COLORS[0]);
    assert.equal(pillColor(-1), PILL_COLORS[PILL_COLORS.length - 1]);
  });
});

describe('study widget models', () => {
  it('review widget: due count, 7-day forecast, streak, exam days', () => {
    const topics = [topic('a'), topic('b'), topic('c', { dueAt: at(7) }), topic('d', { suspended: true })];
    const reviews = [{ reviewedAt: at(5, 9), rating: 2 }, { reviewedAt: at(4, 9), rating: 3 }];
    const m = buildStudyReviewModel(topics, reviews, at(25), NOW);
    assert.equal(m.dueCount, 2);
    assert.deepEqual(m.upcoming, [2, 0, 1, 0, 0, 0, 0]);
    assert.equal(m.streakDays, 2);
    assert.equal(m.examDays, 20);
    assert.equal(buildStudyReviewModel([], [], null, NOW).examDays, null);
    assert.equal(buildStudyReviewModel([], [], at(1), NOW).examDays, null); // exam already passed
  });

  it('subject pills: counts of today\'s reviews per subject, biggest first', () => {
    const topics = [
      topic('a'), topic('b', { subjectId: 's2', subjectName: 'فیزیک' }), topic('c', { subjectId: 's2', subjectName: 'فیزیک' }),
      topic('d', { subjectId: null, subjectName: null }), topic('e', { dueAt: at(9) }),
    ];
    assert.deepEqual(buildSubjectPills(topics, NOW).map((p) => [p.name, p.count]), [['فیزیک', 2], ['بدون درس', 1], ['ریاضی', 1]].sort((x, y) => (y[1] as number) - (x[1] as number) || String(x[0]).localeCompare(String(y[0]))));
    assert.deepEqual(buildSubjectPills([], NOW), []);
  });

  const block = (over: Partial<StudyBlock>): StudyBlock => ({
    id: 'b1', subjectId: 's', subjectName: 'شیمی', subjectColor: '#22C55E', title: 'جلسه', startAt: at(17), status: 'planned',
    currentStep: 0, stepStartedAt: null, startedAt: null, finishedAt: null, createdAt: 0,
    steps: [{ id: '1', title: 'هدف', minutes: 5, sortOrder: 0, done: false }, { id: '2', title: 'یادگیری', minutes: 25, sortOrder: 1, done: false }],
    ...over,
  });

  it('session widget: the running session wins, otherwise the next planned one', () => {
    const run = block({ id: 'r', status: 'running', currentStep: 1, stepStartedAt: at(5, 11, 50) });
    const later = block({ id: 'p', startAt: at(18) });
    const earlier = block({ id: 'e', startAt: at(16) });
    const m = buildSessionModel([later, earlier, run], NOW);
    assert.equal(m?.id, 'r');
    assert.equal(m?.status, 'running');
    assert.equal(m?.run?.stepTitle, 'یادگیری');
    assert.equal(m?.run?.remainingMinutes, 15);
    assert.deepEqual(m?.steps.map((s) => s.current), [false, true]);
    assert.equal(buildSessionModel([later, earlier], NOW)?.id, 'e');
    assert.equal(buildSessionModel([later, earlier], NOW)?.run, null);
  });

  it('session widget: nothing planned, cancelled or finished sessions, and past days are ignored', () => {
    assert.equal(buildSessionModel([], NOW), null);
    assert.equal(buildSessionModel([block({ status: 'done' }), block({ status: 'cancelled' })], NOW), null);
    assert.equal(buildSessionModel([block({ startAt: new Date(2026, 10, 3, 9).getTime() })], NOW), null);
  });

  it('deep links open the study screens', () => {
    assert.equal(studyLinks.review, 'lifepilot://study/review');
    assert.equal(studyLinks.session('x'), 'lifepilot://study/session/x');
  });
});
