import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  AiError, DEEPSEEK_ENDPOINT, DEFAULT_MODEL, FetchLike, buildMessages, describeHttpError, estimateMinutes, maskKey,
  parseBreakdown, requestBreakdown, stepToTitle,
} from '../../src/features/ai/services/breakdown';

const ok = (content: string): FetchLike => async () => ({
  ok: true, status: 200, text: async () => JSON.stringify({ choices: [{ message: { content } }] }),
});
const fail = (status: number, body = ''): FetchLike => async () => ({ ok: false, status, text: async () => body });

describe('parsing the answer', () => {
  it('reads a plain JSON object', () => {
    const steps = parseBreakdown('{"steps":[{"title":"جمع کردن زباله","minutes":5},{"title":"مرتب کردن میز","minutes":10}]}');
    assert.deepEqual(steps, [{ title: 'جمع کردن زباله', minutes: 5 }, { title: 'مرتب کردن میز', minutes: 10 }]);
  });

  it('accepts a code fence, text around it, numbering and a bare array', () => {
    assert.equal(parseBreakdown('بفرمایید:\n```json\n{"steps":[{"title":"1. شروع","minutes":3}]}\n```').at(0)?.title, 'شروع');
    assert.equal(parseBreakdown('[{"title":"الف","minutes":2}]').length, 1);
  });

  it('cleans minutes: Persian digits, strings, bounds and defaults', () => {
    const s = parseBreakdown('{"steps":[{"title":"a","minutes":"۱۰"},{"title":"b","minutes":999},{"title":"c","minutes":0},{"title":"d"}]}');
    assert.deepEqual(s.map((x) => x.minutes), [10, 120, 5, 5]);
  });

  it('limits to 10 steps and skips empty titles', () => {
    const many = JSON.stringify({ steps: Array.from({ length: 15 }, (_, i) => ({ title: i === 2 ? ' ' : `قدم ${i}`, minutes: 5 })) });
    const s = parseBreakdown(many);
    assert.equal(s.length, 10);
    assert.ok(s.every((x) => x.title.trim()));
  });

  it('throws a Persian error for unusable answers', () => {
    for (const bad of ['', 'متن بدون JSON', '{"steps":[]}', '{"steps":"x"}', '{broken']) {
      assert.throws(() => parseBreakdown(bad), (e: unknown) => e instanceof AiError && e.kind === 'format', bad);
    }
  });
});

describe('checklist titles and time', () => {
  it('writes a step with its time and adds the times up', () => {
    assert.equal(stepToTitle({ title: 'مرتب کردن میز', minutes: 10 }), 'مرتب کردن میز (۱۰ دقیقه)');
    assert.equal(estimateMinutes(['الف (۵ دقیقه)', 'ب (۱۰ دقیقه)', 'بدون زمان', 'ج (15 دقیقه)']), 30);
    assert.equal(estimateMinutes([]), 0);
  });

  it('masks keys', () => {
    assert.equal(maskKey('sk-abcdef1234567890'), 'sk-••••7890');
    assert.equal(maskKey('short'), '••••');
  });
});

describe('the request', () => {
  it('sends the key, model, JSON mode and the task to DeepSeek', async () => {
    let seen: { url: string; headers: Record<string, string>; body: Record<string, unknown> } | null = null;
    const fetchFn: FetchLike = async (url, init) => {
      seen = { url, headers: init.headers, body: JSON.parse(init.body) };
      return { ok: true, status: 200, text: async () => JSON.stringify({ choices: [{ message: { content: '{"steps":[{"title":"شروع","minutes":5}]}' } }] }) };
    };
    const steps = await requestBreakdown({ title: 'تمیز کردن اتاق', apiKey: 'sk-test', fetchFn });
    assert.equal(steps.length, 1);
    assert.equal(seen!.url, DEEPSEEK_ENDPOINT);
    assert.equal(seen!.headers.Authorization, 'Bearer sk-test');
    assert.equal(seen!.body.model, DEFAULT_MODEL);
    assert.deepEqual(seen!.body.response_format, { type: 'json_object' });
    assert.ok(JSON.stringify(seen!.body.messages).includes('تمیز کردن اتاق'));
    assert.ok(JSON.stringify(seen!.body.messages).includes('JSON'));
  });

  it('uses the chosen model and includes the description', async () => {
    let body: Record<string, unknown> = {};
    await requestBreakdown({
      title: 'x', description: 'جزئیات مهم', apiKey: 'k', model: 'my-model',
      fetchFn: async (_u, init) => { body = JSON.parse(init.body); return { ok: true, status: 200, text: async () => JSON.stringify({ choices: [{ message: { content: '{"steps":[{"title":"a","minutes":1}]}' } }] }) }; },
    });
    assert.equal(body.model, 'my-model');
    assert.ok(buildMessages('x', 'جزئیات مهم')[1].content.includes('جزئیات مهم'));
  });

  it('requires a key and a title', async () => {
    await assert.rejects(() => requestBreakdown({ title: 'x', apiKey: null, fetchFn: ok('{}') }), (e: unknown) => e instanceof AiError && e.kind === 'no-key');
    await assert.rejects(() => requestBreakdown({ title: '  ', apiKey: 'k', fetchFn: ok('{}') }), AiError);
  });

  it('turns HTTP problems into clear messages', async () => {
    const cases: [number, string][] = [[401, 'auth'], [402, 'quota'], [429, 'rate'], [500, 'server'], [503, 'server'], [400, 'request'], [404, 'request']];
    for (const [status, kind] of cases) {
      await assert.rejects(() => requestBreakdown({ title: 'x', apiKey: 'k', fetchFn: fail(status) }), (e: unknown) => e instanceof AiError && e.kind === kind, String(status));
    }
    const e = describeHttpError(400, '{"error":{"message":"Model Not Exist"}}');
    assert.ok(e.message.includes('Model Not Exist'));
  });

  it('reports network failures and timeouts', async () => {
    await assert.rejects(
      () => requestBreakdown({ title: 'x', apiKey: 'k', fetchFn: async () => { throw new Error('offline'); } }),
      (e: unknown) => e instanceof AiError && e.kind === 'network',
    );
    await assert.rejects(
      () => requestBreakdown({
        title: 'x', apiKey: 'k', timeoutMs: 20,
        fetchFn: (_u, init) => new Promise((_res, rej) => { init.signal?.addEventListener('abort', () => rej(new Error('aborted'))); }),
      }),
      (e: unknown) => e instanceof AiError && e.kind === 'timeout',
    );
  });

  it('rejects answers that are not the expected shape', async () => {
    await assert.rejects(() => requestBreakdown({ title: 'x', apiKey: 'k', fetchFn: async () => ({ ok: true, status: 200, text: async () => 'not json' }) }), (e: unknown) => e instanceof AiError && e.kind === 'format');
    await assert.rejects(() => requestBreakdown({ title: 'x', apiKey: 'k', fetchFn: ok('hello') }), AiError);
  });
});
