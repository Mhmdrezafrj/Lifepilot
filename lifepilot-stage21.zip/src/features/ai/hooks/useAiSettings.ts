import { useCallback, useEffect, useState } from 'react';
import * as SecureStore from 'expo-secure-store';
import { useRepositories } from '@/providers/DatabaseProvider';
import { DEFAULT_MODEL } from '../services/breakdown';

const KEY_NAME = 'deepseek_api_key';
const MODEL_KEY = 'ai_model';
const CONSENT_KEY = 'ai_consent';

/** The DeepSeek key (stored encrypted on the phone), the model name, and whether the user agreed to send task titles. */
export function useAiSettings() {
  const repo = useRepositories().settings;
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [model, setModelState] = useState(DEFAULT_MODEL);
  const [consent, setConsent] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [k, m, c] = await Promise.all([SecureStore.getItemAsync(KEY_NAME), repo.get(MODEL_KEY), repo.get(CONSENT_KEY)]);
        if (!cancelled) {
          setApiKey(k && k.trim() ? k : null);
          setModelState(m && m.trim() ? m : DEFAULT_MODEL);
          setConsent(c === 'yes');
        }
      } catch {
        /* keep defaults */
      }
      if (!cancelled) setLoaded(true);
    })();
    return () => {
      cancelled = true;
    };
  }, [repo]);

  const saveKey = useCallback(async (key: string) => {
    await SecureStore.setItemAsync(KEY_NAME, key.trim());
    setApiKey(key.trim());
  }, []);
  const deleteKey = useCallback(async () => {
    await SecureStore.deleteItemAsync(KEY_NAME);
    setApiKey(null);
  }, []);
  const saveModel = useCallback(
    async (m: string) => {
      const clean = m.trim() || DEFAULT_MODEL;
      await repo.set(MODEL_KEY, clean);
      setModelState(clean);
    },
    [repo],
  );
  const giveConsent = useCallback(async () => {
    await repo.set(CONSENT_KEY, 'yes');
    setConsent(true);
  }, [repo]);

  return { apiKey, model, consent, loaded, saveKey, deleteKey, saveModel, giveConsent };
}
