import { toPersianDigits } from '../../../core/calendar/format';

export const DEEPSEEK_ENDPOINT = 'https://api.deepseek.com/chat/completions';
export const DEFAULT_MODEL = 'deepseek-chat';
const MAX_STEPS = 10;

export interface BreakdownStep {
  title: string;
  minutes: number;
}

export type AiErrorKind = 'no-key' | 'auth' | 'quota' | 'rate' | 'request' | 'server' | 'network' | 'timeout' | 'format';

export class AiError extends Error {
  constructor(readonly kind: AiErrorKind, message: string) {
    super(message);
    this.name = 'AiError';
  }
}

const SYSTEM_PROMPT =
  'تو دستیار برنامه‌ریزی هستی. کاربر یک کار را می‌گوید و تو آن را به ۳ تا ۸ قدم کوچک، مشخص و قابل انجام تقسیم می‌کنی ' +
  'تا شروع کار ترسناک نباشد. هر قدم کوتاه است (حداکثر ۸ کلمه)، با یک فعل شروع می‌شود و به ترتیب اجرا مرتب است. ' +
  'برای هر قدم زمان واقع‌بینی بر حسب دقیقه (۱ تا ۶۰) بده. عنوان‌ها به زبان همان کار (فارسی) باشند. ' +
  'فقط یک شیء JSON برگردان با این ساختار و هیچ متن دیگری ننویس: {"steps":[{"title":"...","minutes":5}]}';

export function buildMessages(title: string, description?: string): { role: 'system' | 'user'; content: string }[] {
  const extra = description && description.trim() ? `\nتوضیحات: ${description.trim()}` : '';
  return [
    { role: 'system', content: SYSTEM_PROMPT },
    { role: 'user', content: `کار: ${title.trim()}${extra}` },
  ];
}

const toAscii = (s: string) => s.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));

/** Reads the model's answer (JSON, possibly inside a code fence) into clean steps. */
export function parseBreakdown(text: string): BreakdownStep[] {
  const fenced = text.replace(/```(?:json)?/gi, '');
  const start = fenced.search(/[{[]/);
  const end = Math.max(fenced.lastIndexOf('}'), fenced.lastIndexOf(']'));
  if (start < 0 || end <= start) throw new AiError('format', 'پاسخ هوش مصنوعی قابل فهم نبود. دوباره تلاش کنید.');
  let data: unknown;
  try {
    data = JSON.parse(fenced.slice(start, end + 1));
  } catch {
    throw new AiError('format', 'پاسخ هوش مصنوعی قابل فهم نبود. دوباره تلاش کنید.');
  }
  const list = Array.isArray(data) ? data : (data as { steps?: unknown }).steps;
  if (!Array.isArray(list)) throw new AiError('format', 'پاسخ هوش مصنوعی قابل فهم نبود. دوباره تلاش کنید.');

  const steps: BreakdownStep[] = [];
  for (const item of list) {
    const o = item as { title?: unknown; minutes?: unknown };
    if (typeof o?.title !== 'string') continue;
    const title = o.title.replace(/^\s*(?:[-•*]|[\d۰-۹]+[.)])\s*/, '').trim().slice(0, 80);
    if (!title) continue;
    const m = typeof o.minutes === 'number' ? o.minutes : Number(toAscii(String(o.minutes ?? '')));
    steps.push({ title, minutes: Number.isFinite(m) && m > 0 ? Math.min(120, Math.max(1, Math.round(m))) : 5 });
    if (steps.length >= MAX_STEPS) break;
  }
  if (steps.length === 0) throw new AiError('format', 'هوش مصنوعی قدمی پیشنهاد نداد. دوباره تلاش کنید.');
  return steps;
}

/** A checklist line such as "مرتب کردن لباس‌ها (۱۰ دقیقه)". */
export function stepToTitle(s: BreakdownStep): string {
  return `${s.title} (${toPersianDigits(s.minutes)} دقیقه)`;
}

/** Total minutes written at the end of checklist titles; lines without a time count as 0. */
export function estimateMinutes(titles: string[]): number {
  let total = 0;
  for (const t of titles) {
    const m = toAscii(t).match(/\((\d+) دقیقه\)\s*$/);
    if (m) total += Number(m[1]);
  }
  return total;
}

function serverMessage(body: string): string {
  try {
    const m = (JSON.parse(body) as { error?: { message?: unknown } }).error?.message;
    return typeof m === 'string' ? m.slice(0, 160) : '';
  } catch {
    return '';
  }
}

export function describeHttpError(status: number, body: string): AiError {
  if (status === 401 || status === 403) return new AiError('auth', 'کلید API نامعتبر یا منقضی است. آن را در تنظیمات بررسی کنید.');
  if (status === 402) return new AiError('quota', 'اعتبار حساب DeepSeek تمام شده است. حساب را شارژ کنید.');
  if (status === 429) return new AiError('rate', 'تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره تلاش کنید.');
  if (status >= 500) return new AiError('server', 'سرور DeepSeek در حال حاضر پاسخ نمی‌دهد. بعداً دوباره تلاش کنید.');
  const detail = serverMessage(body);
  return new AiError('request', `درخواست پذیرفته نشد (${status})${detail ? `: ${detail}` : ''}. نام مدل را در تنظیمات بررسی کنید.`);
}

/** The small part of fetch that is used (so tests can fake it). */
export type FetchLike = (
  url: string,
  init: { method: string; headers: Record<string, string>; body: string; signal?: AbortSignal },
) => Promise<{ ok: boolean; status: number; text(): Promise<string> }>;

export interface BreakdownRequest {
  title: string;
  description?: string;
  apiKey: string | null;
  model?: string;
  fetchFn: FetchLike;
  timeoutMs?: number;
}

/** Asks DeepSeek to split a task into small timed steps. Throws AiError with a Persian message. */
export async function requestBreakdown(r: BreakdownRequest): Promise<BreakdownStep[]> {
  if (!r.apiKey) throw new AiError('no-key', 'ابتدا کلید API را در تنظیمات ← هوش مصنوعی وارد کنید.');
  if (!r.title.trim()) throw new AiError('request', 'اول عنوان کار را بنویسید.');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), r.timeoutMs ?? 30_000);
  let res: Awaited<ReturnType<FetchLike>>;
  try {
    res = await r.fetchFn(DEEPSEEK_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${r.apiKey}` },
      body: JSON.stringify({
        model: r.model || DEFAULT_MODEL,
        messages: buildMessages(r.title, r.description),
        response_format: { type: 'json_object' },
        temperature: 0.3,
        max_tokens: 700,
        stream: false,
      }),
      signal: controller.signal,
    });
  } catch (e) {
    if (controller.signal.aborted) throw new AiError('timeout', 'پاسخی نیامد (زمان تمام شد). اینترنت یا VPN را بررسی کنید.');
    throw new AiError('network', 'اتصال به DeepSeek برقرار نشد. اینترنت یا VPN را بررسی کنید.');
  } finally {
    clearTimeout(timer);
  }

  const body = await res.text().catch(() => '');
  if (!res.ok) throw describeHttpError(res.status, body);

  let content: unknown;
  try {
    content = (JSON.parse(body) as { choices?: { message?: { content?: unknown } }[] }).choices?.[0]?.message?.content;
  } catch {
    content = undefined;
  }
  if (typeof content !== 'string') throw new AiError('format', 'پاسخ هوش مصنوعی قابل فهم نبود. دوباره تلاش کنید.');
  return parseBreakdown(content);
}

/** "sk-••••1234": shows only the end of a key. */
export function maskKey(key: string): string {
  const k = key.trim();
  return k.length <= 8 ? '••••' : `${k.slice(0, 3)}••••${k.slice(-4)}`;
}
