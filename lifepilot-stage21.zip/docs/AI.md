# AI task breakdown with DeepSeek (stage 21)
- Button "✨ خرد کردن با هوش مصنوعی" under the checklist of the task form. It sends ONLY the task title (and description) to
  `https://api.deepseek.com/chat/completions` (JSON mode) and fills the checklist with 3-8 small steps, each with minutes ("... (۱۰ دقیقه)").
- Runs only when pressed. Steps are saved with the task; they are replaced only by "ساخت دوباره" (asks first) or removed by "حذف همه".
- Settings -> هوش مصنوعی: API key (stored with expo-secure-store, encrypted, on this phone only), model name (default `deepseek-chat`), connection test.
- First use asks for consent to send the task text. No key -> a message with a shortcut to settings.
- Errors are explained in Persian: bad key (401), no credit (402), rate limit (429), server (5xx), network/VPN, timeout (30 s), unreadable answer.
- Not tested against the live service from the build environment: use "آزمایش اتصال" on the phone.
