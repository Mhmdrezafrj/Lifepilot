import { ReactNode, createContext, useContext, useMemo, useState } from 'react';
import { useColorScheme } from 'react-native';
import { AccentKey, Scheme, ThemeMode } from './colors';
import { Theme, createTheme } from './theme';
import { FontKey } from './fonts';
import { FontSizeKey, fontScales } from './typography';

interface ThemeSettings {
  mode: ThemeMode;
  setMode: (m: ThemeMode) => void;
  accent: AccentKey;
  setAccent: (a: AccentKey) => void;
  fontSize: FontSizeKey;
  setFontSize: (f: FontSizeKey) => void;
  fontKey: FontKey;
  setFontKey: (f: FontKey) => void;
}

const ThemeContext = createContext<Theme | null>(null);
const SettingsContext = createContext<ThemeSettings | null>(null);

// NOTE: for now the choices live in memory only. Persisting them to the
// database is part of the Settings stage.
export function ThemeProvider({ children }: { children: ReactNode }) {
  const system = useColorScheme();
  const [mode, setMode] = useState<ThemeMode>('system');
  const [accent, setAccent] = useState<AccentKey>('indigo');
  const [fontSize, setFontSize] = useState<FontSizeKey>('normal');
  const [fontKey, setFontKey] = useState<FontKey>('vazirmatn');

  const scheme: Scheme = mode === 'system' ? (system === 'dark' ? 'dark' : 'light') : mode;

  const theme = useMemo(
    () => createTheme(scheme, accent, fontScales[fontSize].scale, fontKey),
    [scheme, accent, fontSize, fontKey],
  );
  const settings = useMemo(
    () => ({ mode, setMode, accent, setAccent, fontSize, setFontSize, fontKey, setFontKey }),
    [mode, accent, fontSize, fontKey],
  );

  return (
    <SettingsContext.Provider value={settings}>
      <ThemeContext.Provider value={theme}>{children}</ThemeContext.Provider>
    </SettingsContext.Provider>
  );
}

export function useTheme(): Theme {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used inside ThemeProvider');
  return ctx;
}

export function useThemeSettings(): ThemeSettings {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useThemeSettings must be used inside ThemeProvider');
  return ctx;
}
