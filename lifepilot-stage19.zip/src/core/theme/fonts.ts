/** Persian-capable fonts bundled with the app (Google Fonts). Vazirmatn is the default. */
export type FontKey = 'vazirmatn' | 'notoSans' | 'plex' | 'cairo' | 'tajawal' | 'naskh';

export const FONT_KEYS: FontKey[] = ['vazirmatn', 'notoSans', 'plex', 'cairo', 'tajawal', 'naskh'];

export const FONT_LABELS: Record<FontKey, string> = {
  vazirmatn: 'وزیرمتن (پیش‌فرض)',
  notoSans: 'نوتو سنس عربی',
  plex: 'آی‌بی‌ام پلکس',
  cairo: 'کایرو',
  tajawal: 'تجوال',
  naskh: 'نوتو نسخ',
};

const PREFIX: Record<FontKey, string> = {
  vazirmatn: 'Vazirmatn',
  notoSans: 'NotoSansArabic',
  plex: 'IBMPlexSansArabic',
  cairo: 'Cairo',
  tajawal: 'Tajawal',
  naskh: 'NotoNaskhArabic',
};

export interface FontFamilies {
  regular: string;
  medium: string;
  bold: string;
}

export function familiesFor(key: FontKey): FontFamilies {
  const p = PREFIX[key];
  return { regular: `${p}_400Regular`, medium: `${p}_500Medium`, bold: `${p}_700Bold` };
}

export function parseFontKey(raw: string | null): FontKey {
  return FONT_KEYS.find((k) => k === raw) ?? 'vazirmatn';
}
