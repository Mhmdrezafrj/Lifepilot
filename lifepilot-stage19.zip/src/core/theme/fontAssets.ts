import * as Cairo from '@expo-google-fonts/cairo';
import * as PlexArabic from '@expo-google-fonts/ibm-plex-sans-arabic';
import * as NotoNaskh from '@expo-google-fonts/noto-naskh-arabic';
import * as NotoSans from '@expo-google-fonts/noto-sans-arabic';
import * as Tajawal from '@expo-google-fonts/tajawal';
import * as Vazirmatn from '@expo-google-fonts/vazirmatn';

// Each package exports its font files as Name_400Regular, Name_500Medium, ... plus a useFonts helper.
// Only the three weights the app uses are taken, to keep the app small.
function pick(ns: object): Record<string, never> {
  const out: Record<string, never> = {};
  for (const [name, value] of Object.entries(ns)) {
    if (/^[A-Za-z0-9]+_(400Regular|500Medium|700Bold)$/.test(name) && typeof value !== 'function') {
      out[name] = value as never;
    }
  }
  return out;
}

export const FONT_ASSETS = {
  ...pick(Vazirmatn),
  ...pick(NotoSans),
  ...pick(PlexArabic),
  ...pick(Cairo),
  ...pick(Tajawal),
  ...pick(NotoNaskh),
};
