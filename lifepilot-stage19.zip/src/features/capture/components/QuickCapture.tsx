import { useEffect, useState } from 'react';
import { Modal, Pressable, ToastAndroid, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { formatDue } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { useTheme } from '@/core/theme/useTheme';
import { PARKED_MESSAGE } from '@/features/focus/services/focus';
import { useAutoEmoji } from '@/features/emoji/hooks/useAutoEmoji';
import { useDefaultReminder } from '@/features/settings/hooks/useDefaultReminder';
import { useTaskActions } from '@/features/tasks/hooks/useTaskActions';
import { useVoiceInput } from '@/features/voice/hooks/useVoiceInput';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Fab } from '@/shared/components/Fab';
import { TextField } from '@/shared/components/TextField';
import { INBOX_TAG } from '../services/inbox';
import { parseQuickText } from '../services/nlParser';

interface SheetProps {
  visible: boolean;
  onClose: () => void;
  /** "park": a distracting thought during focus; always goes to the inbox, no dates. */
  mode?: 'quick' | 'park';
  onSaved?: () => void;
}

/** Type, or hold the microphone and speak. In quick mode a date/time in the text schedules the task. */
export function CaptureSheet({ visible, onClose, mode = 'quick', onSaved }: SheetProps) {
  const { colors, radii, spacing, iconSizes } = useTheme();
  const actions = useTaskActions();
  const defaults = useDefaultReminder();
  const autoEmoji = useAutoEmoji();
  const voice = useVoiceInput();
  const [text, setText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const park = mode === 'park';
  const listening = voice.state.status === 'listening';
  const parsed = parseQuickText(text, Date.now());

  // Spoken words flow into the text field (still editable).
  useEffect(() => {
    if (voice.state.transcript) setText(voice.state.transcript);
  }, [voice.state.transcript]);

  const close = () => {
    voice.reset();
    setText('');
    setError(null);
    onClose();
  };

  const save = async () => {
    if (!text.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const dated = !park && parsed.dueAt !== null;
      await actions.create({
        title: autoEmoji.apply(park ? text.trim() : parsed.title),
        dueAt: dated ? parsed.dueAt : null,
        hasTime: dated ? parsed.hasTime : false,
        tags: dated ? [] : [INBOX_TAG],
        reminders: dated && parsed.hasTime
          ? [{ offsetMinutes: defaults.offset ?? 0, channel: defaults.style, enabled: true }]
          : [],
      });
      ToastAndroid.show(park ? PARKED_MESSAGE : dated ? 'ثبت شد ✅' : 'به صندوق ورودی رفت 📥', ToastAndroid.LONG);
      onSaved?.();
      close();
    } catch (e) {
      setError(describeError(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={close}>
      <Pressable style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: 'flex-end' }} onPress={close}>
        <Pressable
          onPress={() => {}}
          style={{
            backgroundColor: colors.surface, borderTopLeftRadius: radii.xl, borderTopRightRadius: radii.xl,
            padding: spacing.xl, gap: spacing.md,
          }}
        >
          <AppText variant="heading">{park ? 'پارک کردن فکر 🧠' : 'ثبت سریع'}</AppText>
          {park ? <AppText variant="caption" muted>هرچه حواست را پرت کرد اینجا بنویس. بعداً به آن می‌رسیم؛ الان به کارت برگرد.</AppText> : null}
          <TextField
            placeholder={park ? 'مثلاً: به مامان زنگ بزنم' : 'هر چه به ذهنت رسید… مثلاً: فردا ساعت ۵ دکتر'}
            value={text}
            onChangeText={(t) => { setText(t); voice.edit(t); }}
            autoFocus
            multiline
            maxLength={200}
          />

          {!park && text.trim() ? (
            <AppText variant="caption" color={parsed.dueAt ? 'accent' : 'textMuted'}>
              {parsed.dueAt
                ? `برنامه‌ریزی می‌شود: ${formatDue(parsed.dueAt, parsed.hasTime, Date.now())} · «${parsed.title}»`
                : 'بدون تاریخ: به «صندوق ورودی» می‌رود و بعداً برنامه‌ریزی می‌کنی.'}
            </AppText>
          ) : null}

          <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="نگه دارید و صحبت کنید"
              onPressIn={() => void voice.start()}
              onPressOut={() => voice.stop()}
              style={{
                width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center',
                backgroundColor: listening ? colors.danger : colors.accentSoft,
              }}
            >
              <Ionicons name={listening ? 'mic' : 'mic-outline'} size={iconSizes.xl} color={listening ? '#FFFFFF' : colors.accent} />
            </Pressable>
            <View style={{ flex: 1 }}>
              <AppText variant="label" muted>{listening ? 'در حال گوش دادن… رها کن تا تمام شود' : 'نگه دار و صحبت کن'}</AppText>
              {voice.state.error ? <AppText variant="caption" color="danger">{voice.state.error.message}</AppText> : null}
            </View>
          </View>

          {error ? <AppText color="danger">{error}</AppText> : null}
          <View style={{ flexDirection: 'row', gap: spacing.sm }}>
            <Button title={park ? 'پارک کن' : 'ثبت'} disabled={!text.trim() || listening} loading={saving} onPress={() => void save()} />
            <Button title="بستن" variant="ghost" onPress={close} />
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

/** The one floating button of the home screen. */
export function QuickCapture() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Fab onPress={() => setOpen(true)} accessibilityLabel="ثبت سریع" />
      <CaptureSheet visible={open} onClose={() => setOpen(false)} />
    </>
  );
}
