import { useCallback, useEffect, useState } from 'react';
import { useRepositories } from '@/providers/DatabaseProvider';
import { AUTO_EMOJI_KEY, parseAutoEmoji } from '@/features/settings/services/settingsKeys';
import { withEmoji } from '../services/emoji';

/** Whether new tasks get an automatic emoji, and a helper that applies it. */
export function useAutoEmoji(): {
  enabled: boolean;
  loaded: boolean;
  setEnabled: (on: boolean) => Promise<void>;
  apply: (title: string) => string;
} {
  const repo = useRepositories().settings;
  const [enabled, setOn] = useState(true);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    repo
      .get(AUTO_EMOJI_KEY)
      .then((raw) => {
        if (!cancelled) {
          setOn(parseAutoEmoji(raw));
          setLoaded(true);
        }
      })
      .catch(() => {
        if (!cancelled) setLoaded(true);
      });
    return () => {
      cancelled = true;
    };
  }, [repo]);

  const setEnabled = useCallback(
    async (on: boolean) => {
      await repo.set(AUTO_EMOJI_KEY, on ? 'on' : 'off');
      setOn(on);
    },
    [repo],
  );

  const apply = useCallback((title: string) => (enabled ? withEmoji(title) : title), [enabled]);
  return { enabled, loaded, setEnabled, apply };
}
