import { AccentKey, ThemeMode, accents } from '../../../core/theme/colors';
import { FontSizeKey, fontScales } from '../../../core/theme/typography';
import { REMINDER_OPTIONS } from '../../tasks/models/labels';
import type { ReminderChannel } from '../../tasks/models/task';

/** Keys used in the app_settings table. */
export const SETTING_KEYS = {
  themeMode: 'theme_mode',
  accent: 'theme_accent',
  fontSize: 'theme_font_size',
  defaultReminder: 'default_reminder_offset',
  reminderStyle: 'reminder_style',
  fontFamily: 'font_family',
  userName: 'user_name',
  launchCount: 'launch_count',
} as const;

const MODES: ThemeMode[] = ['light', 'dark', 'system'];

export function parseThemeMode(raw: string | null): ThemeMode {
  return MODES.find((m) => m === raw) ?? 'system';
}

export function parseAccent(raw: string | null): AccentKey {
  return raw !== null && Object.prototype.hasOwnProperty.call(accents, raw) ? (raw as AccentKey) : 'indigo';
}

export function parseFontSize(raw: string | null): FontSizeKey {
  return raw !== null && Object.prototype.hasOwnProperty.call(fontScales, raw) ? (raw as FontSizeKey) : 'normal';
}

/** The default reminder for new tasks (minutes before), or null for none. Unknown values mean none. */
export function parseDefaultReminder(raw: string | null): number | null {
  if (raw === null || raw === 'none') return null;
  const n = Number(raw);
  return REMINDER_OPTIONS.some((o) => o.offset === n) ? n : null;
}

export function serializeDefaultReminder(offset: number | null): string {
  return offset === null ? 'none' : String(offset);
}

/** How new reminders ring by default: a loud alarm tone, or a normal notification. Defaults to the alarm. */
export function parseReminderStyle(raw: string | null): ReminderChannel {
  return raw === 'notification' ? 'notification' : 'alarm';
}

export const AUTO_EMOJI_KEY = 'auto_emoji';

/** New tasks get an automatic emoji unless the user turned it off. */
export function parseAutoEmoji(raw: string | null): boolean {
  return raw !== 'off';
}
