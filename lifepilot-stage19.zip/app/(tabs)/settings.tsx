import { ReactNode, useState } from 'react';
import { Linking, Platform, View } from 'react-native';
import Constants from 'expo-constants';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { toPersianDigits } from '@/core/calendar/format';
import { AccentKey, ThemeMode, accents } from '@/core/theme/colors';
import { FontSizeKey, fontScales } from '@/core/theme/typography';
import { useTheme, useThemeSettings } from '@/core/theme/useTheme';
import { useNotificationPermission } from '@/features/reminders/hooks/useNotificationPermission';
import { useNudgeSettings } from '@/features/nudges/hooks/useNudgeSettings';
import { PER_TASK_OPTIONS, SUMMARY_HOURS, WAKING_WINDOWS } from '@/features/nudges/services/nudgeSettings';
import { FONT_KEYS, FONT_LABELS, familiesFor } from '@/core/theme/fonts';
import { useAutoEmoji } from '@/features/emoji/hooks/useAutoEmoji';
import { useDefaultReminder } from '@/features/settings/hooks/useDefaultReminder';
import { scheduleTestNotification } from '@/infrastructure/notifications/expoNotificationGateway';
import { useUserName } from '@/features/settings/hooks/useUserName';
import { REMINDER_OPTIONS } from '@/features/tasks/models/labels';
import { useDbInfo } from '@/providers/DatabaseProvider';
import { AppText } from '@/shared/components/AppText';
import { Badge } from '@/shared/components/Badge';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Chip } from '@/shared/components/Chip';
import { Screen } from '@/shared/components/Screen';
import { SegmentedControl } from '@/shared/components/SegmentedControl';
import { TextField } from '@/shared/components/TextField';
import { IconName } from '@/shared/types/icon';

const MODE_OPTIONS: { value: ThemeMode; label: string }[] = [
  { value: 'light', label: 'روشن' },
  { value: 'dark', label: 'تیره' },
  { value: 'system', label: 'سیستم' },
];

function Section({ title, children }: { title: string; children: ReactNode }) {
  const { spacing } = useTheme();
  return (
    <View style={{ gap: spacing.sm }}>
      <AppText variant="label" muted>{title}</AppText>
      {children}
    </View>
  );
}

function LinkRow({ icon, title, subtitle, onPress }: { icon: IconName; title: string; subtitle: string; onPress: () => void }) {
  const { colors, iconSizes, spacing } = useTheme();
  return (
    <Card onPress={onPress} accessibilityLabel={title}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
        <Ionicons name={icon} size={iconSizes.lg} color={colors.accent} />
        <View style={{ flex: 1 }}>
          <AppText variant="bodyStrong">{title}</AppText>
          <AppText variant="caption" muted>{subtitle}</AppText>
        </View>
      </View>
    </Card>
  );
}

/** A row for a feature that does not exist yet: shown dimmed, with a "soon" badge, and does nothing. */
function UnavailableRow({ icon, title, subtitle }: { icon: IconName; title: string; subtitle: string }) {
  const { colors, iconSizes, spacing } = useTheme();
  return (
    <Card variant="flat">
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md, opacity: 0.7 }}>
        <Ionicons name={icon} size={iconSizes.lg} color={colors.textMuted} />
        <View style={{ flex: 1 }}>
          <AppText variant="bodyStrong">{title}</AppText>
          <AppText variant="caption" muted>{subtitle}</AppText>
        </View>
        <Badge label="به‌زودی" color={colors.textMuted} />
      </View>
    </Card>
  );
}

export default function SettingsScreen() {
  const router = useRouter();
  const { spacing, scheme } = useTheme();
  const db = useDbInfo();
  const { mode, setMode, accent, setAccent, fontSize, setFontSize, fontKey, setFontKey } = useThemeSettings();
  const autoEmoji = useAutoEmoji();
  const defaultReminder = useDefaultReminder();
  const notif = useNotificationPermission();
  const nudge = useNudgeSettings();
  const [testState, setTestState] = useState<'idle' | 'sent' | 'error'>('idle');
  const { name, loaded: nameLoaded, save: saveName } = useUserName();
  const [nameDraft, setNameDraft] = useState<string | null>(null);

  const sizeOptions = (Object.keys(fontScales) as FontSizeKey[]).map((k) => ({ value: k, label: fontScales[k].label }));
  const nameValue = nameDraft ?? name ?? '';

  return (
    <Screen title="تنظیمات">
      <Section title="پروفایل">
        <Card variant="outlined">
          <TextField
            label="نام شما (برای سلام در صفحه‌ی خانه)"
            placeholder="مثلاً: رضا"
            value={nameValue}
            onChangeText={setNameDraft}
            maxLength={40}
            editable={nameLoaded}
          />
          <Button
            title="ذخیره‌ی نام"
            size="sm"
            variant="secondary"
            disabled={nameDraft === null || nameDraft.trim() === (name ?? '')}
            onPress={async () => {
              await saveName(nameDraft ?? '');
              setNameDraft(null);
            }}
          />
        </Card>
      </Section>

      <Section title="ظاهر">
        <Card variant="outlined" style={{ gap: spacing.md }}>
          <AppText variant="label" muted>حالت نمایش</AppText>
          <SegmentedControl options={MODE_OPTIONS} value={mode} onChange={setMode} />
          <AppText variant="label" muted>رنگ اصلی</AppText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            {(Object.keys(accents) as AccentKey[]).map((k) => (
              <Chip key={k} label={accents[k].label} color={accents[k][scheme]} selected={accent === k} onPress={() => setAccent(k)} />
            ))}
          </View>
          <AppText variant="label" muted>اندازه‌ی متن</AppText>
          <SegmentedControl options={sizeOptions} value={fontSize} onChange={setFontSize} />
          <AppText variant="label" muted>فونت</AppText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            {FONT_KEYS.map((k) => (
              <Chip key={k} label={FONT_LABELS[k]} selected={fontKey === k} onPress={() => setFontKey(k)} />
            ))}
          </View>
          <AppText style={{ fontFamily: familiesFor(fontKey).regular }}>
            نمونه‌ی متن: این یک جمله‌ی فارسی برای دیدن فونت است. ۱۲۳۴۵۶۷۸۹۰
          </AppText>
          <AppText variant="label" muted>ایموجی خودکار کنار کارهای جدید</AppText>
          <View style={{ flexDirection: 'row', gap: spacing.sm }}>
            <Chip label="روشن 😀" selected={autoEmoji.enabled} onPress={() => void autoEmoji.setEnabled(true)} />
            <Chip label="خاموش" selected={!autoEmoji.enabled} onPress={() => void autoEmoji.setEnabled(false)} />
          </View>
          <AppText variant="caption" muted>تغییرات بلافاصله اعمال و روی همین گوشی ذخیره می‌شوند.</AppText>
        </Card>
      </Section>

      <Section title="زبان">
        <Card variant="outlined">
          <AppText variant="bodyStrong">فارسی</AppText>
          <AppText variant="caption" muted>در این نسخه فقط فارسی (راست‌به‌چپ) پشتیبانی می‌شود.</AppText>
        </Card>
      </Section>

      <Section title="اعلان‌ها و یادآوری">
        <Card variant="outlined">
          <AppText variant="bodyStrong">
            وضعیت اعلان‌ها:{' '}
            {notif.state === 'granted' ? 'فعال ✅' : notif.state === 'denied' ? 'غیرفعال ❌' : notif.state === 'loading' ? '…' : 'هنوز اجازه داده نشده'}
          </AppText>
          <AppText variant="caption" muted>
            یادآوری‌ها سر موعد به‌صورت اعلان (با صدا و لرزش) نمایش داده می‌شوند، حتی اگر برنامه بسته باشد و بدون اینترنت.
            روی اعلان می‌توانید «انجام شد» یا «۱۰ دقیقه بعد» را بزنید.
          </AppText>
          {notif.state === 'denied' || notif.state === 'undetermined' ? (
            <Button
              title={notif.state === 'denied' && !notif.canAskAgain ? 'باز کردن تنظیمات برنامه' : 'فعال‌سازی اعلان‌ها'}
              size="sm"
              onPress={() => void notif.request()}
            />
          ) : null}
          {notif.state === 'granted' ? (
            <>
              <Button
                title="تست زنگ آلارم (۱۰ ثانیه دیگر)"
                size="sm"
                icon="alarm-outline"
                onPress={async () => {
                  try {
                    await scheduleTestNotification(10, 'alarm');
                    setTestState('sent');
                  } catch {
                    setTestState('error');
                  }
                }}
              />
              <Button
                title="تست اعلان معمولی (۱۰ ثانیه دیگر)"
                variant="secondary"
                size="sm"
                icon="notifications-outline"
                onPress={async () => {
                  try {
                    await scheduleTestNotification(10, 'notification');
                    setTestState('sent');
                  } catch {
                    setTestState('error');
                  }
                }}
              />
            </>
          ) : null}
          {testState === 'sent' ? (
            <AppText variant="caption" muted>
              تست زمان‌بندی شد. برای تست واقعی، برنامه را ببندید، صفحه را قفل کنید و ۱۰ ثانیه صبر کنید. (بلندی «آلارم» گوشی را هم چک کنید.)
            </AppText>
          ) : null}
          {testState === 'error' ? <AppText variant="caption" color="danger">ارسال اعلان آزمایشی ناموفق بود.</AppText> : null}
        </Card>

        <Card variant="flat">
          <AppText variant="bodyStrong">اگر اعلان دیر می‌آید یا نمی‌آید</AppText>
          <AppText variant="caption" muted>
            بعضی گوشی‌ها (مثل شیائومی، هوآوی، اوپو) برنامه‌های بسته را برای صرفه‌جویی باتری متوقف می‌کنند. در تنظیمات گوشی برای «لایف‌پایلوت» این‌ها را بررسی کنید (نام گزینه‌ها بسته به گوشی کمی فرق دارد):{'\n'}
            ۱) «شروع خودکار» (Autostart) روشن باشد.{'\n'}
            ۲) صرفه‌جویی باتری روی «بدون محدودیت» باشد.{'\n'}
            ۳) برنامه را در لیست برنامه‌های اخیر «قفل» کنید.{'\n'}
            ۴) در اندروید ۱۲، اگر گزینه‌ی «آلارم‌ها و یادآورها» (Alarms &amp; reminders) هست، روشن باشد.
          </AppText>
          <Button title="باز کردن تنظیمات برنامه" variant="ghost" size="sm" onPress={() => void Linking.openSettings()} />
        </Card>

        <Card variant="outlined">
          <AppText variant="bodyStrong">یادآوری هوشمند (چندباره)</AppText>
          <AppText variant="caption" muted>
            برای هر کار، قبل از موعد چند یادآوری اضافه در ساعت‌های مختلف و تصادفی می‌آید (فقط در ساعت‌های بیداری). زمان‌ها برای هر کار ثابت می‌ماند و با هر بار باز کردن برنامه جابه‌جا نمی‌شود.
          </AppText>
          <View style={{ flexDirection: 'row', gap: spacing.sm }}>
            <Chip label="روشن" selected={nudge.settings.enabled} onPress={() => void nudge.save({ ...nudge.settings, enabled: true })} />
            <Chip label="خاموش" selected={!nudge.settings.enabled} onPress={() => void nudge.save({ ...nudge.settings, enabled: false })} />
          </View>
          {nudge.settings.enabled ? (
            <>
              <AppText variant="label" muted>تعداد یادآوری اضافه برای هر کار</AppText>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
                {PER_TASK_OPTIONS.map((n) => (
                  <Chip key={n} label={toPersianDigits(n)} selected={nudge.settings.perTask === n} onPress={() => void nudge.save({ ...nudge.settings, perTask: n })} />
                ))}
              </View>
              <AppText variant="label" muted>ساعت‌های بیداری (یادآوری فقط در این بازه)</AppText>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
                {WAKING_WINDOWS.map((w) => (
                  <Chip
                    key={w.start}
                    label={`${toPersianDigits(w.start)} تا ${toPersianDigits(w.end)}`}
                    selected={nudge.settings.dayStartHour === w.start && nudge.settings.dayEndHour === w.end}
                    onPress={() => void nudge.save({ ...nudge.settings, dayStartHour: w.start, dayEndHour: w.end })}
                  />
                ))}
              </View>
            </>
          ) : null}
          <AppText variant="label" muted>خلاصه‌ی صبحگاهی: «امروز N کار داری: …»</AppText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            <Chip label="خاموش" selected={!nudge.settings.summaryEnabled} onPress={() => void nudge.save({ ...nudge.settings, summaryEnabled: false })} />
            {SUMMARY_HOURS.map((h) => (
              <Chip
                key={h}
                label={`ساعت ${toPersianDigits(h)}`}
                selected={nudge.settings.summaryEnabled && nudge.settings.summaryHour === h}
                onPress={() => void nudge.save({ ...nudge.settings, summaryEnabled: true, summaryHour: h })}
              />
            ))}
          </View>
        </Card>

        <Card variant="outlined">
          <AppText variant="bodyStrong">نوع یادآوری پیش‌فرض</AppText>
          <AppText variant="caption" muted>
            «زنگ آلارم»: صدای بلند ۱۵ ثانیه‌ای با بلندی آلارم گوشی (حتی در حالت بی‌صدا) و لرزش. «اعلان معمولی»: فقط صدای کوتاه اعلان.
            هنگام ساختن هر کار هم می‌توانید تغییرش دهید.
          </AppText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            <Chip icon="alarm-outline" label="زنگ آلارم" selected={defaultReminder.style === 'alarm'} onPress={() => void defaultReminder.saveStyle('alarm')} />
            <Chip icon="notifications-outline" label="اعلان معمولی" selected={defaultReminder.style === 'notification'} onPress={() => void defaultReminder.saveStyle('notification')} />
          </View>
        </Card>

        <Card variant="outlined">
          <AppText variant="bodyStrong">یادآوری پیش‌فرض برای کارهای جدید</AppText>
          <AppText variant="caption" muted>در فرم کار جدید، وقتی ساعت انتخاب شود از قبل انتخاب می‌شود.</AppText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            <Chip label="بدون یادآوری" selected={defaultReminder.offset === null} onPress={() => void defaultReminder.save(null)} />
            {REMINDER_OPTIONS.map((o) => (
              <Chip
                key={o.offset}
                label={o.label}
                selected={defaultReminder.offset === o.offset}
                onPress={() => void defaultReminder.save(o.offset)}
              />
            ))}
          </View>
        </Card>
      </Section>

      <Section title="حریم خصوصی و داده‌ها">
        <Card variant="outlined">
          <AppText variant="bodyStrong">داده‌های شما روی همین گوشی است</AppText>
          <AppText variant="caption" muted>
            کارها، دسته‌ها و تنظیمات در پایگاه داده‌ی محلی گوشی ذخیره می‌شوند. برنامه حساب کاربری ندارد و چیزی به سرور ارسال نمی‌کند.
            برنامه بدون اینترنت کار می‌کند. فقط ورودی صوتی فارسی ممکن است برای تشخیص گفتار از سرویس گوگل گوشی استفاده کند (و به اینترنت نیاز داشته باشد)، آن هم فقط وقتی دکمه‌ی میکروفون را بزنید.
          </AppText>
        </Card>
        <UnavailableRow icon="cloud-upload-outline" title="پشتیبان‌گیری" subtitle="هنوز پیاده‌سازی نشده است" />
        <UnavailableRow icon="cloud-download-outline" title="بازیابی از پشتیبان" subtitle="هنوز پیاده‌سازی نشده است" />
      </Section>

      <Section title="مدیریت">
        <LinkRow
          icon="pricetags-outline"
          title="دسته‌بندی‌ها"
          subtitle="ساخت، تغییر نام و رنگ، و حذف دسته‌ها"
          onPress={() => router.push('/categories')}
        />
        <LinkRow
          icon="color-palette-outline"
          title="نمایشگاه طراحی (ابزار توسعه)"
          subtitle="پیش‌نمایش رنگ‌ها و کامپوننت‌ها"
          onPress={() => router.push('/design-showcase')}
        />
      </Section>

      <Section title="درباره">
        <Card variant="outlined">
          <AppText variant="bodyStrong">لایف‌پایلوت</AppText>
          <AppText muted>نسخه برنامه: {toPersianDigits(Constants.expoConfig?.version ?? '—')}</AppText>
          <AppText muted>شماره‌ی ساخت: {toPersianDigits(Constants.expoConfig?.android?.versionCode ?? '—')}</AppText>
          <AppText muted>نوع ساخت: {__DEV__ ? 'توسعه' : 'انتشار'}</AppText>
          <AppText muted>اندروید (API): {toPersianDigits(String(Platform.Version))}</AppText>
          <AppText muted>شناسه بسته: com.lifepilot.personalassistant</AppText>
          <AppText muted>نسخه‌ی ساختار پایگاه داده: {toPersianDigits(db.schemaVersion)}</AppText>
          <AppText muted>دفعات اجرای برنامه: {toPersianDigits(db.launchCount)}</AppText>
        </Card>
      </Section>
    </Screen>
  );
}
