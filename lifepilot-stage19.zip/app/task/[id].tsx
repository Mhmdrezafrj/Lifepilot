import { useMemo, useState } from 'react';
import { ActivityIndicator, Alert, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { toPersianDigits } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { useTheme } from '@/core/theme/useTheme';
import { useCategories } from '@/features/categories/hooks/useCategories';
import { useAutoEmoji } from '@/features/emoji/hooks/useAutoEmoji';
import { useDefaultReminder } from '@/features/settings/hooks/useDefaultReminder';
import { TaskForm } from '@/features/tasks/components/TaskForm';
import { FormState, emptyForm, formFromTask, formToInput } from '@/features/tasks/components/taskFormModel';
import { useTaskActions } from '@/features/tasks/hooks/useTaskActions';
import { useTask } from '@/features/tasks/hooks/useTasks';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Chip } from '@/shared/components/Chip';
import { Screen } from '@/shared/components/Screen';

const SNOOZE_OPTIONS = [
  { minutes: 10, label: '۱۰ دقیقه' },
  { minutes: 60, label: '۱ ساعت' },
  { minutes: 180, label: '۳ ساعت' },
];

export default function TaskEditorScreen() {
  const { id, date, voice } = useLocalSearchParams<{ id: string; date?: string; voice?: string }>();
  const isNew = id === 'new';
  const router = useRouter();
  const { spacing } = useTheme();
  const actions = useTaskActions();
  const autoEmoji = useAutoEmoji();
  const { categories } = useCategories();
  const { task, loading } = useTask(isNew ? null : String(id));
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const defaultReminder = useDefaultReminder();
  const newInitial = useMemo(() => {
    const ms = date ? Number(date) : NaN;
    const form = emptyForm(Number.isFinite(ms) ? new Date(ms) : null);
    const styled = { ...form, reminderChannel: defaultReminder.style };
    return defaultReminder.offset === null ? styled : { ...styled, reminderOffsets: [defaultReminder.offset] };
  }, [date, defaultReminder.offset, defaultReminder.style]);

  const run = async (action: () => Promise<unknown>, closeAfter = true) => {
    try {
      await action();
      if (closeAfter) router.back();
    } catch (e) {
      Alert.alert('خطا', describeError(e));
    }
  };

  const submit = async (f: FormState) => {
    setSubmitting(true);
    setError(null);
    try {
      const input = formToInput(f);
      if (isNew) {
        await actions.create({ ...input, title: autoEmoji.apply(input.title) });
      } else if (task) {
        await actions.update(task.id, {
          title: input.title,
          description: input.description,
          dueAt: input.dueAt,
          hasTime: input.hasTime,
          priority: input.priority,
          categoryId: input.categoryId,
          tags: input.tags,
          checklist: input.checklist,
          reminders: input.reminders,
          recurrence: input.recurrence ?? null,
        });
      }
      router.back();
    } catch (e) {
      setError(describeError(e));
      setSubmitting(false);
    }
  };

  const confirmDelete = () => {
    if (!task) return;
    Alert.alert('حذف کار', `«${task.title}» برای همیشه حذف شود؟`, [
      { text: 'انصراف', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: () => run(() => actions.delete(task.id)) },
    ]);
  };

  if ((!isNew && loading) || (isNew && !defaultReminder.loaded)) {
    return (
      <Screen title={isNew ? 'کار جدید' : 'ویرایش کار'} onBack={() => router.back()}>
        <ActivityIndicator />
      </Screen>
    );
  }

  if (!isNew && !task) {
    return (
      <Screen title="ویرایش کار" onBack={() => router.back()}>
        <AppText muted>این کار پیدا نشد (ممکن است حذف شده باشد).</AppText>
      </Screen>
    );
  }

  return (
    <Screen title={isNew ? 'کار جدید' : 'ویرایش کار'} onBack={() => router.back()}>
      {task ? (
        <Card variant="outlined" style={{ gap: spacing.md }}>
          {task.status === 'pending' ? (
            <>
              <Button
                title="انجام شد"
                icon="checkmark-circle-outline"
                onPress={() => run(() => actions.complete(task.id))}
              />
              <Button title="حالت تمرکز" icon="eye-off-outline" variant="secondary" onPress={() => router.push(`/focus/${task.id}`)} />
              <AppText variant="label" muted>به تعویق انداختن (از همین الان)</AppText>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
                {SNOOZE_OPTIONS.map((o) => (
                  <Chip key={o.minutes} icon="alarm-outline" label={o.label} onPress={() => run(() => actions.snooze(task.id, o.minutes))} />
                ))}
              </View>
            </>
          ) : (
            <>
              <AppText muted>این کار انجام شده است.</AppText>
              <Button title="بازگشایی کار" variant="secondary" icon="refresh-outline" onPress={() => run(() => actions.reopen(task.id))} />
            </>
          )}
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            <Button title="کپی کار" variant="ghost" size="sm" icon="copy-outline" onPress={() => run(() => actions.duplicate(task.id))} />
            <Button title="حذف" variant="ghost" size="sm" icon="trash-outline" onPress={confirmDelete} />
          </View>
          {task.recurrence ? (
            <AppText variant="caption" muted>
              این کار تکرارشونده است؛ با انجام دادن آن، نوبت بعدی ({toPersianDigits(task.recurrence.intervalCount)}×) خودکار ساخته می‌شود.
            </AppText>
          ) : null}
        </Card>
      ) : null}

      <TaskForm
        key={task ? task.id : 'new'}
        mode={isNew ? 'create' : 'edit'}
        initial={task ? formFromTask(task) : newInitial}
        categories={categories}
        submitting={submitting}
        error={error}
        onSubmit={submit}
        autoVoice={isNew && voice === '1'}
      />
    </Screen>
  );
}
