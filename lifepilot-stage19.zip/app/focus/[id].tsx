import { useEffect, useRef, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { toPersianDigits } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { accents } from '@/core/theme/colors';
import { useTheme, useThemeSettings } from '@/core/theme/useTheme';
import { CaptureSheet } from '@/features/capture/components/QuickCapture';
import { FOCUS_OPTIONS, completeStep, currentStepIndex, focusState } from '@/features/focus/services/focus';
import { useTaskActions } from '@/features/tasks/hooks/useTaskActions';
import { useTask } from '@/features/tasks/hooks/useTasks';
import { formatCountdown } from '@/features/study/services/blockPlanner';
import { cancelFocusEnd, scheduleFocusEnd } from '@/infrastructure/notifications/expoNotificationGateway';
import { AppText } from '@/shared/components/AppText';
import { useNow } from '@/shared/hooks/useNow';

const BG = '#05070F';
const TEXT = '#F3F4F6';
const MUTED = '#7C8499';

/** Full-screen focus: only this task and its timer. Everything else is hidden. */
export default function FocusScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { accent } = useThemeSettings();
  const { fontFamilies } = useTheme();
  const color = accents[accent].dark;
  const { task, loading } = useTask(String(id));
  const actions = useTaskActions();
  const now = useNow(1000);
  const [minutes, setMinutes] = useState(25);
  const [endsAt, setEndsAt] = useState<number | null>(null);
  const [parkOpen, setParkOpen] = useState(false);
  const [parked, setParked] = useState(0);
  const running = useRef(false);
  running.current = endsAt !== null;

  useEffect(() => () => { if (running.current) void cancelFocusEnd(); }, []);

  const start = () => {
    const end = Date.now() + minutes * 60_000;
    setEndsAt(end);
    void scheduleFocusEnd(end).catch(() => {});
  };
  const leave = () => {
    void cancelFocusEnd().catch(() => {});
    router.back();
  };
  const fail = (e: unknown) => Alert.alert('خطا', describeError(e));

  const state = endsAt === null ? null : focusState(endsAt, minutes, now);
  const stepIdx = task ? currentStepIndex(task.checklist) : -1;

  const Btn = ({ label, onPress, strong }: { label: string; onPress: () => void; strong?: boolean }) => (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => ({
        paddingVertical: 14, paddingHorizontal: 22, borderRadius: 18, opacity: pressed ? 0.8 : 1,
        backgroundColor: strong ? color : 'rgba(255,255,255,0.08)',
      })}
    >
      <AppText variant="bodyStrong" style={{ color: strong ? '#0B1020' : TEXT }}>{label}</AppText>
    </Pressable>
  );

  return (
    <View style={{ flex: 1, backgroundColor: BG, padding: 28, justifyContent: 'center', gap: 28 }}>
      <StatusBar hidden style="light" />
      {!task ? (
        <AppText style={{ color: MUTED, textAlign: 'center' }}>{loading ? '…' : 'این کار پیدا نشد.'}</AppText>
      ) : (
        <>
          <AppText variant="display" style={{ color: TEXT, textAlign: 'center' }}>{task.title}</AppText>

          {stepIdx >= 0 ? (
            <View style={{ alignItems: 'center', gap: 10 }}>
              <AppText variant="label" style={{ color: MUTED }}>قدم فعلی</AppText>
              <AppText variant="heading" style={{ color, textAlign: 'center' }}>{task.checklist[stepIdx].title}</AppText>
              <Btn
                label="این قدم تمام شد ✓"
                onPress={() =>
                  actions
                    .update(task.id, { checklist: completeStep(task.checklist.map((c) => ({ title: c.title, isCompleted: c.isCompleted })), stepIdx) })
                    .catch(fail)
                }
              />
            </View>
          ) : null}

          {state === null ? (
            <View style={{ alignItems: 'center', gap: 18 }}>
              <AppText variant="label" style={{ color: MUTED }}>چند دقیقه تمرکز؟</AppText>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, justifyContent: 'center' }}>
                {FOCUS_OPTIONS.map((m) => (
                  <Pressable
                    key={m}
                    onPress={() => setMinutes(m)}
                    style={{ paddingVertical: 10, paddingHorizontal: 16, borderRadius: 16, backgroundColor: minutes === m ? color : 'rgba(255,255,255,0.08)' }}
                  >
                    <AppText variant="bodyStrong" style={{ color: minutes === m ? '#0B1020' : TEXT }}>{toPersianDigits(m)}</AppText>
                  </Pressable>
                ))}
              </View>
              <Btn label="شروع تمرکز" strong onPress={start} />
            </View>
          ) : (
            <View style={{ alignItems: 'center', gap: 14 }}>
              <AppText style={{ color: state.finished ? '#4ADE80' : color, fontSize: 72, lineHeight: 96, textAlign: 'center', fontFamily: fontFamilies.bold }}>
                {state.finished ? '🎉' : formatCountdown(state.remainingMs)}
              </AppText>
              <View style={{ width: '70%', height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.12)', overflow: 'hidden' }}>
                <View style={{ width: `${Math.round(state.progress * 100)}%`, height: 6, backgroundColor: color }} />
              </View>
              {state.finished ? <AppText style={{ color: TEXT }}>زمان تمرکزت تمام شد. آفرین!</AppText> : null}
            </View>
          )}

          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12, justifyContent: 'center' }}>
            <Btn label={parked > 0 ? `🧠 پارک کردن فکر (${toPersianDigits(parked)})` : '🧠 پارک کردن فکر'} onPress={() => setParkOpen(true)} />
            <Btn
              label="انجام شد ✅"
              strong
              onPress={() => actions.complete(task.id).then(leave).catch(fail)}
            />
            <Btn label="خروج" onPress={leave} />
          </View>
        </>
      )}
      <CaptureSheet visible={parkOpen} mode="park" onClose={() => setParkOpen(false)} onSaved={() => setParked((n) => n + 1)} />
    </View>
  );
}
