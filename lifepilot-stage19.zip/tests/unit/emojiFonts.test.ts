import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { FALLBACK_EMOJI, emojiFor, hasLeadingEmoji, withEmoji } from '../../src/features/emoji/services/emoji';
import { FONT_KEYS, FONT_LABELS, familiesFor, parseFontKey } from '../../src/core/theme/fonts';
import { createTheme } from '../../src/core/theme/theme';
import { AUTO_EMOJI_KEY, parseAutoEmoji } from '../../src/features/settings/services/settingsKeys';

describe('automatic emoji', () => {
  it('finds a fitting emoji for common Persian titles', () => {
    const cases: [string, string][] = [
      ['دندانپزشکی ساعت ۵', '🦷'], ['قرص فشار', '💊'], ['رفتن پیش دکتر', '🩺'], ['خرید نان', '🥖'], ['خرید لوازم خانه', '🛒'],
      ['ورزش صبحگاهی', '🏃'], ['تمیز کردن اتاقم', '🧹'], ['صافکاری پژو', '🚗'], ['پرداخت قبض برق', '🧾'],
      ['تماس با مامان', '📞'], ['تولد علی', '🎂'], ['جلسه تیم', '👥'], ['حل تست', '📝'], ['حل تست ریاضی', '➗'], ['مدرسه بچه', '🏫'], ['برنامه‌نویسی اپ', '💻'], ['گل‌ها را آب بده', '🌱'], ['کلاس انگلیسی', '🔤'],
      ['ریاضی فصل ۳', '➗'], ['مطالعه زیست', '🧬'], ['درس خواندن', '📚'], ['بلیط تهران', '✈️'], ['نماز', '🕌'],
    ];
    for (const [title, emoji] of cases) assert.equal(emojiFor(title), emoji, title);
  });

  it('understands different spellings (Arabic letters, half-space)', () => {
    assert.equal(emojiFor('پياده‌روی'), '🏃');
    assert.equal(emojiFor('برنامه‌نويسي'), '💻');
  });

  it('returns null for unknown words', () => {
    assert.equal(emojiFor('کار عجیب xyz'), null);
    assert.equal(emojiFor(''), null);
  });

  it('adds the emoji in front, a fallback when nothing matches, and never doubles it', () => {
    assert.equal(withEmoji('دندانپزشکی'), '🦷 دندانپزشکی');
    assert.equal(withEmoji('کار عجیب xyz'), `${FALLBACK_EMOJI} کار عجیب xyz`);
    assert.equal(withEmoji('🦷 دندان'), '🦷 دندان');
    assert.equal(withEmoji('  '), '');
    assert.equal(hasLeadingEmoji('✅ انجام'), true);
    assert.equal(hasLeadingEmoji('انجام'), false);
  });

  it('parses the setting (on by default)', () => {
    assert.equal(AUTO_EMOJI_KEY, 'auto_emoji');
    assert.equal(parseAutoEmoji(null), true);
    assert.equal(parseAutoEmoji('on'), true);
    assert.equal(parseAutoEmoji('off'), false);
  });
});

describe('fonts', () => {
  it('has a label and three families for every font', () => {
    assert.equal(FONT_KEYS.length, 6);
    for (const k of FONT_KEYS) {
      assert.ok(FONT_LABELS[k].length > 2);
      const f = familiesFor(k);
      assert.ok(f.regular.endsWith('_400Regular') && f.medium.endsWith('_500Medium') && f.bold.endsWith('_700Bold'));
    }
    assert.deepEqual(familiesFor('vazirmatn'), { regular: 'Vazirmatn_400Regular', medium: 'Vazirmatn_500Medium', bold: 'Vazirmatn_700Bold' });
  });

  it('parses the saved font, defaulting to Vazirmatn', () => {
    assert.equal(parseFontKey(null), 'vazirmatn');
    assert.equal(parseFontKey('cairo'), 'cairo');
    assert.equal(parseFontKey('comic'), 'vazirmatn');
  });

  it('the theme uses the chosen font for each text weight', () => {
    const t = createTheme('dark', 'indigo', 1, 'cairo');
    assert.equal(t.text('title').fontFamily, 'Cairo_700Bold');
    assert.equal(t.text('bodyStrong').fontFamily, 'Cairo_500Medium');
    assert.equal(t.text('body').fontFamily, 'Cairo_400Regular');
    assert.equal(t.fontFamilies.bold, 'Cairo_700Bold');
    assert.equal(createTheme('light', 'teal', 1).text('title').fontFamily, 'Vazirmatn_700Bold');
  });
});
