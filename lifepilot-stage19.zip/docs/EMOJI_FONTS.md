# Auto emoji and fonts (stage 19)
- New tasks (task form and quick capture) get a fitting emoji in front of the title, chosen locally from Persian keywords
  (specific words first: «خرید نان» -> 🥖, «دندانپزشکی» -> 🦷, «تماس با مامان» -> 📞). Nothing matches -> 📌. A title that already starts with an emoji is kept.
  Existing tasks are not changed. Settings -> ظاهر -> ایموجی خودکار can turn it off. (A smarter match with DeepSeek may come later.)
- Fonts: Vazirmatn (default), Noto Sans Arabic, IBM Plex Sans Arabic, Cairo, Tajawal, Noto Naskh Arabic, chosen in Settings -> ظاهر, saved on the phone.
  If a font lacks some Persian letters the phone falls back to a system font for those letters.
- Home-screen widgets keep using Vazirmatn.
