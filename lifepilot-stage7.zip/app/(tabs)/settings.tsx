import { ReactNode, useState } from 'react';
import { Platform, View } from 'react-native';
import Constants from 'expo-constants';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { toPersianDigits } from '@/core/calendar/format';
import { AccentKey, ThemeMode, accents } from '@/core/theme/colors';
import { FontSizeKey, fontScales } from '@/core/theme/typography';
import { useTheme, useThemeSettings } from '@/core/theme/useTheme';
import { useDefaultReminder } from '@/features/settings/hooks/useDefaultReminder';
import { useUserName } from '@/features/settings/hooks/useUserName';
import { REMINDER_OPTIONS } from '@/features/tasks/models/labels';
import { useDbInfo } from '@/providers/DatabaseProvider';
import { AppText } from '@/shared/components/AppText';
import { Badge } from '@/shared/components/Badge';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Chip } from '@/shared/components/Chip';
import { Screen } from '@/shared/components/Screen';
import { SegmentedControl } from '@/shared/components/SegmentedControl';
import { TextField } from '@/shared/components/TextField';
import { IconName } from '@/shared/types/icon';

const MODE_OPTIONS: { value: ThemeMode; label: string }[] = [
  { value: 'light', label: 'روشن' },
  { value: 'dark', label: 'تیره' },
  { value: 'system', label: 'سیستم' },
];

function Section({ title, children }: { title: string; children: ReactNode }) {
  const { spacing } = useTheme();
  return (
    <View style={{ gap: spacing.sm }}>
      <AppText variant="label" muted>{title}</AppText>
      {children}
    </View>
  );
}

function LinkRow({ icon, title, subtitle, onPress }: { icon: IconName; title: string; subtitle: string; onPress: () => void }) {
  const { colors, iconSizes, spacing } = useTheme();
  return (
    <Card onPress={onPress} accessibilityLabel={title}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md }}>
        <Ionicons name={icon} size={iconSizes.lg} color={colors.accent} />
        <View style={{ flex: 1 }}>
          <AppText variant="bodyStrong">{title}</AppText>
          <AppText variant="caption" muted>{subtitle}</AppText>
        </View>
      </View>
    </Card>
  );
}

/** A row for a feature that does not exist yet: shown dimmed, with a "soon" badge, and does nothing. */
function UnavailableRow({ icon, title, subtitle }: { icon: IconName; title: string; subtitle: string }) {
  const { colors, iconSizes, spacing } = useTheme();
  return (
    <Card variant="flat">
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md, opacity: 0.7 }}>
        <Ionicons name={icon} size={iconSizes.lg} color={colors.textMuted} />
        <View style={{ flex: 1 }}>
          <AppText variant="bodyStrong">{title}</AppText>
          <AppText variant="caption" muted>{subtitle}</AppText>
        </View>
        <Badge label="به‌زودی" color={colors.textMuted} />
      </View>
    </Card>
  );
}

export default function SettingsScreen() {
  const router = useRouter();
  const { spacing, scheme } = useTheme();
  const db = useDbInfo();
  const { mode, setMode, accent, setAccent, fontSize, setFontSize } = useThemeSettings();
  const defaultReminder = useDefaultReminder();
  const { name, loaded: nameLoaded, save: saveName } = useUserName();
  const [nameDraft, setNameDraft] = useState<string | null>(null);

  const sizeOptions = (Object.keys(fontScales) as FontSizeKey[]).map((k) => ({ value: k, label: fontScales[k].label }));
  const nameValue = nameDraft ?? name ?? '';

  return (
    <Screen title="تنظیمات">
      <Section title="پروفایل">
        <Card variant="outlined">
          <TextField
            label="نام شما (برای سلام در صفحه‌ی خانه)"
            placeholder="مثلاً: رضا"
            value={nameValue}
            onChangeText={setNameDraft}
            maxLength={40}
            editable={nameLoaded}
          />
          <Button
            title="ذخیره‌ی نام"
            size="sm"
            variant="secondary"
            disabled={nameDraft === null || nameDraft.trim() === (name ?? '')}
            onPress={async () => {
              await saveName(nameDraft ?? '');
              setNameDraft(null);
            }}
          />
        </Card>
      </Section>

      <Section title="ظاهر">
        <Card variant="outlined" style={{ gap: spacing.md }}>
          <AppText variant="label" muted>حالت نمایش</AppText>
          <SegmentedControl options={MODE_OPTIONS} value={mode} onChange={setMode} />
          <AppText variant="label" muted>رنگ اصلی</AppText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            {(Object.keys(accents) as AccentKey[]).map((k) => (
              <Chip key={k} label={accents[k].label} color={accents[k][scheme]} selected={accent === k} onPress={() => setAccent(k)} />
            ))}
          </View>
          <AppText variant="label" muted>اندازه‌ی متن</AppText>
          <SegmentedControl options={sizeOptions} value={fontSize} onChange={setFontSize} />
          <AppText variant="caption" muted>تغییرات بلافاصله اعمال و روی همین گوشی ذخیره می‌شوند.</AppText>
        </Card>
      </Section>

      <Section title="زبان">
        <Card variant="outlined">
          <AppText variant="bodyStrong">فارسی</AppText>
          <AppText variant="caption" muted>در این نسخه فقط فارسی (راست‌به‌چپ) پشتیبانی می‌شود.</AppText>
        </Card>
      </Section>

      <Section title="اعلان‌ها و یادآوری">
        <Card variant="flat">
          <AppText variant="caption" muted>
            ارسال اعلان، آلارم و تکرار یادآوری هنوز پیاده‌سازی نشده و در فاز بعدی اضافه می‌شود. تا آن زمان یادآوری‌ها فقط همراه کار ذخیره می‌شوند.
          </AppText>
        </Card>
        <UnavailableRow icon="notifications-outline" title="فعال‌سازی اعلان‌ها" subtitle="صدا، لرزش و آلارم دقیق" />
        <Card variant="outlined">
          <AppText variant="bodyStrong">یادآوری پیش‌فرض برای کارهای جدید</AppText>
          <AppText variant="caption" muted>در فرم کار جدید، وقتی ساعت انتخاب شود از قبل انتخاب می‌شود.</AppText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            <Chip label="بدون یادآوری" selected={defaultReminder.offset === null} onPress={() => void defaultReminder.save(null)} />
            {REMINDER_OPTIONS.map((o) => (
              <Chip
                key={o.offset}
                label={o.label}
                selected={defaultReminder.offset === o.offset}
                onPress={() => void defaultReminder.save(o.offset)}
              />
            ))}
          </View>
        </Card>
      </Section>

      <Section title="حریم خصوصی و داده‌ها">
        <Card variant="outlined">
          <AppText variant="bodyStrong">داده‌های شما روی همین گوشی است</AppText>
          <AppText variant="caption" muted>
            کارها، دسته‌ها و تنظیمات در پایگاه داده‌ی محلی گوشی ذخیره می‌شوند. برنامه حساب کاربری ندارد و چیزی به سرور ارسال نمی‌کند.
            برنامه بدون اینترنت کار می‌کند. فقط ورودی صوتی فارسی ممکن است برای تشخیص گفتار از سرویس گوگل گوشی استفاده کند (و به اینترنت نیاز داشته باشد)، آن هم فقط وقتی دکمه‌ی میکروفون را بزنید.
          </AppText>
        </Card>
        <UnavailableRow icon="cloud-upload-outline" title="پشتیبان‌گیری" subtitle="هنوز پیاده‌سازی نشده است" />
        <UnavailableRow icon="cloud-download-outline" title="بازیابی از پشتیبان" subtitle="هنوز پیاده‌سازی نشده است" />
      </Section>

      <Section title="مدیریت">
        <LinkRow
          icon="pricetags-outline"
          title="دسته‌بندی‌ها"
          subtitle="ساخت، تغییر نام و رنگ، و حذف دسته‌ها"
          onPress={() => router.push('/categories')}
        />
        <LinkRow
          icon="color-palette-outline"
          title="نمایشگاه طراحی (ابزار توسعه)"
          subtitle="پیش‌نمایش رنگ‌ها و کامپوننت‌ها"
          onPress={() => router.push('/design-showcase')}
        />
      </Section>

      <Section title="درباره">
        <Card variant="outlined">
          <AppText variant="bodyStrong">لایف‌پایلوت</AppText>
          <AppText muted>نسخه برنامه: {toPersianDigits(Constants.expoConfig?.version ?? '—')}</AppText>
          <AppText muted>شماره‌ی ساخت: {toPersianDigits(Constants.expoConfig?.android?.versionCode ?? '—')}</AppText>
          <AppText muted>نوع ساخت: {__DEV__ ? 'توسعه' : 'انتشار'}</AppText>
          <AppText muted>اندروید (API): {toPersianDigits(String(Platform.Version))}</AppText>
          <AppText muted>شناسه بسته: com.lifepilot.personalassistant</AppText>
          <AppText muted>نسخه‌ی ساختار پایگاه داده: {toPersianDigits(db.schemaVersion)}</AppText>
          <AppText muted>دفعات اجرای برنامه: {toPersianDigits(db.launchCount)}</AppText>
        </Card>
      </Section>
    </Screen>
  );
}
