import { useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { useRouter } from 'expo-router';
import { formatJalaliDate } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import { useCategories } from '@/features/categories/hooks/useCategories';
import { StatCard } from '@/features/dashboard/components/StatCard';
import { TodayTimeline } from '@/features/dashboard/components/TodayTimeline';
import { useDashboard } from '@/features/dashboard/hooks/useDashboard';
import { greetingForHour } from '@/features/dashboard/services/dashboardStats';
import { useUserName } from '@/features/settings/hooks/useUserName';
import { TaskCard } from '@/features/tasks/components/TaskCard';
import { useToggleTask } from '@/features/tasks/hooks/useToggleTask';
import type { Task } from '@/features/tasks/models/task';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { EmptyState } from '@/shared/components/EmptyState';
import { Fab } from '@/shared/components/Fab';
import { Screen } from '@/shared/components/Screen';
import { TextField } from '@/shared/components/TextField';

export default function HomeScreen() {
  const router = useRouter();
  const { colors, spacing } = useTheme();
  const { now, stats, next, timeline, loading, error, hasPendingTasks } = useDashboard();
  const { byId } = useCategories();
  const toggle = useToggleTask();
  const { name, loaded: nameLoaded, save: saveName } = useUserName();
  const [nameDraft, setNameDraft] = useState('');

  const open = (t: Task) => router.push(`/task/${t.id}`);
  const nowDate = new Date(now);
  const greeting = `${greetingForHour(nowDate.getHours())}${name ? `، ${name}` : ''}`;
  const noTasksAtAll = !loading && timeline.length === 0 && !hasPendingTasks;

  return (
    <View style={{ flex: 1 }}>
      <Screen title={greeting} subtitle={formatJalaliDate(nowDate, { weekday: true })}>
        {nameLoaded && name === null ? (
          <Card variant="outlined">
            <AppText variant="bodyStrong">نام شما چیست؟</AppText>
            <AppText variant="caption" muted>برای شخصی‌سازی سلام. فقط روی همین گوشی ذخیره می‌شود.</AppText>
            <TextField
              placeholder="مثلاً: رضا"
              value={nameDraft}
              onChangeText={setNameDraft}
              maxLength={40}
              returnKeyType="done"
              onSubmitEditing={() => saveName(nameDraft)}
            />
            <Button title="ذخیره" size="sm" onPress={() => saveName(nameDraft)} disabled={nameDraft.trim() === ''} />
          </Card>
        ) : null}

        {loading ? <ActivityIndicator /> : null}
        {error ? <AppText color="danger">{error}</AppText> : null}

        <Button
          title="افزودن کار با صدا"
          icon="mic-outline"
          variant="secondary"
          onPress={() => router.push('/task/new?voice=1')}
        />

        <View style={{ flexDirection: 'row', gap: spacing.md }}>
          <StatCard label="کارهای امروز" value={stats.todayTotal} icon="today-outline" />
          <StatCard label="انجام‌شده" value={stats.completedToday} icon="checkmark-done-outline" color={colors.success} />
        </View>
        <View style={{ flexDirection: 'row', gap: spacing.md }}>
          <StatCard label="باقی‌مانده" value={stats.remainingToday} icon="hourglass-outline" color={colors.info} />
          <StatCard
            label="عقب‌افتاده"
            value={stats.overdue}
            icon="alert-circle-outline"
            color={colors.danger}
            onPress={() => router.push('/(tabs)/tasks')}
          />
        </View>

        {noTasksAtAll ? (
          <EmptyState
            icon="sparkles-outline"
            title="هنوز کاری ثبت نکرده‌اید"
            description="اولین کار خود را بسازید تا برنامه‌ی امروز اینجا نمایش داده شود."
            actionLabel="افزودن کار"
            onAction={() => router.push('/task/new')}
          />
        ) : null}

        {next ? (
          <View style={{ gap: spacing.sm }}>
            <AppText variant="heading">کار بعدی</AppText>
            <TaskCard
              task={next}
              category={next.categoryId ? byId.get(next.categoryId) : undefined}
              now={now}
              onPress={open}
              onToggle={toggle}
            />
          </View>
        ) : null}

        {!noTasksAtAll ? (
          <View style={{ gap: spacing.sm }}>
            <AppText variant="heading">برنامه‌ی امروز</AppText>
            {timeline.length > 0 ? (
              <TodayTimeline tasks={timeline} categories={byId} now={now} onPress={open} onToggle={toggle} />
            ) : !loading ? (
              <Card variant="flat">
                <AppText muted>برای امروز کاری ندارید.</AppText>
              </Card>
            ) : null}
          </View>
        ) : null}
        <View style={{ height: 80 }} />
      </Screen>
      <Fab onPress={() => router.push('/task/new')} accessibilityLabel="افزودن کار جدید" />
    </View>
  );
}
