import { useCallback, useEffect, useState } from 'react';
import { useRepositories } from '@/providers/DatabaseProvider';
import { SETTING_KEYS, parseDefaultReminder, serializeDefaultReminder } from '../services/settingsKeys';

/** Default reminder (minutes before the due time) pre-selected for new tasks. */
export function useDefaultReminder(): { offset: number | null; loaded: boolean; save: (offset: number | null) => Promise<void> } {
  const { settings } = useRepositories();
  const [offset, setOffset] = useState<number | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    settings
      .get(SETTING_KEYS.defaultReminder)
      .then((raw) => {
        if (!cancelled) {
          setOffset(parseDefaultReminder(raw));
          setLoaded(true);
        }
      })
      .catch(() => {
        if (!cancelled) setLoaded(true);
      });
    return () => {
      cancelled = true;
    };
  }, [settings]);

  const save = useCallback(
    async (value: number | null) => {
      await settings.set(SETTING_KEYS.defaultReminder, serializeDefaultReminder(value));
      setOffset(value);
    },
    [settings],
  );

  return { offset, loaded, save };
}
