import { useCallback, useEffect, useReducer, useRef } from 'react';
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from 'expo-speech-recognition';
import { initialVoiceState, voiceReducer } from '../services/voiceState';

/**
 * Real speech-to-text through the phone's speech service (Android SpeechRecognizer).
 * Listens only after the user taps the microphone; nothing runs in the background.
 */
export function useVoiceInput() {
  const [state, dispatch] = useReducer(voiceReducer, initialVoiceState);
  const listening = useRef(false);
  listening.current = state.status === 'listening';

  useSpeechRecognitionEvent('result', (event) => {
    dispatch({ type: 'result', transcript: event.results[0]?.transcript ?? '' });
  });
  useSpeechRecognitionEvent('error', (event) => {
    dispatch({ type: 'error', code: event.error });
  });
  useSpeechRecognitionEvent('end', () => {
    dispatch({ type: 'end' });
  });

  const start = useCallback(async () => {
    if (!ExpoSpeechRecognitionModule.isRecognitionAvailable()) {
      dispatch({ type: 'unavailable' });
      return;
    }
    const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
    if (!permission.granted) {
      dispatch({ type: 'permissionDenied', canAskAgain: permission.canAskAgain });
      return;
    }
    dispatch({ type: 'start' });
    ExpoSpeechRecognitionModule.start({
      lang: 'fa-IR',
      interimResults: true,
      continuous: false,
      maxAlternatives: 1,
    });
  }, []);

  const stop = useCallback(() => {
    ExpoSpeechRecognitionModule.stop();
  }, []);

  const edit = useCallback((transcript: string) => dispatch({ type: 'edit', transcript }), []);

  const reset = useCallback(() => {
    if (listening.current) ExpoSpeechRecognitionModule.abort();
    dispatch({ type: 'reset' });
  }, []);

  // Never keep the microphone open after the screen is gone.
  useEffect(() => {
    return () => {
      if (listening.current) ExpoSpeechRecognitionModule.abort();
    };
  }, []);

  return { state, start, stop, edit, reset };
}
