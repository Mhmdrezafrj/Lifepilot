/**
 * Pure state machine for voice input, independent of the native module so it can be tested.
 * Error codes follow the Web Speech API names used by expo-speech-recognition.
 */
export type VoiceStatus = 'idle' | 'listening' | 'error';

export interface VoiceError {
  code: string;
  message: string;
  /** True when the user must enable the microphone permission in system settings. */
  needsSettings: boolean;
}

export interface VoiceState {
  status: VoiceStatus;
  transcript: string;
  error: VoiceError | null;
}

export type VoiceAction =
  | { type: 'start' }
  | { type: 'result'; transcript: string }
  | { type: 'end' }
  | { type: 'error'; code: string }
  | { type: 'permissionDenied'; canAskAgain: boolean }
  | { type: 'unavailable' }
  | { type: 'edit'; transcript: string }
  | { type: 'reset' };

export const initialVoiceState: VoiceState = { status: 'idle', transcript: '', error: null };

export function describeSpeechError(code: string): VoiceError {
  switch (code) {
    case 'not-allowed':
      return { code, needsSettings: true, message: 'اجازه‌ی استفاده از میکروفون داده نشده است. می‌توانید از تنظیمات گوشی آن را فعال کنید یا متن را تایپ کنید.' };
    case 'network':
      return { code, needsSettings: false, message: 'تشخیص گفتار فارسی به اینترنت نیاز دارد و اتصال برقرار نشد. اینترنت را بررسی کنید یا متن را تایپ کنید.' };
    case 'language-not-supported':
      return { code, needsSettings: false, message: 'سرویس گفتار این گوشی زبان فارسی را پشتیبانی نمی‌کند. لطفاً متن را تایپ کنید.' };
    case 'service-not-allowed':
      return { code, needsSettings: false, message: 'سرویس تشخیص گفتار در این گوشی در دسترس نیست. برنامه‌ی Google یا «Speech Recognition & Synthesis» باید نصب و فعال باشد. می‌توانید تایپ کنید.' };
    case 'audio-capture':
      return { code, needsSettings: false, message: 'میکروفون در دسترس نیست یا برنامه‌ی دیگری از آن استفاده می‌کند.' };
    case 'busy':
      return { code, needsSettings: false, message: 'سرویس گفتار مشغول است؛ چند لحظه بعد دوباره تلاش کنید.' };
    case 'no-speech':
    case 'speech-timeout':
      return { code, needsSettings: false, message: 'صدایی شنیده نشد. دوباره تلاش کنید و واضح‌تر صحبت کنید.' };
    default:
      return { code, needsSettings: false, message: 'تشخیص گفتار با خطا روبه‌رو شد. دوباره تلاش کنید یا متن را تایپ کنید.' };
  }
}

export function voiceReducer(state: VoiceState, action: VoiceAction): VoiceState {
  switch (action.type) {
    case 'start':
      return { status: 'listening', transcript: '', error: null };
    case 'result':
      return { ...state, transcript: action.transcript };
    case 'end':
      // "end" is always the last native event, also after errors: keep an error visible.
      return state.status === 'listening' ? { ...state, status: 'idle' } : state;
    case 'error':
      // Cancelling on purpose is not an error.
      if (action.code === 'aborted') return { ...state, status: 'idle' };
      return { ...state, status: 'error', error: describeSpeechError(action.code) };
    case 'permissionDenied':
      return {
        ...state,
        status: 'error',
        error: { ...describeSpeechError('not-allowed'), needsSettings: !action.canAskAgain },
      };
    case 'unavailable':
      return { ...state, status: 'error', error: describeSpeechError('service-not-allowed') };
    case 'edit':
      return { ...state, transcript: action.transcript };
    case 'reset':
      return initialVoiceState;
  }
}
