import { useEffect } from 'react';
import { Linking, Modal, Pressable, View } from 'react-native';
import Animated, {
  Easing, useAnimatedStyle, useSharedValue, withRepeat, withTiming,
} from 'react-native-reanimated';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/core/theme/useTheme';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { TextField } from '@/shared/components/TextField';
import { useVoiceInput } from '../hooks/useVoiceInput';

interface Props {
  visible: boolean;
  /** Start listening as soon as the sheet opens (used by "add with voice"). */
  autoStart?: boolean;
  onUse: (text: string) => void;
  onClose: () => void;
}

function MicButton({ listening, onPress }: { listening: boolean; onPress: () => void }) {
  const { colors, iconSizes } = useTheme();
  const pulse = useSharedValue(0);

  useEffect(() => {
    if (listening) {
      pulse.value = withRepeat(withTiming(1, { duration: 900, easing: Easing.inOut(Easing.ease) }), -1, true);
    } else {
      pulse.value = withTiming(0, { duration: 150 });
    }
  }, [listening, pulse]);

  const ring = useAnimatedStyle(() => ({
    transform: [{ scale: 1 + pulse.value * 0.35 }],
    opacity: 0.35 * (1 - pulse.value * 0.6) * (listening ? 1 : 0),
  }));

  const bg = listening ? colors.danger : colors.accent;
  return (
    <View style={{ width: 120, height: 120, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.View
        style={[{ position: 'absolute', width: 96, height: 96, borderRadius: 48, backgroundColor: bg }, ring]}
      />
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={listening ? 'توقف ضبط' : 'شروع ضبط صدا'}
        onPress={onPress}
        style={{
          width: 84, height: 84, borderRadius: 42, backgroundColor: bg, alignItems: 'center', justifyContent: 'center',
        }}
      >
        <Ionicons name={listening ? 'stop' : 'mic'} size={iconSizes.xl + 4} color={listening ? '#FFFFFF' : colors.textOnAccent} />
      </Pressable>
    </View>
  );
}

/** Bottom sheet for dictating text. The recognised text stays editable and typing is always possible. */
export function VoiceInputModal({ visible, autoStart, onUse, onClose }: Props) {
  const { colors, radii, spacing } = useTheme();
  const { state, start, stop, edit, reset } = useVoiceInput();
  const listening = state.status === 'listening';

  useEffect(() => {
    if (visible) {
      reset();
      if (autoStart) void start();
    } else {
      reset();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible]);

  const hint = listening
    ? 'در حال گوش دادن… صحبت کنید'
    : state.transcript.trim()
      ? 'متن را بررسی و در صورت نیاز ویرایش کنید'
      : 'برای شروع، دکمه‌ی میکروفون را بزنید';

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: 'flex-end' }} onPress={onClose}>
        <Pressable
          onPress={() => {}}
          style={{
            backgroundColor: colors.surface,
            borderTopLeftRadius: radii.xl,
            borderTopRightRadius: radii.xl,
            padding: spacing.xl,
            gap: spacing.md,
          }}
        >
          <AppText variant="heading" style={{ textAlign: 'center' }}>ورودی صوتی</AppText>

          <View style={{ alignItems: 'center', gap: spacing.xs }}>
            <MicButton listening={listening} onPress={listening ? stop : () => void start()} />
            <AppText variant="label" muted style={{ textAlign: 'center' }}>{hint}</AppText>
          </View>

          <TextField
            label="متن تشخیص‌داده‌شده"
            placeholder="اینجا می‌توانید مستقیم هم تایپ کنید"
            value={state.transcript}
            onChangeText={edit}
            editable={!listening}
            multiline
            maxLength={200}
          />

          {state.error ? (
            <Card variant="flat" style={{ gap: spacing.sm }}>
              <AppText color="danger">{state.error.message}</AppText>
              {state.error.needsSettings ? (
                <Button title="باز کردن تنظیمات گوشی" size="sm" variant="secondary" onPress={() => void Linking.openSettings()} />
              ) : null}
            </Card>
          ) : null}

          <AppText variant="caption" muted>
            تشخیص گفتار فارسی از سرویس گفتار گوگل روی گوشی استفاده می‌کند و ممکن است به اینترنت نیاز داشته باشد.
            میکروفون فقط وقتی دکمه را می‌زنید روشن می‌شود.
          </AppText>

          <View style={{ flexDirection: 'row', gap: spacing.sm }}>
            <Button
              title="استفاده از این متن"
              disabled={listening || state.transcript.trim() === ''}
              onPress={() => onUse(state.transcript.trim())}
            />
            <Button title="تایپ می‌کنم" variant="ghost" onPress={onClose} />
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}
