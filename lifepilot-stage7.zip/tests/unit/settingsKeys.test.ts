import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  parseAccent, parseDefaultReminder, parseFontSize, parseThemeMode, serializeDefaultReminder, SETTING_KEYS,
} from '../../src/features/settings/services/settingsKeys';
import { createNodeClient } from '../helpers/nodeClient';
import { migrate, migrations } from '../../src/core/database/migrations';
import { createRepositories } from '../../src/providers/repositories';

describe('settings parsing', () => {
  it('falls back to defaults for missing or invalid values', () => {
    assert.equal(parseThemeMode(null), 'system');
    assert.equal(parseThemeMode('purple'), 'system');
    assert.equal(parseAccent(null), 'indigo');
    assert.equal(parseAccent('constructor'), 'indigo');
    assert.equal(parseAccent('__proto__'), 'indigo');
    assert.equal(parseFontSize('huge'), 'normal');
    assert.equal(parseFontSize(null), 'normal');
  });

  it('accepts every valid value', () => {
    for (const m of ['light', 'dark', 'system']) assert.equal(parseThemeMode(m), m);
    for (const a of ['indigo', 'teal', 'rose', 'amber', 'emerald']) assert.equal(parseAccent(a), a);
    for (const f of ['small', 'normal', 'large', 'xlarge']) assert.equal(parseFontSize(f), f);
  });

  it('parses the default reminder', () => {
    assert.equal(parseDefaultReminder(null), null);
    assert.equal(parseDefaultReminder('none'), null);
    assert.equal(parseDefaultReminder('10'), 10);
    assert.equal(parseDefaultReminder('0'), 0);
    assert.equal(parseDefaultReminder('1440'), 1440);
    assert.equal(parseDefaultReminder('7'), null);
    assert.equal(parseDefaultReminder('abc'), null);
  });

  it('round-trips the default reminder', () => {
    for (const v of [null, 0, 10, 30, 60, 1440]) assert.equal(parseDefaultReminder(serializeDefaultReminder(v)), v);
  });
});

describe('settings persistence', () => {
  it('stores appearance settings in the database and reads them back', async () => {
    const db = createNodeClient();
    await migrate(db, migrations);
    const { settings } = createRepositories(db);
    await settings.set(SETTING_KEYS.themeMode, 'dark');
    await settings.set(SETTING_KEYS.accent, 'teal');
    await settings.set(SETTING_KEYS.fontSize, 'large');
    await settings.set(SETTING_KEYS.defaultReminder, serializeDefaultReminder(30));
    assert.equal(parseThemeMode(await settings.get(SETTING_KEYS.themeMode)), 'dark');
    assert.equal(parseAccent(await settings.get(SETTING_KEYS.accent)), 'teal');
    assert.equal(parseFontSize(await settings.get(SETTING_KEYS.fontSize)), 'large');
    assert.equal(parseDefaultReminder(await settings.get(SETTING_KEYS.defaultReminder)), 30);
  });
});
