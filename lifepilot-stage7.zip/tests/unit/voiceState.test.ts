import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { describeSpeechError, initialVoiceState, voiceReducer } from '../../src/features/voice/services/voiceState';

const run = (...actions: Parameters<typeof voiceReducer>[1][]) =>
  actions.reduce(voiceReducer, initialVoiceState);

describe('voice input state', () => {
  it('starts idle and empty', () => {
    assert.deepEqual(initialVoiceState, { status: 'idle', transcript: '', error: null });
  });

  it('listens, collects results, and returns to idle keeping the text', () => {
    const s = run({ type: 'start' }, { type: 'result', transcript: 'خرید' }, { type: 'result', transcript: 'خرید نان' }, { type: 'end' });
    assert.equal(s.status, 'idle');
    assert.equal(s.transcript, 'خرید نان');
    assert.equal(s.error, null);
  });

  it('shows listening while recording', () => {
    assert.equal(run({ type: 'start' }).status, 'listening');
  });

  it('starting again clears the old text and error', () => {
    const s = run({ type: 'start' }, { type: 'result', transcript: 'a' }, { type: 'error', code: 'network' }, { type: 'start' });
    assert.deepEqual(s, { status: 'listening', transcript: '', error: null });
  });

  it('keeps an error visible after the final "end" event', () => {
    const s = run({ type: 'start' }, { type: 'error', code: 'no-speech' }, { type: 'end' });
    assert.equal(s.status, 'error');
    assert.equal(s.error?.code, 'no-speech');
  });

  it('cancelling on purpose (aborted) is not an error', () => {
    const s = run({ type: 'start' }, { type: 'error', code: 'aborted' }, { type: 'end' });
    assert.equal(s.status, 'idle');
    assert.equal(s.error, null);
  });

  it('keeps recognised text when an error happens after it', () => {
    const s = run({ type: 'start' }, { type: 'result', transcript: 'متن' }, { type: 'error', code: 'network' });
    assert.equal(s.transcript, 'متن');
    assert.equal(s.status, 'error');
  });

  it('lets the user edit the recognised text', () => {
    const s = run({ type: 'start' }, { type: 'result', transcript: 'a' }, { type: 'end' }, { type: 'edit', transcript: 'ab' });
    assert.equal(s.transcript, 'ab');
    assert.equal(s.status, 'idle');
  });

  it('handles denied permission and tells whether settings are needed', () => {
    const askAgain = run({ type: 'permissionDenied', canAskAgain: true });
    assert.equal(askAgain.status, 'error');
    assert.equal(askAgain.error?.needsSettings, false);
    const blocked = run({ type: 'permissionDenied', canAskAgain: false });
    assert.equal(blocked.error?.needsSettings, true);
  });

  it('reports an unavailable speech service', () => {
    const s = run({ type: 'unavailable' });
    assert.equal(s.status, 'error');
    assert.equal(s.error?.code, 'service-not-allowed');
  });

  it('reset returns to the initial state', () => {
    assert.deepEqual(run({ type: 'start' }, { type: 'result', transcript: 'x' }, { type: 'reset' }), initialVoiceState);
  });
});

describe('speech error messages', () => {
  it('explains the network limitation for Persian recognition', () => {
    assert.match(describeSpeechError('network').message, /اینترنت/);
  });

  it('marks only not-allowed as needing system settings', () => {
    assert.equal(describeSpeechError('not-allowed').needsSettings, true);
    for (const c of ['network', 'no-speech', 'service-not-allowed', 'language-not-supported', 'audio-capture', 'busy', 'client', 'unknown']) {
      assert.equal(describeSpeechError(c).needsSettings, false, c);
    }
  });

  it('has a Persian message for every code, including unknown ones', () => {
    for (const c of ['not-allowed', 'network', 'language-not-supported', 'service-not-allowed', 'audio-capture', 'busy', 'no-speech', 'speech-timeout', 'client', 'unknown', 'something-new']) {
      assert.ok(describeSpeechError(c).message.length > 10, c);
    }
  });
});
