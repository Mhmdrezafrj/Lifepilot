import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import { buildReminderContent } from './reminderText';
import {
  ACTION_COMPLETE, ACTION_SNOOZE, REMINDER_CATEGORY, REMINDER_CHANNEL_ID,
} from './notificationResponse';
import type { NotificationGateway, PermissionState, PlannedReminder } from './types';

/** Must run once at startup (module level): decides how notifications look while the app is open. */
export function configureNotificationHandler(): void {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldPlaySound: true,
      shouldSetBadge: false,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
}

/** Creates the Android channel and the action buttons. Safe to call many times. */
export async function setupNotifications(): Promise<void> {
  if (Platform.OS !== 'android') return;
  await Notifications.setNotificationChannelAsync(REMINDER_CHANNEL_ID, {
    name: 'یادآوری کارها',
    description: 'اعلان موعد کارها',
    importance: Notifications.AndroidImportance.HIGH,
    vibrationPattern: [0, 300, 200, 300],
    enableVibrate: true,
    sound: 'default',
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
  });
  await Notifications.setNotificationCategoryAsync(REMINDER_CATEGORY, [
    { identifier: ACTION_COMPLETE, buttonTitle: 'انجام شد', options: { opensAppToForeground: true } },
    { identifier: ACTION_SNOOZE, buttonTitle: '۱۰ دقیقه بعد', options: { opensAppToForeground: true } },
  ]);
}

function mapPermission(status: string): PermissionState {
  if (status === 'granted') return 'granted';
  if (status === 'denied') return 'denied';
  return 'undetermined';
}

export async function getNotificationPermission(): Promise<{ state: PermissionState; canAskAgain: boolean }> {
  if (Platform.OS !== 'android') return { state: 'unavailable', canAskAgain: false };
  const p = await Notifications.getPermissionsAsync();
  return { state: mapPermission(p.status), canAskAgain: p.canAskAgain };
}

export async function requestNotificationPermission(): Promise<{ state: PermissionState; canAskAgain: boolean }> {
  if (Platform.OS !== 'android') return { state: 'unavailable', canAskAgain: false };
  await setupNotifications(); // Android 13+ shows the prompt only once a channel exists
  const p = await Notifications.requestPermissionsAsync();
  return { state: mapPermission(p.status), canAskAgain: p.canAskAgain };
}

/** A real notification a few seconds from now, so the user can check delivery on their own phone. */
export async function scheduleTestNotification(seconds = 10): Promise<void> {
  await setupNotifications();
  await Notifications.scheduleNotificationAsync({
    identifier: 'lifepilot-test',
    content: { title: 'اعلان آزمایشی لایف‌پایلوت', body: 'اگر این را می‌بینید، اعلان‌ها روی گوشی شما کار می‌کنند ✅' },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DATE,
      date: new Date(Date.now() + seconds * 1000),
      channelId: REMINDER_CHANNEL_ID,
    },
  });
}

/**
 * NotificationGateway on top of expo-notifications. On Android it uses AlarmManager under the hood,
 * keeps scheduled notifications across phone restarts, and uses exact timing when Android allows it.
 */
export function createExpoNotificationGateway(): NotificationGateway {
  return {
    isAvailable: async () => Platform.OS === 'android',
    getPermission: async () => (await getNotificationPermission()).state,
    requestPermission: async () => (await requestNotificationPermission()).state,

    async schedule(r: PlannedReminder): Promise<void> {
      const { title, body } = buildReminderContent(r);
      await Notifications.scheduleNotificationAsync({
        identifier: r.id,
        content: {
          title,
          body,
          data: { taskId: r.taskId, reminderId: r.reminderId, plannedFireAt: r.fireAt },
          categoryIdentifier: REMINDER_CATEGORY,
        },
        trigger: {
          type: Notifications.SchedulableTriggerInputTypes.DATE,
          date: new Date(r.fireAt),
          channelId: REMINDER_CHANNEL_ID,
        },
      });
    },

    async cancel(plannedId: string): Promise<void> {
      await Notifications.cancelScheduledNotificationAsync(plannedId);
    },

    async cancelForTask(taskId: string): Promise<void> {
      const all = await Notifications.getAllScheduledNotificationsAsync();
      for (const n of all) {
        const data = n.content.data as { taskId?: unknown } | null;
        if (data && data.taskId === taskId) await Notifications.cancelScheduledNotificationAsync(n.identifier);
      }
    },
  };
}
