import { formatTime, toPersianDigits } from '../../core/calendar/format';
import type { PlannedReminder } from './types';

/** "۱۰ دقیقه", "۲ ساعت", "۱ روز", "۱ ساعت و ۳۰ دقیقه" */
export function formatOffset(minutes: number): string {
  if (minutes % 1440 === 0 && minutes >= 1440) return `${toPersianDigits(minutes / 1440)} روز`;
  if (minutes < 60) return `${toPersianDigits(minutes)} دقیقه`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m === 0 ? `${toPersianDigits(h)} ساعت` : `${toPersianDigits(h)} ساعت و ${toPersianDigits(m)} دقیقه`;
}

/** Title and body of the notification for a planned reminder. */
export function buildReminderContent(r: PlannedReminder): { title: string; body: string } {
  const at = `ساعت ${formatTime(new Date(r.dueAt))}`;
  let body: string;
  if (r.repeatIndex > 0) body = `یادآوری مجدد: موعد انجام این کار ${at} است`;
  else if (r.offsetMinutes === 0) body = `الان موعد انجام این کار است (${at})`;
  else body = `${formatOffset(r.offsetMinutes)} تا موعد (${at})`;
  return { title: r.taskTitle, body };
}
