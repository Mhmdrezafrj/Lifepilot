import type { ReminderChannel, Task } from '../../features/tasks/models/task';

/**
 * Contracts for the reminder system. NotificationGateway is implemented with expo-notifications
 * (expoNotificationGateway.ts). AlarmGateway (loud, full-screen alarm) is not implemented yet; alarm
 * reminders fall back to normal notifications.
 */

/** One concrete moment at which a reminder should fire. */
export interface PlannedReminder {
  /** Stable id: `${reminderId}:${repeatIndex}`. Gateways use it to cancel precisely. */
  id: string;
  reminderId: string;
  taskId: string;
  taskTitle: string;
  /** Epoch milliseconds (UTC). */
  fireAt: number;
  channel: ReminderChannel;
  /** 0 for the first fire, 1.. for repeats. */
  repeatIndex: number;
  /** The task's due time (epoch ms) and how many minutes before it this reminder fires. Used for the message text. */
  dueAt: number;
  offsetMinutes: number;
}

export type PermissionState = 'granted' | 'denied' | 'undetermined' | 'unavailable';

/** Delivers ordinary notifications (Android: NotificationManager / AlarmManager inexact). */
export interface NotificationGateway {
  isAvailable(): Promise<boolean>;
  getPermission(): Promise<PermissionState>;
  requestPermission(): Promise<PermissionState>;
  schedule(reminder: PlannedReminder): Promise<void>;
  cancel(plannedId: string): Promise<void>;
  cancelForTask(taskId: string): Promise<void>;
}

/** Delivers exact, alarm-like reminders (Android: AlarmManager.setExactAndAllowWhileIdle). */
export interface AlarmGateway {
  isAvailable(): Promise<boolean>;
  /** False when the exact-alarm permission/setting is missing or revoked. */
  canScheduleExact(): Promise<boolean>;
  openExactAlarmSettings(): Promise<void>;
  scheduleExact(reminder: PlannedReminder): Promise<void>;
  cancel(plannedId: string): Promise<void>;
  cancelForTask(taskId: string): Promise<void>;
}

export type SkipReason = 'gateway-unavailable' | 'permission-not-granted' | 'exact-alarm-unavailable';

export interface ScheduleReport {
  planned: number;
  scheduled: number;
  skipped: number;
  reasons: SkipReason[];
}

/** What the task service talks to. It never knows how reminders are delivered. */
export interface ReminderScheduler {
  /** (Re)plans all reminders of a task, replacing any earlier plan. */
  scheduleTask(task: Task): Promise<ScheduleReport>;
  cancelTask(taskId: string): Promise<void>;
  /** For boot, timezone change, or permission change: rebuilds everything from the database. */
  rescheduleAll(tasks: Task[]): Promise<ScheduleReport>;
}
