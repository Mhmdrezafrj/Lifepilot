import type { Task } from '../../features/tasks/models/task';
import type { PlannedReminder } from './types';

/** When a reminder has a repeat interval but no limit, it repeats this many extra times. */
export const DEFAULT_MAX_REPEATS = 5;

const MINUTE_MS = 60_000;

/**
 * Turns a task's reminder settings into concrete future moments. Pure function, no I/O.
 * - Only pending tasks with a due date AND a time get reminders (offsets need a time of day).
 * - Disabled reminders are skipped. Moments that are not in the future are dropped.
 * - A reminder with `repeatIntervalMinutes` fires again every interval, `maxRepeats` extra times.
 */
export function planReminders(task: Task, now: number): PlannedReminder[] {
  if (task.status !== 'pending' || task.dueAt === null || !task.hasTime) return [];

  const planned: PlannedReminder[] = [];
  for (const r of task.reminders) {
    if (!r.enabled) continue;
    const first = task.dueAt - r.offsetMinutes * MINUTE_MS;
    const extra = r.repeatIntervalMinutes !== null ? (r.maxRepeats ?? DEFAULT_MAX_REPEATS) : 0;
    for (let k = 0; k <= extra; k++) {
      const fireAt = first + k * (r.repeatIntervalMinutes ?? 0) * MINUTE_MS;
      if (fireAt <= now) continue;
      planned.push({
        id: `${r.id}:${k}`,
        reminderId: r.id,
        taskId: task.id,
        taskTitle: task.title,
        fireAt,
        channel: r.channel,
        repeatIndex: k,
        dueAt: task.dueAt,
        offsetMinutes: r.offsetMinutes,
      });
    }
  }
  return planned.sort((a, b) => a.fireAt - b.fireAt || a.id.localeCompare(b.id));
}
