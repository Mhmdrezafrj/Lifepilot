import { useCallback, useEffect, useState } from 'react';
import { AppState, Linking } from 'react-native';
import {
  getNotificationPermission, requestNotificationPermission,
} from '@/infrastructure/notifications/expoNotificationGateway';
import type { PermissionState } from '@/infrastructure/notifications/types';

/** Current notification permission, refreshed whenever the app returns to the foreground. */
export function useNotificationPermission(): {
  state: PermissionState | 'loading';
  canAskAgain: boolean;
  request: () => Promise<void>;
  refresh: () => Promise<void>;
} {
  const [state, setState] = useState<PermissionState | 'loading'>('loading');
  const [canAskAgain, setCanAskAgain] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const p = await getNotificationPermission();
      setState(p.state);
      setCanAskAgain(p.canAskAgain);
    } catch {
      setState('unavailable');
    }
  }, []);

  useEffect(() => {
    void refresh();
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') void refresh();
    });
    return () => sub.remove();
  }, [refresh]);

  const request = useCallback(async () => {
    // After the system refused twice Android no longer shows the prompt: send the user to settings.
    if (state === 'denied' && !canAskAgain) {
      await Linking.openSettings();
      return;
    }
    try {
      const p = await requestNotificationPermission();
      setState(p.state);
      setCanAskAgain(p.canAskAgain);
    } catch {
      setState('unavailable');
    }
  }, [state, canAskAgain]);

  return { state, canAskAgain, request, refresh };
}
