import { ReactNode, useState } from 'react';
import { View } from 'react-native';
import { addDays, isSameDay, startOfDay } from '@/core/calendar/dates';
import { WEEKDAY_NAMES, formatJalaliDate, formatTimeParts, toPersianDigits } from '@/core/calendar/format';
import { useTheme } from '@/core/theme/useTheme';
import type { Category } from '@/features/categories/models/category';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Chip } from '@/shared/components/Chip';
import { IconButton } from '@/shared/components/IconButton';
import { JalaliDatePicker } from '@/shared/components/JalaliDatePicker';
import { TextField } from '@/shared/components/TextField';
import { TimePicker } from '@/shared/components/TimePicker';
import { useNotificationPermission } from '@/features/reminders/hooks/useNotificationPermission';
import { VoiceInputModal } from '@/features/voice/components/VoiceInputModal';
import { FREQUENCY_LABELS, PRIORITY_LABELS, REMINDER_OPTIONS } from '../models/labels';
import { PRIORITIES, RECURRENCE_FREQUENCIES } from '../models/task';
import { FormState, hasAdvancedContent } from './taskFormModel';

const TIME_PRESETS = [
  { hour: 9, minute: 0 },
  { hour: 12, minute: 0 },
  { hour: 18, minute: 0 },
];
// Persian week order, as Date.getDay() values (Saturday first).
const WEEKDAY_ORDER = [6, 0, 1, 2, 3, 4, 5];
const INTERVAL_UNITS = { daily: 'روز', weekly: 'هفته', monthly: 'ماه', yearly: 'سال' } as const;

function Section({ label, note, children }: { label: string; note?: string; children: ReactNode }) {
  const { spacing } = useTheme();
  return (
    <View style={{ gap: spacing.sm }}>
      <AppText variant="label" muted>{label}</AppText>
      {children}
      {note ? <AppText variant="caption" muted>{note}</AppText> : null}
    </View>
  );
}

function Row({ children }: { children: ReactNode }) {
  const { spacing } = useTheme();
  return <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>{children}</View>;
}

interface Props {
  initial: FormState;
  mode: 'create' | 'edit';
  categories: Category[];
  submitting: boolean;
  error: string | null;
  onSubmit: (form: FormState) => void;
  /** Open the voice input sheet right away ("add with voice"). */
  autoVoice?: boolean;
}

export function TaskForm({ initial, mode, categories, submitting, error, onSubmit, autoVoice }: Props) {
  const { colors, spacing } = useTheme();
  const [f, setF] = useState<FormState>(initial);
  const [showMore, setShowMore] = useState(() => hasAdvancedContent(initial));
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [timePickerOpen, setTimePickerOpen] = useState(false);
  const [tagDraft, setTagDraft] = useState('');
  const [itemDraft, setItemDraft] = useState('');
  const notif = useNotificationPermission();
  const [voiceOpen, setVoiceOpen] = useState(!!autoVoice);
  const [voiceAutoStart, setVoiceAutoStart] = useState(!!autoVoice);

  const patch = (p: Partial<FormState>) => setF((s) => ({ ...s, ...p }));

  const today = startOfDay(new Date());
  const tomorrow = addDays(today, 1);
  const isToday = f.date !== null && isSameDay(f.date, today);
  const isTomorrow = f.date !== null && isSameDay(f.date, tomorrow);
  const isCustomDate = f.date !== null && !isToday && !isTomorrow;
  const presetTime = f.time !== null && TIME_PRESETS.some((p) => p.hour === f.time?.hour && p.minute === f.time?.minute);
  const isCustomTime = f.time !== null && !presetTime;
  const hasTime = f.date !== null && f.time !== null;

  const setTime = (hour: number, minute: number) =>
    patch({ time: { hour, minute }, date: f.date ?? today });

  const addTag = () => {
    const tag = tagDraft.trim();
    if (tag && !f.tags.includes(tag) && f.tags.length < 10) patch({ tags: [...f.tags, tag] });
    setTagDraft('');
  };

  const addItem = () => {
    const title = itemDraft.trim();
    if (title && f.checklist.length < 50) patch({ checklist: [...f.checklist, { title, isCompleted: false }] });
    setItemDraft('');
  };

  const toggleReminder = (offset: number) => {
    // Ask for the notification permission the first time a reminder is chosen.
    if (!f.reminderOffsets.includes(offset) && (notif.state === 'undetermined' || notif.state === 'denied')) {
      void notif.request();
    }
    patch({
      reminderOffsets: f.reminderOffsets.includes(offset)
        ? f.reminderOffsets.filter((o) => o !== offset)
        : [...f.reminderOffsets, offset].sort((a, b) => b - a),
    });
  };

  const toggleWeekday = (d: number) =>
    patch({
      recurrenceWeekdays: f.recurrenceWeekdays.includes(d)
        ? f.recurrenceWeekdays.filter((x) => x !== d)
        : [...f.recurrenceWeekdays, d],
    });

  return (
    <View style={{ gap: spacing.lg }}>
      <TextField
        label="عنوان"
        placeholder="چه کاری باید انجام شود؟"
        value={f.title}
        onChangeText={(title) => patch({ title })}
        autoFocus={mode === 'create'}
        maxLength={200}
        returnKeyType="done"
      />

      <Button
        title="گفتن عنوان با صدا"
        variant="secondary"
        size="sm"
        icon="mic-outline"
        onPress={() => setVoiceOpen(true)}
      />

      <Section label="تاریخ">
        <Row>
          <Chip
            label="بدون تاریخ"
            selected={f.date === null}
            onPress={() =>
              patch({ date: null, time: null, reminderOffsets: [], recurrenceFrequency: null })
            }
          />
          <Chip label="امروز" selected={isToday} onPress={() => patch({ date: today })} />
          <Chip label="فردا" selected={isTomorrow} onPress={() => patch({ date: tomorrow })} />
          <Chip
            icon="calendar-outline"
            label={isCustomDate && f.date ? formatJalaliDate(f.date, { weekday: true, year: 'auto' }) : 'انتخاب تاریخ…'}
            selected={isCustomDate}
            onPress={() => setDatePickerOpen(true)}
          />
        </Row>
      </Section>

      <Section label="ساعت">
        <Row>
          <Chip
            label="بدون ساعت"
            selected={f.time === null}
            onPress={() => patch({ time: null, reminderOffsets: [] })}
          />
          {TIME_PRESETS.map((p) => (
            <Chip
              key={`${p.hour}:${p.minute}`}
              label={formatTimeParts(p.hour, p.minute)}
              selected={f.time?.hour === p.hour && f.time?.minute === p.minute}
              onPress={() => setTime(p.hour, p.minute)}
            />
          ))}
          <Chip
            icon="time-outline"
            label={isCustomTime && f.time ? formatTimeParts(f.time.hour, f.time.minute) : 'انتخاب ساعت…'}
            selected={isCustomTime}
            onPress={() => setTimePickerOpen(true)}
          />
        </Row>
      </Section>

      <Section label="اولویت">
        <Row>
          {PRIORITIES.map((p) => (
            <Chip
              key={p}
              label={PRIORITY_LABELS[p]}
              color={colors.priority[p]}
              selected={f.priority === p}
              onPress={() => patch({ priority: p })}
            />
          ))}
        </Row>
      </Section>

      <Section label="دسته‌بندی">
        <Row>
          <Chip label="بدون دسته" selected={f.categoryId === null} onPress={() => patch({ categoryId: null })} />
          {categories.map((c) => (
            <Chip
              key={c.id}
              label={c.name}
              color={c.color}
              selected={f.categoryId === c.id}
              onPress={() => patch({ categoryId: c.id })}
            />
          ))}
        </Row>
      </Section>

      <Section
        label="یادآوری"
        note={
          hasTime
            ? 'سر زمان یادآوری، اعلان با صدا و لرزش نمایش داده می‌شود (حتی اگر برنامه بسته باشد).'
            : 'برای انتخاب یادآوری، ابتدا تاریخ و ساعت را مشخص کنید.'
        }
      >
        {notif.state === 'denied' || notif.state === 'undetermined' ? (
          <Card variant="flat" style={{ gap: spacing.sm }}>
            <AppText variant="caption" color="danger">
              اعلان‌ها برای لایف‌پایلوت فعال نیست؛ بدون آن یادآوری نمی‌رسد.
            </AppText>
            <Button
              title={notif.state === 'denied' && !notif.canAskAgain ? 'باز کردن تنظیمات برنامه' : 'فعال‌سازی اعلان‌ها'}
              size="sm"
              variant="secondary"
              onPress={() => void notif.request()}
            />
          </Card>
        ) : null}
        <View style={{ opacity: hasTime ? 1 : 0.45 }}>
          <Row>
            {REMINDER_OPTIONS.map((o) => (
              <Chip
                key={o.offset}
                label={o.label}
                selected={f.reminderOffsets.includes(o.offset)}
                onPress={hasTime ? () => toggleReminder(o.offset) : undefined}
              />
            ))}
          </Row>
        </View>
      </Section>

      <Button
        title={showMore ? 'پنهان کردن گزینه‌های بیشتر' : 'گزینه‌های بیشتر'}
        variant="ghost"
        size="sm"
        icon={showMore ? 'chevron-up' : 'chevron-down'}
        onPress={() => setShowMore((v) => !v)}
      />

      {showMore ? (
        <Card variant="outlined" style={{ gap: spacing.lg }}>
          <TextField
            label="توضیحات"
            placeholder="اختیاری"
            value={f.description}
            onChangeText={(description) => patch({ description })}
            multiline
            maxLength={2000}
          />

          <Section label="برچسب‌ها">
            {f.tags.length > 0 ? (
              <Row>
                {f.tags.map((t) => (
                  <Chip
                    key={t}
                    icon="close"
                    label={t}
                    onPress={() => patch({ tags: f.tags.filter((x) => x !== t) })}
                  />
                ))}
              </Row>
            ) : null}
            <TextField
              placeholder="برچسب جدید و Enter"
              value={tagDraft}
              onChangeText={setTagDraft}
              onSubmitEditing={addTag}
              onBlur={addTag}
              maxLength={30}
              returnKeyType="done"
              blurOnSubmit={false}
            />
          </Section>

          <Section label="فهرست کارهای کوچک‌تر">
            {f.checklist.map((item, i) => (
              <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
                <IconButton
                  icon={item.isCompleted ? 'checkbox' : 'square-outline'}
                  color={item.isCompleted ? colors.accent : colors.textMuted}
                  accessibilityLabel="تغییر وضعیت"
                  onPress={() =>
                    patch({
                      checklist: f.checklist.map((c, j) => (j === i ? { ...c, isCompleted: !c.isCompleted } : c)),
                    })
                  }
                />
                <View style={{ flex: 1 }}>
                  <AppText
                    muted={item.isCompleted}
                    style={item.isCompleted ? { textDecorationLine: 'line-through' } : undefined}
                  >
                    {item.title}
                  </AppText>
                </View>
                <IconButton
                  icon="trash-outline"
                  color={colors.danger}
                  accessibilityLabel="حذف مورد"
                  onPress={() => patch({ checklist: f.checklist.filter((_, j) => j !== i) })}
                />
              </View>
            ))}
            <TextField
              placeholder="مورد جدید و Enter"
              value={itemDraft}
              onChangeText={setItemDraft}
              onSubmitEditing={addItem}
              onBlur={addItem}
              maxLength={200}
              returnKeyType="done"
              blurOnSubmit={false}
            />
          </Section>

          <Section
            label="تکرار"
            note={f.date === null ? 'برای تکرار، ابتدا تاریخ را مشخص کنید.' : 'ماهانه و سالانه بر اساس تقویم شمسی محاسبه می‌شود.'}
          >
            <View style={{ opacity: f.date === null ? 0.45 : 1, gap: spacing.sm }}>
              <Row>
                <Chip
                  label="بدون تکرار"
                  selected={f.recurrenceFrequency === null}
                  onPress={() => patch({ recurrenceFrequency: null })}
                />
                {RECURRENCE_FREQUENCIES.map((fr) => (
                  <Chip
                    key={fr}
                    label={FREQUENCY_LABELS[fr]}
                    selected={f.recurrenceFrequency === fr}
                    onPress={f.date === null ? undefined : () => patch({ recurrenceFrequency: fr })}
                  />
                ))}
              </Row>
              {f.recurrenceFrequency === 'weekly' ? (
                <Row>
                  {WEEKDAY_ORDER.map((d) => (
                    <Chip
                      key={d}
                      label={WEEKDAY_NAMES[d]}
                      selected={f.recurrenceWeekdays.includes(d)}
                      onPress={() => toggleWeekday(d)}
                    />
                  ))}
                </Row>
              ) : null}
              {f.recurrenceFrequency !== null ? (
                <View style={{ gap: spacing.xs }}>
                  <AppText variant="caption" muted>فاصله‌ی تکرار (هر چند {INTERVAL_UNITS[f.recurrenceFrequency]} یک‌بار)</AppText>
                  <Row>
                    {[1, 2, 3, 4].map((n) => (
                      <Chip
                        key={n}
                        label={toPersianDigits(n)}
                        selected={f.recurrenceInterval === n}
                        onPress={() => patch({ recurrenceInterval: n })}
                      />
                    ))}
                  </Row>
                </View>
              ) : null}
            </View>
          </Section>
        </Card>
      ) : null}

      {error ? <AppText color="danger">{error}</AppText> : null}

      <Button
        title={mode === 'create' ? 'ذخیره کار' : 'ذخیره تغییرات'}
        size="lg"
        fullWidth
        loading={submitting}
        onPress={() => onSubmit(f)}
      />

      <VoiceInputModal
        visible={voiceOpen}
        autoStart={voiceAutoStart}
        onUse={(text) => {
          patch({ title: (f.title.trim() ? `${f.title.trim()} ${text}` : text).slice(0, 200) });
          setVoiceOpen(false);
          setVoiceAutoStart(false);
        }}
        onClose={() => {
          setVoiceOpen(false);
          setVoiceAutoStart(false);
        }}
      />
      <JalaliDatePicker
        visible={datePickerOpen}
        value={f.date}
        onSelect={(d) => {
          patch({ date: startOfDay(d) });
          setDatePickerOpen(false);
        }}
        onClear={() => {
          patch({ date: null, time: null, reminderOffsets: [], recurrenceFrequency: null });
          setDatePickerOpen(false);
        }}
        onClose={() => setDatePickerOpen(false)}
      />
      <TimePicker
        visible={timePickerOpen}
        value={f.time}
        onConfirm={(h, m) => {
          setTime(h, m);
          setTimePickerOpen(false);
        }}
        onClose={() => setTimePickerOpen(false)}
      />
    </View>
  );
}
