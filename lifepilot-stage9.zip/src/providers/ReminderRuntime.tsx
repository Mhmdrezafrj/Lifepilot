import { useEffect, useRef } from 'react';
import { AppState, ToastAndroid } from 'react-native';
import * as Notifications from 'expo-notifications';
import { useRootNavigationState, useRouter } from 'expo-router';
import { setupNotifications } from '@/infrastructure/notifications/expoNotificationGateway';
import { parseReminderResponse, ReminderResponse } from '@/infrastructure/notifications/notificationResponse';
import { useDataStore } from '@/shared/state/dataStore';
import { useRepositories, useServices } from './DatabaseProvider';

/**
 * Keeps reminders alive and reacts to them. Renders nothing.
 * 1) On start and whenever the app returns to the foreground it rebuilds every reminder from the
 *    database (covers app updates, time zone changes, cleared alarms, and permission changes).
 *    After a phone restart Android re-creates scheduled notifications by itself.
 * 2) It handles taps on a notification and its "done" / "10 minutes later" buttons.
 */
export function ReminderRuntime() {
  const repos = useRepositories();
  const services = useServices();
  const router = useRouter();
  const navState = useRootNavigationState();
  const bump = useDataStore((s) => s.bump);
  const lastResponse = Notifications.useLastNotificationResponse();
  const handled = useRef<string | null>(null);

  useEffect(() => {
    const sync = async () => {
      try {
        await setupNotifications();
        const pending = await repos.tasks.list({ status: 'pending' });
        await services.scheduler.rescheduleAll(pending);
      } catch {
        /* reminders are best effort; the app keeps working */
      }
    };
    void sync();
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') void sync();
    });
    return () => sub.remove();
  }, [repos, services]);

  useEffect(() => {
    if (!lastResponse || !navState?.key) return;
    const id = `${lastResponse.notification.request.identifier}|${lastResponse.actionIdentifier}|${lastResponse.notification.date}`;
    if (handled.current === id) return;
    handled.current = id;

    const parsed = parseReminderResponse(
      lastResponse.actionIdentifier,
      lastResponse.notification.request.content.data,
      lastResponse.actionIdentifier === Notifications.DEFAULT_ACTION_IDENTIFIER,
    );
    if (!parsed) return;

    void (async () => {
      await recordEvent(parsed);
      try {
        if (parsed.kind === 'complete') {
          await services.tasks.complete(parsed.taskId);
          ToastAndroid.show('کار انجام شد ✅', ToastAndroid.SHORT);
        } else if (parsed.kind === 'snooze') {
          await services.tasks.snooze(parsed.taskId, parsed.minutes ?? 10);
          ToastAndroid.show('۱۰ دقیقه دیگر یادآوری می‌شود', ToastAndroid.SHORT);
        } else {
          router.push(`/task/${parsed.taskId}`);
        }
      } catch {
        ToastAndroid.show('این کار دیگر پیدا نشد یا قبلاً انجام شده است', ToastAndroid.SHORT);
      } finally {
        bump();
      }
    })();

    async function recordEvent(r: ReminderResponse): Promise<void> {
      try {
        const e = await repos.reminders.createEvent({
          reminderId: r.reminderId,
          taskId: r.taskId,
          scheduledAt: r.plannedFireAt ?? Date.now(),
          deliveryStatus: 'delivered',
        });
        await repos.reminders.markTriggered(e.id, r.plannedFireAt ?? Date.now(), 'delivered');
        await repos.reminders.markAcknowledged(
          e.id, Date.now(), r.kind === 'complete' ? 'completed' : r.kind === 'snooze' ? 'snoozed' : 'dismissed',
        );
      } catch {
        /* history is optional (the task or reminder may have been deleted) */
      }
    }
  }, [lastResponse, navState?.key, repos, services, router, bump]);

  return null;
}
