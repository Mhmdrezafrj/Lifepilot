import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { Reminder, Task } from '../../src/features/tasks/models/task';
import { DEFAULT_MAX_REPEATS, planReminders } from '../../src/infrastructure/notifications/reminderPlanner';

const NOW = new Date(2026, 10, 5, 12, 0).getTime();
const at = (d: number, h: number, m = 0) => new Date(2026, 10, d, h, m).getTime();
const rem = (over: Partial<Reminder>): Reminder => ({
  id: 'r1', taskId: 't1', offsetMinutes: 0, channel: 'notification', enabled: true,
  repeatIntervalMinutes: null, maxRepeats: null, ...over,
});
const task = (over: Partial<Task>): Task => ({
  id: 't1', title: 'جلسه', description: null, dueAt: at(5, 18), hasTime: true, priority: 'medium', categoryId: null,
  status: 'pending', snoozedUntil: null, createdAt: 0, updatedAt: 0, completedAt: null, recurrenceId: null,
  tags: [], checklist: [], reminders: [rem({})], recurrence: null, ...over,
});

describe('reminder planner', () => {
  it('fires at due time minus the offset', () => {
    const plan = planReminders(task({ reminders: [rem({ offsetMinutes: 30 })] }), NOW);
    assert.equal(plan.length, 1);
    assert.equal(plan[0].fireAt, at(5, 17, 30));
    assert.equal(plan[0].taskTitle, 'جلسه');
    assert.equal(plan[0].repeatIndex, 0);
    assert.equal(plan[0].id, 'r1:0');
    assert.equal(plan[0].dueAt, at(5, 18));
    assert.equal(plan[0].offsetMinutes, 30);
  });

  it('plans nothing for completed tasks, undated tasks, or date-only tasks', () => {
    assert.deepEqual(planReminders(task({ status: 'completed' }), NOW), []);
    assert.deepEqual(planReminders(task({ dueAt: null }), NOW), []);
    assert.deepEqual(planReminders(task({ hasTime: false }), NOW), []);
  });

  it('skips disabled reminders and moments that are not in the future', () => {
    assert.deepEqual(planReminders(task({ reminders: [rem({ enabled: false })] }), NOW), []);
    assert.deepEqual(planReminders(task({ dueAt: at(5, 11), reminders: [rem({})] }), NOW), []);
    assert.deepEqual(planReminders(task({ dueAt: NOW, reminders: [rem({})] }), NOW), []); // exactly now is not future
  });

  it('keeps only the future part of an offset reminder', () => {
    // due 18:00; 7h before is 11:00 (past), 1h before is 17:00 (future)
    const plan = planReminders(task({ reminders: [rem({ id: 'a', offsetMinutes: 420 }), rem({ id: 'b', offsetMinutes: 60 })] }), NOW);
    assert.deepEqual(plan.map((p) => p.reminderId), ['b']);
  });

  it('repeats every interval, limited by maxRepeats', () => {
    const plan = planReminders(task({ reminders: [rem({ repeatIntervalMinutes: 10, maxRepeats: 3 })] }), NOW);
    assert.deepEqual(plan.map((p) => p.fireAt), [at(5, 18, 0), at(5, 18, 10), at(5, 18, 20), at(5, 18, 30)]);
    assert.deepEqual(plan.map((p) => p.repeatIndex), [0, 1, 2, 3]);
  });

  it('uses a default repeat limit when only an interval is set', () => {
    const plan = planReminders(task({ reminders: [rem({ repeatIntervalMinutes: 5 })] }), NOW);
    assert.equal(plan.length, DEFAULT_MAX_REPEATS + 1);
  });

  it('drops repeats that are already in the past', () => {
    // first fire 11:50 (past), repeats at 12:00 (not future), 12:10, 12:20
    const plan = planReminders(task({ dueAt: at(5, 11, 50), reminders: [rem({ repeatIntervalMinutes: 10, maxRepeats: 3 })] }), NOW);
    assert.deepEqual(plan.map((p) => p.fireAt), [at(5, 12, 10), at(5, 12, 20)]);
  });

  it('sorts all reminders by time and keeps the channel', () => {
    const plan = planReminders(
      task({ reminders: [rem({ id: 'a', offsetMinutes: 0, channel: 'alarm' }), rem({ id: 'b', offsetMinutes: 60 })] }), NOW);
    assert.deepEqual(plan.map((p) => [p.reminderId, p.channel]), [['b', 'notification'], ['a', 'alarm']]);
  });
});
