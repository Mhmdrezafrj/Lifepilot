import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  ACTION_COMPLETE, ACTION_SNOOZE, SNOOZE_MINUTES, parseReminderResponse,
} from '../../src/infrastructure/notifications/notificationResponse';

const data = { taskId: 't1', reminderId: 'r1', plannedFireAt: 123 };

describe('notification responses', () => {
  it('a tap on the notification opens the task', () => {
    assert.deepEqual(parseReminderResponse('default', data, true), {
      kind: 'open', taskId: 't1', reminderId: 'r1', plannedFireAt: 123,
    });
  });

  it('the done button completes the task', () => {
    assert.equal(parseReminderResponse(ACTION_COMPLETE, data, false)?.kind, 'complete');
  });

  it('the snooze button snoozes for 10 minutes', () => {
    const r = parseReminderResponse(ACTION_SNOOZE, data, false);
    assert.equal(r?.kind, 'snooze');
    assert.equal(r?.minutes, SNOOZE_MINUTES);
    assert.equal(SNOOZE_MINUTES, 10);
  });

  it('ignores unknown actions and malformed data', () => {
    assert.equal(parseReminderResponse('other', data, false), null);
    assert.equal(parseReminderResponse('default', null, true), null);
    assert.equal(parseReminderResponse('default', 'x', true), null);
    assert.equal(parseReminderResponse('default', {}, true), null);
    assert.equal(parseReminderResponse('default', { taskId: '' }, true), null);
    assert.equal(parseReminderResponse('default', { taskId: 5 }, true), null);
  });

  it('tolerates missing optional fields', () => {
    assert.deepEqual(parseReminderResponse(ACTION_COMPLETE, { taskId: 't' }, false), {
      kind: 'complete', taskId: 't', reminderId: null, plannedFireAt: null,
    });
  });
});
