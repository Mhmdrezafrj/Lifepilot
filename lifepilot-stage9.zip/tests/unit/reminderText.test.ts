import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { buildReminderContent, formatOffset } from '../../src/infrastructure/notifications/reminderText';
import type { PlannedReminder } from '../../src/infrastructure/notifications/types';

const due = new Date(2026, 10, 5, 18, 30).getTime();
const planned = (over: Partial<PlannedReminder>): PlannedReminder => ({
  id: 'r:0', reminderId: 'r', taskId: 't', taskTitle: 'جلسه تیم', fireAt: due, channel: 'notification',
  repeatIndex: 0, dueAt: due, offsetMinutes: 0, ...over,
});

describe('reminder message', () => {
  it('formats offsets in Persian', () => {
    assert.equal(formatOffset(10), '۱۰ دقیقه');
    assert.equal(formatOffset(60), '۱ ساعت');
    assert.equal(formatOffset(90), '۱ ساعت و ۳۰ دقیقه');
    assert.equal(formatOffset(120), '۲ ساعت');
    assert.equal(formatOffset(1440), '۱ روز');
    assert.equal(formatOffset(2880), '۲ روز');
  });

  it('uses the task title as the notification title', () => {
    assert.equal(buildReminderContent(planned({})).title, 'جلسه تیم');
  });

  it('says it is time now for an on-time reminder', () => {
    assert.equal(buildReminderContent(planned({})).body, 'الان موعد انجام این کار است (ساعت ۱۸:۳۰)');
  });

  it('says how long is left for an early reminder', () => {
    assert.equal(buildReminderContent(planned({ offsetMinutes: 30 })).body, '۳۰ دقیقه تا موعد (ساعت ۱۸:۳۰)');
    assert.equal(buildReminderContent(planned({ offsetMinutes: 1440 })).body, '۱ روز تا موعد (ساعت ۱۸:۳۰)');
  });

  it('marks repeated reminders', () => {
    assert.match(buildReminderContent(planned({ repeatIndex: 2 })).body, /^یادآوری مجدد/);
  });
});
