# LifePilot architecture notes

## Data layer (stage 3)
- SQLite is the single source of truth; the app works fully offline.
- `DbClient` (src/core/database/connection/types.ts) is a tiny async interface.
  expo-sqlite implements it in the app, node:sqlite implements it in tests, so the
  same SQL and repositories are tested without a phone.
- Schema changes are migrations (src/core/database/migrations), versioned with
  `PRAGMA user_version`. Each migration runs in a transaction. Never edit an old
  migration after release; add a new one.
- UI code never writes SQL. Screens use repositories/services through hooks.
- All timestamps are UTC epoch milliseconds. "Overdue" is derived from `due_at`,
  not stored, and overdue tasks are never deleted automatically.
- IDs are random UUIDs (strings). Booleans are stored as 0/1.
- Input is validated with Zod inside the repositories, so invalid data cannot reach the DB.
- Tables `reminder_events` and `behavior_events` exist for later phases and are not written yet.

## Task management (stage 4)
- `taskService` (src/features/tasks/services) owns the rules: complete / reopen /
  snooze / reschedule / duplicate / delete. Status is stored as `pending` or `completed` only.
- Recurring tasks: completing one creates the next occurrence as a new task
  (details copied, checklist reset). Occurrences already in the past are skipped.
  `maxOccurrences` counts down on each generated task; `endsAt` stops the series.
  Monthly and yearly rules use the Jalali calendar (day is clamped to the month length).
- A task with a recurrence must have a date.
- Jalali calendar code lives in src/core/calendar (33-year leap rule, cross-checked
  against ICU for years 1300-1500 in tests). No external calendar dependency.
- After every successful change `useTaskActions()` bumps a tiny zustand store
  (`useDataStore.version`); `useTasks()` / `useCategories()` reload when it changes.
- Reminders are stored with tasks but nothing is delivered yet (notification phase).

## Dashboard and categories (stage 5)
- Dashboard numbers come from pure functions in `features/dashboard/services/dashboardStats.ts`
  (unit-tested): today = tasks due today (any status); remaining = pending among them;
  overdue = all pending overdue tasks from any day.
- "Next task" = earliest pending, non-overdue task; a date-only task due today counts from "now".
- The greeting name is stored locally in `app_settings` (`user_name`).
- Deleting a category never deletes tasks: they move to another category or become uncategorized.
  Category names must be unique (case/space-insensitive).

## Calendar (stage 6)
- Pure helpers in `core/calendar/grid.ts` (month rows, weeks Saturday-Friday, half-open day/week/month ranges)
  are shared by the date picker and the calendar screen, and are unit-tested.
- The calendar loads only the tasks of the visible range (`dueFrom`/`dueTo`) and groups them by local day
  (`features/calendar/services/dayIndicators.ts`). Tasks without a date do not appear in the calendar.
- Month view shows up to 3 dots per day (pending by priority, then completed); selecting a day lists its tasks.
- Creating a task from the calendar passes `?date=<ms>` to the task editor.

## Voice input and settings (stage 7)
- Voice input uses the real Android SpeechRecognizer through `expo-speech-recognition` (Persian, `fa-IR`).
  It listens only after the user taps the microphone and stops when the sheet closes. Recognised text is
  editable, and typing is always available. Persian recognition uses the phone's Google speech service and
  may need internet; the UI says so. Android permission: RECORD_AUDIO.
- The voice state machine is a pure reducer (`features/voice/services/voiceState.ts`, unit-tested); the
  native module is only touched in `useVoiceInput`.
- Appearance (mode, accent, font size), the default reminder and the user name are stored in `app_settings`
  (keys in `features/settings/services/settingsKeys.ts`). `DatabaseProvider` restores them before the first screen.
- Backup/restore and notification settings are shown as "coming soon" and do nothing.
- Natural-language parsing of the dictated text is not implemented; the transcript simply becomes the task title.

## Reminders (stages 8-9)
- `ReminderScheduler`, `NotificationGateway`, `AlarmGateway` and a persistent `ReminderRepository` are tested with fake gateways.
- Real delivery: `expoNotificationGateway.ts` (expo-notifications, Android). The task service calls the scheduler on every change.
- Details, limits and next steps: docs/NOTIFICATIONS.md.

## Folder note
Routes live in the root `app/` folder (Expo Router). Do not create `src/app/`, it would conflict.
