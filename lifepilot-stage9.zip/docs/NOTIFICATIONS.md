# Reminders

## What works (stage 9)
- A task with a date, a time, and one or more reminders gets real Android notifications, scheduled with
  `expo-notifications` (AlarmManager underneath). They show with sound and vibration on the high-importance
  channel "یادآوری کارها", even if the app is closed and without internet.
- Scheduled notifications survive a phone restart (the library re-creates them on boot).
- On every app start and whenever the app returns to the foreground, `ReminderRuntime` rebuilds all reminders
  from the database (covers updates, time zone changes, cleared alarms). The database is the source of truth.
- Notification buttons: "انجام شد" and "۱۰ دقیقه بعد". Tapping them opens the app, which performs the action;
  tapping the notification itself opens the task. (Buttons open the app so the action is never lost.)
- Settings → اعلان‌ها: permission status, enable button, a real test notification (10 seconds), battery guidance.
- Permissions declared: POST_NOTIFICATIONS, RECEIVE_BOOT_COMPLETED, VIBRATE, SCHEDULE_EXACT_ALARM, USE_EXACT_ALARM.

## Honest limits
- Exact timing: with USE_EXACT_ALARM (Android 13+) alarms are exact. On Android 12 the user may need to allow
  "Alarms & reminders" for the app; without it Android may deliver a little late.
- Phones with aggressive battery managers (Xiaomi/MIUI/HyperOS, Huawei, Oppo, Vivo) may stop a closed app.
  The user must enable Autostart, set battery to "No restrictions", and lock the app in recents. Settings explains this.
- Not implemented: a loud, full-screen, alarm-clock style ringing (AlarmGateway). Alarm-channel reminders fall back to
  normal notifications. Repeating reminders are planned (up to the repeat limit) but the form does not expose repeat settings yet.
- Delivery cannot be tested in CI or in unit tests; it must be checked on a real phone (use the test notification).

## Code map
- `infrastructure/notifications/types.ts` interfaces, `reminderPlanner.ts` (pure plan), `reminderScheduler.ts` (routes to gateways),
  `reminderText.ts` (message), `notificationResponse.ts` (parse taps), `expoNotificationGateway.ts` (the real gateway).
- `providers/ReminderRuntime.tsx` (sync + responses), `features/reminders/hooks/useNotificationPermission.ts`.
- `reminder_events` records responses (opened / completed / snoozed).

## Next
Full-screen alarm (Kotlin AlarmGateway with a full-screen intent), repeat settings in the form, snooze/complete from the
notification without opening the app (needs a native receiver).
